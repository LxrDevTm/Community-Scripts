

local LootAnimations = {
    ['right_bag'] = {
        scene = true,
        dict = 'anim@heists@ornate_bank@grab_cash',
        anims = {
            { 'intro', 'bag_intro' },
            { 'grab',  'bag_grab', 'cart_cash_dissapear' },
            { 'exit',  'bag_exit' }
        }
    },
    ['front_bag'] = {
        scene = true,
        dict = 'anim@scripted@player@mission@tun_table_grab@cash@',
        anims = {
            { 'enter', 'enter_bag' },
            { 'grab',  'grab_bag', 'cart_cash_dissapear' },
            { 'exit',  'exit_bag' }
        }
    },
    ['grab_cash'] = {
        scene = true,
        dict = 'anim@scripted@heist@ig1_table_grab@cash@male@',
        anims = {
            { 'enter', 'enter_bag' },
            { 'grab',  'grab_bag', 'grab_cash' },
            { 'exit',  'exit_bag' },
        }
    },
    ['tamper'] = {
        scene = false,
        dict = 'mp_arresting',
        anim = 'a_uncuff',
    },
    ['search'] = {
        scene = false,
        dict = 'missexile3',
        anim = 'ex03_dingy_search_case_base_michael',
    },
}

--- StopTabletAnim()
--- @return nil
--- @description This function stops the tablet animation and deletes the tablet object if it exists.
function StopTabletAnim()
    if IsEntityPlayingAnim(PlayerPedId(), "amb@code_human_in_bus_passenger_idles@female@tablet@idle_a", "idle_a", 3) then
        StopAnimTask(PlayerPedId(), "amb@code_human_in_bus_passenger_idles@female@tablet@idle_a", "idle_a", 8.0)
    end

    if TabletModel ~= nil and DoesEntityExist(TabletModel) then
        DeleteObject(TabletModel)
        TabletModel = nil
    end
end

--- StartTabletAnim()
--- @return nil
--- @description This function plays an animation for using a tablet and creates a tablet object.
function StartTabletAnim()
    RequestAnimDict("amb@code_human_in_bus_passenger_idles@female@tablet@idle_a")
    while not HasAnimDictLoaded("amb@code_human_in_bus_passenger_idles@female@tablet@idle_a") do
        Citizen.Wait(0)
    end
    TaskPlayAnim(PlayerPedId(), "amb@code_human_in_bus_passenger_idles@female@tablet@idle_a", "idle_a", 8.0, -8.0, -1, 50,
        0, false, false, false)
    TabletModel = CreateObject(GetHashKey("prop_cs_tablet"), 0, 0, 0, true, true, true)
    AttachEntityToEntity(TabletModel, PlayerPedId(), GetPedBoneIndex(PlayerPedId(), 28422), -0.05, 0.0, 0.0, 0.0, 0.0,
        0.0, true, true, false, true, 1, true)
end

--- StartEnterAnim()
--- @return nil
--- @description This function plays an animation for entering a vehicle or location.
function StartEnterAnim()
    if HandIsBusy then return end
    RequestAnimDict("anim@heists@keycard@")
    while not HasAnimDictLoaded("anim@heists@keycard@") do
        Citizen.Wait(0)
    end
    TaskPlayAnim(PlayerPedId(), 'anim@heists@keycard@', 'exit', 5.0, 1.0, -1, 16, 0, false, false, false)
    Wait(400)
    ClearPedTasks(PlayerPedId())
end

--- DrawText3Ds()
--- @param x number: The x-coordinate for the text.
--- @param y number: The y-coordinate for the text.
--- @param z number: The z-coordinate for the text.
--- @param text string: The text to be displayed.
--- @return nil
--- @description This function draws 3D text at the specified coordinates in the game world.
function DrawText3Ds(x, y, z, text)
    SetTextScale(0.35, 0.35)
    SetTextFont(4)
    SetTextProportional(true)
    SetTextColour(255, 255, 255, 215)
    BeginTextCommandDisplayText('STRING')
    SetTextCentre(true)
    AddTextComponentSubstringPlayerName(text)
    SetDrawOrigin(x, y, z, 0)
    EndTextCommandDisplayText(0.0, 0.0)
    local factor = (string.len(text)) / 370
    DrawRect(0.0, 0.0 + 0.0125, 0.017 + factor, 0.03, 0, 0, 0, 75)
    ClearDrawOrigin()
end

--- CreateBlipForRobbery()
--- @param self table: The robbery object containing coordinates and blip properties.
--- @return number: The blip ID for the created blip.
--- @description This function creates a blip on the map for the robbery location.
function CreateBlipForRobbery(self)
    local blip = AddBlipForCoord(self.coords.x, self.coords.y, self.coords.z)
    SetBlipSprite(blip, self.sprite)
    SetBlipColour(blip, self.color)
    SetBlipScale(blip, self.scale)
    SetBlipAsShortRange(blip, true)
    SetBlipRoute(blip, true)
    SetBlipRouteColour(blip, self.color)
    BeginTextCommandSetBlipName("STRING")
    AddTextComponentString(self.name)
    EndTextCommandSetBlipName(blip)

    return blip
end

--- CreateDUI()
--- @return number: The Dui object ID and Dui handle ID.
--- @description This function creates a Dui object and handle, and sets up a texture replacement.
function CreateDUI()
    local duiObject = CreateDui("nui://0r-houserobbery/web/build/index.html", 256, 256)
    local DuiHandle = GetDuiHandle(duiObject)

    local txd = CreateRuntimeTxd('dui_texture')
    CreateRuntimeTextureFromDuiHandle(txd, 'dui_handle', DuiHandle)
    AddReplaceTexture('w_am_hackdevice_m32', 'script_rt_w_am_hackdevice_m32', 'dui_texture', 'dui_handle')

    local retval = IsDuiAvailable(duiObject)

    while not retval do
        Wait(100)
        retval = IsDuiAvailable(duiObject)
    end

    return duiObject, DuiHandle
end

--- DeleteDUI()
--- @param duiObject number: The Dui object ID to be deleted.
--- @param DuiHandle number: The Dui handle ID to be deleted.
--- @return nil
--- @description This function deletes the Dui object and handle, and removes the texture replacement.
function DeleteDUI(duiObject, DuiHandle)
    RemoveReplaceTexture('w_am_hackdevice_m32', 'script_rt_w_am_hackdevice_m32')
    DestroyDui(duiObject)
end

--- RemoveBlipForRobbery()
--- @param blip number: The blip ID to be removed.
--- @return boolean: True if the blip was removed, false otherwise.
--- @description This function removes a blip from the map if it exists.
function RemoveBlipForRobbery(blip)
    if DoesBlipExist(blip) then
        SetBlipRoute(blip, false)
        RemoveBlip(blip)
        return true
    end

    return false
end

--- CollectLoot()
--- @param homeIndex number: The index of the home.
--- @param propId number: The ID of the prop.
--- @param loot table: The loot object containing ID and type.
--- @param object number: The object ID to be collected.
--- @return nil
--- @description This function handles the collection of loot during a robbery.
function CollectLoot(homeIndex, propId, loot, object, cb)
    if HandIsBusy then
        cb(false)
        return
    end

    local ped = PlayerPedId()
    FreezeEntityPosition(ped, true)

    TriggerServerEvent('0r-houserobbery:server:setLootStateBusy', homeIndex, loot.id, true)

    if loot.type == 'safe' then
        local animData = LootAnimations['tamper']

        lib.requestAnimDict(animData.dict)

        TaskPlayAnim(ped, animData.dict, animData.anim, 8.0, -8.0, -1, 49, 0, false, false, false)
        Wait(5750)

        lib.requestModel(loot.prop.model)

        local retval = GetOffsetFromEntityInWorldCoords(object, 0.2, 0.0, 0.1)

       local safeObject = CreateObject(loot.prop.model, retval.x, retval.y, retval.z, true, true, false)

        SetEntityAsMissionEntity(safeObject, true, true)
        SetModelAsNoLongerNeeded(loot.prop.model)

        local safeNetId = ObjToNet(safeObject)
        while not NetworkDoesNetworkIdExist(safeNetId) do
            NetworkRegisterEntityAsNetworked(safeObject)
            safeNetId = ObjToNet(safeObject)
            Wait(10)
        end

        SafeObject = {
            object = SafeObject,
            netId = safeNetId,
        }

        SetEntityRotation(safeObject, loot.prop.rotation.x, loot.prop.rotation.y, loot.prop.rotation.z)
        FreezeEntityPosition(safeObject, true)

        retval = GetOffsetFromEntityInWorldCoords(object, 0.3, -0.4, 0.0)
        SetEntityRotation(object, 0.0, 0.0, GetEntityHeading(object) + 90.0)
        SetEntityCoords(object, retval.x, retval.y, retval.z)

        ClearPedTasksImmediately(ped)

        retval = GetOffsetFromEntityInWorldCoords(safeObject, -0.5, -0.7, 0.0)

        SetEntityCoordsNoOffset(ped, retval.x, retval.y, retval.z)
        SetEntityHeading(ped, GetEntityHeading(safeObject))
        Wait(3000)

        TaskStartScenarioInPlace(ped, 'WORLD_HUMAN_WELDING', -1, -1)
        Wait(10000)

        ClearPedTasksImmediately(ped)
    else
        local animData = LootAnimations[loot.animation.type]

        lib.requestAnimDict(animData.dict)

        local pos = GetEntityCoords(ped)

        if (loot.type == 'prop') then
            local success = lib.skillCheck(Config.LootSettings.difficulty, Config.LootSettings.keys)

            if not (success) then
                TriggerServerEvent('0r-houserobbery:server:setLootStateBusy', homeIndex, loot.id, false)
                SecondHandIsBusy = false
                FreezeEntityPosition(ped, false)
                cb(false)
                return
            end
        end

        if animData.scene then
            lib.requestModel('hei_p_m_bag_var22_arm_s')

            local sceneObject = nil
            local scenePos = nil
            local sceneRot = nil

            if (loot.animation.type == 'grab_cash') then
                sceneObject = GetClosestObjectOfType(pos, 2.0, GetHashKey(loot.prop.model), 0, 0, 0)
                NetworkRequestControlOfEntity(sceneObject)
                scenePos = GetEntityCoords(sceneObject)
                sceneRot = GetEntityRotation(sceneObject)
            else
                scenePos = GetOffsetFromEntityInWorldCoords(object, loot.animation.coords.x,
                    loot.animation.coords.y, loot.animation.coords.z)
                sceneRot = GetEntityRotation(ped)
            end

            SetPedComponentVariation(ped, 5, 0, 0, 0)
            local bag = CreateObject(GetHashKey("hei_p_m_bag_var22_arm_s"), pos, true, true, false)

            local scenes = {}

            for i = 1, #animData.anims do
                scenes[i] = NetworkCreateSynchronisedScene(scenePos, sceneRot, 2, true, false, 1065353216, 0, 1.3)
                NetworkAddPedToSynchronisedScene(ped, scenes[i], animData.dict, animData.anims[i][1], 1.5, -4.0, 1, 16,
                    1148846080, 0)
                NetworkAddEntityToSynchronisedScene(bag, scenes[i], animData.dict, animData.anims[i][2], 4.0, -8.0, 1)
                if i == 2 and loot.animation.type == 'grab_cash' then
                    NetworkAddEntityToSynchronisedScene(sceneObject, scenes[i], animData.dict, animData.anims[i][3], 1.0,
                        -1.0,
                        1148846080)
                end
            end

            NetworkStartSynchronisedScene(scenes[1])
            if loot.animation.type == 'grab_cash' then
                Wait(1250)
            else
                Wait(2000)
            end

            NetworkStartSynchronisedScene(scenes[2])
            if loot.animation.type == 'grab_cash' then
                Wait(10500)
            else
                Wait(2000)
            end

            NetworkStartSynchronisedScene(scenes[3])
            if loot.animation.type == 'grab_cash' then
                Wait(GetAnimDuration(animData.dict, animData.anims[3][1]) * 1000)
            else
                Wait(2000)
            end

            DeleteObject(bag)

            local hash = GetEntityModel(ped)
            if hash == `mp_m_freemode_01` then
                SetPedComponentVariation(ped, 5, Config.HeistBag.male, 0, 0)
            else
                SetPedComponentVariation(ped, 5, Config.HeistBag.female, 0, 0)
            end
        else
            TaskPlayAnim(ped, animData.dict, animData.anim, 8.0, -8.0, -1, 49, 0, false, false, false)
            Wait(5750)
        end

        ClearPedTasks(ped)
        RemoveAnimDict(animData.dict)

        if (loot.type == 'prop') then
            SetEntityDrawOutline(object, false)
            lib.requestAnimDict(loot.props.hand.dict)
            TaskPlayAnim(ped, loot.props.hand.dict, loot.props.hand.anim, 8.0, -8.0, -1, 50, 0, false, false, false)

            while IsEntityPlayingAnim(ped, loot.props.hand.dict, loot.props.hand.anim, 3) do
                Wait(0)
            end

            lib.requestModel(loot.props.hand.model)

            local obj = CreateObject(loot.props.hand.model, 0, 0, 0, true, true, false)
            SetEntityAsMissionEntity(obj, true, true)
            SetModelAsNoLongerNeeded(loot.props.hand.model)

            AttachEntityToEntity(obj, ped, GetPedBoneIndex(ped, 28422), loot.props.hand.coords.x, loot.props.hand.coords.y, loot.props.hand.coords.z, loot.props.hand.rotation.x, loot.props.hand.rotation.y, loot.props.hand.rotation.z, true, true, false, true, 1, true)

            local objNet = ObjToNet(obj)

            while not NetworkDoesNetworkIdExist(objNet) do
                NetworkRegisterEntityAsNetworked(obj)
                objNet = ObjToNet(obj)
                Wait(10)
            end

            HandObjects[loot.props.hand.model .. '_' .. loot.id] = {
                object = obj,
                netId = objNet,
            }

            TriggerServerEvent('0r-houserobbery:server:syncRobberyData', {
                action = 'handObject',
                data = {
                    objects = HandObjects
                }
            })

            HandIsBusy = true

            CreateThread(function()
                while HandIsBusy do
                    Wait(0)

                    if not (IsEntityPlayingAnim(ped, loot.props.hand.dict, loot.props.hand.anim, 3)) then
                        TaskPlayAnim(ped, loot.props.hand.dict, loot.props.hand.anim, 8.0, -8.0, -1, 50, 0, false, false,
                            false)
                    end

                    if not Inside then
                        local veh = NetToVeh(RoomData.settings.heistCar.netId)

                        if (DoesEntityExist(veh)) then
                            local pedPos = GetEntityCoords(ped)
                            local vehPos = GetEntityCoords(veh)
                            local dist = #(pedPos - vehPos)

                            if dist < 2.0 then
                                lib.requestModel(loot.props.vehicle.model)

                                local vehObject = CreateObject(GetHashKey(loot.props.vehicle.model), 0, 0, 0, true, true, false)
                                SetEntityAsMissionEntity(vehObject, true, true)
                                SetModelAsNoLongerNeeded(loot.props.vehicle.model)
                                local vehObjectCoords = GetOffsetFromEntityInWorldCoords(vehObject, loot.props.vehicle.coords.x, loot.props.vehicle.coords.y, loot.props.vehicle.coords.z)

                                local boneIndex = GetEntityBoneIndexByName(veh, 'chassis')
                                AttachEntityToEntity(vehObject, veh, boneIndex, vehObjectCoords.x, vehObjectCoords.y, vehObjectCoords.z, loot.props.vehicle.rotation.x, loot.props.vehicle.rotation.y, loot.props.vehicle.rotation.z, true, true, false, true, 1, true)

                                HandIsBusy = false
                                StopAnimTask(ped, loot.props.hand.dict, loot.props.hand.anim, 8.0)

                                local objectKey = loot.props.hand.model .. '_' .. loot.id
                                local existing = HandObjects[objectKey]

                                if existing then
                                    if existing.netId and NetworkDoesEntityExistWithNetworkId(existing.netId) then
                                        local netObj = NetToObj(existing.netId)
                                        if DoesEntityExist(netObj) then
                                            SetEntityAsMissionEntity(netObj, true, true)
                                            DeleteEntity(netObj)
                                        end
                                    end
                                end

                                local vehObjNet = ObjToNet(vehObject)
                                while not NetworkDoesNetworkIdExist(vehObjNet) do
                                    NetworkRegisterEntityAsNetworked(vehObject)
                                    vehObjNet = ObjToNet(vehObject)
                                    Wait(10)
                                end

                                HandObjects[loot.props.vehicle.model .. '_' .. loot.id] = {
                                    object = vehObject,
                                    netId = vehObjNet,
                                }

                                TriggerServerEvent('0r-houserobbery:server:syncRobberyData', {
                                    action = 'handObject',
                                    data = {
                                        objects = HandObjects
                                    }
                                })
                                break
                            end
                        end
                    end
                end
            end)
        end
    end

    cb(true)
    TriggerServerEvent('0r-houserobbery:server:setLootStateBusy', homeIndex, loot.id, false)
    TriggerServerEvent('0r-houserobbery:server:collectLoot', homeIndex, loot.id)
    TriggerServerEvent('0r-houserobbery:server:setLootUsed', homeIndex, loot.id, propId)
end

--- CheckDistance()
--- @return nil
--- @description This function checks the distance between the player and the robbery location.
function CheckDistance()
    CreateThread(function()
        while not DeliveredVehicle do
            if RoomData and RoomData.settings and RoomData.settings.heistHouse and RoomData.settings.startedRobbery then
                local ped = PlayerPedId()
                local pos = GetEntityCoords(ped)
                local house = Config.RobberyLocation[RoomData.settings.heistHouse]
                local dist = #(pos - vector3(house.coords.enter.x, house.coords.enter.y, house.coords.enter.z))

                if dist > 75.0 and not delivered then
                    local serverId = cache.serverId

                    for k, v in pairs(RoomData.players) do
                        if v.source == serverId and v.leader and not Inside then
                            DeliveredVehicle = true
                            TriggerServerEvent('0r-houserobbery:server:setHouseState', RoomData.settings.heistHouse, false)
                            if (RoomData.settings.heistCar.type == 'randomCar') then
                                TriggerEvent('0r-houserobbery:client:deliverRobberyVehicle')
                            else
                                TriggerEvent('0r-houserobbery:client:resetRobbery')
                            end
                            break
                        end
                    end
                end
                if DeliveredVehicle then
                    break
                end
            else
                DeliveredVehicle = true
                break
            end

            Wait(1000)
        end
    end)
end

--- CheckDispatch()
--- @return nil
--- @description This function checks the dispatch alert for police and sends an alert if necessary.
function CheckDispatch()
    local chance = math.random(1, 100)
    if Config.PoliceAlert >= chance then
        local enterCoords = vector3(Config.RobberyLocation[RoomData.settings.heistHouse]['coords']['enter']['x'], Config.RobberyLocation[RoomData.settings.heistHouse]['coords']['enter']['y'], Config.RobberyLocation[RoomData.settings.heistHouse]['coords']['enter']['z'])
        Dispatch.SendAlert({
            coords = enterCoords,
            title = Locales[Config.Locale]['Lua']['dispatch_title'],
            message = Locales[Config.Locale]['Lua']['dispatch_message'],
            vehicle = nil,
            code = '10-12',
            plate = nil,
            time = 10000,
            jobs = {
                'police'
            },
            blipData = {
                sprite = 60,
                scale = 1.0,
                color = 1,
            },
        })
    end
end

function DrawText3Ds(x, y, z, text)
    SetTextScale(0.35, 0.35)
    SetTextFont(4)
    SetTextProportional(1)
    SetTextColour(255, 255, 255, 215)
    BeginTextCommandDisplayText('STRING')
    SetTextCentre(true)
    AddTextComponentSubstringPlayerName(text)
    SetDrawOrigin(x, y, z, 0)
    EndTextCommandDisplayText(0.0, 0.0)
    local factor = (string.len(text)) / 370
    DrawRect(0.0, 0.0 + 0.0125, 0.017 + factor, 0.03, 0, 0, 0, 75)
    ClearDrawOrigin()
end

local showedText = false
function ShowTextUI(text)
    if not showedText then
        showedText = true
        lib.showTextUI(text, {
            position = 'right-center',
        })
    end
end

function HideTextUI()
    if showedText then
        showedText = false
        lib.hideTextUI()
    end
end

CreateThread(function()
    while true do
        local ped = PlayerPedId()
        local pos = GetEntityCoords(ped)

        local sleep = 1000

        if not (Inside) then
            for k, _ in pairs(Config.RobberyLocation) do
                local dist = #(pos - vector3(Config.RobberyLocation[k]['coords']['enter']['x'], Config.RobberyLocation[k]['coords']['enter']['y'], Config.RobberyLocation[k]['coords']['enter']['z']))

                if (Config.RobberyLocation[k]['opened']) then
                    if (dist < 2.5) then
                        sleep = 0
                        ShowTextUI('[E] ' .. Locales[Config.Locale]['Lua']['enter_house'])

                        if (IsControlJustPressed(0, 38)) then
                            HideTextUI()
                            EnterHouse(k)
                        end
                    else
                        HideTextUI()
                    end
                end
            end
        end

        if (Inside) then
            Wait(1000)
        end

        Wait(sleep)
    end
end)

function LeaveTextControl()
    CreateThread(function()
        local textUIActive = false

        while Inside do
            local ped = PlayerPedId()
            local pos = GetEntityCoords(ped)

            if (Inside) then
                if #(pos - vector3(ExitCoords.x, ExitCoords.y, ExitCoords.z)) < 1.5 then
                    if not textUIActive then
                        textUIActive = true
                        ShowTextUI('[E] ' .. Locales[Config.Locale]['Lua']['leave_house'])
                    end

                    if (IsControlJustPressed(0, 38)) then
                        HideTextUI()
                        LeaveHouse(EnterCoords)
                        textUIActive = false
                        break
                    end
                else
                    if textUIActive then
                        HideTextUI()
                        textUIActive = false
                    end
                end
            end

            if not (Inside) then
                break
            end

            Wait(3)
        end
    end)
end

function ShowTasks(process)
    if process == 'take_vehicle' then
        Wait(1000)
        Tasks = {
            time = 60 * Config.ProcessTimes[process],
            message = Locales[Config.Locale]['Lua']['take_vehicle_task_message'],
            list = {
                {
                    id = 'take_vehicle',
                    message = Locales[Config.Locale]['Lua']['take_vehicle_task_list'],
                    completed = false,
                },
            }
        }
    elseif process == 'hack_keypad' then
        Tasks = {
            time = 60 * Config.ProcessTimes[process],
            message = Locales[Config.Locale]['Lua']['hack_keypad_task_message'],
            list = {
                {
                    id = 'hack_keypad',
                    message = Locales[Config.Locale]['Lua']['hack_keypad_task_list'],
                    completed = false,
                },
            }
        }
    elseif process == 'robbery_house' then
        Tasks = {
            time = 60 * Config.ProcessTimes[process],
            message = Locales[Config.Locale]['Lua']['robbery_house_task_message'],
            list = {}
        }

        Tasks.list[1] = {
            id = 'search_chest',
            message = Locales[Config.Locale]['Lua']['search_chest_task'],
            completed = false,
        }

        Tasks.list[2] = {
            id = 'take_loot',
            message = Locales[Config.Locale]['Lua']['take_loot_task'],
            completed = false,
        }

        Tasks.list[3] = {
            id = 'take_cash',
            message = Locales[Config.Locale]['Lua']['take_cash_task'],
            completed = false,
        }

        Tasks.list[4] = {
            id = 'search_safe',
            message = Locales[Config.Locale]['Lua']['search_safe_task'],
            completed = false,
        }
    elseif process == 'deliver_vehicle' then
        Tasks = {
            time = 60 * Config.ProcessTimes[process],
            message = Locales[Config.Locale]['Lua']['deliver_vehicle_task_message'],
            list = {
                {
                    id = 'deliver_vehicle',
                    message = Locales[Config.Locale]['Lua']['deliver_vehicle_task_list'],
                    completed = false,
                },
            }
        }
    end

    NuiMessage('task', Tasks)
    TaskNUI = true

    if RoomData and RoomData.settings and RoomData.settings.startedRobbery and not IsWorkingLoop then
        IsWorkingLoop = true
        CreateThread(function ()
            while RoomData and RoomData.settings and RoomData.settings.startedRobbery do
                if IsControlJustPressed(0, 29) then
                    NuiMessage('showDetailTask')
                end

                if not TaskNUI then
                    NuiMessage('showTask')
                    TaskNUI = true
                end

                Wait(0)
            end
        end)
    end
end