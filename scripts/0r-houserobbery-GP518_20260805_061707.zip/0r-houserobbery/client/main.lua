

NuiLoaded, PlayerLoaded, IsDuiActive, Inside, HandIsBusy, SecondHandIsBusy, FirstSafeProcess, IsWorkingLoop, TaskNUI, DeliveredVehicle  = false, false, false, false,false, false, false, false, false, false
PlayerData, TabletModel, DuiObject, DuiHandle = nil, nil, nil, nil
RoomData, ScriptCache, ExitCoords, EnterCoords, HandObjects, Tasks = {}, {}, {}, {}, {}, {}
SafeObject = {}
TableObject = {}
MarketPed = nil

local bagBackup = nil
local homeObjects, homeChests = {}, {}

--- CheckNui()
--- @return nil
--- @description This function checks if the NUI is loaded. It waits until the NUI is loaded before proceeding with the rest of the code.
local function CheckNui()
    while not NuiLoaded do
        Wait(100)
    end
end

--- NuiMessage()
--- @param action string - The action to perform in the NUI.
--- @param payload table - The data to send to the NUI.
--- @return nil
--- @description This function sends a message to the NUI with the specified action and payload. It checks if the NUI is loaded before sending the message.
function NuiMessage(action, payload)
    CheckNui()
    SendNUIMessage({
        action = action,
        payload = payload
    })
end

--- FillBridgeTables()
--- @return nil
--- @description This function fills the bridge tables with player data. It retrieves the player's identifier, job information, and name, and stores them in the PlayerData table.
local function FillBridgeTables()
    PlayerLoaded = true
    local identifier = Framework.GetPlayerIdentifier()
    local playerJobName, playerJobLabel, playerJobGradeName, playerJobGradeLevel = Framework.GetPlayerJob()
    local firstname, lastname = Framework.GetPlayerName()

    PlayerData = {
        identifier = identifier,
        firstname = firstname,
        lastname = lastname,
        job = {
            name = playerJobName,
            label = playerJobLabel,
            grade_label = playerJobGradeName,
            grade = playerJobGradeLevel,
        },
    }

    lib.requestModel(Config.MarketPed.model, 10000)

    MarketPed = CreatePed(0, Config.MarketPed.model, Config.MarketPed.coords.x, Config.MarketPed.coords.y, Config.MarketPed.coords.z-1.0, Config.MarketPed.coords.w, false, true)
    FreezeEntityPosition(MarketPed, true)
    SetEntityInvincible(MarketPed, true)
    SetBlockingOfNonTemporaryEvents(MarketPed, true)

    SetModelAsNoLongerNeeded(Config.MarketPed.model)

    local ped = PlayerPedId()
    local activeText = false
    CreateThread(function()
        while true do
            local sleep = 1000

            if not DoesEntityExist(MarketPed) then
                MarketPed = nil
                break
            end

            if not IsPedInAnyVehicle(ped, false) then
                local coords = GetEntityCoords(ped)
                local distance = #(coords - vector3(Config.MarketPed.coords.x, Config.MarketPed.coords.y, Config.MarketPed.coords.z))

                if distance < 2.0 then
                    sleep = 0

                    if not activeText then
                        ShowTextUI("[E] Market")
                        activeText = true
                    end

                    if IsControlJustPressed(0, 38) then
                        local options = {}

                        for _, item in pairs(Config.MarketPlace) do
                            options[#options + 1] = {
                                title = item.label,
                                description = item.description,
                                serverEvent = '0r-houserobbery:server:sellItem',
                                args = {
                                    item = item.item,
                                }
                            }
                        end

                        lib.registerContext({
                            id = 'market_place',
                            title = 'Market',
                            options = options
                        })

                        lib.showContext('market_place')
                    end
                else
                    if activeText then
                        HideTextUI()
                        activeText = false
                    end
                end
            end

            Wait(sleep)
        end
    end)
end

--- ClearClientSideVariables()
--- @return nil
--- @description This function clears the client-side variables related to the player and the robbery. It resets the PlayerLoaded flag, PlayerData, and other variables to their initial state.
local function ClearClientSideVariables()
    PlayerLoaded = false
    PlayerData = {}
    StoredOldClothing = {}
end

--- FetchNui()
--- @return nil
--- @description This function checks if the NUI is loaded. It sends a message to the NUI to check its status and waits until it is loaded.
local function FetchNui()
    while not NuiLoaded do
        if NetworkIsSessionStarted() then
            SendNUIMessage({
                action = "checkNui",
            })
        end
        Wait(2000)
    end
end

--- EnterHouse()
--- @param homeIndex number - The index of the house to enter.
--- @return nil
--- @description This function handles the animation and transition of entering the house. It plays a sound, starts the enter animation, and creates the interior based on the home index. It also sets up the loot objects and their interactions.
function EnterHouse(homeIndex)
    local playerPed = PlayerPedId()
    local home = Config.RobberyLocation[homeIndex]

    TriggerServerEvent('InteractSound_SV:PlayOnSource', 'houses_door_open', 0.25)
    StartEnterAnim()
    FreezeEntityPosition(playerPed, true)

    Inside = true
    ExitCoords = vector3(home.coords.exit.x, home.coords.exit.y, home.coords.exit.z)
    EnterCoords = vector3(home.coords.enter.x, home.coords.enter.y, home.coords.enter.z)

    Wait(250)

    DoScreenFadeOut(250)

    while not IsScreenFadedOut() do
        Wait(100)
    end

    SetEntityCoords(playerPed, home.coords.exit.x, home.coords.exit.y, home.coords.exit.z-0.5)
    SetEntityHeading(playerPed, home.coords.exit.w)

    DoScreenFadeIn(250)

    Wait(1000)

    FreezeEntityPosition(playerPed, false)

    for k, v in pairs(home.loot) do
        if v.taken == false then
            if v.type ~= 'chest' then
                if (v and not v.create) and (RoomData and RoomData.settings and RoomData.settings.heistCar and RoomData.settings.heistCar.type == 'randomCar') and (v.type == 'prop') then
                    local prop = {
                        loot = v,
                        object = nil,
                        netId = nil,
                        data = v.props and v.props.place or v.prop,
                        type = v.type,
                        id = nil,
                        coords = nil,
                        create = false,
                        configId = k,
                        outlined = true
                    }

                    prop.object = GetClosestObjectOfType(prop.data.coords.x, prop.data.coords.y, prop.data.coords.z, 0.5, GetHashKey(prop.data.model), false, false, false)
                    prop.id = prop.data.model .. '_' .. k

                    homeObjects[prop.id] = prop
                elseif (v and not v.create) and v.type ~= 'prop' then
                    local prop = {
                        loot = v,
                        object = nil,
                        netId = nil,
                        data = v.props and v.props.place or v.prop,
                        type = v.type,
                        id = nil,
                        coords = nil,
                        create = false,
                        configId = k,
                        outlined = true
                    }

                    prop.object = GetClosestObjectOfType(prop.data.coords.x, prop.data.coords.y, prop.data.coords.z, 0.5, GetHashKey(prop.data.model), false, false, false)

                    prop.id = prop.data.model .. '_' .. k

                    homeObjects[prop.id] = prop
                end
            else
                local chest = {
                    loot = v,
                    object = nil,
                    netId = nil,
                    data = v.props and v.props.place or v.prop,
                    type = v.type,
                    id = nil,
                    coords = nil,
                    configId = k
                }

                chest.coords = vector3(chest.data.coords.x, chest.data.coords.y, chest.data.coords.z)

                homeChests[chest.loot.id] = chest
            end
        else
            local prop = {
                data = v.props and v.props.place or v.prop,
            }

            local object = GetClosestObjectOfType(prop.data.coords.x, prop.data.coords.y, prop.data.coords.z, 0.5, GetHashKey(prop.data.model), false, false, false)

            if object and DoesEntityExist(object) then
                SetEntityAsMissionEntity(object, true, true)
                DeleteObject(object)
            end
        end
    end

    if RoomData then
        NuiMessage('showNoise')
        TriggerServerEvent('0r-houserobbery:server:setEnterHouse', true)

        CreateThread(function()
            local textUIActive = false
            local currentType = nil

            while Inside do
                local sleep = 1000
                local playerCoords = GetEntityCoords(playerPed)
                local closestObject, closestChest = nil, nil
                local closestObjectDistance = 2.0
                local closestChestDistance = 2.0

                if RoomData and RoomData.settings and RoomData.settings.startedRobbery then
                    for k, v in pairs(homeObjects) do
                        local objectCoords = nil

                        if v.netId then
                            local object = NetToObj(v.netId)
                            if DoesEntityExist(object) then
                                objectCoords = GetEntityCoords(object)
                                v.object = object
                            end
                        elseif DoesEntityExist(v.object) then
                            objectCoords = GetEntityCoords(v.object)
                        end

                        if v.data and v.outlined ~= false then
                            if playerCoords and objectCoords then
                                local distance = #(playerCoords - objectCoords)

                                local lootData = Config.RobberyLocation[RoomData.settings.heistHouse].loot[v.configId]

                                if distance < closestObjectDistance and not lootData.taken and not lootData.busy then
                                    closestObject = v
                                    closestObjectDistance = distance
                                end

                                SetEntityDrawOutline(v.object, distance < 2.0)
                                if distance < 2.0 then
                                    SetEntityDrawOutlineColor(255, 165, 0, 255)
                                    SetEntityDrawOutlineShader(1)
                                end
                            end
                        end
                    end

                    for k, v in pairs(homeChests) do
                        if v.coords then
                            local distance = #(playerCoords - v.coords)
                            local lootData = Config.RobberyLocation[RoomData.settings.heistHouse].loot[v.configId]
                            if distance < closestChestDistance and not lootData.taken and not lootData.busy then
                                closestChest = v
                                closestChestDistance = distance
                            end
                        end
                    end

                    local isCloserToChest = closestChest and (closestChestDistance < closestObjectDistance)
                    local isCloserToObject = closestObject and (closestObjectDistance < closestChestDistance)

                    if isCloserToChest or isCloserToObject then
                        sleep = 0

                        if isCloserToChest and closestChest then
                            if currentType ~= "chest" then
                                if textUIActive then
                                    HideTextUI()
                                    textUIActive = false
                                end

                                ShowTextUI('[E] ' .. Locales[Config.Locale]['Lua']['search_chest'])
                                textUIActive = true
                                currentType = "chest"
                            end

                            if IsControlJustPressed(0, 38) then
                                if not HandIsBusy then
                                    if not SecondHandIsBusy then
                                        local ped = PlayerPedId()
                                        local drawable = GetPedDrawableVariation(ped, 5)
                                        if drawable ~= Config.HeistBag.male and drawable ~= Config.HeistBag.female then
                                            Notify.SendNotify(Locales[Config.Locale]['Lua']['need_wear_heist_bag'], 'error', 5000)
                                        else
                                            SecondHandIsBusy = true
                                            Notify.SendNotify(Locales[Config.Locale]['Lua']['searching_chest'], 'inform', 3000)
                                            CollectLoot(homeIndex, closestChest.id, closestChest.loot, nil, function() end)
                                        end
                                    end
                                end
                            end
                        elseif isCloserToObject and closestObject then
                            if currentType ~= "object" then
                                if textUIActive then
                                    HideTextUI()
                                    textUIActive = false
                                end

                                ShowTextUI('[E] ' .. Locales[Config.Locale]['Lua']['take_loot'])
                                textUIActive = true
                                currentType = "object"
                            end

                            if IsControlJustPressed(0, 38) then
                                if not HandIsBusy then
                                    if not SecondHandIsBusy then
                                        local ped = PlayerPedId()
                                        local drawable = GetPedDrawableVariation(ped, 5)
                                        if drawable ~= Config.HeistBag.male and drawable ~= Config.HeistBag.female then
                                            Notify.SendNotify(Locales[Config.Locale]['Lua']['need_wear_heist_bag'], 'error', 5000)
                                        else
                                            SecondHandIsBusy = true
                                            local data = closestObject.loot
                                            SetEntityDrawOutline(closestObject.object, false)
                                            closestObject.outlined = false
                                            if data then
                                                Notify.SendNotify(Locales[Config.Locale]['Lua']['taking_loot'], 'inform', 3000)
                                                CollectLoot(homeIndex, closestObject.id, data, closestObject.object,
                                                    function(bool)
                                                        if not bool then
                                                            closestObject.outlined = true
                                                        end
                                                    end)
                                            end
                                        end
                                    end
                                end
                            end
                        end
                    else
                        if textUIActive then
                            HideTextUI()
                            textUIActive = false
                            currentType = nil
                        end
                    end
                else
                    if textUIActive then
                        HideTextUI()
                        textUIActive = false
                        currentType = nil
                    end
                end

                Wait(sleep)
            end
        end)

        CreateThread(function()
            while true do
                local sleep = 1500
                if Inside then
                    sleep = 1000
                    for k, v in pairs(homeChests) do
                        if not v.taken then
                            sleep = 0

                            local pedCoords = GetEntityCoords(PlayerPedId())
                            local distance = #(pedCoords - v.coords)
                            if distance < 5.0 then
                                DrawMarker(2, v.coords.x, v.coords.y, v.coords.z, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.2, 0.2, 0.2, 0, 255, 0, 100, false, true, 2, false, nil, nil, false)
                            end
                        end
                    end
                end
                Wait(sleep)
            end
        end)

        local alertCounter = 0
        local sendNotify = false
        CreateThread(function()
            while Inside do
                if Inside then
                    local crouchAnim = GetHashKey("move_ped_crouched")
                    local currentAnim = GetPedMovementClipset(playerPed)

                    if (currentAnim == crouchAnim) then
                        if IsPedJumping(playerPed) then
                            alertCounter = alertCounter + 2
                            NuiMessage('noiseProgress', 40)
                        elseif IsPedRunning(playerPed) then
                            alertCounter = alertCounter + 2
                            NuiMessage('noiseProgress', 20)
                        else
                            NuiMessage('noiseProgress', 5)
                        end

                        if alertCounter >= 30 then
                            alertCounter = 0
                            if not sendNotify then
                                Notify.SendNotify(Locales[Config.Locale]['Lua']['making_much_noise_called_911'], 'error', 5000)
                                sendNotify = true
                            end
                            CreateThread(function()
                                CheckDispatch()
                            end)
                            Wait(10000)
                            sendNotify = false
                        end
                    else
                        if IsPedJumping(playerPed) then
                            alertCounter = alertCounter + 3
                            NuiMessage('noiseProgress', 80)
                        elseif IsPedRunning(playerPed) then
                            alertCounter = alertCounter + 2
                            NuiMessage('noiseProgress', 60)
                        elseif IsPedWalking(playerPed) then
                            alertCounter = alertCounter + 1
                            NuiMessage('noiseProgress', 30)
                        else
                            NuiMessage('noiseProgress', 0)
                        end

                        if alertCounter >= 30 then
                            alertCounter = 0
                            if not sendNotify then
                                Notify.SendNotify(Locales[Config.Locale]['Lua']['making_much_noise_called_911'], 'error', 5000)
                                sendNotify = true
                            end
                            CreateThread(function()
                                CheckDispatch()
                            end)
                            Wait(10000)
                            sendNotify = false
                        end
                    end
                else
                    break
                end

                Wait(1000)
            end
        end)
    end

    Wait(500)
    TriggerEvent('qb-weathersync:client:DisableSync')

    LeaveTextControl()
    CheckDistance()
end

--- LeaveHouse()
--- @param coords vector4 The coordinates to leave the house.
--- @return nil
--- @description This function handles the animation and transition of leaving the house. It fades out the screen, despawns the interior, and sets the player's position to the specified coordinates.
function LeaveHouse(coords)
    local ped = PlayerPedId()
    TriggerServerEvent('InteractSound_SV:PlayOnSource', 'houses_door_open', 0.25)
    StartEnterAnim()
    Wait(250)
    DoScreenFadeOut(250)
    Wait(500)
    TriggerEvent('qb-weathersync:client:EnableSync')
    Wait(250)

    if RoomData then
        NuiMessage('unshowNoise')
        TriggerServerEvent('0r-houserobbery:server:setEnterHouse', false)
    end

    DoScreenFadeIn(250)
    SetEntityCoords(ped, coords.x, coords.y, coords.z + 0.5, false, false, false, false)
    SetEntityHeading(ped, coords.w)
    Inside = false
end

--- StartHackSequence()
--- @return nil
--- @description Starts the hack sequence for the keypad lock. It checks if the player is aiming at the lock and has the hacking device equipped. If so, it plays a sound and updates the progress on the Dui interface. If the player fails, it resets the progress and notifies them.
local function StartHackSequence()
    while IsDuiActive do
        Wait(0)
        local playerCoords = GetEntityCoords(PlayerPedId())
        local lockCoords = vector3(Config.RobberyLocation[RoomData.settings.heistHouse].coords.lock.x,
            Config.RobberyLocation[RoomData.settings.heistHouse].coords.lock.y,
            Config.RobberyLocation[RoomData.settings.heistHouse].coords.lock.z)

        local distance = math.floor(#(lockCoords - playerCoords))

        if (distance < 2.0) then
            if GetSelectedPedWeapon(PlayerPedId()) == `weapon_hackingdevice` then
                if (IsControlJustPressed(0, 24)) then
                    PlaySoundFromCoord(-1, "IDLE_BEEP", playerCoords.x, playerCoords.y, playerCoords.z, 'EPSILONISM_04_SOUNDSET', true, 5.0, false)

                    SendDuiMessage(DuiObject, json.encode({
                        action = "minigameData",
                    }))
                end
            end
        end
    end
end

function EnterPasswordDUI()
    local isWinning = false

    local lockObject = NetToObj(RoomData.settings.lock)

    if (not lockObject) then
        return Notify.SendNotify(Locales[Config.Locale]['Lua']['keypad_not_available'], 'error', 5000)
    end

    CreateThread(function()
        while not isWinning do
            local sleep = 1000

            if not isWinning then
                local playerCoords = GetEntityCoords(PlayerPedId())
                local lockCoords = GetEntityCoords(lockObject)
                local distance = #(playerCoords - lockCoords)
                if (distance < 2.0) then
                    sleep = 0
                    ShowTextUI('[E] ' .. Locales[Config.Locale]['Lua']['open_door'])

                    if IsControlJustPressed(0, 38) then
                        HideTextUI()
                        local input = lib.inputDialog('Keypad', {
                            { type = 'number', label = 'Password', description = 'Enter the door password', required = true, min = 100000, max = 999999 },
                        })

                        if not input or not input[1] then
                            goto skip
                        end

                        if input[1] == RoomData.settings.password then
                            isWinning = true
                            break
                        else
                            Notify.SendNotify(Locales[Config.Locale]['Lua']['wrong_password'], 'error', 5000)
                            goto skip
                        end
                    end
                    ::skip::
                else
                    HideTextUI()
                end
            else
                break
            end

            Wait(sleep)
        end
    end)

    repeat
        Wait(1000)
    until isWinning

    if (IsDuiActive) then
        DeleteDUI(DuiObject, DuiHandle)
        DuiObject = nil
        DuiHandle = nil
        IsDuiActive = false
    end

    TriggerServerEvent('0r-houserobbery:server:setHouseState', RoomData.settings.heistHouse, true)

    CheckDispatch()

    ShowTasks('robbery_house')

    TriggerServerEvent('0r-houserobbery:server:syncRobberyData', {
        action = 'showTasks',
        data = {
            task = 'robbery_house'
        }
    })

    local home = Config.RobberyLocation[RoomData.settings.heistHouse]

    for k, v in pairs(home.loot) do
        if v.type ~= 'chest' then
            if v and v.create then
                if v.type == 'safe' then
                    local prop = {
                        loot = v,
                        object = nil,
                        netId = nil,
                        data = v.art,
                        type = v.type,
                        id = nil,
                        coords = nil,
                        create = true,
                        configId = k,
                        outlined = true
                    }

                    lib.requestModel(prop.data.model, 10000)

                    prop.coords = vector3(prop.data.coords.x, prop.data.coords.y, prop.data.coords.z)

                    prop.object = CreateObjectNoOffset(prop.data.model, prop.coords.x, prop.coords and prop.coords.y or 0, prop.coords and prop.coords.z or 0, true, true, false)
                    SetEntityRotation(prop.object, prop.data.rotation.x, prop.data.rotation.y, prop.data.rotation.z, 2, true)

                    prop.netId = ObjToNet(prop.object)
                    while not NetworkDoesNetworkIdExist(prop.netId) do
                        NetworkRegisterEntityAsNetworked(prop.object)
                        prop.netId = ObjToNet(prop.object)
                        Wait(10)
                    end

                    TableObject = {
                        object = prop.object,
                        netId = prop.netId,
                    }

                    prop.id = prop.data.model .. '_' .. k

                    SetModelAsNoLongerNeeded(prop.data.model)
                    FreezeEntityPosition(prop.object, true)
                    TriggerEvent('0r-houserobbery:client:deleteObjectTimer', prop.id)

                    homeObjects[prop.id] = prop
                elseif RoomData.settings.heistCar.type == 'randomCar' and v.type == 'prop' then
                    local prop = {
                        loot = v,
                        object = nil,
                        netId = nil,
                        data = v.props and v.props.place or v.prop,
                        type = v.type,
                        id = nil,
                        coords = nil,
                        create = true,
                        configId = k,
                        outlined = true
                    }

                    lib.requestModel(prop.data.model, 10000)

                    prop.coords = vector3(prop.data.coords.x, prop.data.coords.y, prop.data.coords.z)

                    prop.object = CreateObjectNoOffset(prop.data.model, prop.coords.x, prop.coords.y, prop.coords.z, true, true, false)
                    SetEntityRotation(prop.object, prop.data.rotation.x, prop.data.rotation.y, prop.data.rotation.z, 2, true)

                    prop.netId = ObjToNet(prop.object)
                    while not NetworkDoesNetworkIdExist(prop.netId) do
                        NetworkRegisterEntityAsNetworked(prop.object)
                        prop.netId = ObjToNet(prop.object)
                        Wait(10)
                    end

                    prop.id = prop.data.model .. '_' .. k

                    SetModelAsNoLongerNeeded(prop.data.model)
                    FreezeEntityPosition(prop.object, true)
                    TriggerEvent('0r-houserobbery:client:deleteObjectTimer', prop.id)

                    homeObjects[prop.id] = prop
                elseif v.type ~= 'prop' then
                    local prop = {
                        loot = v,
                        object = nil,
                        netId = nil,
                        data = v.props and v.props.place or v.prop,
                        type = v.type,
                        id = nil,
                        coords = nil,
                        create = true,
                        configId = k,
                        outlined = true
                    }

                    lib.requestModel(prop.data.model, 10000)

                    prop.coords = vector3(prop.data.coords.x, prop.data.coords.y, prop.data.coords.z)

                    prop.object = CreateObjectNoOffset(GetHashKey(prop.data.model), prop.coords.x, prop.coords.y, prop.coords.z, true, true, false)
                    SetEntityRotation(prop.object, prop.data.rotation.x, prop.data.rotation.y, prop.data.rotation.z, 2, true)

                    prop.netId = ObjToNet(prop.object)

                    while not NetworkDoesNetworkIdExist(prop.netId) do
                        NetworkRegisterEntityAsNetworked(prop.object)
                        prop.netId = ObjToNet(prop.object)
                        Wait(10)
                    end

                    prop.id = prop.data.model .. '_' .. k

                    SetModelAsNoLongerNeeded(prop.data.model)
                    FreezeEntityPosition(prop.object, true)
                    TriggerEvent('0r-houserobbery:client:deleteObjectTimer', prop.id)

                    homeObjects[prop.id] = prop
                end
            end
        end
    end

    TriggerServerEvent('0r-houserobbery:server:syncRobberyData', {
        action = 'syncHouseObjects',
        data = {
            objects = homeObjects,
        }
    })
end

function ResetRobbery()
    if (ScriptCache['peds']) then
        for k, v in pairs(ScriptCache['peds']) do
            if DoesEntityExist(v) then
                DeleteEntity(v)
            end
        end
    end

    if (ScriptCache['blips']) then
        for k, v in pairs(ScriptCache['blips']) do
            if DoesBlipExist(v) then
                RemoveBlip(v)
            end
        end
    end

    if (ScriptCache['cars']) then
        for k, v in pairs(ScriptCache['cars']) do
            DeleteEntity(v)
        end
    end

    if (homeObjects and next(homeObjects)) then
        for k, v in pairs(homeObjects) do
            if v.object then
                if v.netId then
                    local object = NetToObj(v.netId)

                    if DoesEntityExist(object) then
                        SetEntityAsMissionEntity(object, true, true)
                        DeleteObject(object)
                    end
                else
                     if DoesEntityExist(object) then
                        SetEntityAsMissionEntity(object, true, true)
                        DeleteObject(object)
                    end
                end
                homeObjects[k] = nil
            end
        end
    end

    if (SafeObject and SafeObject.object) then
        if SafeObject.netId then
            local object = NetToObj(SafeObject.netId)

            if DoesEntityExist(object) then
                SetEntityAsMissionEntity(object, true, true)
                DeleteObject(object)
            end
        else
            if DoesEntityExist(SafeObject.object) then
                SetEntityAsMissionEntity(SafeObject.object, true, true)
                DeleteObject(SafeObject.object)
            end
        end
        SafeObject = {}
    end

    if (TableObject and TableObject.object) then
        if TableObject.netId then
            local object = NetToObj(TableObject.netId)

            if DoesEntityExist(object) then
                SetEntityAsMissionEntity(object, true, true)
                DeleteObject(object)
            end
        else
            if DoesEntityExist(TableObject.object) then
                SetEntityAsMissionEntity(TableObject.object, true, true)
                DeleteObject(TableObject.object)
            end
        end
        TableObject = {}
    end

    ScriptCache['peds'] = nil
    ScriptCache['blips'] = nil
    ScriptCache['cars'] = nil

    if (IsDuiActive) then
        RemoveReplaceTexture('w_am_hackdevice_m32', 'script_rt_w_am_hackdevice_m32')
        if (DuiObject) then
            DestroyDui(DuiObject)
        end
        DuiObject = nil
        DuiHandle = nil
        IsDuiActive = false
    end

    local count = 0
    for _ in pairs(HandObjects) do
        count = count + 1
    end

    DeliveredVehicle = false

    TriggerServerEvent('0r-houserobbery:server:syncRobberyData', {
        action = 'deliveredVehicleFalse',
        data = {}
    })

    TriggerServerEvent('0r-houserobbery:server:finishRobbery', count, HandObjects)
end

RegisterNetEvent('0r-houserobbery:client:OnPlayerLoaded')
AddEventHandler('0r-houserobbery:client:OnPlayerLoaded', function()
    Wait(1500)
    FillBridgeTables()
    FetchNui()
    TriggerServerEvent('0r-houserobbery:server:scriptStarted')
end)

RegisterNetEvent('onResourceStart', function(resourceName)
    if resourceName == GetCurrentResourceName() then
        Wait(1500)
        FillBridgeTables()
        FetchNui()
        TriggerServerEvent('0r-houserobbery:server:scriptStarted')
    end
end)

RegisterNetEvent('0r-houserobbery:client:OnPlayerUnload')
AddEventHandler('0r-houserobbery:client:OnPlayerUnload', function()
    ClearClientSideVariables()
    StopTabletAnim()
end)

RegisterNetEvent('onResourceStop', function(resourceName)
    if resourceName == GetCurrentResourceName() then
        ClearClientSideVariables()
        StopTabletAnim()

        FreezeEntityPosition(PlayerPedId(), false)

        if (ScriptCache['peds']) then
            for k, v in pairs(ScriptCache['peds']) do
                if DoesEntityExist(v) then
                    DeleteEntity(v)
                end
            end
        end

        if (ScriptCache['blips']) then
            for k, v in pairs(ScriptCache['blips']) do
                if DoesBlipExist(v) then
                    RemoveBlip(v)
                end
            end
        end

        if (ScriptCache['cars']) then
            for k, v in pairs(ScriptCache['cars']) do
                DeleteEntity(v)
            end
        end

        if (homeObjects and next(homeObjects)) then
            for k, v in pairs(homeObjects) do
                if v.netId then
                    local object = NetToObj(v.netId)

                    if DoesEntityExist(object) then
                        SetEntityAsMissionEntity(object, true, true)
                        DeleteObject(object)
                    end
                end
                if v.object then
                    if DoesEntityExist(v.object) then
                        SetEntityAsMissionEntity(v.object, true, true)
                        DeleteObject(v.object)
                    end
                end
            end
        end

        if SafeObject and type(SafeObject) == "table" then
            if SafeObject.netId and type(SafeObject.netId) == "number" then
                local object = NetToObj(SafeObject.netId)

                if object and type(object) == "number" and DoesEntityExist(object) then
                    SetEntityAsMissionEntity(object, true, true)
                    DeleteObject(object)
                end
            end

            if SafeObject.object and type(SafeObject.object) == "number" then
                if DoesEntityExist(SafeObject.object) then
                    SetEntityAsMissionEntity(SafeObject.object, true, true)
                    DeleteObject(SafeObject.object)
                end
            end

            SafeObject = {}
        end

        if TableObject and type(TableObject) == "table" and TableObject.object then
            if TableObject.netId and type(TableObject.netId) == "number" then
                local object = NetToObj(TableObject.netId)

                if object and type(object) == "number" and DoesEntityExist(object) then
                    SetEntityAsMissionEntity(object, true, true)
                    DeleteObject(object)
                end
            end

            if TableObject.object and type(TableObject.object) == "number" then
                if DoesEntityExist(TableObject.object) then
                    SetEntityAsMissionEntity(TableObject.object, true, true)
                    DeleteObject(TableObject.object)
                end
            end

            TableObject = {}
        end

        if (HandObjects and next(HandObjects)) then
            for k, v in pairs(HandObjects) do
                if v.netId then
                    local object = NetToObj(v.netId)

                    if DoesEntityExist(object) then
                        SetEntityAsMissionEntity(object, true, true)
                        DeleteObject(object)
                    end
                end

                if v.object then
                    if DoesEntityExist(v.object) then
                        SetEntityAsMissionEntity(v.object, true, true)
                        DeleteObject(v.object)
                    end
                end
            end
        end

        if (MarketPed and DoesEntityExist(MarketPed)) then
            DeleteEntity(MarketPed)
            MarketPed = nil
        end

        HideTextUI()

        TriggerEvent('qb-weathersync:client:EnableSync')

        if (IsDuiActive) then
            RemoveReplaceTexture('w_am_hackdevice_m32', 'script_rt_w_am_hackdevice_m32')
            if (DuiObject) then
                DestroyDui(DuiObject)
            end
            DuiObject = nil
            DuiHandle = nil
            IsDuiActive = false
        end
    end
end)

RegisterNetEvent('0r-houserobbery:client:openHouseRobberyMenu')
AddEventHandler('0r-houserobbery:client:openHouseRobberyMenu', function(data)
    while not PlayerLoaded do
        Wait(100)
    end

    if (IsNuiFocused()) then
        return
    end

    if (Framework.GetIsPlayerDead()) then
        return
    end

    if (not NuiLoaded) then
        return
    end

    StartTabletAnim()
    SetNuiFocus(true, true)
    NuiMessage('openUi', data)
end)

RegisterNetEvent('0r-houserobbery:client:openHeistBagMenu')
AddEventHandler('0r-houserobbery:client:openHeistBagMenu', function()
    ProgressBar.Open({
        duration = 3500,
        label = bagBackup and Locales[Config.Locale]['Lua']['removing_bag'] or Locales[Config.Locale]['Lua']['wearing_bag'],
        disable = {
            move = true,
            combat = true
        },
        anim = {
            dict = 'clothingshirt',
            clip = 'try_shirt_positive_d',
        },
        style = 'circle',
        position = 'bottom',
    }, function(status)
        if (Config.ProgressBarSystem == 'ox_lib' and status) or (Config.ProgressBarSystem == 'progressbar' and not status) then
            return
        end

        local ped = PlayerPedId()
        local hash = GetEntityModel(ped)

        if bagBackup then
            SetPedComponentVariation(ped, 5, bagBackup.drawable, bagBackup.texture, 0)
            bagBackup = nil
            return
        end

        local drawable = GetPedDrawableVariation(ped, 5)

        if drawable == Config.HeistBag.male or drawable == Config.HeistBag.female then
            drawable = 0
        end

        local texture = GetPedTextureVariation(ped, 5)

        bagBackup = {
            drawable = drawable,
            texture = texture
        }

        if hash == `mp_m_freemode_01` then
            SetPedComponentVariation(ped, 5, Config.HeistBag.male, 0, 0)
        else
            SetPedComponentVariation(ped, 5, Config.HeistBag.female, 0, 0)
        end
    end)
end)

RegisterNetEvent('0r-houserobbery:client:deleteObjectTimer', function(index)
    Wait(1000 * 60 * Config.TimeToResetItem)

    if homeObjects[index] and homeObjects[index].object then
        if homeObjects[index].create then
            if homeObjects[index].netId then
                local retval = NetToObj(homeObjects[index].netId)

                if DoesEntityExist(retval) then
                    SetEntityAsMissionEntity(retval, true, true)
                    DeleteObject(retval)
                end
            end

            if DoesEntityExist(homeObjects[index].object) then
                SetEntityAsMissionEntity(retval, true, true)
                DeleteObject(homeObjects[index].object)
            end
        else
            local retval = GetClosestObjectOfType(homeObjects[index].data.coords.x, homeObjects[index].data.coords.y, homeObjects[index].data.coords.z, 0.5, homeObjects[index].data.model, false, false, false)

            if DoesEntityExist(retval) then
                SetEntityAsMissionEntity(retval, true, true)
                DeleteObject(retval)
            end
        end

        homeObjects[index] = nil
    end
end)

RegisterNetEvent('0r-houserobbery:client:resetHouseState', function(homeIndex)
    Config.RobberyLocation[homeIndex]['opened'] = false

    for _, v in pairs(Config.RobberyLocation[homeIndex]['loot']) do
        v['taken'] = false
        v['busy'] = false
    end
end)

RegisterNetEvent('0r-houserobbery:client:setHouseState', function(index, state)
    Config.RobberyLocation[index]['opened'] = state
end)

RegisterNetEvent('0r-houserobbery:client:setLootState', function(index, k, state, object)
    if homeObjects[object] and homeObjects[object].object and homeObjects[object].loot.type ~= 'safe' then
        if homeObjects[object].create then
             if DoesEntityExist(homeObjects[object].object) then
                DeleteObject(homeObjects[object].object)
            end
        else
            local retval = GetClosestObjectOfType(homeObjects[object].data.coords.x, homeObjects[object].data.coords.y, homeObjects[object].data.coords.z, 0.5, homeObjects[object].data.model, false, false, false)

            if DoesEntityExist(retval) then
                SetEntityAsMissionEntity(retval, true, true)
                DeleteObject(retval)
            end
        end
    end

    SecondHandIsBusy = false

    FreezeEntityPosition(PlayerPedId(), false)

    Config.RobberyLocation[index]['loot'][k].taken = state

    local loot = Config.RobberyLocation[index]['loot'][k]

    if loot.type == 'chest' then
        homeChests[loot.id] = nil
    else
        if homeObjects[object] then
            homeObjects[object] = nil
        end
    end
end)

RegisterNetEvent('0r-houserobbery:client:setLootStateBusy', function(index, k, state)
    Config.RobberyLocation[index]['loot'][k].busy = state
end)

RegisterNetEvent('0r-houserobbery:client:refreshTeamList')
AddEventHandler('0r-houserobbery:client:refreshTeamList', function(data)
    NuiMessage('refreshTeamList', data)
end)

RegisterNetEvent('0r-houserobbery:client:sendInvite')
AddEventHandler('0r-houserobbery:client:sendInvite', function(data)
    SetNuiFocus(true, true)
    NuiMessage('sendInvite', data)
end)

RegisterNetEvent('0r-houserobbery:client:refreshRoomData')
AddEventHandler('0r-houserobbery:client:refreshRoomData', function(data)
    RoomData = data
end)

RegisterNetEvent('0r-houserobbery:client:syncRobberyData')
AddEventHandler('0r-houserobbery:client:syncRobberyData', function(action, data)
    if (action == 'startRobbery') then
        lib.requestModel(data.ped.model)

        local ped = CreatePed(0, data.ped.model, data.ped.coords.x, data.ped.coords.y, data.ped.coords.z - 1,
            data.ped.coords.w, false, false)
        FreezeEntityPosition(ped, true)
        SetEntityInvincible(ped, true)
        SetBlockingOfNonTemporaryEvents(ped, true)
        SetModelAsNoLongerNeeded(ped)

        local blip = AddBlipForCoord(data.ped.coords.x, data.ped.coords.y, data.ped.coords.z)
        SetBlipSprite(blip, data.blip.id)
        SetBlipColour(blip, data.blip.color)
        SetBlipScale(blip, data.blip.scale)
        SetBlipDisplay(blip, 4)
        SetBlipAsShortRange(blip, true)
        BeginTextCommandSetBlipName("STRING")
        AddTextComponentSubstringPlayerName(data.blip.name)
        EndTextCommandSetBlipName(blip)

        if not ScriptCache['peds'] then
            ScriptCache['peds'] = {}
        end

        if not ScriptCache['blips'] then
            ScriptCache['blips'] = {}
        end

        ScriptCache['peds']['car_dealer'] = ped
        ScriptCache['blips']['car_dealer'] = blip
    elseif (action == 'buyHeistCar') then
        VehicleKey.GiveKeys(nil, GetVehicleNumberPlateText(data.plate))

        if DoesEntityExist(ScriptCache['peds']['car_dealer']) then
            DeleteEntity(ScriptCache['peds']['car_dealer'])
        end

        if DoesBlipExist(ScriptCache['blips']['car_dealer']) then
            RemoveBlip(ScriptCache['blips']['car_dealer'])
        end

        ScriptCache['peds']['car_dealer'] = nil
        ScriptCache['blips']['car_dealer'] = nil
    elseif (action == 'showTasks') then
        ShowTasks(data.task)
    elseif (action == 'handObject') then
        HandObjects = data.objects
    elseif (action == 'syncHouseObjects') then
        homeObjects = data.objects
    elseif (action == 'leaveVehicle') then
        TaskLeaveAnyVehicle(PlayerPedId())
    elseif (action == 'deliveredVehicleFalse') then
        DeliveredVehicle = false
    elseif (action == 'createHouseBlip') then
        local blip = CreateBlipForRobbery({
            coords = Config.RobberyLocation[RoomData.settings.heistHouse].coords.enter,
            sprite = Config.BlipSettings['robbery_house'].id,
            color = Config.BlipSettings['robbery_house'].color,
            scale = Config.BlipSettings['robbery_house'].scale,
            name = Config.BlipSettings['robbery_house'].name,
        })

        if not ScriptCache['blips'] then
            ScriptCache['blips'] = {}
        end

        ScriptCache['blips']['robbery_house'] = blip
    elseif (action == 'deliverVehicleBlip') then
        local blip = CreateBlipForRobbery({
            coords = data.coords,
            sprite = Config.BlipSettings['illegal_vehicle_dealer'].id,
            color = Config.BlipSettings['illegal_vehicle_dealer'].color,
            scale = Config.BlipSettings['illegal_vehicle_dealer'].scale,
            name = Config.BlipSettings['illegal_vehicle_dealer'].name,
        })

        if not ScriptCache['blips'] then
            ScriptCache['blips'] = {}
        end

        ScriptCache['blips']['deliver_car'] = blip
    end
end)

RegisterNetEvent('0r-houserobbery:client:receiveMessage')
AddEventHandler('0r-houserobbery:client:receiveMessage', function(data)
    NuiMessage('receiveMessage', data)
end)

RegisterNetEvent('0r-houserobbery:client:startRobbery')
AddEventHandler('0r-houserobbery:client:startRobbery', function()
    while RoomData == '{}' do
        Wait(100)
    end

    if not (RoomData and RoomData.settings and RoomData.settings.startedRobbery) then
        return
    end

    if (RoomData.settings.heistCar.type == 'randomCar') then
        CreateThread(function()
            ShowTasks('take_vehicle')
        end)

        local carDealer = Config.HeistCarPeds[math.random(1, #Config.HeistCarPeds)]
        lib.requestModel(carDealer.model)

        local ped = CreatePed(0, carDealer.model, carDealer.coords.ped.x, carDealer.coords.ped.y, carDealer.coords.ped.z - 1,
            carDealer.coords.ped.w, false, false)
        FreezeEntityPosition(ped, true)
        SetEntityInvincible(ped, true)
        SetBlockingOfNonTemporaryEvents(ped, true)
        SetModelAsNoLongerNeeded(ped)

        local blip = CreateBlipForRobbery({
            coords = carDealer.coords.ped,
            sprite = Config.BlipSettings['illegal_vehicle_dealer'].id,
            color = Config.BlipSettings['illegal_vehicle_dealer'].color,
            scale = Config.BlipSettings['illegal_vehicle_dealer'].scale,
            name = Config.BlipSettings['illegal_vehicle_dealer'].name,
        })

        local playerPed = PlayerPedId()
        local loop = true

        CreateThread(function()
            while loop do
                local sleep = 1000
                local pedCoords = GetEntityCoords(playerPed)
                local distance = #(pedCoords - vector3(carDealer.coords.ped.x, carDealer.coords.ped.y, carDealer.coords.ped.z))

                if (distance < 2.5) then
                    sleep = 0
                    ShowTextUI('[E] ' .. Locales[Config.Locale]['Lua']['open_illegal_vehicle_dealer'])
                    if IsControlJustPressed(0, 38) then
                        HideTextUI()
                        local alert = lib.alertDialog({
                            header = Locales[Config.Locale]['Lua']['illegal_vehicle_dealer'],
                            content = string.format(Locales[Config.Locale]['Lua']['illegal_vehicle_dealer_description'], Config.HeistCar.price),
                            centered = true,
                            cancel = true
                        })

                        if (alert == 'cancel') then
                            goto skip
                        end

                        if (alert == 'confirm') then
                            lib.callback('0r-houserobbery:callback:buyHeistCar', false, function(bool)
                                if bool then
                                    loop = false
                                end
                            end)
                        end
                    end
                    ::skip::
                else
                    HideTextUI()
                end

                Wait(sleep)
            end
        end)

        TriggerServerEvent('0r-houserobbery:server:syncRobberyData', {
            action = 'startRobbery',
            data = {
                ped = {
                    model = carDealer.model,
                    coords = carDealer.coords.ped,
                },
                blip = {
                    id = Config.BlipSettings['illegal_vehicle_dealer'].id,
                    color = Config.BlipSettings['illegal_vehicle_dealer'].color,
                    scale = Config.BlipSettings['illegal_vehicle_dealer'].scale,
                    name = Config.BlipSettings['illegal_vehicle_dealer'].name,
                },
                spawnCoords = carDealer.coords.car
            }
        })

        TriggerServerEvent('0r-houserobbery:server:syncRobberyData', {
            action = 'showTasks',
            data = {
                task = 'take_vehicle'
            }
        })

        if not ScriptCache['peds'] then
            ScriptCache['peds'] = {}
        end

        if not ScriptCache['blips'] then
            ScriptCache['blips'] = {}
        end

        if not ScriptCache['zones'] then
            ScriptCache['zones'] = {}
        end

        ScriptCache['peds']['car_dealer'] = ped
        ScriptCache['blips']['car_dealer'] = blip
        ScriptCache['zones']['car_dealer'] = zone
    else
        local blip = CreateBlipForRobbery({
            coords = Config.RobberyLocation[RoomData.settings.heistHouse].coords.enter,
            sprite = Config.BlipSettings['robbery_house'].id,
            color = Config.BlipSettings['robbery_house'].color,
            scale = Config.BlipSettings['robbery_house'].scale,
            name = Config.BlipSettings['robbery_house'].name,
        })

        if not ScriptCache['blips'] then
            ScriptCache['blips'] = {}
        end

        ScriptCache['blips']['robbery_house'] = blip

        TriggerServerEvent('0r-houserobbery:server:syncRobberyData', {
            action = 'createHouseBlip',
            data = {}
        })

        if not (ScriptCache['lock']) then
            ScriptCache['lock'] = {}
        end

        lib.requestModel(`vw_prop_casino_keypad_01`)

        local object = CreateObject(`vw_prop_casino_keypad_01`, Config.RobberyLocation[RoomData.settings.heistHouse].coords.lock.x, Config.RobberyLocation[RoomData.settings.heistHouse].coords.lock.y, Config.RobberyLocation[RoomData.settings.heistHouse].coords.lock.z, true, true, false)
        FreezeEntityPosition(object, true)
        SetEntityHeading(object, Config.RobberyLocation[RoomData.settings.heistHouse].coords.lock.w)
        SetModelAsNoLongerNeeded(`vw_prop_casino_keypad_01`)

        local lockObject = ObjToNet(object)
        while not NetworkDoesNetworkIdExist(lockObject) do
            NetworkRegisterEntityAsNetworked(object)
            lockObject = ObjToNet(object)
            Wait(10)
        end

        TriggerServerEvent('0r-houserobbery:server:syncRobberyData', {
            action = 'netIdObject',
            data = {
                netId = lockObject,
            }
        })

        local playerPed = PlayerPedId()
        CreateThread(function()
            while RoomData and RoomData.settings and not RoomData.settings.failed do
                local sleep = 1000
                local pedCoords = GetEntityCoords(playerPed)
                local distance = #(pedCoords - vector3(Config.RobberyLocation[RoomData.settings.heistHouse].coords.lock.x,
                    Config.RobberyLocation[RoomData.settings.heistHouse].coords.lock.y, Config.RobberyLocation[RoomData.settings.heistHouse].coords.lock.z))

                if (distance < 2.5) then
                    sleep = 0
                    ShowTextUI('[E] Hack the Keypad')
                    if IsControlJustPressed(0, 38) then
                        if (IsDuiActive) then
                            goto skip
                        end

                        if not (GetSelectedPedWeapon(PlayerPedId()) == `weapon_hackingdevice`) then
                            Notify.SendNotify('You need to equip the hack device first', 'error', 5000)
                            goto skip
                        end

                        Notify.SendNotify(Locales[Config.Locale]['Lua']['hacking_keypad'], 'success', 5000)

                        IsDuiActive = false

                        while not IsDuiActive do
                            Wait(100)
                            if (GetSelectedPedWeapon(PlayerPedId()) == `weapon_hackingdevice`) then
                                if (not DuiObject and not DuiHandle) then
                                    DuiObject, DuiHandle = CreateDUI()
                                end

                                Wait(1500)
                                if (DuiObject) then
                                    SendDuiMessage(DuiObject, json.encode({
                                        action = "toggleDui",
                                    }))

                                    SendDuiMessage(DuiObject, json.encode({
                                        action = "duiPassword",
                                        payload = tostring(RoomData.settings.password),
                                    }))
                                end
                            end
                        end

                        HideTextUI()
                        StartHackSequence()
                        break
                    end
                    ::skip::
                else
                    HideTextUI()
                end

                Wait(sleep)
            end
        end)

        TriggerServerEvent('0r-houserobbery:client:syncRobberyData', {
            action = 'keypad',
            data = {}
        })

        TriggerServerEvent('0r-houserobbery:server:syncRobberyData', {
            action = 'showTasks',
            data = {
                task = 'hack_keypad'
            }
        })

        ShowTasks('hack_keypad')
    end
end)

RegisterNetEvent('0r-houserobbery:client:buyHeistCar')
AddEventHandler('0r-houserobbery:client:buyHeistCar', function()
    if not (RoomData and RoomData.settings and RoomData.settings.startedRobbery) then
        return
    end

    if not (RoomData and RoomData.settings and RoomData.settings.heistCar and RoomData.settings.heistCar.paid) then
        return
    end

    if (RoomData and RoomData.settings and RoomData.settings.heistCar and RoomData.settings.heistCar.netId == nil) then
        local vehicle = Config.HeistCar
        local spawnCoords = nil

        repeat
            spawnCoords = RoomData.settings.heistCar.coords[math.random(1, #RoomData.settings.heistCar.coords)]
            Wait(100)

            local retval = GetClosestVehicle(spawnCoords.x, spawnCoords.y, spawnCoords.z, 2.5, 0, 71)
            local object = GetClosestObjectOfType(spawnCoords.x, spawnCoords.y, spawnCoords.z, 2.5, 0, false)
        until not DoesEntityExist(retval) and not DoesEntityExist(object)

        lib.requestModel(vehicle.hash)

        local car = CreateVehicle(vehicle.hash, spawnCoords.x, spawnCoords.y, spawnCoords.z, spawnCoords.w, true, false)
        VehicleKey.GiveKeys(car, GetVehicleNumberPlateText(car))
        SetVehicleOnGroundProperly(car)
        SetEntityAsMissionEntity(car, true, true)
        SetVehicleDoorsLocked(car, 1)

        local vehnet = VehToNet(car)
        while not NetworkDoesNetworkIdExist(vehnet) do
            NetworkRegisterEntityAsNetworked(car)
            vehnet = VehToNet(car)
            Wait(10)
        end
        SetModelAsNoLongerNeeded(vehicle.hash)

        Fuel.SetFuel(car, 100.0)

        if not (ScriptCache['cars']) then
            ScriptCache['cars'] = {}
        end

        ScriptCache['cars']['heist_car'] = car

        if (DoesEntityExist(ScriptCache['peds']['car_dealer'])) then
            DeleteEntity(ScriptCache['peds']['car_dealer'])
            ScriptCache['peds']['car_dealer'] = nil
        end

        if (DoesBlipExist(ScriptCache['blips']['car_dealer'])) then
            RemoveBlip(ScriptCache['blips']['car_dealer'])
            ScriptCache['blips']['car_dealer'] = nil
        end

        TriggerServerEvent('0r-houserobbery:server:syncRobberyData', {
            action = 'buyHeistCar',
            data = {
                id = car,
                netId = vehnet,
                plate = GetVehicleNumberPlateText(car),
            }
        })

        local blip = CreateBlipForRobbery({
            coords = Config.RobberyLocation[RoomData.settings.heistHouse].coords.enter,
            sprite = Config.BlipSettings['robbery_house'].id,
            color = Config.BlipSettings['robbery_house'].color,
            scale = Config.BlipSettings['robbery_house'].scale,
            name = Config.BlipSettings['robbery_house'].name,
        })

        ScriptCache['blips']['robbery_house'] = blip

        TriggerServerEvent('0r-houserobbery:server:syncRobberyData', {
            action = 'createHouseBlip',
            data = {}
        })

        if not (ScriptCache['lock']) then
            ScriptCache['lock'] = {}
        end

        lib.requestModel(`vw_prop_casino_keypad_01`)

        local object = CreateObject(`vw_prop_casino_keypad_01`, Config.RobberyLocation[RoomData.settings.heistHouse].coords.lock.x, Config.RobberyLocation[RoomData.settings.heistHouse].coords.lock.y, Config.RobberyLocation[RoomData.settings.heistHouse].coords.lock.z, true, true, false)
        FreezeEntityPosition(object, true)
        SetEntityHeading(object, Config.RobberyLocation[RoomData.settings.heistHouse].coords.lock.w)
        SetModelAsNoLongerNeeded(`vw_prop_casino_keypad_01`)

        local lockObject = ObjToNet(object)
        while not NetworkDoesNetworkIdExist(lockObject) do
            NetworkRegisterEntityAsNetworked(object)
            lockObject = ObjToNet(object)
            Wait(10)
        end

        TriggerServerEvent('0r-houserobbery:server:syncRobberyData', {
            action = 'netIdObject',
            data = {
                netId = lockObject,
            }
        })

        local playerPed = PlayerPedId()
        CreateThread(function()
            while RoomData and RoomData.settings and not RoomData.settings.failed do
                local sleep = 1000
                local pedCoords = GetEntityCoords(playerPed)
                local distance = #(pedCoords - vector3(Config.RobberyLocation[RoomData.settings.heistHouse].coords.lock.x,
                    Config.RobberyLocation[RoomData.settings.heistHouse].coords.lock.y, Config.RobberyLocation[RoomData.settings.heistHouse].coords.lock.z))

                if (distance < 2.5) then
                    sleep = 0
                    ShowTextUI('[E] Hack the Keypad')
                    if IsControlJustPressed(0, 38) then
                        if (IsDuiActive) then
                            goto skip
                        end

                        if not (GetSelectedPedWeapon(PlayerPedId()) == `weapon_hackingdevice`) then
                            Notify.SendNotify('You need to equip the hack device first', 'error', 5000)
                            goto skip
                        end

                        Notify.SendNotify(Locales[Config.Locale]['Lua']['hacking_keypad'], 'success', 5000)

                        IsDuiActive = false

                        while not IsDuiActive do
                            Wait(100)
                            if (GetSelectedPedWeapon(PlayerPedId()) == `weapon_hackingdevice`) then
                                if (not DuiObject and not DuiHandle) then
                                    DuiObject, DuiHandle = CreateDUI()
                                end

                                Wait(1500)
                                if (DuiObject) then
                                    SendDuiMessage(DuiObject, json.encode({
                                        action = "toggleDui",
                                    }))

                                    SendDuiMessage(DuiObject, json.encode({
                                        action = "duiPassword",
                                        payload = tostring(RoomData.settings.password),
                                    }))
                                end
                            end
                        end

                        HideTextUI()
                        StartHackSequence()
                        break
                    end
                    ::skip::
                else
                    HideTextUI()
                end

                Wait(sleep)
            end
        end)
    end

    TriggerServerEvent('0r-houserobbery:client:syncRobberyData', {
        action = 'keypad',
        data = {}
    })

    TriggerServerEvent('0r-houserobbery:server:syncRobberyData', {
        action = 'showTasks',
        data = {
            task = 'hack_keypad'
        }
    })

    ShowTasks('hack_keypad')
end)

RegisterNetEvent('0r-houserobbery:client:deliverRobberyVehicle')
AddEventHandler('0r-houserobbery:client:deliverRobberyVehicle', function()
    if DoesBlipExist(ScriptCache['blips']['robbery_house']) then
        RemoveBlip(ScriptCache['blips']['robbery_house'])
    end

    ScriptCache['blips']['robbery_house'] = nil

    local carDealer = Config.HeistCarPeds[math.random(1, #Config.HeistCarPeds)]

    if ScriptCache['blips'] and not ScriptCache['blips']['deliver_car'] then
        ScriptCache['blips']['deliver_car'] = nil

        local blip = CreateBlipForRobbery({
            coords = carDealer.coords.ped,
            sprite = Config.BlipSettings['illegal_vehicle_dealer'].id,
            color = Config.BlipSettings['illegal_vehicle_dealer'].color,
            scale = Config.BlipSettings['illegal_vehicle_dealer'].scale,
            name = Config.BlipSettings['illegal_vehicle_dealer'].name,
        })

        ScriptCache['blips']['deliver_car'] = blip
    end

    if ScriptCache['peds'] and not ScriptCache['peds']['deliver_car'] then
        lib.requestModel(carDealer.model)

        local ped = CreatePed(0, carDealer.model, carDealer.coords.ped.x, carDealer.coords.ped.y,
            carDealer.coords.ped.z - 1, carDealer.coords.ped.w, false, false)
        FreezeEntityPosition(ped, true)
        SetEntityInvincible(ped, true)
        SetBlockingOfNonTemporaryEvents(ped, true)
        SetModelAsNoLongerNeeded(ped)

        ScriptCache['peds']['deliver_car'] = ped
    end

    ShowTasks('deliver_vehicle')

    TriggerServerEvent('0r-houserobbery:server:syncRobberyData', {
        action = 'showTasks',
        data = {
            task = 'deliver_vehicle'
        }
    })

    TriggerServerEvent('0r-houserobbery:server:syncRobberyData', {
        action = 'deliverVehicleBlip',
        data = {
            coords = carDealer.coords.ped,
        }
    })

    local playerPed = PlayerPedId()
    CreateThread(function()
        while true do
            local sleep = 1000
            local pedCoords = GetEntityCoords(playerPed)
            local distance = #(pedCoords - vector3(carDealer.coords.ped.x, carDealer.coords.ped.y, carDealer.coords.ped.z))

            if (distance < 2.5) then
                sleep = 0
                ShowTextUI('[E] ' .. Locales[Config.Locale]['Lua']['open_illegal_vehicle_dealer'])
                if IsControlJustPressed(0, 38) then
                    local alert = lib.alertDialog({
                        header = Locales[Config.Locale]['Lua']['illegal_vehicle_dealer'],
                        content = Locales[Config.Locale]['Lua']['deliver_vehicle_message'],
                        centered = true,
                        cancel = true
                    })

                    if (alert == 'cancel') then
                        goto skip
                    end

                    if (alert == 'confirm') then
                        local targetVehicle = NetToVeh(RoomData.settings.heistCar.netId)

                        if not DoesEntityExist(targetVehicle) then
                            goto skip
                        end

                        local distance = #(GetEntityCoords(targetVehicle) - GetEntityCoords(PlayerPedId()))

                        if distance > 10.0 then
                            Notify.SendNotify(Locales[Config.Locale]['Lua']['far_away_from_vehicle'], 'error', 5000)
                            goto skip
                        end

                        if ScriptCache['blips'] and ScriptCache['blips']['deliver_car'] then
                            RemoveBlip(ScriptCache['blips']['deliver_car'])
                        end

                        ScriptCache['blips']['deliver_car'] = nil

                        TaskLeaveAnyVehicle(PlayerPedId())

                        TriggerServerEvent('0r-houserobbery:server:syncRobberyData', {
                            action = 'leaveVehicle',
                            data = {}
                        })

                        Wait(2000)

                        DeleteVehicle(targetVehicle)

                        Notify.SendNotify(Locales[Config.Locale]['Lua']['delivered_vehicle'], 'success', 5000)

                        ResetRobbery()
                        HideTextUI()
                        break
                    end
                end
                ::skip::
            else
                HideTextUI()
            end

            Wait(sleep)
        end
    end)
end)

RegisterNetEvent('0r-houserobbery:client:resetRobbery')
AddEventHandler('0r-houserobbery:client:resetRobbery', function()
    if (ScriptCache['peds'] and ScriptCache['peds']['car_dealer']) then
        DeleteEntity(ScriptCache['peds']['car_dealer'])
        ScriptCache['peds']['car_dealer'] = nil
    end

    if (ScriptCache['blips'] and ScriptCache['blips']['car_dealer']) then
        RemoveBlip(ScriptCache['blips']['car_dealer'])
        ScriptCache['blips']['car_dealer'] = nil
    end

    ResetRobbery()
end)

RegisterNetEvent('0r-houserobbery:client:resetHandObject')
AddEventHandler('0r-houserobbery:client:resetHandObject', function(objects)
    if (objects and next(objects)) then
        for k, v in pairs(objects) do
            if v.netId then
                local object = NetToObj(v.netId)

                if DoesEntityExist(object) then
                    SetEntityAsMissionEntity(object, true, true)
                    DeleteObject(object)
                end
            end

            if v.object then
                if DoesEntityExist(v.object) then
                    SetEntityAsMissionEntity(v.object, true, true)
                    DeleteObject(v.object)
                end
            end
        end
    end
end)

RegisterNetEvent('0r-houserobbery:client:finishRobbery')
AddEventHandler('0r-houserobbery:client:finishRobbery', function()
    NuiMessage('task')
end)
