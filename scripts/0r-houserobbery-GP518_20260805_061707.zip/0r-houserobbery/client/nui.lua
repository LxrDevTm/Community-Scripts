

RegisterNUICallback('nuiChecked', function(data, cb)
    SendNUIMessage({
        action = 'setConfig',
        payload = {
            Locations = Config.RobberyLocation,
            Locales = Locales[Config.Locale].Web,
        }
    })
    cb('ok')
end)

RegisterNUICallback('nuiReady', function(data, cb)
    NuiLoaded = true
    print('NUI Loaded!')
    cb('ok')
end)

RegisterNUICallback('closeUi', function(data, cb)
    StopTabletAnim()
    SetNuiFocus(false, false)
    TaskNUI = false
    cb('ok')
end)

RegisterNUICallback('sendInvite', function(data, cb)
    TriggerServerEvent('0r-houserobbery:server:sendInvite', data.playerId)
    cb('ok')
end)

RegisterNUICallback('setNickname', function(data, cb)
    TriggerServerEvent('0r-houserobbery:server:setNickname', data.nickname)
    cb('ok')
end)

RegisterNUICallback('declineInvite', function(data, cb)
    SetNuiFocus(false, false)
    StopTabletAnim()
    cb('ok')
end)

RegisterNUICallback('acceptInvite', function(data, cb)
    TriggerServerEvent('0r-houserobbery:server:addTeamMember', data.inviterData)

    SetNuiFocus(false, false)
    StopTabletAnim()
    cb('ok')
end)

RegisterNUICallback('kickMember', function(data, cb)
    TriggerServerEvent('0r-houserobbery:server:removeTeamMember', data)
    cb('ok')
end)

RegisterNUICallback('leaveTeam', function(data, cb)
    TriggerServerEvent('0r-houserobbery:server:leaveTeam')
    cb('ok')
end)

RegisterNUICallback('sendMessage', function(data, cb)
    TriggerServerEvent('0r-houserobbery:server:sendMessage', data.newMessage)
    cb('ok')
end)

RegisterNUICallback('duiReady', function(data, cb)
    IsDuiActive = true
    cb('ok')
end)

RegisterNUICallback('carType', function(type, cb)
    TriggerServerEvent('0r-houserobbery:server:selectCarType', type)
    cb('ok')
end)

RegisterNUICallback('startRobbery', function(data, cb)
    if Config.RobberyTimeRestriction then
        if GetClockHours() >= Config.RobberyEndTime and GetClockHours() < Config.RobberyStartTime then
            Notify.SendNotify(Locales[Config.Locale]['Lua']['enough_time'], 'error', 5000)
            cb('ok')
            return
        end
    end

    if Config.RobberyCooldown then
        lib.callback('0r-houserobbery:server:checkRobberyCooldown', 10000, function(isOnCooldown)
            if isOnCooldown then
                Notify.SendNotify(Locales[Config.Locale]['Lua']['cooldown'], 'error', 5000)
                cb('ok')
                return
            end

            if Config.PoliceOnDutyRequired > 0 then
                lib.callback('0r-houserobbery:server:checkPoliceCount', 10000, function(isEnoughPolice)
                    if isEnoughPolice then
                        Notify.SendNotify(Locales[Config.Locale]['Lua']['enough_police'], 'error', 5000)
                        cb('ok')
                        return
                    end

                    TriggerServerEvent('0r-houserobbery:server:startRobbery', data.id)
                    cb('ok')
                end)
            else
                TriggerServerEvent('0r-houserobbery:server:startRobbery', data.id)
                cb('ok')
            end
        end)
    else
        if Config.PoliceOnDutyRequired > 0 then
            lib.callback('0r-houserobbery:server:checkPoliceCount', 10000, function(isEnoughPolice)
                if isEnoughPolice then
                    Notify.SendNotify(Locales[Config.Locale]['Lua']['enough_police'], 'error', 5000)
                    cb('ok')
                    return
                end

                TriggerServerEvent('0r-houserobbery:server:startRobbery', data.id)
                cb('ok')
            end)
        else
            TriggerServerEvent('0r-houserobbery:server:startRobbery', data.id)
            cb('ok')
        end
    end
end)

local expiredTime = 0
RegisterNUICallback('taskTimeExpired', function (data, cb)
    expiredTime = expiredTime + 1

    if expiredTime >= 2 then
        TriggerEvent('0r-houserobbery:client:deleteRobberyVehicle')
        return
    end

    TriggerServerEvent('0r-houserobbery:server:taskTimeExpired')
    cb('ok')
end)

local Number = 0
RegisterNUICallback('minigameData', function (data, cb)
    if data then
        if data.hereIndex == data.defaultIndex then
            if Number >= 5 then
                SendDuiMessage(DuiObject, json.encode({
                    action = "showPassword",
                }))

                Notify.SendNotify(Locales[Config.Locale]['Lua']['successfully_hacked_keypad'], 'success', 5000)
                EnterPasswordDUI()

                Number = 0
            else
                SendDuiMessage(DuiObject, json.encode({
                    action = "randomColumn",
                }))
                Number = Number + 1
            end
        else
            SendDuiMessage(DuiObject, json.encode({
                action = "randomColumn",
            }))

            if Number >= 1 then
                Number = Number - 1
            else
                Number = 0
            end
        end
    end
    cb('ok')
end)

RegisterNUICallback('marketPlace', function(data, cb)
    if RoomData and RoomData.settings and RoomData.settings.startRobbery then
        return
    end

    Notify.SendNotify(Locales[Config.Locale]['Lua']['waypoint_marketplace'], 'error', 5000)

    SetNewWaypoint(Config.MarketPed.coords.x, Config.MarketPed.coords.y)

    cb('ok')
end)