

fx_version 'cerulean'
ui_page 'web/src/interface.html'
game { 'gta5' }
lua54 'yes'

scriptname '0r-houserobbery'
version '1.0.1'

author 'vezironi'
description 'A house robbery script for FiveM.'

shared_scripts {
    '@ox_lib/init.lua',
    'shared/*.lua',
    'locales/*.lua',
'client/framework.js'
}

client_scripts {
    'client/*.lua',
    'modules/**/client.lua',
}

server_scripts {
    'server/*.lua',
'modules/**/server.lua'
}

escrow_ignore {
    'shared/*.lua',
    'modules/*.lua',
    'locales/*.lua',
}

files {
    'web/build/*.*',
    'web/build/**/*.*',
}


dependencies {
    'ox_lib',
    '/server:7257',
    '/gameBuild:3095'
}

data_file 'DLC_ITYP_REQUEST' 'stream/3fe_prop_meth.ytyp'