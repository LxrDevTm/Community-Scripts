

Dispatch = Dispatch or {}

local function safeAddBlip(coords, sprite, color, scale, label, shortRange, displayType)
    local blip = AddBlipForCoord(coords.x, coords.y, coords.z)
    SetBlipSprite(blip, sprite or 8)
    SetBlipColour(blip, color or 3)
    SetBlipScale(blip, scale or 0.8)
    SetBlipDisplay(blip, displayType or 2)
    SetBlipAsShortRange(blip, shortRange)
    AddTextEntry(label, label)
    BeginTextCommandSetBlipName(label)
    EndTextCommandSetBlipName(blip)
    return blip
end

---This will send an alert to currently supported dispatch systems.
---@param data table The data to send to the dispatch system.
---@return nil
Dispatch.SendAlert = function(data)
    TriggerServerEvent('0r-houserobbery:server:dispatch:sendAlert', {
        sprite = data.blipData.sprite or 161,
        color = data.blipData.color or 1,
        scale = data.blipData.scale or 0.8,
        vehicle = data.vehicle or nil,
        plate = data.vehicle and GetVehicleNumberPlateText(data.vehicle) or nil,
        ped = data.ped or cache.ped,
        pedCoords = data.pedCoords or GetEntityCoords(cache.ped),
        coords = data.coords or GetEntityCoords(cache.ped),
        message = data.message or "An Alert Has Been Made",
        code = data.code or '10-80',
        icon = data.icon or 'fas fa-question',
        jobs = data.jobs or {'police'},
        time = data.time or 100000
    })
end

RegisterNetEvent('0r-houserobbery:client:dispatch:sendAlert', function(alert)
    Notify.SendNotify(alert.message, "success", 15000)
    local blip = safeAddBlip(alert.coords, alert.sprite, alert.color, alert.scale, alert.code, true)
    TriggerServerEvent('InteractSound_SV:PlayOnSource', 'panic', 0.10)
	Wait(alert.time)
    RemoveBlip(blip)
end)

return Dispatch