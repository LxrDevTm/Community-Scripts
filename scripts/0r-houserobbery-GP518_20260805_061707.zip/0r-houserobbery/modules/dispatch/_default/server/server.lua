Dispatch = Dispatch or {}

RegisterNetEvent("0r-houserobbery:server:dispatch:sendAlert", function(data)
    local jobs = data.jobs
    for _, name in pairs(jobs) do
        local activeJobPlayers = Framework.GetPlayersByJob(name)

        for _, src in pairs(activeJobPlayers) do
            TriggerClientEvent('0r-houserobbery:client:dispatch:sendAlert', src, data)
        end
    end
end)

return Dispatch