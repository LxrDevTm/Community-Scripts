

local botToken = 'MTM0NDY3MzIwMjQwMzU0MTA1Mg.G4fy44.WUzOmiCST6d0Opuqsw-x-BBvloKGGKlkZusTck'

local Avatars = {}

local FormattedToken = "Bot "..botToken

--- DiscordRequest()
--- @param method string: The HTTP method to use (GET, POST, etc.).
--- @param endpoint string: The Discord API endpoint to call.
--- @param jsondata table: The data to send in the request body.
--- @return table: The response data from the Discord API.
--- @description This function performs an HTTP request to the Discord API and returns the response data.
function DiscordRequest(method, endpoint, jsondata)
    local data = nil
    PerformHttpRequest("https://discordapp.com/api/"..endpoint, function(errorCode, resultData, resultHeaders)
        data = {data=resultData, code=errorCode, headers=resultHeaders}
    end, method, #jsondata > 0 and json.encode(jsondata) or "", {["Content-Type"] = "application/json", ["Authorization"] = FormattedToken})

    while data == nil do
        Citizen.Wait(0)
    end

    return data
end

--- GetDiscordAvatar()
--- @param user number: The user ID of the player.
--- @return string: The URL of the user's Discord avatar.
--- @description This function retrieves the Discord avatar URL for a given user ID.
function GetDiscordAvatar(user)
    local discordId = nil
    local imgURL = nil;
    for _, id in ipairs(GetPlayerIdentifiers(user)) do
        if string.match(id, "discord:") then
            discordId = string.gsub(id, "discord:", "")
            break
        end
    end
    if discordId then
        if Avatars[discordId] == nil then
            local endpoint = ("users/%s"):format(discordId)
            local member = DiscordRequest("GET", endpoint, {})

            if member.code == 200 then
                local data = json.decode(member.data)
                if data ~= nil and data.avatar ~= nil then
                    if (data.avatar:sub(1, 1) and data.avatar:sub(2, 2) == "_") then

                        imgURL = "https://media.discordapp.net/avatars/" .. discordId .. "/" .. data.avatar .. ".gif";
                    else
                        imgURL = "https://media.discordapp.net/avatars/" .. discordId .. "/" .. data.avatar .. ".png"
                    end
                end
            else
                print("Please make sure the botToken is correct")
                return false
            end
            Avatars[discordId] = imgURL;
        else
            imgURL = Avatars[discordId];
        end
    else
        print("Discord ID was not found : " ..GetPlayerName(user))
        return false
    end

    return imgURL;
end


--- SaveDatabase()
--- @param data table: The data to be saved to the database.
--- @return nil
--- @description This function saves the provided data to a JSON file in the resource's directory.
function SaveDatabase(data)
    SaveResourceFile(GetCurrentResourceName(), "database/index.json", json.encode(data, {indent = true}), -1)
end

--- CheckDistance()
--- @param source number: The source player ID.
--- @param coords vector3: The coordinates to check the distance against.
--- @param distance number: The maximum distance allowed.
--- @return boolean: True if the distance is less than or equal to the specified distance, false otherwise.
--- @description This function checks if the distance between two coordinates is within the specified limit.
function CheckDistance(source, coords, distance)
    local playerPed = GetPlayerPed(source)
    local playerCoords = GetEntityCoords(playerPed)
    local dist = math.floor(#(playerCoords - coords))
    if dist <= distance then
        return true
    else
        return false
    end
end