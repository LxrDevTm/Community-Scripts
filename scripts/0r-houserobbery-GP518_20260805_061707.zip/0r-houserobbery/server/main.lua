

local database = {}
local roomData = {}
local inLobby = {}
local cooldown = {}
local busyTiers = {}

CreateThread(function()
    local file = json.decode(LoadResourceFile(GetCurrentResourceName(), "database/index.json"))
    if file then
        for index, data in pairs(file) do
            database[index] = data
        end
    end
end)

while not Framework do
    Citizen.Wait(1000)
end

local function ResetHouseStateTimer(homeIndex)
    Config.RobberyLocation[homeIndex]['opened'] = false
    for _, v in pairs(Config.RobberyLocation[homeIndex]['loot']) do
        v['taken'] = false
        v['busy'] = false
    end
    TriggerClientEvent('0r-houserobbery:client:resetHouseState', -1, homeIndex)
end

Framework.RegisterUsableItem(Config.RobberyTabletItem.name, function(source, itemData)
    if Config.RobberyTabletItem.requiredItem.status then
        local hasItem = Framework.HasItem(Config.RobberyTabletItem.requiredItem.item[1])

        if not hasItem or hasItem < 1 then
            Notify.SendNotify(source, Locales[Config.Locale]['Lua']['required_item'], "error", 5000)
            return
        end
    end

    if Config.RobberyTabletItem.requiredJobs.status then
        local jobName = Framework.GetPlayerJob()

        if not Config.RobberyTabletItem.requiredJobs.jobs[jobName] then
            Notify.SendNotify(source, Locales[Config.Locale]['Lua']['required_job'], "error", 5000)
            return
        end
    end

    local identifier = Framework.GetPlayerIdentifier(source)
    local firstname, lastname = Framework.GetPlayerName(source)
    local profilePhoto = GetDiscordAvatar(source)
    local data = database[identifier]

    if inLobby[identifier] then
        TriggerClientEvent("0r-houserobbery:client:openHouseRobberyMenu", source, {
            roomData = roomData[inLobby[identifier].roomId],
            playerData = {
                source = source,
                photo = profilePhoto and profilePhoto or Config.DefaultProfilePhoto,
                name = data.fakename and data.fakename or firstname .. ' ' .. lastname,
                xp = data.xp,
            },
        })
        return
    end

    if identifier then
        if not roomData[identifier] then
            roomData[identifier] = {
                settings = {
                    ownerIdentifier = identifier,
                    ownerSrc = source,
                    startedRobbery = false,
                    heistHouse = nil,
                    heistCar = {
                        type = 'randomCar',
                        paid = false,
                        hash = nil,
                        netId = nil,
                        id = nil,
                        coords = {},
                    },
                    lock = nil,
                    cash = nil,
                    password = nil,
                    failed = false,
                    handObjects = {},
                },
                players = {
                    {
                        id = 1,
                        source = source,
                        photo = profilePhoto,
                        name = data.fakename and data.fakename or firstname .. ' ' .. lastname,
                        leader = true,
                        xp = data.xp,
                        inside = false,
                    },
                }
            }
        end

        inLobby[identifier] = {
            roomId = identifier,
        }
    else
        Notify.SendNotify(source, "Failed to assign room: invalid identifier.", "error", 5000)
    end

    TriggerClientEvent("0r-houserobbery:client:openHouseRobberyMenu", source, {
        roomData = roomData[identifier],
        playerData = {
            source = source,
            photo = profilePhoto,
            name = data.fakename and data.fakename or firstname .. ' ' .. lastname,
            xp = data.xp,
        },
    })
end)

Framework.RegisterUsableItem(Config.HeistBag.item, function(source, itemData)
    TriggerClientEvent("0r-houserobbery:client:openHeistBagMenu", source)
end)

AddEventHandler('onResourceStop', function(resourceName)
    if (GetCurrentResourceName() ~= resourceName) then return end

    for k, _ in pairs(roomData) do
        if roomData[k].settings.startedRobbery then
            if roomData[k].settings.heistCar.netId then
                local car = NetworkGetEntityFromNetworkId(roomData[k].settings.heistCar.netId)
                if DoesEntityExist(car) then
                    DeleteEntity(car)
                end
            end

            if roomData[k].settings.lock then
                local lock = NetworkGetEntityFromNetworkId(roomData[k].settings.lock)
                if DoesEntityExist(lock) then
                    DeleteEntity(lock)
                end
            end

            if roomData[k].settings.cash then
                local cash = NetworkGetEntityFromNetworkId(roomData[k].settings.cash)
                if DoesEntityExist(cash) then
                    DeleteEntity(cash)
                end
            end

            if roomData[k].settings.handObjects then
                for _, object in pairs(roomData[k].settings.handObjects) do
                    if object.netId then
                        local handObject = NetworkGetEntityFromNetworkId(object.netId)
                        if DoesEntityExist(handObject) then
                            DeleteEntity(handObject)
                        end
                    end

                    if object.object then
                        if DoesEntityExist(object.object) then
                            DeleteEntity(object.object)
                        end
                    end
                end
            end
        end
    end
end)

lib.callback.register('0r-houserobbery:callback:buyHeistCar', function(source)
    local xPlayer = Framework.GetPlayer(source)
    if not xPlayer then return false end

    local identifier = Framework.GetPlayerIdentifier(source)

    if not inLobby[identifier] then
        return false
    end

    local currentRoomData = roomData[inLobby[identifier].roomId]

    if currentRoomData.settings.ownerIdentifier ~= identifier then
        Notify.SendNotify(source, Locales[Config.Locale]['Lua']['not_owner_room'], "error", 5000)
        return false
    end

    if not currentRoomData.settings.startedRobbery then
        Notify.SendNotify(source, "You cannot buy a car before starting the robbery.", "error", 5000)
        return false
    end

    local carData = Config.HeistCar

    if not carData then
        Notify.SendNotify(source, "Invalid car data.", "error", 5000)
        return false
    end

    if Framework.GetAccountBalance(source, 'money') < carData.price then
        Notify.SendNotify(source, Locales[Config.Locale]['Lua']['enough_money'], "error", 5000)
        return false
    end

    if not Framework.RemoveAccountBalance(source, 'money', carData.price) then
        Notify.SendNotify(source, "Failed to remove money from your account.", "error", 5000)
        return false
    end

    roomData[identifier].settings.heistCar.paid = true
    roomData[identifier].settings.heistCar.hash = carData.hash
    roomData[identifier].settings.heistCar.netId = nil

    for _, player in pairs(currentRoomData.players) do
        TriggerClientEvent("0r-houserobbery:client:refreshRoomData", player.source, currentRoomData)
    end

    TriggerClientEvent("0r-houserobbery:client:buyHeistCar", source)
    return true
end)

lib.callback.register('0r-houserobbery:server:checkRobberyCooldown', function(source)
    local xPlayer = Framework.GetPlayer(source)
    if not xPlayer then return false end

    local identifier = Framework.GetPlayerIdentifier(source)

    if not identifier then return false end

    if cooldown[identifier] and cooldown[identifier].time > os.time() then
        return true
    end

    return false
end)

local CooldownTimer = GetGameTimer()
local LastControlCount = {}

lib.callback.register('0r-houserobbery:server:checkPoliceCount', function(source)
    local xPlayer = Framework.GetPlayer(source)
    if not xPlayer then return 0 end

    if CooldownTimer + 60 * 1000 < GetGameTimer() then
        CooldownTimer = GetGameTimer()
    else
        if LastControlCount and #LastControlCount > 0 then
            if #LastControlCount < Config.PoliceOnDutyRequired then
                return true
            end

            return false
        end

        return true
    end

    LastControlCount = Framework.GetPlayersByJob(Config.PoliceJobName)

    if not LastControlCount or #LastControlCount == 0 then
        return true
    end

    if #LastControlCount < Config.PoliceOnDutyRequired then
        return true
    end

    return false
end)

RegisterNetEvent('0r-houserobbery:server:scriptStarted')
AddEventHandler('0r-houserobbery:server:scriptStarted', function()
    local CitizenID = Framework.GetPlayerIdentifier(source)

    if not CitizenID then return end

    if not database[CitizenID] then
        database[CitizenID] = {
            xp = 5000,
            fakename = false,
        }
    end

    SaveDatabase(database)
end)

RegisterNetEvent('0r-houserobbery:server:setNickname')
AddEventHandler('0r-houserobbery:server:setNickname', function(nickname)
    local xPlayer = Framework.GetPlayer(source)
    if not xPlayer then return end

    local identifier = Framework.GetPlayerIdentifier(source)

    if not database[identifier] then
        Notify.SendNotify(source, "Failed to set nickname: invalid identifier.", "error", 5000)
        return
    end

    database[identifier].fakename = nickname

    SaveDatabase(database)

    if inLobby[identifier] then
        local currentRoomData = roomData[inLobby[identifier].roomId]

        for _, player in pairs(currentRoomData.players) do
            if player.source == source then
                currentRoomData.players[_].name = nickname
                break
            end
        end

        for _, player in pairs(currentRoomData.players) do
            TriggerClientEvent("0r-houserobbery:client:refreshTeamList", player.source, currentRoomData.players)
            TriggerClientEvent("0r-houserobbery:client:refreshRoomData", player.source, currentRoomData)
        end
    end
end)

RegisterNetEvent('0r-houserobbery:server:sendInvite')
AddEventHandler('0r-houserobbery:server:sendInvite', function(targetId)
    local xPlayer = Framework.GetPlayer(source)
    if not xPlayer then return end

    local tPlayer = Framework.GetPlayer(targetId)
    if not tPlayer then return end

    local identifier = Framework.GetPlayerIdentifier(source)

    if source == targetId then
        Notify.SendNotify(source, Locales[Config.Locale]['Lua']['cannot_send_invite_yourself'], "error", 5000)
        return
    end

    if not roomData[identifier] then
        return
    end

    local currentRoomData = roomData[identifier]

    for _, player in pairs(currentRoomData.players) do
        if player.source == targetId then
            Notify.SendNotify(source, Locales[Config.Locale]['Lua']['already_in_team'], "error", 5000)
            return
        end
    end

    if currentRoomData.settings.ownerIdentifier ~= identifier then
        Notify.SendNotify(source, Locales[Config.Locale]['Lua']['not_owner_room'], "error", 5000)
        return
    end

    if currentRoomData.settings.startedRobbery then
        Notify.SendNotify(source, Locales[Config.Locale]['Lua']['cannot_started_robbery'], "error", 5000)
        return
    end

    local xPed = GetPlayerPed(source)
    local tPed = GetPlayerPed(targetId)
    local xPlayerCoords = GetEntityCoords(xPed)
    local tPlayerCoords = GetEntityCoords(tPed)

    local distance = #(xPlayerCoords - tPlayerCoords)

    if distance > 5.0 then
        Notify.SendNotify(source, Locales[Config.Locale]['Lua']['far_away_from_player'], "error", 5000)
        return
    end

    local profilePhoto = GetDiscordAvatar(source)
    local firstname, lastname = Framework.GetPlayerName(source)
    TriggerClientEvent('0r-houserobbery:client:sendInvite', targetId, {
        identifier = identifier,
        source = source,
        name = database[identifier].fakename and database[identifier].fakename or firstname .. ' ' .. lastname,
        photo = profilePhoto and profilePhoto or Config.DefaultProfilePhoto,
    })
end)

RegisterNetEvent('0r-houserobbery:server:removeTeamMember')
AddEventHandler('0r-houserobbery:server:removeTeamMember', function(data)
    if not source then return end

    local xPlayer = Framework.GetPlayer(source)
    if not xPlayer then return end

    local tPlayer = Framework.GetPlayer(data.source)
    if not tPlayer then return end

    local identifier = Framework.GetPlayerIdentifier(source)
    local tIdentifier = Framework.GetPlayerIdentifier(data.source)

    if not roomData[identifier] then
        return
    end

    local currentRoomData = roomData[identifier]

    if currentRoomData.settings.ownerIdentifier ~= identifier then
        Notify.SendNotify(source, Locales[Config.Locale]['Lua']['not_owner_room'], "error", 5000)
        return
    end

    if currentRoomData.settings.startedRobbery then
        Notify.SendNotify(source, Locales[Config.Locale]['Lua']['cannot_started_robbery'], "error", 5000)
        return
    end

    local xPed = GetPlayerPed(source)
    local tPed = GetPlayerPed(data.source)
    local xPlayerCoords = GetEntityCoords(xPed)
    local tPlayerCoords = GetEntityCoords(tPed)

    local distance = #(xPlayerCoords - tPlayerCoords)

    if distance > 5.0 then
        Notify.SendNotify(source, Locales[Config.Locale]['Lua']['far_away_from_player'], "error", 5000)
        return
    end

    local newPlayers = {}
    for _, player in pairs(currentRoomData.players) do
        if player.source ~= data.source then
            newPlayers[#newPlayers + 1] = player
        end
    end
    roomData[identifier].players = newPlayers

    for _, player in pairs(roomData[identifier].players) do
        TriggerClientEvent("0r-houserobbery:client:refreshTeamList", player.source, roomData[identifier].players)
        TriggerClientEvent("0r-houserobbery:client:refreshRoomData", player.source, roomData[identifier])
    end

    if tIdentifier then
        inLobby[tIdentifier] = nil
    else
        Notify.SendNotify(source, "Failed to remove team member: invalid identifier.", "error", 5000)
    end

    TriggerEvent('0r-houserobbery:server:kickedRoom', data.source)
end)

RegisterNetEvent('0r-houserobbery:server:addTeamMember')
AddEventHandler('0r-houserobbery:server:addTeamMember', function(data)
    local src = source
    if not src then return end

    local xPlayer = Framework.GetPlayer(data.source)
    if not xPlayer then return end

    local tPlayer = Framework.GetPlayer(src)
    if not tPlayer then return end

    local identifier = Framework.GetPlayerIdentifier(data.source)
    local tIdentifier = Framework.GetPlayerIdentifier(src)

    local xPed = GetPlayerPed(data.source)
    local tPed = GetPlayerPed(src)
    local xPlayerCoords = GetEntityCoords(xPed)
    local tPlayerCoords = GetEntityCoords(tPed)

    local distance = #(xPlayerCoords - tPlayerCoords)

    if distance > 5.0 then
        Notify.SendNotify(data.source, Locales[Config.Locale]['Lua']['far_away_from_player'], "error", 5000)
        return
    end

    if not roomData[identifier] then
        return
    end

    local currentRoomData = roomData[identifier]

    if currentRoomData.settings.ownerIdentifier ~= data.identifier then
        Notify.SendNotify(data.source, Locales[Config.Locale]['Lua']['not_owner_room'], "error", 5000)
        return
    end

    for _, player in pairs(currentRoomData.players) do
        if player.source == src then
            return
        end
    end

    local profilePhoto = GetDiscordAvatar(src)
    local firstname, lastname = Framework.GetPlayerName(src)
    roomData[identifier].players[#roomData[identifier].players + 1] = {
        id = #roomData[identifier].players + 1,
        source = source,
        photo = profilePhoto and profilePhoto or Config.DefaultProfilePhoto,
        name = database[tIdentifier].fakename and database[tIdentifier].fakename or firstname .. ' ' .. lastname,
        leader = false,
        xp = database[tIdentifier].xp,
        inside = false,
    }

    if tIdentifier then
        inLobby[tIdentifier] = {
            roomId = identifier,
        }
    else
        Notify.SendNotify(source, "Failed to add team member: invalid identifier.", "error", 5000)
    end

    for _, player in pairs(roomData[identifier].players) do
        TriggerClientEvent("0r-houserobbery:client:refreshTeamList", player.source, roomData[identifier].players)
        TriggerClientEvent("0r-houserobbery:client:refreshRoomData", player.source, roomData[identifier])
    end
end)

RegisterNetEvent('0r-houserobbery:server:leaveTeam')
AddEventHandler('0r-houserobbery:server:leaveTeam', function()
    if not source then return end

    local xPlayer = Framework.GetPlayer(source)
    if not xPlayer then return end

    local identifier = Framework.GetPlayerIdentifier(source)
    local inLobbyData = inLobby[identifier]

    if not inLobbyData or not inLobbyData.roomId then
        Notify.SendNotify(source, Locales[Config.Locale]['Lua']['not_in_team'], "error", 5000)
        return
    end

    local currentRoomData = roomData[inLobbyData.roomId]

    if currentRoomData.settings.startedRobbery then
        Notify.SendNotify(source, Locales[Config.Locale]['Lua']['cannot_started_robbery'], "error", 5000)
        return
    end

    local isLeader = false
    for _, player in pairs(currentRoomData.players) do
        if player.source == source and player.leader then
            isLeader = true
            break
        end
    end

    if isLeader then
        for _, player in pairs(currentRoomData.players) do
            local pSrc = player.source
            local pIdentifier = Framework.GetPlayerIdentifier(pSrc)
            local firstname, lastname = Framework.GetPlayerName(pSrc)
            local profilePhoto = GetDiscordAvatar(pSrc)
            local data = database[pIdentifier]

            if pIdentifier then
                roomData[pIdentifier] = {
                    settings = {
                        ownerIdentifier = pIdentifier,
                        ownerSrc = pSrc,
                        startedRobbery = false,
                        heistHouse = nil,
                        heistCar = {
                            type = 'randomCar',
                            paid = false,
                            hash = nil,
                            netId = nil,
                            id = nil,
                            coords = {},
                        },
                        lock = nil,
                        cash = nil,
                        password = nil,
                        failed = false,
                        handObjects = {},
                    },
                    players = {
                        {
                            id = 1,
                            source = pSrc,
                            photo = profilePhoto and profilePhoto or Config.DefaultProfilePhoto,
                            name = data.fakename and data.fakename or firstname .. ' ' .. lastname,
                            leader = true,
                            xp = data.xp,
                            inside = false,
                        },
                    }
                }

                inLobby[pIdentifier] = {
                    roomId = pIdentifier,
                }

                TriggerClientEvent("0r-houserobbery:client:refreshTeamList", pSrc, roomData[pIdentifier].players)
                TriggerClientEvent("0r-houserobbery:client:refreshRoomData", pSrc, roomData[pIdentifier])
            end
        end

        roomData[inLobbyData.roomId] = nil

        local firstname, lastname = Framework.GetPlayerName(source)

        roomData[identifier] = {
            settings = {
                ownerIdentifier = identifier,
                ownerSrc = source,
                startedRobbery = false,
                heistHouse = nil,
                heistCar = {
                    type = 'randomCar',
                    paid = false,
                    hash = nil,
                    netId = nil,
                    id = nil,
                    coords = {},
                },
                lock = nil,
                cash = nil,
                password = nil,
                failed = false,
                handObjects = {},
            },
            players = {
                {
                    id = 1,
                    source = source,
                    photo = GetDiscordAvatar(source) or Config.DefaultProfilePhoto,
                    name = database[identifier].fakename and database[identifier].fakename or firstname .. ' ' .. lastname,
                    leader = true,
                    xp = database[identifier].xp,
                    inside = false,
                },
            }
        }
    else
        for index, player in pairs(currentRoomData.players) do
            if player.source == source then
                table.remove(currentRoomData.players, index)
                break
            end
        end

        for _, player in pairs(currentRoomData.players) do
            TriggerClientEvent("0r-houserobbery:client:refreshTeamList", player.source, currentRoomData.players)
            TriggerClientEvent("0r-houserobbery:client:refreshRoomData", player.source, currentRoomData)
        end
    end

    if not identifier then return end

    inLobby[identifier] = {
        roomId = identifier,
    }
end)

RegisterNetEvent('0r-houserobbery:server:kickedRoom')
AddEventHandler('0r-houserobbery:server:kickedRoom', function(source)
    local identifier = Framework.GetPlayerIdentifier(source)

    if not identifier then return end

    local firstname, lastname = Framework.GetPlayerName(source)
    local profilePhoto = GetDiscordAvatar(source)
    local data = database[identifier]

    roomData[identifier] = {
        settings = {
            ownerIdentifier = identifier,
            ownerSrc = source,
            startedRobbery = false,
            heistHouse = nil,
            heistCar = {
                type = 'randomCar',
                paid = false,
                hash = nil,
                netId = nil,
                id = nil,
                coords = {},
            },
            lock = nil,
            cash = nil,
            password = nil,
            failed = false,
            handObjects = {},
        },
        players = {
            {
                id = 1,
                source = source,
                photo = profilePhoto and profilePhoto or Config.DefaultProfilePhoto,
                name = data.fakename and data.fakename or firstname .. ' ' .. lastname,
                leader = true,
                xp = data.xp,
                inside = false,
            },
        }
    }

    inLobby[identifier] = {
        roomId = identifier,
    }

    TriggerClientEvent("0r-houserobbery:client:refreshTeamList", source, roomData[identifier].players)
    TriggerClientEvent("0r-houserobbery:client:refreshRoomData", source, roomData[identifier])
end)

RegisterNetEvent('0r-houserobbery:server:sendMessage')
AddEventHandler('0r-houserobbery:server:sendMessage', function(data)
    local xPlayer = Framework.GetPlayer(source)
    if not xPlayer then return end

    TriggerClientEvent("0r-houserobbery:client:receiveMessage", -1, data)
end)

RegisterNetEvent('0r-houserobbery:server:setHouseState', function(index, state)
    local identifier = Framework.GetPlayerIdentifier(source)

    if not identifier then return end

    local data = roomData[inLobby[identifier].roomId]

    if not data then return end
    if not data.settings.startedRobbery then return end

    Config.RobberyLocation[index]['opened'] = state

    TriggerClientEvent('0r-houserobbery:client:setHouseState', -1, index, state)
end)

RegisterNetEvent('0r-houserobbery:server:setLootStateBusy', function(index, k, state)
    local identifier = Framework.GetPlayerIdentifier(source)

    if not identifier then return end

    local data = roomData[inLobby[identifier].roomId]

    if not data then return end
    if not data.settings.startedRobbery then return end

    Config.RobberyLocation[index]['loot'][k].busy = state

    TriggerClientEvent('0r-houserobbery:client:setLootStateBusy', -1, index, k, state)
end)

RegisterNetEvent('0r-houserobbery:server:setLootUsed', function(index, k, object)
    local identifier = Framework.GetPlayerIdentifier(source)

    if not identifier then return end

    local data = roomData[inLobby[identifier].roomId]

    if not data then return end
    if not data.settings.startedRobbery then return end

    Config.RobberyLocation[index]['loot'][k].taken = true
    TriggerClientEvent('0r-houserobbery:client:setLootState', -1, index, k, true, object)

    Wait(1000 * 60 * Config.TimeToResetItem)

    Config.RobberyLocation[index]['loot'][k].taken = false
    TriggerClientEvent('0r-houserobbery:client:setLootState', -1, index, k, false)
end)

RegisterNetEvent('0r-houserobbery:server:setEnterHouse', function(state)
    local identifier = Framework.GetPlayerIdentifier(source)
    if not identifier then return end

    local roomId = inLobby[identifier].roomId

    if not roomId or not roomData[roomId] then return end

    local currentRoomData = roomData[roomId]

    if not currentRoomData.settings.startedRobbery then return end

    local me = nil

    for _, player in pairs(currentRoomData.players) do
        if player.source == source then
            me = _
            break
        end
    end

    if not me then return end

    if not currentRoomData.players[me] then
        return
    end

    roomData[roomId].players[me].inside = state

    for _, player in pairs(currentRoomData.players) do
        TriggerClientEvent("0r-houserobbery:client:refreshRoomData", player.source, currentRoomData)
    end
end)

RegisterNetEvent('0r-houserobbery:server:syncRobberyData')
AddEventHandler('0r-houserobbery:server:syncRobberyData', function(self)
    local xPlayer = Framework.GetPlayer(source)
    if not xPlayer then return end

    local identifier = Framework.GetPlayerIdentifier(source)

    if not inLobby[identifier] then
        Notify.SendNotify(source, Locales[Config.Locale]['Lua']['not_in_team'], "error", 5000)
        return
    end

    local currentRoomData = roomData[inLobby[identifier].roomId]

    if self.action == 'startRobbery' then
        roomData[inLobby[identifier].roomId].settings.heistCar.coords = self.data.spawnCoords
    end

    if self.action == 'buyHeistCar' then
        roomData[inLobby[identifier].roomId].settings.heistCar.netId = self.data.netId
        roomData[inLobby[identifier].roomId].settings.heistCar.id = self.data.id
        roomData[inLobby[identifier].roomId].settings.heistCar.coords = nil
    end

    if self.action == 'netIdObject' then
        roomData[inLobby[identifier].roomId].settings.lock = self.data.netId
    end

    if self.action == 'cashNetId' then
        roomData[inLobby[identifier].roomId].settings.cash = self.data.netId
    end

    if self.action == 'handObject' then
        roomData[inLobby[identifier].roomId].settings.handObjects = self.data.objects
    end

    for _, player in pairs(currentRoomData.players) do
        TriggerClientEvent("0r-houserobbery:client:refreshRoomData", player.source, currentRoomData)
        if player.source ~= source then
            TriggerClientEvent("0r-houserobbery:client:syncRobberyData", player.source, self.action, self.data)
        end
    end
end)

RegisterNetEvent('0r-houserobbery:server:selectCarType')
AddEventHandler('0r-houserobbery:server:selectCarType', function(type)
    local xPlayer = Framework.GetPlayer(source)
    if not xPlayer then return end

    local identifier = Framework.GetPlayerIdentifier(source)

    if not inLobby[identifier] then
        Notify.SendNotify(source, Locales[Config.Locale]['Lua']['not_in_team'], "error", 5000)
        return
    end

    local currentRoomData = roomData[inLobby[identifier].roomId]

    if currentRoomData.settings.ownerIdentifier ~= identifier then
        return
    end

    if currentRoomData.settings.startedRobbery then
        return
    end

    roomData[identifier].settings.heistCar.type = type

    for _, player in pairs(currentRoomData.players) do
        TriggerClientEvent("0r-houserobbery:client:refreshRoomData", player.source, currentRoomData)
    end

    TriggerClientEvent("0r-houserobbery:client:selectCarType", source, type)
end)

RegisterNetEvent('0r-houserobbery:server:startRobbery')
AddEventHandler('0r-houserobbery:server:startRobbery', function(index)
    local xPlayer = Framework.GetPlayer(source)
    if not xPlayer then return end

    local identifier = Framework.GetPlayerIdentifier(source)

    if not inLobby[identifier] then
        return
    end

    local currentRoomData = roomData[inLobby[identifier].roomId]

    if currentRoomData.settings.ownerIdentifier ~= identifier then
        Notify.SendNotify(source, Locales[Config.Locale]['Lua']['not_owner_room'], "error", 5000)
        return
    end

    if currentRoomData.settings.startedRobbery then
        return
    end

    local house = Config.RobberyLocation[index]

    if busyTiers[house.tier] then
        Notify.SendNotify(source, Locales[Config.Locale]['Lua']['tier_busy'], "error", 5000)
        return
    end

    roomData[identifier].settings.startedRobbery = true
    roomData[identifier].settings.heistHouse = index
    roomData[identifier].settings.password = math.random(100000, 999999)

    for _, player in pairs(currentRoomData.players) do
        TriggerClientEvent("0r-houserobbery:client:refreshRoomData", player.source, currentRoomData)
    end

    TriggerClientEvent("0r-houserobbery:client:startRobbery", source)
    local house = Config.RobberyLocation[index]
    busyTiers[house.tier] = true
end)

RegisterNetEvent('0r-houserobbery:server:collectLoot')
AddEventHandler('0r-houserobbery:server:collectLoot', function(index, k)
    if not source then return end

    local src = source
    local xPlayer = Framework.GetPlayer(src)
    if not xPlayer then return end

    local identifier = Framework.GetPlayerIdentifier(src)

    if not inLobby[identifier] then
        Notify.SendNotify(src, Locales[Config.Locale]['Lua']['not_in_team'], "error", 5000)
        return
    end

    local currentRoomData = roomData[inLobby[identifier].roomId]

    if not currentRoomData.settings.startedRobbery then
        return
    end

    local house = Config.RobberyLocation[index]

    if not house then
        Notify.SendNotify(src, "Invalid house data.", "error", 5000)
        return
    end

    local loot = house['loot'][k]

    if loot.taken then
        Notify.SendNotify(src, Locales[Config.Locale]['Lua']['already_taken'], "error", 5000)
        return
    end

    local lootCoords = loot.props and loot.props.place.coords or loot.prop.coords

    if not CheckDistance(src, lootCoords, 4.0) then
        Notify.SendNotify(src, Locales[Config.Locale]['Lua']['far_away_from_loot'], "error", 5000)
        return
    end

    if loot.type == 'chest' then
        local cashChance = math.random(1, 100)
        local cashAmount = math.random(Config.MoneySettings.min, Config.MoneySettings.max)

        local itemCount = math.random(0, 3)

        if itemCount > 0 then
            local availableItems = Config.ChestRewards[house.tier][loot.furniture]

            if cashChance <= Config.MoneySettings.chance then
                if Config.MoneySettings.item.cashItem then
                    Inventory.AddItem(src, Config.MoneySettings.item.name, cashAmount)
                else
                    Framework.AddAccountBalance(src, 'money', cashAmount)
                end

                Notify.SendNotify(src, string.format(Locales[Config.Locale]['Lua']['found_dolar_in_chest'], cashAmount), "success", 5000)
            end

            for _ = 1, itemCount do
                local selectedItem = availableItems[math.random(1, #availableItems)]
                local amount = math.random(selectedItem.min, selectedItem.max)

                Inventory.AddItem(src, selectedItem.item, amount)
                Wait(500)
            end
        else
            Notify.SendNotify(src, Locales[Config.Locale]['Lua']['not_found_in_chest'], "error", 5000)
            return
        end
    elseif loot.type == 'item' or loot.type == 'art' then
        if type(loot.item) == 'table' and loot.item[1] ~= nil then
            for _, item in pairs(loot.item) do
                local amount = item.amount or 1

                if item.random then
                    amount = math.random(item.min, item.max)
                end

                Inventory.AddItem(src, item.name, amount)
            end
        else
            local amount = loot.item.amount or 1

            if loot.item.random then
                amount = math.random(loot.item.min, loot.item.max)
            end

            Inventory.AddItem(src, loot.item.name, amount)
        end
    elseif loot.type == 'money' then
        local cash = NetworkGetEntityFromNetworkId(currentRoomData.settings.cash)

        if DoesEntityExist(cash) then
            DeleteEntity(cash)
        end

        local cashAmount = 0

        if loot.item.random then
            cashAmount = math.random(loot.item.min, loot.item.max)
        else
            cashAmount = loot.item.amount
        end

        if Config.MoneySettings.item.cashItem then
            Inventory.AddItem(src, Config.MoneySettings.item.name, cashAmount)
        else
            Framework.AddAccountBalance(src, 'money', cashAmount)
        end

        Notify.SendNotify(source, string.format(Locales[Config.Locale]['Lua']['fount_dolar'], cashAmount), "success", 5000)
    elseif loot.type == 'cabinet' then
        if loot.item then
            if type(loot.item) == 'table' and loot.item[1] ~= nil then
                for _, item in pairs(loot.item) do
                    local amount = item.amount or 1

                    if item.random then
                        amount = math.random(item.min, item.max)
                    end

                    Inventory.AddItem(src, item.name, amount)
                end
            else
                local amount = loot.item.amount or 1

                if loot.item.random then
                    amount = math.random(loot.item.min, loot.item.max)
                end

                Inventory.AddItem(src, loot.item.name, amount)
            end
        else
            local cashChance = math.random(1, 100)
            local cashAmount = math.random(Config.MoneySettings.min, Config.MoneySettings.max)

            local itemCount = math.random(0, 3)

            if itemCount > 0 then
                local availableItems = Config.ChestRewards[house.tier][loot.furniture]

                if cashChance <= Config.MoneySettings.chance then
                    if Config.MoneySettings.item.cashItem then
                        Inventory.AddItem(src, Config.MoneySettings.item.name, cashAmount)
                    else
                        Framework.AddAccountBalance(src, 'money', cashAmount)
                    end

                    Notify.SendNotify(src, string.format(Locales[Config.Locale]['Lua']['found_dolar_in_chest'], cashAmount), "success", 5000)
                end

                for _ = 1, itemCount do
                    local selectedItem = availableItems[math.random(1, #availableItems)]
                    local amount = math.random(selectedItem.min, selectedItem.max)

                    Inventory.AddItem(src, selectedItem.item, amount)
                    Wait(500)
                end
            else
                Notify.SendNotify(src, Locales[Config.Locale]['Lua']['not_found_in_chest'], "error", 5000)
                return
            end
        end
    elseif loot.type == 'safe' then
        local itemCount = math.random(1, 3)
        local availableItems = Config.ChestRewards[house.tier][loot.furniture]

        if itemCount > 1 then
            for _ = 1, itemCount do
                local selectedItem = availableItems[math.random(1, #availableItems)]
                local amount = math.random(selectedItem.min, selectedItem.max)

                if selectedItem.item == Config.MoneySettings.item.name then
                    if Config.MoneySettings.item.cashItem then
                        Inventory.AddItem(src, Config.MoneySettings.item.name, amount)
                    else
                        Framework.AddAccountBalance(src, selectedItem.item, amount)
                    end
                else
                    Inventory.AddItem(src, selectedItem.item, amount)
                end
                Wait(500)
            end

            Notify.SendNotify(src, string.format(Locales[Config.Locale]['Lua']['found_items_in_safe'], itemCount), "success", 5000)
        else
            local selectedItem = availableItems[math.random(1, #availableItems)]
            local amount = math.random(selectedItem.min, selectedItem.max)

            if selectedItem.item == Config.MoneySettings.item.name then
                if Config.MoneySettings.item.cashItem then
                    Inventory.AddItem(src, Config.MoneySettings.item.name, amount)
                else
                    Framework.AddAccountBalance(src, selectedItem.item, amount)
                end

                Notify.SendNotify(src, string.format(Locales[Config.Locale]['Lua']['found_dolar_in_safe'], amount), "success", 5000)
            else
                Inventory.AddItem(src, selectedItem.item, amount)

                Notify.SendNotify(src, string.format(Locales[Config.Locale]['Lua']['found_item_in_safe'], amount, selectedItem.item), "success", 5000)
            end
        end
    end
end)

RegisterNetEvent('0r-houserobbery:server:finishRobbery')
AddEventHandler('0r-houserobbery:server:finishRobbery', function(objectAmount, carObjects)
    if not source then return end

    local xPlayer = Framework.GetPlayer(source)
    if not xPlayer then return end

    local identifier = Framework.GetPlayerIdentifier(source)

    if not inLobby[identifier] then
        return
    end

    local currentRoomData = roomData[inLobby[identifier].roomId]

    if not currentRoomData.settings.startedRobbery then
        return
    end

    local house = Config.RobberyLocation[currentRoomData.settings.heistHouse]

    if not house then
        Notify.SendNotify(source, "Invalid house data.", "error", 5000)
        return
    end

    if not currentRoomData.settings.failed then
        local reward = house.reward
        local rewards = {
            money = 0,
            xp = 0,
        }

        rewards.xp = reward

        if objectAmount > 0 then
            local newMoneyAmount = house.objectRewards.money * objectAmount
            local newEXPAmount = house.objectRewards.xp * objectAmount
            rewards.money = newMoneyAmount
            rewards.xp = rewards.xp + newEXPAmount
        end

        for _, player in pairs(currentRoomData.players) do
            local playerIdentifier = Framework.GetPlayerIdentifier(player.source)

            if playerIdentifier then
                local playerData = database[playerIdentifier]

                if playerData then
                    playerData.xp = playerData.xp + rewards.xp
                    database[playerIdentifier] = playerData

                    SaveDatabase(database)
                end

                if Config.MoneySettings.item.cashItem then
                    Inventory.AddItem(player.source, Config.MoneySettings.item.name, rewards.money)
                else
                    Framework.AddAccountBalance(player.source, 'money', rewards.money)
                end

                Notify.SendNotify(player.source, string.format(Locales[Config.Locale]['Lua']['finish_message'], rewards.money, rewards.xp), "success", 5000)
            end
        end
    end

    TriggerClientEvent('0r-houserobbery:client:resetHandObject', -1, carObjects)

    local veh = NetworkGetEntityFromNetworkId(currentRoomData.settings.heistCar.netId)
    if veh and DoesEntityExist(veh) then
        DeleteEntity(veh)
    end

    local obj = NetworkGetEntityFromNetworkId(currentRoomData.settings.lock)
    if obj and DoesEntityExist(obj) then
        DeleteEntity(obj)
    end

    for k, v in pairs(carObjects) do
        local carObj = NetworkGetEntityFromNetworkId(v.netId)
        if carObj and DoesEntityExist(carObj) then
            DeleteEntity(carObj)
        end
    end

    ResetHouseStateTimer(currentRoomData.settings.heistHouse)

    roomData[inLobby[identifier].roomId].settings = {
        ownerIdentifier = identifier,
        ownerSrc = source,
        startedRobbery = false,
        heistHouse = nil,
        heistCar = {
            type = 'randomCar',
            paid = false,
            hash = nil,
            netId = nil,
            id = nil,
            coords = {},
        },
        lock = nil,
        cash = nil,
        password = nil,
        failed = false,
        handObjects = {},
    }

    for _, player in pairs(currentRoomData.players) do
        TriggerClientEvent("0r-houserobbery:client:finishRobbery", player.source)
        TriggerClientEvent("0r-houserobbery:client:refreshRoomData", player.source, roomData[inLobby[identifier].roomId])

        local playerIdentifier = Framework.GetPlayerIdentifier(player.source)

        cooldown[playerIdentifier] = {
            time = os.time() + Config.CooldownTime,
        }
    end

    busyTiers[house.tier] = false
end)

RegisterNetEvent('0r-houserobbery:server:taskTimeExpired')
AddEventHandler('0r-houserobbery:server:taskTimeExpired', function()
    local xPlayer = Framework.GetPlayer(source)
    if not xPlayer then return end

    local identifier = Framework.GetPlayerIdentifier(source)

    if not inLobby[identifier] then
        return
    end

    local currentRoomData = roomData[inLobby[identifier].roomId]

    if currentRoomData.settings.ownerIdentifier ~= identifier then
        return
    end

    if not currentRoomData.settings.startedRobbery then
        return
    end

    roomData[inLobby[identifier].roomId].settings.failed = true

    TriggerClientEvent("0r-houserobbery:client:taskTimeExpired", source)

    for _, player in pairs(currentRoomData.players) do
        Notify.SendNotify(player.source, Locales[Config.Locale]['Lua']['time_expired'], "error", 5000)
        TriggerClientEvent("0r-houserobbery:client:refreshRoomData", player.source, roomData[inLobby[identifier].roomId])
    end

    if currentRoomData.settings.heistCar.paid then
        TriggerClientEvent('0r-houserobbery:client:deliverRobberyVehicle', source)
    else
        for _, player in pairs(currentRoomData.players) do
            TriggerClientEvent('0r-houserobbery:client:resetRobbery', player.source)
        end
    end
end)

RegisterNetEvent('0r-houserobbery:client:resetHandObject')
AddEventHandler('0r-houserobbery:client:resetHandObject', function(objects)
    TriggerClientEvent('0r-houserobbery:client:resetHandObject', -1, objects)
end)

RegisterNetEvent('0r-houserobbery:server:sellItem')
AddEventHandler('0r-houserobbery:server:sellItem', function(data)
    local xPlayer = Framework.GetPlayer(source)
    if not xPlayer then return end

    local itemData = Config.MarketPlace[data.item]

    if not itemData then
        return
    end

    local itemCount = Inventory.GetItemCount(source, itemData.item)

    if itemCount >= itemData.max then
        itemCount = itemData.max
    end

    if itemCount <= 0 then
        Notify.SendNotify(source, Locales[Config.Locale]['Lua']['not_enough_item'], "error", 5000)
        return
    end

    local price = itemData.price * itemCount

    if Inventory.RemoveItem(source, itemData.item, itemCount) then
        if Config.MoneySettings.item.cashItem then
            Inventory.AddItem(source, Config.MoneySettings.item.name, price)
            Notify.SendNotify(source, string.format(Locales[Config.Locale]['Lua']['sold_item'], itemCount, itemData.item, price), "success", 5000)
        else
            Framework.AddAccountBalance(source, 'money', price)
            Notify.SendNotify(source, string.format(Locales[Config.Locale]['Lua']['sold_item'], itemCount, itemData.item, price), "success", 5000)
        end
    else
        Notify.SendNotify(source, Locales[Config.Locale]['Lua']['not_enough_item'], "error", 5000)
        return
    end
end)
