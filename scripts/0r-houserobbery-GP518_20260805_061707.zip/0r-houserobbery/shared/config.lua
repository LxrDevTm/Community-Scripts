

Config = {}

Config.Locale = 'en' -- en

Config.Fuel = "auto" -- auto, default, cdn-fuel, esx-sna-fuel, okokGasStation, ox_fuel, ps-fuel, qs-fuelstations, Renewed-Fuel, ti-fuel, x-fuel
Config.VehicleKey = "auto" -- auto, cd-garage, mk_vehiclekeys, okokGarage, qb-vehiclekeys, qbx_vehiclekeys, qs-vehiclekeys, Renewed-Vehiclekeys, wasabi_carlock
Config.NotifySystem = "ox" -- qb, mythic, pNotify, esx, ox, okok, t-notify, wasabi, r_notify, custom
Config.ProgressBarSystem = "ox_lib" -- ox_lib, progressbar
Config.ShowHelpText = "ox" -- ox, jg, qb, okok, cd, lab, custom

Config.DefaultProfilePhoto = 'https://r2.fivemanage.com/PRMGg8LOew8Wiszjkbwm3/example-profile-photo.png'

Config.RobberyTimeRestriction = true -- If true, robbery can only be done between start and end time
Config.RobberyEndTime = 0 -- 6 AM
Config.RobberyStartTime = 0 -- 10 PM

Config.TimeToResetItem = 25

Config.RobberyCooldown = true -- If true, robbery will have a cooldown after it has been done
Config.CooldownTime = 0 * 0 * 0 -- 1 hour

Config.ProcessTimes = { -- Time in minute for each process
    ['take_vehicle'] = 15,
    ['hack_keypad'] = 15,
    ['robbery_house'] = 15,
    ['deliver_vehicle'] = 15,
    ['deliver_items'] = 15,
}

Config.PoliceAlert = 20 -- Percentage chance to alert police when robbery is started
Config.PoliceOnDutyRequired = 0 -- Minimum number of police on duty required to start a robbery
Config.PoliceJobName = "police" -- Job name for police, used for alerts and checks

Config.MoneySettings = { -- Settings for money rewards
    chance = 20, -- Percentage chance to get money from a robbery
    min = 100, -- Minimum amount of money to get
    max = 500, -- Maximum amount of money to get
    item = { -- Item settings for money
        cashItem = false, -- If true, money will be given as an item
        name = "money", -- Item name for money
        label = "Cash", -- Item label for money
    }
}

Config.RobberyTabletItem = { -- Settings for the robbery tablet item
    name = 'houserobbery_tablet', -- Item name for the tablet
    requiredJobs = { -- Jobs required to use the tablet
        status = false, -- If true, only players with the required jobs can use the tablet
        jobs = { -- List of jobs that can use the tablet
            ['police'] = true, -- Job name
            ['ambulance'] = true, -- Job name
            ['taxi'] = true, -- Job name
            ['mechanic'] = true, -- Job name
            ['sheriff'] = true, -- Job name
        },
    },
    requiredItem = { -- Settings for the required item to use the tablet
        status = false, -- If true, player must have the required item to use the tablet
        item = { -- List of required items
            ['bandage'] = true, -- Item named
        },
    },
}

Config.LootSettings = { -- Settings for loot in the robbery
    difficulty = { -- Difficulty levels for loot
        'easy', 'easy', 'easy' -- Easy difficulty for all loot
    },
    keys = { -- Keys for loot interaction
        'w', 'a', 's', 'd' -- Keys used for loot interaction
    },
}

Config.BlipSettings = { -- Settings for blips on the map
    ['illegal_vehicle_dealer'] = { -- Blip for illegal vehicle dealer
        id = 326, -- Blip ID
        name = 'Illegal Vehicle Dealer', -- Blip name
        color = 5, -- Blip color
        scale = 0.7, -- Blip scale
    },
    ['robbery_house'] = { -- Blip for robbery house
        id = 40, -- Blip ID
        name = 'Robbery House', -- Blip name
        color = 5, -- Blip color
        scale = 0.7, -- Blip scale
    },
    ['deliver_items'] = { -- Blip for delivering items
        id = 110, -- Blip ID
        name = 'Deliver Items', -- Blip name
        color = 5, -- Blip color
        scale = 0.7, -- Blip scale
    },
}

Config.HeistCar = { -- Settings for the heist car
    hash = `bison`, -- Vehicle hash for the heist car
    name = 'Bison', -- Vehicle name for the heist car
    price = 1000, -- Price for the heist car
}

Config.HeistCarPeds = { -- Settings for the car dealer peds
    [1] = { -- Car dealer ped
        model = `s_m_m_ccrew_01`, -- Ped model
        name = 'Car Dealer', -- Ped name
        coords = { -- Ped coordinates
            car = {
                vector4(250.95, -1794.15, 26.49, 232.25),
                vector4(248.96, -1796.58, 26.49, 231.8),
                vector4(247.12, -1799.4, 26.49, 231.24),
            },
            ped = vector4(259.11, -1801.89, 27.11, 54.23),
        },
    }
}

Config.MarketPed = { -- Settings for the market ped
    model = `s_m_m_ccrew_01`, -- Ped model for the market
    name = 'Market', -- Ped name for the market
    coords = vector4(1491.92, -2093.03, 76.74, 275.0),
    blip = { -- Blip settings for the market
        id = 52, -- Blip ID
        name = 'Market', -- Blip name
        color = 5, -- Blip color
        scale = 0.7, -- Blip scale
    },
}

Config.MarketPlace = { -- Settings for the market place
    ['plastic'] = {
        item = 'plastic', -- Item name for plastic
        price = 50, -- Price for plastic in the market
        label = 'Plastic', -- Item label for plastic
        description = 'A versatile material used in various applications.', -- Item description for plastic
        min = 1, -- Minimum amount of plastic to sell
        max = 50, -- Maximum amount of plastic to sell
    },
    ['diamond_ring'] = {
        item = 'diamond_ring', -- Item name for diamond ring
        price = 500, -- Price for diamond ring in the market
        label = 'Diamond Ring', -- Item label for diamond ring
        description = 'A beautiful diamond ring.', -- Item description for diamond ring
        min = 1, -- Minimum amount of diamond ring to sell
        max = 50, -- Maximum amount of diamond ring to sell
    },
    ['goldchain'] = {
        item = 'goldchain', -- Item name for gold chain
        price = 300, -- Price for gold chain in the market
        label = 'Gold Chain', -- Item label for gold chain
        description = 'A shiny gold chain.', -- Item description for gold chain
        min = 1, -- Minimum amount of gold chain to sell
        max = 50, -- Maximum amount of gold chain to sell
    },
    ['weed_skunk'] = {
        item = 'weed_skunk', -- Item name for weed skunk
        price = 100, -- Price for weed skunk in the market
        label = 'Weed Skunk', -- Item label for weed skunk
        description = 'High quality skunk weed.', -- Item description for weed skunk
        min = 1, -- Minimum amount of weed skunk to sell
        max = 50, -- Maximum amount of weed skunk to sell
    },
    ['cryptostick'] = {
        item = 'cryptostick', -- Item name for cryptostick
        price = 200, -- Price for cryptostick in the market
        label = 'Cryptostick', -- Item label for cryptostick
        description = 'A device used for cryptocurrency transactions.', -- Item description for cryptostick
        min = 1, -- Minimum amount of cryptostick to sell
        max = 50, -- Maximum amount of cryptostick to sell
    },
    ['phone'] = {
        item = 'phone', -- Item name for phone
        price = 150, -- Price for phone in the market
        label = 'Phone', -- Item label for phone
        description = 'A smartphone with various features.', -- Item description for phone
        min = 1, -- Minimum amount of phone to sell
        max = 50, -- Maximum amount of phone to sell
    },
    ['tablet'] = {
        item = 'tablet', -- Item name for tablet
        price = 250, -- Price for tablet in the market
        label = 'Tablet', -- Item label for tablet
        description = 'A portable tablet with a large screen.', -- Item description for tablet
        min = 1, -- Minimum amount of tablet to sell
        max = 50, -- Maximum amount of tablet to sell
    },
    ['rolex'] = {
        item = 'rolex', -- Item name for rolex
        price = 1000, -- Price for rolex in the market
        label = 'Rolex', -- Item label for rolex
        description = 'A luxury Rolex watch.', -- Item description for rolex
        min = 1, -- Minimum amount of rolex to sell
        max = 50, -- Maximum amount of rolex to sell
    },
    ['pistol_ammo'] = {
        item = 'pistol_ammo', -- Item name for pistol ammo
        price = 50, -- Price for pistol ammo in the market
        label = 'Pistol Ammo', -- Item label for pistol ammo
        description = 'A box of pistol ammunition.', -- Item description for pistol ammo
        min = 1, -- Minimum amount of pistol ammo to sell
        max = 50, -- Maximum amount of pistol ammo to sell
    },
    ['meth'] = {
        item = 'meth', -- Item name for meth
        price = 300, -- Price for meth in the market
        label = 'Meth', -- Item label for meth
        description = 'A bag of high-quality methamphetamine.', -- Item description for meth
        min = 1, -- Minimum amount of meth to sell
        max = 50, -- Maximum amount of meth to sell
    },
    ['tosti'] = {
        item = 'tosti', -- Item name for tosti
        price = 10, -- Price for tosti in the market
        label = 'Tosti', -- Item label for tosti
        description = 'A delicious toasted sandwich.', -- Item description for tosti
        min = 1, -- Minimum amount of tosti to sell
        max = 50, -- Maximum amount of tosti to sell
    },
    ['sandwich'] = {
        item = 'sandwich', -- Item name for sandwich
        price = 15, -- Price for sandwich in the market
        label = 'Sandwich', -- Item label for sandwich
        description = 'A tasty sandwich with various fillings.', -- Item description for sandwich
        min = 1, -- Minimum amount of sandwich to sell
        max = 50, -- Maximum amount of sandwich to sell
    },
}

Config.HeistBag = { -- Settings for the heist bag
    item = 'houserobbery_bag', -- Item name for the heist bag
    male = 45,
    female = 45,
}

Config.ChestRewards = {
    [1] = {
        ['cabin'] = {
            { item = 'plastic',         min = 1, max = 3 },
            { item = 'diamond_ring',    min = 1, max = 1 },
            { item = 'goldchain',       min = 1, max = 1 },
            { item = 'weed_skunk',      min = 1, max = 3 },
            { item = 'cryptostick',     min = 1, max = 1 },
        },
        ['kitchen'] = {
            { item = 'tosti',     min = 1, max = 3 },
            { item = 'sandwich',  min = 1, max = 2 },
            { item = 'goldchain', min = 1, max = 1 }
        },
        ['chest'] = {
            { item = 'plastic',         min = 1, max = 3 },
            { item = 'diamond_ring',    min = 1, max = 1 },
            { item = 'goldchain',       min = 1, max = 1 },
            { item = 'weed_skunk',      min = 1, max = 3 },
            { item = 'cryptostick',     min = 1, max = 1 },
            { item = 'phone',           min = 1, max = 1 },
            { item = 'tablet',          min = 1, max = 1 },
        },
        ['livingroom'] = {
            { item = 'phone',        min = 1, max = 1 },
            { item = 'tablet',       min = 1, max = 1 },
            { item = 'plastic',      min = 1, max = 4 },
            { item = 'rolex',        min = 1, max = 1 },
            { item = 'diamond_ring', min = 1, max = 1 },
            { item = 'goldchain',    min = 1, max = 1 },
            { item = 'cryptostick',  min = 1, max = 1 },
            { item = 'pistol_ammo',  min = 1, max = 3 }
        },
        ['safe'] = {
            { item = 'rolex',        min = 1, max = 3 },
            { item = 'diamond_ring', min = 1, max = 3 },
            { item = 'goldchain',    min = 1, max = 3 },
            { item = 'pistol_ammo',  min = 1, max = 6 }
        }
    },
    [2] = {
        ['cabin'] = {
            { item = 'plastic',         min = 1, max = 3 },
            { item = 'diamond_ring',    min = 1, max = 1 },
            { item = 'goldchain',       min = 1, max = 1 },
            { item = 'weed_skunk',      min = 1, max = 3 },
            { item = 'cryptostick',     min = 1, max = 1 },
        },
        ['kitchen'] = {
            { item = 'tosti',     min = 1, max = 3 },
            { item = 'sandwich',  min = 1, max = 2 },
            { item = 'goldchain', min = 1, max = 1 }
        },
        ['chest'] = {
            { item = 'plastic',         min = 1, max = 3 },
            { item = 'diamond_ring',    min = 1, max = 1 },
            { item = 'goldchain',       min = 1, max = 1 },
            { item = 'weed_skunk',      min = 1, max = 3 },
            { item = 'cryptostick',     min = 1, max = 1 },
            { item = 'phone',           min = 1, max = 1 },
            { item = 'tablet',          min = 1, max = 1 },
        },
        ['livingroom'] = {
            { item = 'phone',        min = 1, max = 1 },
            { item = 'tablet',       min = 1, max = 1 },
            { item = 'plastic',      min = 1, max = 4 },
            { item = 'rolex',        min = 1, max = 1 },
            { item = 'diamond_ring', min = 1, max = 1 },
            { item = 'goldchain',    min = 1, max = 1 },
            { item = 'cryptostick',  min = 1, max = 1 },
            { item = 'pistol_ammo',  min = 1, max = 3 }
        },
        ['safe'] = {
            { item = 'rolex',        min = 1, max = 3 },
            { item = 'diamond_ring', min = 1, max = 3 },
            { item = 'goldchain',    min = 1, max = 3 },
            { item = 'pistol_ammo',  min = 1, max = 6 }
        }
    },
    [3] = {
        ['cabin'] = {
            { item = 'plastic',         min = 1, max = 3 },
            { item = 'diamond_ring',    min = 1, max = 1 },
            { item = 'goldchain',       min = 1, max = 1 },
            { item = 'weed_skunk',      min = 1, max = 3 },
            { item = 'cryptostick',     min = 1, max = 1 },
        },
        ['kitchen'] = {
            { item = 'tosti',     min = 1, max = 3 },
            { item = 'sandwich',  min = 1, max = 2 },
            { item = 'goldchain', min = 1, max = 1 }
        },
        ['chest'] = {
            { item = 'plastic',         min = 1, max = 3 },
            { item = 'diamond_ring',    min = 1, max = 1 },
            { item = 'goldchain',       min = 1, max = 1 },
            { item = 'weed_skunk',      min = 1, max = 3 },
            { item = 'cryptostick',     min = 1, max = 1 },
            { item = 'phone',           min = 1, max = 1 },
            { item = 'tablet',          min = 1, max = 1 },
        },
        ['livingroom'] = {
            { item = 'phone',        min = 1, max = 1 },
            { item = 'tablet',       min = 1, max = 1 },
            { item = 'plastic',      min = 1, max = 4 },
            { item = 'rolex',        min = 1, max = 1 },
            { item = 'diamond_ring', min = 1, max = 1 },
            { item = 'goldchain',    min = 1, max = 1 },
            { item = 'cryptostick',  min = 1, max = 1 },
            { item = 'pistol_ammo',  min = 1, max = 3 }
        },
        ['safe'] = {
            { item = 'rolex',        min = 1, max = 3 },
            { item = 'diamond_ring', min = 1, max = 3 },
            { item = 'goldchain',    min = 1, max = 3 },
            { item = 'pistol_ammo',  min = 1, max = 6 }
        }
    }
}

Config.RobberyLocation = {
    [1] = {
        id = 1,
        name = 'Paleto Bay House 1',
        description = 'Small but beautiful house',
        image = 'house-1',
        coords = {
            enter = vector3(-480.89, 6266.68, 13.61),
            exit = vector4(266.05, -1007.41, -101.01, 345.28),
            lock = vector4(-479.766, 6266.164, 14.013, -26.099),
        },
        tier = 1,
        level = 1,
        opened = false,
        objectRewards = {
            money = 250,
            xp = 250,
        },
        reward = 250,
        loot = {
            [1] = {
                id = 1,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(265.96, -999.44, -99.01),
                },
                furniture = 'livingroom',
            },
            [2] = {
                id = 2,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(264.34, -995.41, -99.01),
                },
                furniture = 'kitchen',
            },
            [3] = {
                id = 3,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(265.83, -996.76, -99.01),
                },
                furniture = 'kitchen',
            },
            [4] = {
                id = 4,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(259.72, -1004.04, -99.01),
                },
                furniture = 'cabin',
            },
            [5] = {
                id = 5,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(261.4, -1002.48, -99.01),
                },
                furniture = 'livingroom',
            },
            [6] = {
                id = 6,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_tv_flat_03",
                        coords = vector3(262.51, -1001.86, -98.97),
                    },
                    hand = {
                        model = "prop_tv_flat_03",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.1, -0.1),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_tv_flat_03",
                        coords = vector3(0.3, -1.2, 0.24),
                        rotation = vector3(0.0, 0.0, 270.0),
                    }
                }
            },
            [7] = {
                id = 7,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_console_01",
                        coords = vector3(263.26, -1001.89, -99.24),
                    },
                    hand = {
                        model = "prop_console_01",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.1, -0.14),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_console_01",
                        coords = vector3(-0.6, -1.6, 0.4),
                        rotation = vector3(0.0, 90.0, 0.0),
                    }
                }
            },
            [8] = {
                id = 8,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_tv_03",
                        coords = vector3(256.98, -995.37, -98.66),
                    },
                    hand = {
                        model = "prop_tv_03",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.12, -0.32, 0.1),
                        rotation = vector3(0.0, 0.0, 90.0),
                    },
                    vehicle = {
                        model = "prop_tv_03",
                        coords = vector3(0.1, -1.2, 0.24),
                        rotation = vector3(0.0, 0.0, 90.0),
                    }
                }
            },
            [9] = {
                id = 9,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_vcr_01",
                        coords = vector3(256.84, -995.51, -99.28),
                    },
                    hand = {
                        model = "prop_vcr_01",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.02, -0.2, -0.1),
                        rotation = vector3(0.0, 0.0, 90.0),
                    },
                    vehicle = {
                        model = "prop_vcr_01",
                        coords = vector3(0.5, -2.0, 0.24),
                        rotation = vector3(0.0, 0.0, 90.0),
                    }
                }
            },
            [10] = {
                id = 10,
                taken = false,
                busy = false,
                create = true,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "3fe_prop_meth_smallbag_01a",
                    coords = vector3(262.13, -1000.6, -99.3),
                    rotation = vector3(0.0, 0.0, 270.0),
                },
                item = {
                    name = "meth",
                    amount = 1,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
        }
    },
    [2] = {
        id = 2,
        name = 'Paleto Bay House 2',
        description = 'Small but beautiful house',
        image = 'house-2',
        coords = {
            enter = vector3(-347.79, 6225.44, 31.88),
            exit = vector4(266.05, -1007.41, -101.01, 345.28),
            lock = vector4(-346.823, 6226.061, 32.199, -44.399),
        },
        tier = 1,
        level = 1,
        opened = false,
        objectRewards = {
            money = 250,
            xp = 250,
        },
        reward = 250,
        loot = {
            [1] = {
                id = 1,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(265.96, -999.44, -99.01),
                },
                furniture = 'livingroom',
            },
            [2] = {
                id = 2,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(264.34, -995.41, -99.01),
                },
                furniture = 'kitchen',
            },
            [3] = {
                id = 3,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(265.83, -996.76, -99.01),
                },
                furniture = 'kitchen',
            },
            [4] = {
                id = 4,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(259.72, -1004.04, -99.01),
                },
                furniture = 'cabin',
            },
            [5] = {
                id = 5,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(261.4, -1002.48, -99.01),
                },
                furniture = 'livingroom',
            },
            [6] = {
                id = 6,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_tv_flat_03",
                        coords = vector3(262.51, -1001.86, -98.97),
                    },
                    hand = {
                        model = "prop_tv_flat_03",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.1, -0.1),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_tv_flat_03",
                        coords = vector3(0.3, -1.2, 0.24),
                        rotation = vector3(0.0, 0.0, 270.0),
                    }
                }
            },
            [7] = {
                id = 7,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_console_01",
                        coords = vector3(263.26, -1001.89, -99.24),
                    },
                    hand = {
                        model = "prop_console_01",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.1, -0.14),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_console_01",
                        coords = vector3(-0.6, -1.6, 0.4),
                        rotation = vector3(0.0, 90.0, 0.0),
                    }
                }
            },
            [8] = {
                id = 8,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_tv_03",
                        coords = vector3(256.98, -995.37, -98.66),
                    },
                    hand = {
                        model = "prop_tv_03",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.12, -0.32, 0.1),
                        rotation = vector3(0.0, 0.0, 90.0),
                    },
                    vehicle = {
                        model = "prop_tv_03",
                        coords = vector3(0.1, -1.2, 0.24),
                        rotation = vector3(0.0, 0.0, 90.0),
                    }
                }
            },
            [9] = {
                id = 9,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_vcr_01",
                        coords = vector3(256.84, -995.51, -99.28),
                    },
                    hand = {
                        model = "prop_vcr_01",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.02, -0.2, -0.1),
                        rotation = vector3(0.0, 0.0, 90.0),
                    },
                    vehicle = {
                        model = "prop_vcr_01",
                        coords = vector3(0.5, -2.0, 0.24),
                        rotation = vector3(0.0, 0.0, 90.0),
                    }
                }
            },
            [10] = {
                id = 10,
                taken = false,
                busy = false,
                create = true,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "3fe_prop_meth_smallbag_01a",
                    coords = vector3(262.13, -1000.6, -99.3),
                    rotation = vector3(0.0, 0.0, 270.0),
                },
                item = {
                    name = "meth",
                    amount = 1,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
        }
    },
    [3] = {
        id = 3,
        name = 'Paleto Bay House 3',
        description = 'Small but beautiful house',
        image = 'house-3',
        coords = {
            enter = vector3(-188.86, 6409.18, 32.61),
            exit = vector4(266.05, -1007.41, -101.01, 345.28),
            lock = vector4(-189.540, 6408.814, 32.716, 137.698),
        },
        tier = 1,
        level = 2,
        opened = false,
        objectRewards = {
            money = 350,
            xp = 350,
        },
        reward = 350,
        loot = {
            [1] = {
                id = 1,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(265.96, -999.44, -99.01),
                },
                furniture = 'livingroom',
            },
            [2] = {
                id = 2,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(264.34, -995.41, -99.01),
                },
                furniture = 'kitchen',
            },
            [3] = {
                id = 3,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(265.83, -996.76, -99.01),
                },
                furniture = 'kitchen',
            },
            [4] = {
                id = 4,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(259.72, -1004.04, -99.01),
                },
                furniture = 'cabin',
            },
            [5] = {
                id = 5,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(261.4, -1002.48, -99.01),
                },
                furniture = 'livingroom',
            },
            [6] = {
                id = 6,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_tv_flat_03",
                        coords = vector3(262.51, -1001.86, -98.97),
                    },
                    hand = {
                        model = "prop_tv_flat_03",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.1, -0.1),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_tv_flat_03",
                        coords = vector3(0.3, -1.2, 0.24),
                        rotation = vector3(0.0, 0.0, 270.0),
                    }
                }
            },
            [7] = {
                id = 7,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_console_01",
                        coords = vector3(263.26, -1001.89, -99.24),
                    },
                    hand = {
                        model = "prop_console_01",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.1, -0.14),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_console_01",
                        coords = vector3(-0.6, -1.6, 0.4),
                        rotation = vector3(0.0, 90.0, 0.0),
                    }
                }
            },
            [8] = {
                id = 8,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_tv_03",
                        coords = vector3(256.98, -995.37, -98.66),
                    },
                    hand = {
                        model = "prop_tv_03",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.12, -0.32, 0.1),
                        rotation = vector3(0.0, 0.0, 90.0),
                    },
                    vehicle = {
                        model = "prop_tv_03",
                        coords = vector3(0.1, -1.2, 0.24),
                        rotation = vector3(0.0, 0.0, 90.0),
                    }
                }
            },
            [9] = {
                id = 9,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_vcr_01",
                        coords = vector3(256.84, -995.51, -99.28),
                    },
                    hand = {
                        model = "prop_vcr_01",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.02, -0.2, -0.1),
                        rotation = vector3(0.0, 0.0, 90.0),
                    },
                    vehicle = {
                        model = "prop_vcr_01",
                        coords = vector3(0.5, -2.0, 0.24),
                        rotation = vector3(0.0, 0.0, 90.0),
                    }
                }
            },
            [10] = {
                id = 10,
                taken = false,
                busy = false,
                create = true,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "3fe_prop_meth_smallbag_01a",
                    coords = vector3(262.13, -1000.6, -99.3),
                    rotation = vector3(0.0, 0.0, 270.0),
                },
                item = {
                    name = "meth",
                    amount = 1,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
        }
    },
    [4] = {
        id = 4,
        name = 'Paleto Bay House 4',
        description = 'Small but beautiful house',
        image = 'house-4',
        coords = {
            enter = vector3(-245.93, 6414.44, 31.46),
            exit = vector4(266.05, -1007.41, -101.01, 345.28),
            lock = vector4(-245.230, 6413.987, 31.833, -50.922),
        },
        tier = 1,
        level = 2,
        opened = false,
        objectRewards = {
            money = 350,
            xp = 350,
        },
        reward = 350,
        loot = {
            [1] = {
                id = 1,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(265.96, -999.44, -99.01),
                },
                furniture = 'livingroom',
            },
            [2] = {
                id = 2,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(264.34, -995.41, -99.01),
                },
                furniture = 'kitchen',
            },
            [3] = {
                id = 3,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(265.83, -996.76, -99.01),
                },
                furniture = 'kitchen',
            },
            [4] = {
                id = 4,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(259.72, -1004.04, -99.01),
                },
                furniture = 'cabin',
            },
            [5] = {
                id = 5,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(261.4, -1002.48, -99.01),
                },
                furniture = 'livingroom',
            },
            [6] = {
                id = 6,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_tv_flat_03",
                        coords = vector3(262.51, -1001.86, -98.97),
                    },
                    hand = {
                        model = "prop_tv_flat_03",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.1, -0.1),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_tv_flat_03",
                        coords = vector3(0.3, -1.2, 0.24),
                        rotation = vector3(0.0, 0.0, 270.0),
                    }
                }
            },
            [7] = {
                id = 7,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_console_01",
                        coords = vector3(263.26, -1001.89, -99.24),
                    },
                    hand = {
                        model = "prop_console_01",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.1, -0.14),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_console_01",
                        coords = vector3(-0.6, -1.6, 0.4),
                        rotation = vector3(0.0, 90.0, 0.0),
                    }
                }
            },
            [8] = {
                id = 8,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_tv_03",
                        coords = vector3(256.98, -995.37, -98.66),
                    },
                    hand = {
                        model = "prop_tv_03",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.12, -0.32, 0.1),
                        rotation = vector3(0.0, 0.0, 90.0),
                    },
                    vehicle = {
                        model = "prop_tv_03",
                        coords = vector3(0.1, -1.2, 0.24),
                        rotation = vector3(0.0, 0.0, 90.0),
                    }
                }
            },
            [9] = {
                id = 9,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_vcr_01",
                        coords = vector3(256.84, -995.51, -99.28),
                    },
                    hand = {
                        model = "prop_vcr_01",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.02, -0.2, -0.1),
                        rotation = vector3(0.0, 0.0, 90.0),
                    },
                    vehicle = {
                        model = "prop_vcr_01",
                        coords = vector3(0.5, -2.0, 0.24),
                        rotation = vector3(0.0, 0.0, 90.0),
                    }
                }
            },
            [10] = {
                id = 10,
                taken = false,
                busy = false,
                create = true,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "3fe_prop_meth_smallbag_01a",
                    coords = vector3(262.13, -1000.6, -99.3),
                    rotation = vector3(0.0, 0.0, 270.0),
                },
                item = {
                    name = "meth",
                    amount = 1,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
        }

    },
    [5] = {
        id = 5,
        name = 'Paleto Bay House 5',
        description = 'Small but beautiful house',
        image = 'house-5',
        coords = {
            enter = vector3(-272.68, 6401.27, 31.46),
            exit = vector4(266.05, -1007.41, -101.01, 345.28),
            lock = vector4(-281.275, 6404.404, 31.577, -151.166),
        },
        tier = 1,
        level = 3,
        opened = false,
        objectRewards = {
            money = 450,
            xp = 450,
        },
        reward = 450,
        loot = {
            [1] = {
                id = 1,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(265.96, -999.44, -99.01),
                },
                furniture = 'livingroom',
            },
            [2] = {
                id = 2,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(264.34, -995.41, -99.01),
                },
                furniture = 'kitchen',
            },
            [3] = {
                id = 3,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(265.83, -996.76, -99.01),
                },
                furniture = 'kitchen',
            },
            [4] = {
                id = 4,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(259.72, -1004.04, -99.01),
                },
                furniture = 'cabin',
            },
            [5] = {
                id = 5,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(261.4, -1002.48, -99.01),
                },
                furniture = 'livingroom',
            },
            [6] = {
                id = 6,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_tv_flat_03",
                        coords = vector3(262.51, -1001.86, -98.97),
                    },
                    hand = {
                        model = "prop_tv_flat_03",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.1, -0.1),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_tv_flat_03",
                        coords = vector3(0.3, -1.2, 0.24),
                        rotation = vector3(0.0, 0.0, 270.0),
                    }
                }
            },
            [7] = {
                id = 7,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_console_01",
                        coords = vector3(263.26, -1001.89, -99.24),
                    },
                    hand = {
                        model = "prop_console_01",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.1, -0.14),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_console_01",
                        coords = vector3(-0.6, -1.6, 0.4),
                        rotation = vector3(0.0, 90.0, 0.0),
                    }
                }
            },
            [8] = {
                id = 8,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_tv_03",
                        coords = vector3(256.98, -995.37, -98.66),
                    },
                    hand = {
                        model = "prop_tv_03",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.12, -0.32, 0.1),
                        rotation = vector3(0.0, 0.0, 90.0),
                    },
                    vehicle = {
                        model = "prop_tv_03",
                        coords = vector3(0.1, -1.2, 0.24),
                        rotation = vector3(0.0, 0.0, 90.0),
                    }
                }
            },
            [9] = {
                id = 9,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_vcr_01",
                        coords = vector3(256.84, -995.51, -99.28),
                    },
                    hand = {
                        model = "prop_vcr_01",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.02, -0.2, -0.1),
                        rotation = vector3(0.0, 0.0, 90.0),
                    },
                    vehicle = {
                        model = "prop_vcr_01",
                        coords = vector3(0.5, -2.0, 0.24),
                        rotation = vector3(0.0, 0.0, 90.0),
                    }
                }
            },
            [10] = {
                id = 10,
                taken = false,
                busy = false,
                create = true,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "3fe_prop_meth_smallbag_01a",
                    coords = vector3(262.13, -1000.6, -99.3),
                    rotation = vector3(0.0, 0.0, 270.0),
                },
                item = {
                    name = "meth",
                    amount = 1,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
        }
    },
    [6] = {
        id = 6,
        name = 'East Los Santos House 1',
        description = 'Small but beautiful house',
        image = 'house-6',
        coords = {
            enter = vector3(1205.43, -1607.35, 50.73),
            exit = vector4(266.05, -1007.41, -101.01, 345.28),
            lock = vector4(1206.103, -1606.632, 51.095, 32.307),
        },
        tier = 1,
        level = 3,
        opened = false,
        objectRewards = {
            money = 450,
            xp = 450,
        },
        reward = 450,
        loot = {
            [1] = {
                id = 1,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(265.96, -999.44, -99.01),
                },
                furniture = 'livingroom',
            },
            [2] = {
                id = 2,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(264.34, -995.41, -99.01),
                },
                furniture = 'kitchen',
            },
            [3] = {
                id = 3,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(265.83, -996.76, -99.01),
                },
                furniture = 'kitchen',
            },
            [4] = {
                id = 4,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(259.72, -1004.04, -99.01),
                },
                furniture = 'cabin',
            },
            [5] = {
                id = 5,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(261.4, -1002.48, -99.01),
                },
                furniture = 'livingroom',
            },
            [6] = {
                id = 6,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_tv_flat_03",
                        coords = vector3(262.51, -1001.86, -98.97),
                    },
                    hand = {
                        model = "prop_tv_flat_03",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.1, -0.1),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_tv_flat_03",
                        coords = vector3(0.3, -1.2, 0.24),
                        rotation = vector3(0.0, 0.0, 270.0),
                    }
                }
            },
            [7] = {
                id = 7,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_console_01",
                        coords = vector3(263.26, -1001.89, -99.24),
                    },
                    hand = {
                        model = "prop_console_01",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.1, -0.14),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_console_01",
                        coords = vector3(-0.6, -1.6, 0.4),
                        rotation = vector3(0.0, 90.0, 0.0),
                    }
                }
            },
            [8] = {
                id = 8,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_tv_03",
                        coords = vector3(256.98, -995.37, -98.66),
                    },
                    hand = {
                        model = "prop_tv_03",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.12, -0.32, 0.1),
                        rotation = vector3(0.0, 0.0, 90.0),
                    },
                    vehicle = {
                        model = "prop_tv_03",
                        coords = vector3(0.1, -1.2, 0.24),
                        rotation = vector3(0.0, 0.0, 90.0),
                    }
                }
            },
            [9] = {
                id = 9,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_vcr_01",
                        coords = vector3(256.84, -995.51, -99.28),
                    },
                    hand = {
                        model = "prop_vcr_01",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.02, -0.2, -0.1),
                        rotation = vector3(0.0, 0.0, 90.0),
                    },
                    vehicle = {
                        model = "prop_vcr_01",
                        coords = vector3(0.5, -2.0, 0.24),
                        rotation = vector3(0.0, 0.0, 90.0),
                    }
                }
            },
            [10] = {
                id = 10,
                taken = false,
                busy = false,
                create = true,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "3fe_prop_meth_smallbag_01a",
                    coords = vector3(262.13, -1000.6, -99.3),
                    rotation = vector3(0.0, 0.0, 270.0),
                },
                item = {
                    name = "meth",
                    amount = 1,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
        }
    },
    [7] = {
        id = 7,
        name = 'South Los Santos House 1',
        description = 'Small but beautiful house',
        image = 'house-7',
        coords = {
            enter = vector3(-141.62, -1692.85, 36.17),
            exit = vector4(266.05, -1007.41, -101.01, 345.28),
            lock = vector4(-142.079, -1692.122, 36.653, -37.202),
        },
        tier = 1,
        level = 4,
        opened = false,
        objectRewards = {
            money = 550,
            xp = 550,
        },
        reward = 550,
        loot = {
            [1] = {
                id = 1,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(265.96, -999.44, -99.01),
                },
                furniture = 'livingroom',
            },
            [2] = {
                id = 2,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(264.34, -995.41, -99.01),
                },
                furniture = 'kitchen',
            },
            [3] = {
                id = 3,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(265.83, -996.76, -99.01),
                },
                furniture = 'kitchen',
            },
            [4] = {
                id = 4,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(259.72, -1004.04, -99.01),
                },
                furniture = 'cabin',
            },
            [5] = {
                id = 5,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(261.4, -1002.48, -99.01),
                },
                furniture = 'livingroom',
            },
            [6] = {
                id = 6,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_tv_flat_03",
                        coords = vector3(262.51, -1001.86, -98.97),
                    },
                    hand = {
                        model = "prop_tv_flat_03",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.1, -0.1),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_tv_flat_03",
                        coords = vector3(0.3, -1.2, 0.24),
                        rotation = vector3(0.0, 0.0, 270.0),
                    }
                }
            },
            [7] = {
                id = 7,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_console_01",
                        coords = vector3(263.26, -1001.89, -99.24),
                    },
                    hand = {
                        model = "prop_console_01",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.1, -0.14),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_console_01",
                        coords = vector3(-0.6, -1.6, 0.4),
                        rotation = vector3(0.0, 90.0, 0.0),
                    }
                }
            },
            [8] = {
                id = 8,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_tv_03",
                        coords = vector3(256.98, -995.37, -98.66),
                    },
                    hand = {
                        model = "prop_tv_03",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.12, -0.32, 0.1),
                        rotation = vector3(0.0, 0.0, 90.0),
                    },
                    vehicle = {
                        model = "prop_tv_03",
                        coords = vector3(0.1, -1.2, 0.24),
                        rotation = vector3(0.0, 0.0, 90.0),
                    }
                }
            },
            [9] = {
                id = 9,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_vcr_01",
                        coords = vector3(256.84, -995.51, -99.28),
                    },
                    hand = {
                        model = "prop_vcr_01",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.02, -0.2, -0.1),
                        rotation = vector3(0.0, 0.0, 90.0),
                    },
                    vehicle = {
                        model = "prop_vcr_01",
                        coords = vector3(0.5, -2.0, 0.24),
                        rotation = vector3(0.0, 0.0, 90.0),
                    }
                }
            },
            [10] = {
                id = 10,
                taken = false,
                busy = false,
                create = true,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "3fe_prop_meth_smallbag_01a",
                    coords = vector3(262.13, -1000.6, -99.3),
                    rotation = vector3(0.0, 0.0, 270.0),
                },
                item = {
                    name = "meth",
                    amount = 1,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
        }
    },
    [8] = {
        id = 8,
        name = 'South Los Santos House 2',
        description = 'Small but beautiful house',
        image = 'house-8',
        coords = {
            enter = vector3(-141.46, -1693.5, 33.07),
            exit = vector4(266.05, -1007.41, -101.01, 345.28),
            lock = vector4(-141.857, -1694.376, 33.505, -131.701),
        },
        tier = 1,
        level = 4,
        opened = false,
        objectRewards = {
            money = 550,
            xp = 550,
        },
        reward = 550,
        loot = {
            [1] = {
                id = 1,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(265.96, -999.44, -99.01),
                },
                furniture = 'livingroom',
            },
            [2] = {
                id = 2,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(264.34, -995.41, -99.01),
                },
                furniture = 'kitchen',
            },
            [3] = {
                id = 3,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(265.83, -996.76, -99.01),
                },
                furniture = 'kitchen',
            },
            [4] = {
                id = 4,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(259.72, -1004.04, -99.01),
                },
                furniture = 'cabin',
            },
            [5] = {
                id = 5,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(261.4, -1002.48, -99.01),
                },
                furniture = 'livingroom',
            },
            [6] = {
                id = 6,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_tv_flat_03",
                        coords = vector3(262.51, -1001.86, -98.97),
                    },
                    hand = {
                        model = "prop_tv_flat_03",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.1, -0.1),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_tv_flat_03",
                        coords = vector3(0.3, -1.2, 0.24),
                        rotation = vector3(0.0, 0.0, 270.0),
                    }
                }
            },
            [7] = {
                id = 7,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_console_01",
                        coords = vector3(263.26, -1001.89, -99.24),
                    },
                    hand = {
                        model = "prop_console_01",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.1, -0.14),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_console_01",
                        coords = vector3(-0.6, -1.6, 0.4),
                        rotation = vector3(0.0, 90.0, 0.0),
                    }
                }
            },
            [8] = {
                id = 8,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_tv_03",
                        coords = vector3(256.98, -995.37, -98.66),
                    },
                    hand = {
                        model = "prop_tv_03",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.12, -0.32, 0.1),
                        rotation = vector3(0.0, 0.0, 90.0),
                    },
                    vehicle = {
                        model = "prop_tv_03",
                        coords = vector3(0.1, -1.2, 0.24),
                        rotation = vector3(0.0, 0.0, 90.0),
                    }
                }
            },
            [9] = {
                id = 9,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_vcr_01",
                        coords = vector3(256.84, -995.51, -99.28),
                    },
                    hand = {
                        model = "prop_vcr_01",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.02, -0.2, -0.1),
                        rotation = vector3(0.0, 0.0, 90.0),
                    },
                    vehicle = {
                        model = "prop_vcr_01",
                        coords = vector3(0.5, -2.0, 0.24),
                        rotation = vector3(0.0, 0.0, 90.0),
                    }
                }
            },
            [10] = {
                id = 10,
                taken = false,
                busy = false,
                create = true,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "3fe_prop_meth_smallbag_01a",
                    coords = vector3(262.13, -1000.6, -99.3),
                    rotation = vector3(0.0, 0.0, 270.0),
                },
                item = {
                    name = "meth",
                    amount = 1,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
        }
    },
    [9] = {
        id = 9,
        name = 'East Los Santos House 2',
        description = 'Small but beautiful house',
        image = 'house-9',
        coords = {
            enter = vector3(1358.38, -1752.16, 64.45),
            exit = vector4(266.05, -1007.41, -101.01, 345.28),
            lock = vector4(1358.983, -1753.260, 64.926, -75.542),
        },
        tier = 1,
        level = 5,
        opened = false,
        objectRewards = {
            money = 650,
            xp = 650,
        },
        reward = 650,
        loot = {
            [1] = {
                id = 1,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(265.96, -999.44, -99.01),
                },
                furniture = 'livingroom',
            },
            [2] = {
                id = 2,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(264.34, -995.41, -99.01),
                },
                furniture = 'kitchen',
            },
            [3] = {
                id = 3,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(265.83, -996.76, -99.01),
                },
                furniture = 'kitchen',
            },
            [4] = {
                id = 4,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(259.72, -1004.04, -99.01),
                },
                furniture = 'cabin',
            },
            [5] = {
                id = 5,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(261.4, -1002.48, -99.01),
                },
                furniture = 'livingroom',
            },
            [6] = {
                id = 6,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_tv_flat_03",
                        coords = vector3(262.51, -1001.86, -98.97),
                    },
                    hand = {
                        model = "prop_tv_flat_03",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.1, -0.1),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_tv_flat_03",
                        coords = vector3(0.3, -1.2, 0.24),
                        rotation = vector3(0.0, 0.0, 270.0),
                    }
                }
            },
            [7] = {
                id = 7,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_console_01",
                        coords = vector3(263.26, -1001.89, -99.24),
                    },
                    hand = {
                        model = "prop_console_01",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.1, -0.14),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_console_01",
                        coords = vector3(-0.6, -1.6, 0.4),
                        rotation = vector3(0.0, 90.0, 0.0),
                    }
                }
            },
            [8] = {
                id = 8,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_tv_03",
                        coords = vector3(256.98, -995.37, -98.66),
                    },
                    hand = {
                        model = "prop_tv_03",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.12, -0.32, 0.1),
                        rotation = vector3(0.0, 0.0, 90.0),
                    },
                    vehicle = {
                        model = "prop_tv_03",
                        coords = vector3(0.1, -1.2, 0.24),
                        rotation = vector3(0.0, 0.0, 90.0),
                    }
                }
            },
            [9] = {
                id = 9,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_vcr_01",
                        coords = vector3(256.84, -995.51, -99.28),
                    },
                    hand = {
                        model = "prop_vcr_01",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.02, -0.2, -0.1),
                        rotation = vector3(0.0, 0.0, 90.0),
                    },
                    vehicle = {
                        model = "prop_vcr_01",
                        coords = vector3(0.5, -2.0, 0.24),
                        rotation = vector3(0.0, 0.0, 90.0),
                    }
                }
            },
            [10] = {
                id = 10,
                taken = false,
                busy = false,
                create = true,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "3fe_prop_meth_smallbag_01a",
                    coords = vector3(262.13, -1000.6, -99.3),
                    rotation = vector3(0.0, 0.0, 270.0),
                },
                item = {
                    name = "meth",
                    amount = 1,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
        }
    },
    [10] = {
        id = 10,
        name = 'East Los Santos House 3',
        description = 'Small but beautiful house',
        image = 'house-10',
        coords = {
            enter = vector3(1314.58, -1733.31, 54.7),
            exit = vector4(266.05, -1007.41, -101.01, 345.28),
            lock = vector4(1313.648, -1732.122, 55.123, 110.999),
        },
        tier = 1,
        level = 5,
        opened = false,
        objectRewards = {
            money = 550,
            xp = 550,
        },
        reward = 650,
        loot = {
            [1] = {
                id = 1,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(265.96, -999.44, -99.01),
                },
                furniture = 'livingroom',
            },
            [2] = {
                id = 2,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(264.34, -995.41, -99.01),
                },
                furniture = 'kitchen',
            },
            [3] = {
                id = 3,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(265.83, -996.76, -99.01),
                },
                furniture = 'kitchen',
            },
            [4] = {
                id = 4,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(259.72, -1004.04, -99.01),
                },
                furniture = 'cabin',
            },
            [5] = {
                id = 5,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(261.4, -1002.48, -99.01),
                },
                furniture = 'livingroom',
            },
            [6] = {
                id = 6,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_tv_flat_03",
                        coords = vector3(262.51, -1001.86, -98.97),
                    },
                    hand = {
                        model = "prop_tv_flat_03",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.1, -0.1),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_tv_flat_03",
                        coords = vector3(0.3, -1.2, 0.24),
                        rotation = vector3(0.0, 0.0, 270.0),
                    }
                }
            },
            [7] = {
                id = 7,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_console_01",
                        coords = vector3(263.26, -1001.89, -99.24),
                    },
                    hand = {
                        model = "prop_console_01",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.1, -0.14),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_console_01",
                        coords = vector3(-0.6, -1.6, 0.4),
                        rotation = vector3(0.0, 90.0, 0.0),
                    }
                }
            },
            [8] = {
                id = 8,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_tv_03",
                        coords = vector3(256.98, -995.37, -98.66),
                    },
                    hand = {
                        model = "prop_tv_03",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.12, -0.32, 0.1),
                        rotation = vector3(0.0, 0.0, 90.0),
                    },
                    vehicle = {
                        model = "prop_tv_03",
                        coords = vector3(0.1, -1.2, 0.24),
                        rotation = vector3(0.0, 0.0, 90.0),
                    }
                }
            },
            [9] = {
                id = 9,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_vcr_01",
                        coords = vector3(256.84, -995.51, -99.28),
                    },
                    hand = {
                        model = "prop_vcr_01",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.02, -0.2, -0.1),
                        rotation = vector3(0.0, 0.0, 90.0),
                    },
                    vehicle = {
                        model = "prop_vcr_01",
                        coords = vector3(0.5, -2.0, 0.24),
                        rotation = vector3(0.0, 0.0, 90.0),
                    }
                }
            },
            [10] = {
                id = 10,
                taken = false,
                busy = false,
                create = true,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "3fe_prop_meth_smallbag_01a",
                    coords = vector3(262.13, -1000.6, -99.3),
                    rotation = vector3(0.0, 0.0, 270.0),
                },
                item = {
                    name = "meth",
                    amount = 1,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
        }
    },
    [11] = {
        id = 11,
        name = 'East Los Santos House 4',
        description = 'Small but beautiful house',
        image = 'house-11',
        coords = {
            enter = vector3(1289.17, -1710.56, 55.48),
            exit = vector4(266.05, -1007.41, -101.01, 345.28),
            lock = vector4(1290.592, -1709.684, 56.009, 22.642),
        },
        tier = 1,
        level = 6,
        opened = false,
        objectRewards = {
            money = 750,
            xp = 750,
        },
        reward = 750,
        loot = {
            [1] = {
                id = 1,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(265.96, -999.44, -99.01),
                },
                furniture = 'livingroom',
            },
            [2] = {
                id = 2,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(264.34, -995.41, -99.01),
                },
                furniture = 'kitchen',
            },
            [3] = {
                id = 3,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(265.83, -996.76, -99.01),
                },
                furniture = 'kitchen',
            },
            [4] = {
                id = 4,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(259.72, -1004.04, -99.01),
                },
                furniture = 'cabin',
            },
            [5] = {
                id = 5,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(261.4, -1002.48, -99.01),
                },
                furniture = 'livingroom',
            },
            [6] = {
                id = 6,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_tv_flat_03",
                        coords = vector3(262.51, -1001.86, -98.97),
                    },
                    hand = {
                        model = "prop_tv_flat_03",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.1, -0.1),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_tv_flat_03",
                        coords = vector3(0.3, -1.2, 0.24),
                        rotation = vector3(0.0, 0.0, 270.0),
                    }
                }
            },
            [7] = {
                id = 7,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_console_01",
                        coords = vector3(263.26, -1001.89, -99.24),
                    },
                    hand = {
                        model = "prop_console_01",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.1, -0.14),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_console_01",
                        coords = vector3(-0.6, -1.6, 0.4),
                        rotation = vector3(0.0, 90.0, 0.0),
                    }
                }
            },
            [8] = {
                id = 8,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_tv_03",
                        coords = vector3(256.98, -995.37, -98.66),
                    },
                    hand = {
                        model = "prop_tv_03",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.12, -0.32, 0.1),
                        rotation = vector3(0.0, 0.0, 90.0),
                    },
                    vehicle = {
                        model = "prop_tv_03",
                        coords = vector3(0.1, -1.2, 0.24),
                        rotation = vector3(0.0, 0.0, 90.0),
                    }
                }
            },
            [9] = {
                id = 9,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_vcr_01",
                        coords = vector3(256.84, -995.51, -99.28),
                    },
                    hand = {
                        model = "prop_vcr_01",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.02, -0.2, -0.1),
                        rotation = vector3(0.0, 0.0, 90.0),
                    },
                    vehicle = {
                        model = "prop_vcr_01",
                        coords = vector3(0.5, -2.0, 0.24),
                        rotation = vector3(0.0, 0.0, 90.0),
                    }
                }
            },
            [10] = {
                id = 10,
                taken = false,
                busy = false,
                create = true,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "3fe_prop_meth_smallbag_01a",
                    coords = vector3(262.13, -1000.6, -99.3),
                    rotation = vector3(0.0, 0.0, 270.0),
                },
                item = {
                    name = "meth",
                    amount = 1,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
        }
    },
    [12] = {
        id = 12,
        name = 'East Los Santos House 5',
        description = 'Small but beautiful house',
        image = 'house-12',
        coords = {
            enter = vector3(1334.07, -1566.44, 54.45),
            exit = vector4(266.05, -1007.41, -101.01, 345.28),
            lock = vector4(1333.635, -1567.101, 54.857, -141.851),
        },
        tier = 1,
        level = 6,
        opened = false,
        objectRewards = {
            money = 550,
            xp = 550,
        },
        reward = 750,
        loot = {
            [1] = {
                id = 1,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(265.96, -999.44, -99.01),
                },
                furniture = 'livingroom',
            },
            [2] = {
                id = 2,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(264.34, -995.41, -99.01),
                },
                furniture = 'kitchen',
            },
            [3] = {
                id = 3,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(265.83, -996.76, -99.01),
                },
                furniture = 'kitchen',
            },
            [4] = {
                id = 4,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(259.72, -1004.04, -99.01),
                },
                furniture = 'cabin',
            },
            [5] = {
                id = 5,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(261.4, -1002.48, -99.01),
                },
                furniture = 'livingroom',
            },
            [6] = {
                id = 6,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_tv_flat_03",
                        coords = vector3(262.51, -1001.86, -98.97),
                    },
                    hand = {
                        model = "prop_tv_flat_03",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.1, -0.1),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_tv_flat_03",
                        coords = vector3(0.3, -1.2, 0.24),
                        rotation = vector3(0.0, 0.0, 270.0),
                    }
                }
            },
            [7] = {
                id = 7,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_console_01",
                        coords = vector3(263.26, -1001.89, -99.24),
                    },
                    hand = {
                        model = "prop_console_01",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.1, -0.14),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_console_01",
                        coords = vector3(-0.6, -1.6, 0.4),
                        rotation = vector3(0.0, 90.0, 0.0),
                    }
                }
            },
            [8] = {
                id = 8,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_tv_03",
                        coords = vector3(256.98, -995.37, -98.66),
                    },
                    hand = {
                        model = "prop_tv_03",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.12, -0.32, 0.1),
                        rotation = vector3(0.0, 0.0, 90.0),
                    },
                    vehicle = {
                        model = "prop_tv_03",
                        coords = vector3(0.1, -1.2, 0.24),
                        rotation = vector3(0.0, 0.0, 90.0),
                    }
                }
            },
            [9] = {
                id = 9,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_vcr_01",
                        coords = vector3(256.84, -995.51, -99.28),
                    },
                    hand = {
                        model = "prop_vcr_01",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.02, -0.2, -0.1),
                        rotation = vector3(0.0, 0.0, 90.0),
                    },
                    vehicle = {
                        model = "prop_vcr_01",
                        coords = vector3(0.5, -2.0, 0.24),
                        rotation = vector3(0.0, 0.0, 90.0),
                    }
                }
            },
            [10] = {
                id = 10,
                taken = false,
                busy = false,
                create = true,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "3fe_prop_meth_smallbag_01a",
                    coords = vector3(262.13, -1000.6, -99.3),
                    rotation = vector3(0.0, 0.0, 270.0),
                },
                item = {
                    name = "meth",
                    amount = 1,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
        }
    },
    [13] = {
        id = 13,
        name = 'Vespucci House 1',
        description = 'Big, beautiful and magnificent house',
        image = 'house-13',
        coords = {
            enter = vector3(-1182.78, -1064.47, 2.15),
            exit = vector4(346.56, -1012.84, -99.2, 358.05),
            lock = vector4(-1182.064, -1064.995, 2.5, -58.136),
        },
        tier = 2,
        level = 7,
        opened = false,
        objectRewards = {
            money = 800,
            xp = 800,
        },
        reward = 800,
        loot = {
            [1] = {
                id = 1,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(351.3, -993.51, -99.2),
                },
                furniture = 'cabin',
            },
            [2] = {
                id = 2,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(350.08, -993.49, -99.2),
                },
                furniture = 'cabin',
            },
            [3] = {
                id = 3,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(349.2, -994.79, -99.2),
                },
                furniture = 'livingroom',
            },
            [4] = {
                id = 4,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(351.21, -999.28, -99.2),
                },
                furniture = 'livingroom',
            },
            [5] = {
                id = 5,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(351.96, -998.79, -99.2),
                },
                furniture = 'livingroom',
            },
            [6] = {
                id = 6,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(346.11, -1001.76, -99.2),
                },
                furniture = 'chest',
            },
            [7] = {
                id = 7,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(338.14, -994.98, -99.2),
                },
                furniture = 'chest',
            },
            [8] = {
                id = 8,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(343.76, -1003.27, -99.2),
                },
                furniture = 'kitchen',
            },
            [9] = {
                id = 9,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(344.03, -1001.25, -99.2),
                },
                furniture = 'kitchen',
            },
            [10] = {
                id = 10,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(339.25, -1003.43, -99.2),
                },
                furniture = 'livingroom',
            },
            [11] = {
                id = 11,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_micro_01",
                        coords = vector3(344.7, -1002.03, -98.97),
                    },
                    hand = {
                        model = "prop_micro_01",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.05, -0.1),
                        rotation = vector3(0.0, 0.0, 180.0),
                    },
                    vehicle = {
                        model = "prop_micro_01",
                        coords = vector3(0.15, -1.0, 0.3),
                        rotation = vector3(0.0, 0.0, 0.0),
                    }
                }
            },
            [12] = {
                id = 12,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_coffee_mac_02",
                        coords = vector3(342.74, -1003.89, -98.99),
                    },
                    hand = {
                        model = "prop_coffee_mac_02",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.1, -0.08),
                        rotation = vector3(0.0, 90.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_coffee_mac_02",
                        coords = vector3(-0.25, -1.0, 0.3),
                        rotation = vector3(0.0, 0.0, 0.0),
                    }
                }
            },
            [13] = {
                id = 13,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_toaster_01",
                        coords = vector3(341.78, -1003.87, -99.06),
                    },
                    hand = {
                        model = "prop_toaster_01",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.05, -0.05),
                        rotation = vector3(0.0, 0.0, 180.0),
                    },
                    vehicle = {
                        model = "prop_toaster_01",
                        coords = vector3(-0.25, -1.3, 0.3),
                        rotation = vector3(0.0, 0.0, 0.0),
                    }
                }
            },
            [14] = {
                id = 14,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_tapeplayer_01",
                        coords = vector3(341.61, -1001.1, -99.01),
                    },
                    hand = {
                        model = "prop_tapeplayer_01",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.07, -0.1),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_tapeplayer_01",
                        coords = vector3(-0.6, -1.8, 0.3),
                        rotation = vector3(0.0, 0.0, 90.0),
                    }
                }
            },
            [15] = {
                id = 15,
                taken = false,
                busy = false,
                create = true,
                type = "safe",
                animation = {
                    type = 'safe'
                },
                art = {
                    model = "ch_prop_vault_painting_01j",
                    coords = vector3(351.055, -1007.392, -98.911),
                    rotation = vector3(0.0, 0.0, 270),
                },
                prop = {
                    coords = vector3(351.055, -1007.392, -98.911),
                    rotation = vector3(0.0, 0.0, 270),
                    model = "ch_prop_ch_arcade_safe_door",
                },
                furniture = 'safe',
            },
            [16] = {
                id = 16,
                taken = false,
                busy = false,
                create = true,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "vw_prop_vw_watch_case_01b",
                    coords = vector3(341.19, -996.65, -99.657),
                    rotation = vector3(0.0, 0.0, 312.3),
                },
                item = {
                    [1] = {
                        name = "smartwatch",
                        amount = 1,
                        random = true,
                        min = 1,
                        max = 3,
                    },
                    [2] = {
                        name = "rolex",
                        amount = 1,
                        random = true,
                        min = 1,
                        max = 3,
                    }
                },
            },
            [17] = {
                id = 17,
                taken = false,
                busy = false,
                create = true,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "ex_office_swag_electronic2",
                    coords = vector3(352.567, -998.855, -99.535),
                    rotation = vector3(0.0, 0.0, 312.3),
                },
                item = {
                    name = "electronickit",
                    amount = 1,
                    random = true,
                    min = 1,
                    max = 3,
                },
            },
            [18] = {
                id = 18,
                taken = false,
                busy = false,
                create = true,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "3fe_prop_meth_smallbag_01a",
                    coords = vector3(349.34, -996.82, -99.53),
                    rotation = vector3(0.0, 0.0, 90.0),
                },
                item = {
                    name = "meth",
                    amount = 3,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
            [19] = {
                id = 19,
                taken = false,
                busy = false,
                create = true,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "ex_office_swag_drugbags",
                    coords = vector3(338.59, -1001.75, -99.463),
                    rotation = vector3(0.0, 0.0, 308.7),
                },
                item = {
                    name = "cokebaggy",
                    amount = 3,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
            [20] = {
                id = 20,
                taken = false,
                busy = false,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "p_whiskey_bottle_s",
                    coords = vector3(341.94, -1001.43, -99.14),
                },
                item = {
                    name = "whiskey",
                    amount = 1,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
        }
    },
    [14] = {
        id = 14,
        name = 'Vespucci House 2',
        description = 'Big, beautiful and magnificent house',
        image = 'house-14',
        coords = {
            enter = vector3(-1200.48, -1031.98, 2.15),
            exit = vector4(346.56, -1012.84, -99.2, 358.05),
            lock = vector4(-1199.726, -1032.567, 2.487, -58.199),
        },
        tier = 2,
        level = 7,
        opened = false,
        objectRewards = {
            money = 800,
            xp = 800,
        },
        reward = 800,
        loot = {
            [1] = {
                id = 1,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(351.3, -993.51, -99.2),
                },
                furniture = 'cabin',
            },
            [2] = {
                id = 2,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(350.08, -993.49, -99.2),
                },
                furniture = 'cabin',
            },
            [3] = {
                id = 3,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(349.2, -994.79, -99.2),
                },
                furniture = 'livingroom',
            },
            [4] = {
                id = 4,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(351.21, -999.28, -99.2),
                },
                furniture = 'livingroom',
            },
            [5] = {
                id = 5,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(351.96, -998.79, -99.2),
                },
                furniture = 'livingroom',
            },
            [6] = {
                id = 6,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(346.11, -1001.76, -99.2),
                },
                furniture = 'chest',
            },
            [7] = {
                id = 7,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(338.14, -994.98, -99.2),
                },
                furniture = 'chest',
            },
            [8] = {
                id = 8,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(343.76, -1003.27, -99.2),
                },
                furniture = 'kitchen',
            },
            [9] = {
                id = 9,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(344.03, -1001.25, -99.2),
                },
                furniture = 'kitchen',
            },
            [10] = {
                id = 10,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(339.25, -1003.43, -99.2),
                },
                furniture = 'livingroom',
            },
            [11] = {
                id = 11,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_micro_01",
                        coords = vector3(344.7, -1002.03, -98.97),
                    },
                    hand = {
                        model = "prop_micro_01",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.05, -0.1),
                        rotation = vector3(0.0, 0.0, 180.0),
                    },
                    vehicle = {
                        model = "prop_micro_01",
                        coords = vector3(0.15, -1.0, 0.3),
                        rotation = vector3(0.0, 0.0, 0.0),
                    }
                }
            },
            [12] = {
                id = 12,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_coffee_mac_02",
                        coords = vector3(342.74, -1003.89, -98.99),
                    },
                    hand = {
                        model = "prop_coffee_mac_02",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.1, -0.08),
                        rotation = vector3(0.0, 90.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_coffee_mac_02",
                        coords = vector3(-0.25, -1.0, 0.3),
                        rotation = vector3(0.0, 0.0, 0.0),
                    }
                }
            },
            [13] = {
                id = 13,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_toaster_01",
                        coords = vector3(341.78, -1003.87, -99.06),
                    },
                    hand = {
                        model = "prop_toaster_01",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.05, -0.05),
                        rotation = vector3(0.0, 0.0, 180.0),
                    },
                    vehicle = {
                        model = "prop_toaster_01",
                        coords = vector3(-0.25, -1.3, 0.3),
                        rotation = vector3(0.0, 0.0, 0.0),
                    }
                }
            },
            [14] = {
                id = 14,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_tapeplayer_01",
                        coords = vector3(341.61, -1001.1, -99.01),
                    },
                    hand = {
                        model = "prop_tapeplayer_01",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.07, -0.1),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_tapeplayer_01",
                        coords = vector3(-0.6, -1.8, 0.3),
                        rotation = vector3(0.0, 0.0, 90.0),
                    }
                }
            },
            [15] = {
                id = 15,
                taken = false,
                busy = false,
                create = true,
                type = "safe",
                animation = {
                    type = 'safe'
                },
                art = {
                    model = "ch_prop_vault_painting_01j",
                    coords = vector3(351.055, -1007.392, -98.911),
                    rotation = vector3(0.0, 0.0, 270),
                },
                prop = {
                    coords = vector3(351.055, -1007.392, -98.911),
                    rotation = vector3(0.0, 0.0, 270),
                    model = "ch_prop_ch_arcade_safe_door",
                },
                furniture = 'safe',
            },
            [16] = {
                id = 16,
                taken = false,
                busy = false,
                create = true,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "vw_prop_vw_watch_case_01b",
                    coords = vector3(341.19, -996.65, -99.657),
                    rotation = vector3(0.0, 0.0, 312.3),
                },
                item = {
                    [1] = {
                        name = "smartwatch",
                        amount = 1,
                        random = true,
                        min = 1,
                        max = 3,
                    },
                    [2] = {
                        name = "rolex",
                        amount = 1,
                        random = true,
                        min = 1,
                        max = 3,
                    }
                },
            },
            [17] = {
                id = 17,
                taken = false,
                busy = false,
                create = true,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "ex_office_swag_electronic2",
                    coords = vector3(352.567, -998.855, -99.535),
                    rotation = vector3(0.0, 0.0, 312.3),
                },
                item = {
                    name = "electronickit",
                    amount = 1,
                    random = true,
                    min = 1,
                    max = 3,
                },
            },
            [18] = {
                id = 18,
                taken = false,
                busy = false,
                create = true,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "3fe_prop_meth_smallbag_01a",
                    coords = vector3(349.34, -996.82, -99.53),
                    rotation = vector3(0.0, 0.0, 90.0),
                },
                item = {
                    name = "meth",
                    amount = 3,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
            [19] = {
                id = 19,
                taken = false,
                busy = false,
                create = true,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "ex_office_swag_drugbags",
                    coords = vector3(338.59, -1001.75, -99.463),
                    rotation = vector3(0.0, 0.0, 308.7),
                },
                item = {
                    name = "cokebaggy",
                    amount = 3,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
            [20] = {
                id = 20,
                taken = false,
                busy = false,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "p_whiskey_bottle_s",
                    coords = vector3(341.94, -1001.43, -99.14),
                },
                item = {
                    name = "whiskey",
                    amount = 1,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
        }
    },
    [15] = {
        id = 15,
        name = 'Vespucci House 3',
        description = 'Big, beautiful and magnificent house',
        image = 'house-15',
        coords = {
            enter = vector3(-1151.61, -990.5, 2.15),
            exit = vector4(346.56, -1012.84, -99.2, 358.05),
            lock = vector4(-1161.693, -974.587, 2.371, -150.429),
        },
        tier = 2,
        level = 8,
        opened = false,
        objectRewards = {
            money = 900,
            xp = 900,
        },
        reward = 900,
        loot = {
            [1] = {
                id = 1,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(351.3, -993.51, -99.2),
                },
                furniture = 'cabin',
            },
            [2] = {
                id = 2,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(350.08, -993.49, -99.2),
                },
                furniture = 'cabin',
            },
            [3] = {
                id = 3,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(349.2, -994.79, -99.2),
                },
                furniture = 'livingroom',
            },
            [4] = {
                id = 4,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(351.21, -999.28, -99.2),
                },
                furniture = 'livingroom',
            },
            [5] = {
                id = 5,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(351.96, -998.79, -99.2),
                },
                furniture = 'livingroom',
            },
            [6] = {
                id = 6,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(346.11, -1001.76, -99.2),
                },
                furniture = 'chest',
            },
            [7] = {
                id = 7,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(338.14, -994.98, -99.2),
                },
                furniture = 'chest',
            },
            [8] = {
                id = 8,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(343.76, -1003.27, -99.2),
                },
                furniture = 'kitchen',
            },
            [9] = {
                id = 9,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(344.03, -1001.25, -99.2),
                },
                furniture = 'kitchen',
            },
            [10] = {
                id = 10,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(339.25, -1003.43, -99.2),
                },
                furniture = 'livingroom',
            },
            [11] = {
                id = 11,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_micro_01",
                        coords = vector3(344.7, -1002.03, -98.97),
                    },
                    hand = {
                        model = "prop_micro_01",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.05, -0.1),
                        rotation = vector3(0.0, 0.0, 180.0),
                    },
                    vehicle = {
                        model = "prop_micro_01",
                        coords = vector3(0.15, -1.0, 0.3),
                        rotation = vector3(0.0, 0.0, 0.0),
                    }
                }
            },
            [12] = {
                id = 12,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_coffee_mac_02",
                        coords = vector3(342.74, -1003.89, -98.99),
                    },
                    hand = {
                        model = "prop_coffee_mac_02",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.1, -0.08),
                        rotation = vector3(0.0, 90.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_coffee_mac_02",
                        coords = vector3(-0.25, -1.0, 0.3),
                        rotation = vector3(0.0, 0.0, 0.0),
                    }
                }
            },
            [13] = {
                id = 13,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_toaster_01",
                        coords = vector3(341.78, -1003.87, -99.06),
                    },
                    hand = {
                        model = "prop_toaster_01",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.05, -0.05),
                        rotation = vector3(0.0, 0.0, 180.0),
                    },
                    vehicle = {
                        model = "prop_toaster_01",
                        coords = vector3(-0.25, -1.3, 0.3),
                        rotation = vector3(0.0, 0.0, 0.0),
                    }
                }
            },
            [14] = {
                id = 14,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_tapeplayer_01",
                        coords = vector3(341.61, -1001.1, -99.01),
                    },
                    hand = {
                        model = "prop_tapeplayer_01",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.07, -0.1),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_tapeplayer_01",
                        coords = vector3(-0.6, -1.8, 0.3),
                        rotation = vector3(0.0, 0.0, 90.0),
                    }
                }
            },
            [15] = {
                id = 15,
                taken = false,
                busy = false,
                create = true,
                type = "safe",
                animation = {
                    type = 'safe'
                },
                art = {
                    model = "ch_prop_vault_painting_01j",
                    coords = vector3(351.055, -1007.392, -98.911),
                    rotation = vector3(0.0, 0.0, 270),
                },
                prop = {
                    coords = vector3(351.055, -1007.392, -98.911),
                    rotation = vector3(0.0, 0.0, 270),
                    model = "ch_prop_ch_arcade_safe_door",
                },
                furniture = 'safe',
            },
            [16] = {
                id = 16,
                taken = false,
                busy = false,
                create = true,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "vw_prop_vw_watch_case_01b",
                    coords = vector3(341.19, -996.65, -99.657),
                    rotation = vector3(0.0, 0.0, 312.3),
                },
                item = {
                    [1] = {
                        name = "smartwatch",
                        amount = 1,
                        random = true,
                        min = 1,
                        max = 3,
                    },
                    [2] = {
                        name = "rolex",
                        amount = 1,
                        random = true,
                        min = 1,
                        max = 3,
                    }
                },
            },
            [17] = {
                id = 17,
                taken = false,
                busy = false,
                create = true,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "ex_office_swag_electronic2",
                    coords = vector3(352.567, -998.855, -99.535),
                    rotation = vector3(0.0, 0.0, 312.3),
                },
                item = {
                    name = "electronickit",
                    amount = 1,
                    random = true,
                    min = 1,
                    max = 3,
                },
            },
            [18] = {
                id = 18,
                taken = false,
                busy = false,
                create = true,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "3fe_prop_meth_smallbag_01a",
                    coords = vector3(349.34, -996.82, -99.53),
                    rotation = vector3(0.0, 0.0, 90.0),
                },
                item = {
                    name = "meth",
                    amount = 3,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
            [19] = {
                id = 19,
                taken = false,
                busy = false,
                create = true,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "ex_office_swag_drugbags",
                    coords = vector3(338.59, -1001.75, -99.463),
                    rotation = vector3(0.0, 0.0, 308.7),
                },
                item = {
                    name = "cokebaggy",
                    amount = 3,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
            [20] = {
                id = 20,
                taken = false,
                busy = false,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "p_whiskey_bottle_s",
                    coords = vector3(341.94, -1001.43, -99.14),
                },
                item = {
                    name = "whiskey",
                    amount = 1,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
        }
    },
    [16] = {
        id = 16,
        name = 'Vespucci House 4',
        description = 'Big, beautiful and magnificent house',
        image = 'house-16',
        coords = {
            enter = vector3(-1103.24, -1014.51, 2.54),
            exit = vector4(346.56, -1012.84, -99.2, 358.05),
            lock = vector4(-1104.117, -1014.771, 2.8, -151.200),
        },
        tier = 2,
        level = 8,
        opened = false,
        objectRewards = {
            money = 900,
            xp = 900,
        },
        reward = 900,
        loot = {
            [1] = {
                id = 1,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(351.3, -993.51, -99.2),
                },
                furniture = 'cabin',
            },
            [2] = {
                id = 2,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(350.08, -993.49, -99.2),
                },
                furniture = 'cabin',
            },
            [3] = {
                id = 3,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(349.2, -994.79, -99.2),
                },
                furniture = 'livingroom',
            },
            [4] = {
                id = 4,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(351.21, -999.28, -99.2),
                },
                furniture = 'livingroom',
            },
            [5] = {
                id = 5,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(351.96, -998.79, -99.2),
                },
                furniture = 'livingroom',
            },
            [6] = {
                id = 6,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(346.11, -1001.76, -99.2),
                },
                furniture = 'chest',
            },
            [7] = {
                id = 7,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(338.14, -994.98, -99.2),
                },
                furniture = 'chest',
            },
            [8] = {
                id = 8,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(343.76, -1003.27, -99.2),
                },
                furniture = 'kitchen',
            },
            [9] = {
                id = 9,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(344.03, -1001.25, -99.2),
                },
                furniture = 'kitchen',
            },
            [10] = {
                id = 10,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(339.25, -1003.43, -99.2),
                },
                furniture = 'livingroom',
            },
            [11] = {
                id = 11,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_micro_01",
                        coords = vector3(344.7, -1002.03, -98.97),
                    },
                    hand = {
                        model = "prop_micro_01",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.05, -0.1),
                        rotation = vector3(0.0, 0.0, 180.0),
                    },
                    vehicle = {
                        model = "prop_micro_01",
                        coords = vector3(0.15, -1.0, 0.3),
                        rotation = vector3(0.0, 0.0, 0.0),
                    }
                }
            },
            [12] = {
                id = 12,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_coffee_mac_02",
                        coords = vector3(342.74, -1003.89, -98.99),
                    },
                    hand = {
                        model = "prop_coffee_mac_02",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.1, -0.08),
                        rotation = vector3(0.0, 90.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_coffee_mac_02",
                        coords = vector3(-0.25, -1.0, 0.3),
                        rotation = vector3(0.0, 0.0, 0.0),
                    }
                }
            },
            [13] = {
                id = 13,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_toaster_01",
                        coords = vector3(341.78, -1003.87, -99.06),
                    },
                    hand = {
                        model = "prop_toaster_01",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.05, -0.05),
                        rotation = vector3(0.0, 0.0, 180.0),
                    },
                    vehicle = {
                        model = "prop_toaster_01",
                        coords = vector3(-0.25, -1.3, 0.3),
                        rotation = vector3(0.0, 0.0, 0.0),
                    }
                }
            },
            [14] = {
                id = 14,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_tapeplayer_01",
                        coords = vector3(341.61, -1001.1, -99.01),
                    },
                    hand = {
                        model = "prop_tapeplayer_01",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.07, -0.1),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_tapeplayer_01",
                        coords = vector3(-0.6, -1.8, 0.3),
                        rotation = vector3(0.0, 0.0, 90.0),
                    }
                }
            },
            [15] = {
                id = 15,
                taken = false,
                busy = false,
                create = true,
                type = "safe",
                animation = {
                    type = 'safe'
                },
                art = {
                    model = "ch_prop_vault_painting_01j",
                    coords = vector3(351.055, -1007.392, -98.911),
                    rotation = vector3(0.0, 0.0, 270),
                },
                prop = {
                    coords = vector3(351.055, -1007.392, -98.911),
                    rotation = vector3(0.0, 0.0, 270),
                    model = "ch_prop_ch_arcade_safe_door",
                },
                furniture = 'safe',
            },
            [16] = {
                id = 16,
                taken = false,
                busy = false,
                create = true,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "vw_prop_vw_watch_case_01b",
                    coords = vector3(341.19, -996.65, -99.657),
                    rotation = vector3(0.0, 0.0, 312.3),
                },
                item = {
                    [1] = {
                        name = "smartwatch",
                        amount = 1,
                        random = true,
                        min = 1,
                        max = 3,
                    },
                    [2] = {
                        name = "rolex",
                        amount = 1,
                        random = true,
                        min = 1,
                        max = 3,
                    }
                },
            },
            [17] = {
                id = 17,
                taken = false,
                busy = false,
                create = true,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "ex_office_swag_electronic2",
                    coords = vector3(352.567, -998.855, -99.535),
                    rotation = vector3(0.0, 0.0, 312.3),
                },
                item = {
                    name = "electronickit",
                    amount = 1,
                    random = true,
                    min = 1,
                    max = 3,
                },
            },
            [18] = {
                id = 18,
                taken = false,
                busy = false,
                create = true,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "3fe_prop_meth_smallbag_01a",
                    coords = vector3(349.34, -996.82, -99.53),
                    rotation = vector3(0.0, 0.0, 90.0),
                },
                item = {
                    name = "meth",
                    amount = 3,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
            [19] = {
                id = 19,
                taken = false,
                busy = false,
                create = true,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "ex_office_swag_drugbags",
                    coords = vector3(338.59, -1001.75, -99.463),
                    rotation = vector3(0.0, 0.0, 308.7),
                },
                item = {
                    name = "cokebaggy",
                    amount = 3,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
            [20] = {
                id = 20,
                taken = false,
                busy = false,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "p_whiskey_bottle_s",
                    coords = vector3(341.94, -1001.43, -99.14),
                },
                item = {
                    name = "whiskey",
                    amount = 1,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
        }
    },
    [17] = {
        id = 17,
        name = 'Vespucci House 5',
        description = 'Big, beautiful and magnificent house',
        image = 'house-17',
        coords = {
            enter = vector3(-1130.28, -1031.6, 2.15),
            exit = vector4(346.56, -1012.84, -99.2, 358.05),
            lock = vector4(-1130.926, -1032.307, 2.499, -150.224),
        },
        tier = 2,
        level = 9,
        opened = false,
        objectRewards = {
            money = 1000,
            xp = 1000,
        },
        reward = 1000,
        loot = {
            [1] = {
                id = 1,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(351.3, -993.51, -99.2),
                },
                furniture = 'cabin',
            },
            [2] = {
                id = 2,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(350.08, -993.49, -99.2),
                },
                furniture = 'cabin',
            },
            [3] = {
                id = 3,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(349.2, -994.79, -99.2),
                },
                furniture = 'livingroom',
            },
            [4] = {
                id = 4,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(351.21, -999.28, -99.2),
                },
                furniture = 'livingroom',
            },
            [5] = {
                id = 5,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(351.96, -998.79, -99.2),
                },
                furniture = 'livingroom',
            },
            [6] = {
                id = 6,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(346.11, -1001.76, -99.2),
                },
                furniture = 'chest',
            },
            [7] = {
                id = 7,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(338.14, -994.98, -99.2),
                },
                furniture = 'chest',
            },
            [8] = {
                id = 8,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(343.76, -1003.27, -99.2),
                },
                furniture = 'kitchen',
            },
            [9] = {
                id = 9,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(344.03, -1001.25, -99.2),
                },
                furniture = 'kitchen',
            },
            [10] = {
                id = 10,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(339.25, -1003.43, -99.2),
                },
                furniture = 'livingroom',
            },
            [11] = {
                id = 11,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_micro_01",
                        coords = vector3(344.7, -1002.03, -98.97),
                    },
                    hand = {
                        model = "prop_micro_01",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.05, -0.1),
                        rotation = vector3(0.0, 0.0, 180.0),
                    },
                    vehicle = {
                        model = "prop_micro_01",
                        coords = vector3(0.15, -1.0, 0.3),
                        rotation = vector3(0.0, 0.0, 0.0),
                    }
                }
            },
            [12] = {
                id = 12,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_coffee_mac_02",
                        coords = vector3(342.74, -1003.89, -98.99),
                    },
                    hand = {
                        model = "prop_coffee_mac_02",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.1, -0.08),
                        rotation = vector3(0.0, 90.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_coffee_mac_02",
                        coords = vector3(-0.25, -1.0, 0.3),
                        rotation = vector3(0.0, 0.0, 0.0),
                    }
                }
            },
            [13] = {
                id = 13,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_toaster_01",
                        coords = vector3(341.78, -1003.87, -99.06),
                    },
                    hand = {
                        model = "prop_toaster_01",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.05, -0.05),
                        rotation = vector3(0.0, 0.0, 180.0),
                    },
                    vehicle = {
                        model = "prop_toaster_01",
                        coords = vector3(-0.25, -1.3, 0.3),
                        rotation = vector3(0.0, 0.0, 0.0),
                    }
                }
            },
            [14] = {
                id = 14,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_tapeplayer_01",
                        coords = vector3(341.61, -1001.1, -99.01),
                    },
                    hand = {
                        model = "prop_tapeplayer_01",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.07, -0.1),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_tapeplayer_01",
                        coords = vector3(-0.6, -1.8, 0.3),
                        rotation = vector3(0.0, 0.0, 90.0),
                    }
                }
            },
            [15] = {
                id = 15,
                taken = false,
                busy = false,
                create = true,
                type = "safe",
                animation = {
                    type = 'safe'
                },
                art = {
                    model = "ch_prop_vault_painting_01j",
                    coords = vector3(351.055, -1007.392, -98.911),
                    rotation = vector3(0.0, 0.0, 270),
                },
                prop = {
                    coords = vector3(351.055, -1007.392, -98.911),
                    rotation = vector3(0.0, 0.0, 270),
                    model = "ch_prop_ch_arcade_safe_door",
                },
                furniture = 'safe',
            },
            [16] = {
                id = 16,
                taken = false,
                busy = false,
                create = true,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "vw_prop_vw_watch_case_01b",
                    coords = vector3(341.19, -996.65, -99.657),
                    rotation = vector3(0.0, 0.0, 312.3),
                },
                item = {
                    [1] = {
                        name = "smartwatch",
                        amount = 1,
                        random = true,
                        min = 1,
                        max = 3,
                    },
                    [2] = {
                        name = "rolex",
                        amount = 1,
                        random = true,
                        min = 1,
                        max = 3,
                    }
                },
            },
            [17] = {
                id = 17,
                taken = false,
                busy = false,
                create = true,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "ex_office_swag_electronic2",
                    coords = vector3(352.567, -998.855, -99.535),
                    rotation = vector3(0.0, 0.0, 312.3),
                },
                item = {
                    name = "electronickit",
                    amount = 1,
                    random = true,
                    min = 1,
                    max = 3,
                },
            },
            [18] = {
                id = 18,
                taken = false,
                busy = false,
                create = true,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "3fe_prop_meth_smallbag_01a",
                    coords = vector3(349.34, -996.82, -99.53),
                    rotation = vector3(0.0, 0.0, 90.0),
                },
                item = {
                    name = "meth",
                    amount = 3,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
            [19] = {
                id = 19,
                taken = false,
                busy = false,
                create = true,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "ex_office_swag_drugbags",
                    coords = vector3(338.59, -1001.75, -99.463),
                    rotation = vector3(0.0, 0.0, 308.7),
                },
                item = {
                    name = "cokebaggy",
                    amount = 3,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
            [20] = {
                id = 20,
                taken = false,
                busy = false,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "p_whiskey_bottle_s",
                    coords = vector3(341.94, -1001.43, -99.14),
                },
                item = {
                    name = "whiskey",
                    amount = 1,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
        }
    },
    [18] = {
        id = 18,
        name = 'Vespucci House 6',
        description = 'Big, beautiful and magnificent house',
        image = 'house-18',
        coords = {
            enter = vector3(-1122.63, -1089.36, 2.55),
            exit = vector4(346.56, -1012.84, -99.2, 358.05),
            lock = vector4(-1122.124, -1090.329, 2.732, -149.701),
        },
        tier = 2,
        level = 9,
        opened = false,
        objectRewards = {
            money = 1000,
            xp = 1000,
        },
        reward = 1000,
        loot = {
            [1] = {
                id = 1,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(351.3, -993.51, -99.2),
                },
                furniture = 'cabin',
            },
            [2] = {
                id = 2,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(350.08, -993.49, -99.2),
                },
                furniture = 'cabin',
            },
            [3] = {
                id = 3,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(349.2, -994.79, -99.2),
                },
                furniture = 'livingroom',
            },
            [4] = {
                id = 4,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(351.21, -999.28, -99.2),
                },
                furniture = 'livingroom',
            },
            [5] = {
                id = 5,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(351.96, -998.79, -99.2),
                },
                furniture = 'livingroom',
            },
            [6] = {
                id = 6,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(346.11, -1001.76, -99.2),
                },
                furniture = 'chest',
            },
            [7] = {
                id = 7,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(338.14, -994.98, -99.2),
                },
                furniture = 'chest',
            },
            [8] = {
                id = 8,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(343.76, -1003.27, -99.2),
                },
                furniture = 'kitchen',
            },
            [9] = {
                id = 9,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(344.03, -1001.25, -99.2),
                },
                furniture = 'kitchen',
            },
            [10] = {
                id = 10,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(339.25, -1003.43, -99.2),
                },
                furniture = 'livingroom',
            },
            [11] = {
                id = 11,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_micro_01",
                        coords = vector3(344.7, -1002.03, -98.97),
                    },
                    hand = {
                        model = "prop_micro_01",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.05, -0.1),
                        rotation = vector3(0.0, 0.0, 180.0),
                    },
                    vehicle = {
                        model = "prop_micro_01",
                        coords = vector3(0.15, -1.0, 0.3),
                        rotation = vector3(0.0, 0.0, 0.0),
                    }
                }
            },
            [12] = {
                id = 12,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_coffee_mac_02",
                        coords = vector3(342.74, -1003.89, -98.99),
                    },
                    hand = {
                        model = "prop_coffee_mac_02",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.1, -0.08),
                        rotation = vector3(0.0, 90.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_coffee_mac_02",
                        coords = vector3(-0.25, -1.0, 0.3),
                        rotation = vector3(0.0, 0.0, 0.0),
                    }
                }
            },
            [13] = {
                id = 13,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_toaster_01",
                        coords = vector3(341.78, -1003.87, -99.06),
                    },
                    hand = {
                        model = "prop_toaster_01",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.05, -0.05),
                        rotation = vector3(0.0, 0.0, 180.0),
                    },
                    vehicle = {
                        model = "prop_toaster_01",
                        coords = vector3(-0.25, -1.3, 0.3),
                        rotation = vector3(0.0, 0.0, 0.0),
                    }
                }
            },
            [14] = {
                id = 14,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_tapeplayer_01",
                        coords = vector3(341.61, -1001.1, -99.01),
                    },
                    hand = {
                        model = "prop_tapeplayer_01",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.07, -0.1),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_tapeplayer_01",
                        coords = vector3(-0.6, -1.8, 0.3),
                        rotation = vector3(0.0, 0.0, 90.0),
                    }
                }
            },
            [15] = {
                id = 15,
                taken = false,
                busy = false,
                create = true,
                type = "safe",
                animation = {
                    type = 'safe'
                },
                art = {
                    model = "ch_prop_vault_painting_01j",
                    coords = vector3(351.055, -1007.392, -98.911),
                    rotation = vector3(0.0, 0.0, 270),
                },
                prop = {
                    coords = vector3(351.055, -1007.392, -98.911),
                    rotation = vector3(0.0, 0.0, 270),
                    model = "ch_prop_ch_arcade_safe_door",
                },
                furniture = 'safe',
            },
            [16] = {
                id = 16,
                taken = false,
                busy = false,
                create = true,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "vw_prop_vw_watch_case_01b",
                    coords = vector3(341.19, -996.65, -99.657),
                    rotation = vector3(0.0, 0.0, 312.3),
                },
                item = {
                    [1] = {
                        name = "smartwatch",
                        amount = 1,
                        random = true,
                        min = 1,
                        max = 3,
                    },
                    [2] = {
                        name = "rolex",
                        amount = 1,
                        random = true,
                        min = 1,
                        max = 3,
                    }
                },
            },
            [17] = {
                id = 17,
                taken = false,
                busy = false,
                create = true,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "ex_office_swag_electronic2",
                    coords = vector3(352.567, -998.855, -99.535),
                    rotation = vector3(0.0, 0.0, 312.3),
                },
                item = {
                    name = "electronickit",
                    amount = 1,
                    random = true,
                    min = 1,
                    max = 3,
                },
            },
            [18] = {
                id = 18,
                taken = false,
                busy = false,
                create = true,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "3fe_prop_meth_smallbag_01a",
                    coords = vector3(349.34, -996.82, -99.53),
                    rotation = vector3(0.0, 0.0, 90.0),
                },
                item = {
                    name = "meth",
                    amount = 3,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
            [19] = {
                id = 19,
                taken = false,
                busy = false,
                create = true,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "ex_office_swag_drugbags",
                    coords = vector3(338.59, -1001.75, -99.463),
                    rotation = vector3(0.0, 0.0, 308.7),
                },
                item = {
                    name = "cokebaggy",
                    amount = 3,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
            [20] = {
                id = 20,
                taken = false,
                busy = false,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "p_whiskey_bottle_s",
                    coords = vector3(341.94, -1001.43, -99.14),
                },
                item = {
                    name = "whiskey",
                    amount = 1,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
        }
    },
    [19] = {
        id = 19,
        name = 'Vespucci House 7',
        description = 'Big, beautiful and magnificent house',
        image = 'house-19',
        coords = {
            enter = vector3(-1034.6, -1147.07, 2.15),
            exit = vector4(346.56, -1012.84, -99.2, 358.05),
            lock = vector4(-1035.836, -1148.196, 2.414, -150.126),
        },
        tier = 2,
        level = 10,
        opened = false,
        objectRewards = {
            money = 1100,
            xp = 1100,
        },
        reward = 1100,
        loot = {
            [1] = {
                id = 1,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(351.3, -993.51, -99.2),
                },
                furniture = 'cabin',
            },
            [2] = {
                id = 2,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(350.08, -993.49, -99.2),
                },
                furniture = 'cabin',
            },
            [3] = {
                id = 3,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(349.2, -994.79, -99.2),
                },
                furniture = 'livingroom',
            },
            [4] = {
                id = 4,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(351.21, -999.28, -99.2),
                },
                furniture = 'livingroom',
            },
            [5] = {
                id = 5,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(351.96, -998.79, -99.2),
                },
                furniture = 'livingroom',
            },
            [6] = {
                id = 6,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(346.11, -1001.76, -99.2),
                },
                furniture = 'chest',
            },
            [7] = {
                id = 7,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(338.14, -994.98, -99.2),
                },
                furniture = 'chest',
            },
            [8] = {
                id = 8,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(343.76, -1003.27, -99.2),
                },
                furniture = 'kitchen',
            },
            [9] = {
                id = 9,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(344.03, -1001.25, -99.2),
                },
                furniture = 'kitchen',
            },
            [10] = {
                id = 10,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(339.25, -1003.43, -99.2),
                },
                furniture = 'livingroom',
            },
            [11] = {
                id = 11,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_micro_01",
                        coords = vector3(344.7, -1002.03, -98.97),
                    },
                    hand = {
                        model = "prop_micro_01",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.05, -0.1),
                        rotation = vector3(0.0, 0.0, 180.0),
                    },
                    vehicle = {
                        model = "prop_micro_01",
                        coords = vector3(0.15, -1.0, 0.3),
                        rotation = vector3(0.0, 0.0, 0.0),
                    }
                }
            },
            [12] = {
                id = 12,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_coffee_mac_02",
                        coords = vector3(342.74, -1003.89, -98.99),
                    },
                    hand = {
                        model = "prop_coffee_mac_02",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.1, -0.08),
                        rotation = vector3(0.0, 90.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_coffee_mac_02",
                        coords = vector3(-0.25, -1.0, 0.3),
                        rotation = vector3(0.0, 0.0, 0.0),
                    }
                }
            },
            [13] = {
                id = 13,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_toaster_01",
                        coords = vector3(341.78, -1003.87, -99.06),
                    },
                    hand = {
                        model = "prop_toaster_01",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.05, -0.05),
                        rotation = vector3(0.0, 0.0, 180.0),
                    },
                    vehicle = {
                        model = "prop_toaster_01",
                        coords = vector3(-0.25, -1.3, 0.3),
                        rotation = vector3(0.0, 0.0, 0.0),
                    }
                }
            },
            [14] = {
                id = 14,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_tapeplayer_01",
                        coords = vector3(341.61, -1001.1, -99.01),
                    },
                    hand = {
                        model = "prop_tapeplayer_01",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.07, -0.1),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_tapeplayer_01",
                        coords = vector3(-0.6, -1.8, 0.3),
                        rotation = vector3(0.0, 0.0, 90.0),
                    }
                }
            },
            [15] = {
                id = 15,
                taken = false,
                busy = false,
                create = true,
                type = "safe",
                animation = {
                    type = 'safe'
                },
                art = {
                    model = "ch_prop_vault_painting_01j",
                    coords = vector3(351.055, -1007.392, -98.911),
                    rotation = vector3(0.0, 0.0, 270),
                },
                prop = {
                    coords = vector3(351.055, -1007.392, -98.911),
                    rotation = vector3(0.0, 0.0, 270),
                    model = "ch_prop_ch_arcade_safe_door",
                },
                furniture = 'safe',
            },
            [16] = {
                id = 16,
                taken = false,
                busy = false,
                create = true,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "vw_prop_vw_watch_case_01b",
                    coords = vector3(341.19, -996.65, -99.657),
                    rotation = vector3(0.0, 0.0, 312.3),
                },
                item = {
                    [1] = {
                        name = "smartwatch",
                        amount = 1,
                        random = true,
                        min = 1,
                        max = 3,
                    },
                    [2] = {
                        name = "rolex",
                        amount = 1,
                        random = true,
                        min = 1,
                        max = 3,
                    }
                },
            },
            [17] = {
                id = 17,
                taken = false,
                busy = false,
                create = true,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "ex_office_swag_electronic2",
                    coords = vector3(352.567, -998.855, -99.535),
                    rotation = vector3(0.0, 0.0, 312.3),
                },
                item = {
                    name = "electronickit",
                    amount = 1,
                    random = true,
                    min = 1,
                    max = 3,
                },
            },
            [18] = {
                id = 18,
                taken = false,
                busy = false,
                create = true,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "3fe_prop_meth_smallbag_01a",
                    coords = vector3(349.34, -996.82, -99.53),
                    rotation = vector3(0.0, 0.0, 90.0),
                },
                item = {
                    name = "meth",
                    amount = 3,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
            [19] = {
                id = 19,
                taken = false,
                busy = false,
                create = true,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "ex_office_swag_drugbags",
                    coords = vector3(338.59, -1001.75, -99.463),
                    rotation = vector3(0.0, 0.0, 308.7),
                },
                item = {
                    name = "cokebaggy",
                    amount = 3,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
            [20] = {
                id = 20,
                taken = false,
                busy = false,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "p_whiskey_bottle_s",
                    coords = vector3(341.94, -1001.43, -99.14),
                },
                item = {
                    name = "whiskey",
                    amount = 1,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
        }
    },
    [20] = {
        id = 20,
        name = 'Vespucci House 8',
        description = 'Big, beautiful and magnificent house',
        image = 'house-20',
        coords = {
            enter = vector3(-1063.65, -1160.25, 2.74),
            exit = vector4(346.56, -1012.84, -99.2, 358.05),
            lock = vector4(-1062.856, -1160.140, 3.127, -60.561),
        },
        tier = 2,
        level = 10,
        opened = false,
        objectRewards = {
            money = 1100,
            xp = 1100,
        },
        reward = 1100,
        loot = {
            [1] = {
                id = 1,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(351.3, -993.51, -99.2),
                },
                furniture = 'cabin',
            },
            [2] = {
                id = 2,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(350.08, -993.49, -99.2),
                },
                furniture = 'cabin',
            },
            [3] = {
                id = 3,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(349.2, -994.79, -99.2),
                },
                furniture = 'livingroom',
            },
            [4] = {
                id = 4,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(351.21, -999.28, -99.2),
                },
                furniture = 'livingroom',
            },
            [5] = {
                id = 5,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(351.96, -998.79, -99.2),
                },
                furniture = 'livingroom',
            },
            [6] = {
                id = 6,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(346.11, -1001.76, -99.2),
                },
                furniture = 'chest',
            },
            [7] = {
                id = 7,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(338.14, -994.98, -99.2),
                },
                furniture = 'chest',
            },
            [8] = {
                id = 8,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(343.76, -1003.27, -99.2),
                },
                furniture = 'kitchen',
            },
            [9] = {
                id = 9,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(344.03, -1001.25, -99.2),
                },
                furniture = 'kitchen',
            },
            [10] = {
                id = 10,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(339.25, -1003.43, -99.2),
                },
                furniture = 'livingroom',
            },
            [11] = {
                id = 11,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_micro_01",
                        coords = vector3(344.7, -1002.03, -98.97),
                    },
                    hand = {
                        model = "prop_micro_01",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.05, -0.1),
                        rotation = vector3(0.0, 0.0, 180.0),
                    },
                    vehicle = {
                        model = "prop_micro_01",
                        coords = vector3(0.15, -1.0, 0.3),
                        rotation = vector3(0.0, 0.0, 0.0),
                    }
                }
            },
            [12] = {
                id = 12,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_coffee_mac_02",
                        coords = vector3(342.74, -1003.89, -98.99),
                    },
                    hand = {
                        model = "prop_coffee_mac_02",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.1, -0.08),
                        rotation = vector3(0.0, 90.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_coffee_mac_02",
                        coords = vector3(-0.25, -1.0, 0.3),
                        rotation = vector3(0.0, 0.0, 0.0),
                    }
                }
            },
            [13] = {
                id = 13,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_toaster_01",
                        coords = vector3(341.78, -1003.87, -99.06),
                    },
                    hand = {
                        model = "prop_toaster_01",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.05, -0.05),
                        rotation = vector3(0.0, 0.0, 180.0),
                    },
                    vehicle = {
                        model = "prop_toaster_01",
                        coords = vector3(-0.25, -1.3, 0.3),
                        rotation = vector3(0.0, 0.0, 0.0),
                    }
                }
            },
            [14] = {
                id = 14,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_tapeplayer_01",
                        coords = vector3(341.61, -1001.1, -99.01),
                    },
                    hand = {
                        model = "prop_tapeplayer_01",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.07, -0.1),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_tapeplayer_01",
                        coords = vector3(-0.6, -1.8, 0.3),
                        rotation = vector3(0.0, 0.0, 90.0),
                    }
                }
            },
            [15] = {
                id = 15,
                taken = false,
                busy = false,
                create = true,
                type = "safe",
                animation = {
                    type = 'safe'
                },
                art = {
                    model = "ch_prop_vault_painting_01j",
                    coords = vector3(351.055, -1007.392, -98.911),
                    rotation = vector3(0.0, 0.0, 270),
                },
                prop = {
                    coords = vector3(351.055, -1007.392, -98.911),
                    rotation = vector3(0.0, 0.0, 270),
                    model = "ch_prop_ch_arcade_safe_door",
                },
                furniture = 'safe',
            },
            [16] = {
                id = 16,
                taken = false,
                busy = false,
                create = true,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "vw_prop_vw_watch_case_01b",
                    coords = vector3(341.19, -996.65, -99.657),
                    rotation = vector3(0.0, 0.0, 312.3),
                },
                item = {
                    [1] = {
                        name = "smartwatch",
                        amount = 1,
                        random = true,
                        min = 1,
                        max = 3,
                    },
                    [2] = {
                        name = "rolex",
                        amount = 1,
                        random = true,
                        min = 1,
                        max = 3,
                    }
                },
            },
            [17] = {
                id = 17,
                taken = false,
                busy = false,
                create = true,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "ex_office_swag_electronic2",
                    coords = vector3(352.567, -998.855, -99.535),
                    rotation = vector3(0.0, 0.0, 312.3),
                },
                item = {
                    name = "electronickit",
                    amount = 1,
                    random = true,
                    min = 1,
                    max = 3,
                },
            },
            [18] = {
                id = 18,
                taken = false,
                busy = false,
                create = true,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "3fe_prop_meth_smallbag_01a",
                    coords = vector3(349.34, -996.82, -99.53),
                    rotation = vector3(0.0, 0.0, 90.0),
                },
                item = {
                    name = "meth",
                    amount = 3,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
            [19] = {
                id = 19,
                taken = false,
                busy = false,
                create = true,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "ex_office_swag_drugbags",
                    coords = vector3(338.59, -1001.75, -99.463),
                    rotation = vector3(0.0, 0.0, 308.7),
                },
                item = {
                    name = "cokebaggy",
                    amount = 3,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
            [20] = {
                id = 20,
                taken = false,
                busy = false,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "p_whiskey_bottle_s",
                    coords = vector3(341.94, -1001.43, -99.14),
                },
                item = {
                    name = "whiskey",
                    amount = 1,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
        }
    },
    [21] = {
        id = 21,
        name = 'Vespucci Beach House 1',
        description = 'Big, beautiful and magnificent house',
        image = 'house-21',
        coords = {
            enter = vector3(-1082.55, -1631.18, 4.74),
            exit = vector4(346.56, -1012.84, -99.2, 358.05),
            lock = vector4(-1082.904, -1630.352, 5, 35.179),
        },
        tier = 2,
        level = 11,
        opened = false,
        objectRewards = {
            money = 1200,
            xp = 1200,
        },
        reward = 1200,
        loot = {
            [1] = {
                id = 1,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(351.3, -993.51, -99.2),
                },
                furniture = 'cabin',
            },
            [2] = {
                id = 2,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(350.08, -993.49, -99.2),
                },
                furniture = 'cabin',
            },
            [3] = {
                id = 3,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(349.2, -994.79, -99.2),
                },
                furniture = 'livingroom',
            },
            [4] = {
                id = 4,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(351.21, -999.28, -99.2),
                },
                furniture = 'livingroom',
            },
            [5] = {
                id = 5,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(351.96, -998.79, -99.2),
                },
                furniture = 'livingroom',
            },
            [6] = {
                id = 6,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(346.11, -1001.76, -99.2),
                },
                furniture = 'chest',
            },
            [7] = {
                id = 7,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(338.14, -994.98, -99.2),
                },
                furniture = 'chest',
            },
            [8] = {
                id = 8,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(343.76, -1003.27, -99.2),
                },
                furniture = 'kitchen',
            },
            [9] = {
                id = 9,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(344.03, -1001.25, -99.2),
                },
                furniture = 'kitchen',
            },
            [10] = {
                id = 10,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(339.25, -1003.43, -99.2),
                },
                furniture = 'livingroom',
            },
            [11] = {
                id = 11,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_micro_01",
                        coords = vector3(344.7, -1002.03, -98.97),
                    },
                    hand = {
                        model = "prop_micro_01",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.05, -0.1),
                        rotation = vector3(0.0, 0.0, 180.0),
                    },
                    vehicle = {
                        model = "prop_micro_01",
                        coords = vector3(0.15, -1.0, 0.3),
                        rotation = vector3(0.0, 0.0, 0.0),
                    }
                }
            },
            [12] = {
                id = 12,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_coffee_mac_02",
                        coords = vector3(342.74, -1003.89, -98.99),
                    },
                    hand = {
                        model = "prop_coffee_mac_02",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.1, -0.08),
                        rotation = vector3(0.0, 90.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_coffee_mac_02",
                        coords = vector3(-0.25, -1.0, 0.3),
                        rotation = vector3(0.0, 0.0, 0.0),
                    }
                }
            },
            [13] = {
                id = 13,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_toaster_01",
                        coords = vector3(341.78, -1003.87, -99.06),
                    },
                    hand = {
                        model = "prop_toaster_01",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.05, -0.05),
                        rotation = vector3(0.0, 0.0, 180.0),
                    },
                    vehicle = {
                        model = "prop_toaster_01",
                        coords = vector3(-0.25, -1.3, 0.3),
                        rotation = vector3(0.0, 0.0, 0.0),
                    }
                }
            },
            [14] = {
                id = 14,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_tapeplayer_01",
                        coords = vector3(341.61, -1001.1, -99.01),
                    },
                    hand = {
                        model = "prop_tapeplayer_01",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.07, -0.1),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_tapeplayer_01",
                        coords = vector3(-0.6, -1.8, 0.3),
                        rotation = vector3(0.0, 0.0, 90.0),
                    }
                }
            },
            [15] = {
                id = 15,
                taken = false,
                busy = false,
                create = true,
                type = "safe",
                animation = {
                    type = 'safe'
                },
                art = {
                    model = "ch_prop_vault_painting_01j",
                    coords = vector3(351.055, -1007.392, -98.911),
                    rotation = vector3(0.0, 0.0, 270),
                },
                prop = {
                    coords = vector3(351.055, -1007.392, -98.911),
                    rotation = vector3(0.0, 0.0, 270),
                    model = "ch_prop_ch_arcade_safe_door",
                },
                furniture = 'safe',
            },
            [16] = {
                id = 16,
                taken = false,
                busy = false,
                create = true,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "vw_prop_vw_watch_case_01b",
                    coords = vector3(341.19, -996.65, -99.657),
                    rotation = vector3(0.0, 0.0, 312.3),
                },
                item = {
                    [1] = {
                        name = "smartwatch",
                        amount = 1,
                        random = true,
                        min = 1,
                        max = 3,
                    },
                    [2] = {
                        name = "rolex",
                        amount = 1,
                        random = true,
                        min = 1,
                        max = 3,
                    }
                },
            },
            [17] = {
                id = 17,
                taken = false,
                busy = false,
                create = true,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "ex_office_swag_electronic2",
                    coords = vector3(352.567, -998.855, -99.535),
                    rotation = vector3(0.0, 0.0, 312.3),
                },
                item = {
                    name = "electronickit",
                    amount = 1,
                    random = true,
                    min = 1,
                    max = 3,
                },
            },
            [18] = {
                id = 18,
                taken = false,
                busy = false,
                create = true,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "3fe_prop_meth_smallbag_01a",
                    coords = vector3(349.34, -996.82, -99.53),
                    rotation = vector3(0.0, 0.0, 90.0),
                },
                item = {
                    name = "meth",
                    amount = 3,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
            [19] = {
                id = 19,
                taken = false,
                busy = false,
                create = true,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "ex_office_swag_drugbags",
                    coords = vector3(338.59, -1001.75, -99.463),
                    rotation = vector3(0.0, 0.0, 308.7),
                },
                item = {
                    name = "cokebaggy",
                    amount = 3,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
            [20] = {
                id = 20,
                taken = false,
                busy = false,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "p_whiskey_bottle_s",
                    coords = vector3(341.94, -1001.43, -99.14),
                },
                item = {
                    name = "whiskey",
                    amount = 1,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
        }
    },
    [22] = {
        id = 22,
        name = 'Vespucci Beach House 2',
        description = 'Big, beautiful and magnificent house',
        image = 'house-22',
        coords = {
            enter = vector3(-1097.58, -1673.16, 8.39),
            exit = vector4(346.56, -1012.84, -99.2, 358.05),
            lock = vector4(-1097.960, -1672.292, 8.647, 35.100),
        },
        tier = 2,
        level = 11,
        opened = false,
        objectRewards = {
            money = 1200,
            xp = 1200,
        },
        reward = 1200,
        loot = {
            [1] = {
                id = 1,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(351.3, -993.51, -99.2),
                },
                furniture = 'cabin',
            },
            [2] = {
                id = 2,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(350.08, -993.49, -99.2),
                },
                furniture = 'cabin',
            },
            [3] = {
                id = 3,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(349.2, -994.79, -99.2),
                },
                furniture = 'livingroom',
            },
            [4] = {
                id = 4,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(351.21, -999.28, -99.2),
                },
                furniture = 'livingroom',
            },
            [5] = {
                id = 5,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(351.96, -998.79, -99.2),
                },
                furniture = 'livingroom',
            },
            [6] = {
                id = 6,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(346.11, -1001.76, -99.2),
                },
                furniture = 'chest',
            },
            [7] = {
                id = 7,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(338.14, -994.98, -99.2),
                },
                furniture = 'chest',
            },
            [8] = {
                id = 8,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(343.76, -1003.27, -99.2),
                },
                furniture = 'kitchen',
            },
            [9] = {
                id = 9,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(344.03, -1001.25, -99.2),
                },
                furniture = 'kitchen',
            },
            [10] = {
                id = 10,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(339.25, -1003.43, -99.2),
                },
                furniture = 'livingroom',
            },
            [11] = {
                id = 11,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_micro_01",
                        coords = vector3(344.7, -1002.03, -98.97),
                    },
                    hand = {
                        model = "prop_micro_01",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.05, -0.1),
                        rotation = vector3(0.0, 0.0, 180.0),
                    },
                    vehicle = {
                        model = "prop_micro_01",
                        coords = vector3(0.15, -1.0, 0.3),
                        rotation = vector3(0.0, 0.0, 0.0),
                    }
                }
            },
            [12] = {
                id = 12,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_coffee_mac_02",
                        coords = vector3(342.74, -1003.89, -98.99),
                    },
                    hand = {
                        model = "prop_coffee_mac_02",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.1, -0.08),
                        rotation = vector3(0.0, 90.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_coffee_mac_02",
                        coords = vector3(-0.25, -1.0, 0.3),
                        rotation = vector3(0.0, 0.0, 0.0),
                    }
                }
            },
            [13] = {
                id = 13,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_toaster_01",
                        coords = vector3(341.78, -1003.87, -99.06),
                    },
                    hand = {
                        model = "prop_toaster_01",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.05, -0.05),
                        rotation = vector3(0.0, 0.0, 180.0),
                    },
                    vehicle = {
                        model = "prop_toaster_01",
                        coords = vector3(-0.25, -1.3, 0.3),
                        rotation = vector3(0.0, 0.0, 0.0),
                    }
                }
            },
            [14] = {
                id = 14,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_tapeplayer_01",
                        coords = vector3(341.61, -1001.1, -99.01),
                    },
                    hand = {
                        model = "prop_tapeplayer_01",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.07, -0.1),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_tapeplayer_01",
                        coords = vector3(-0.6, -1.8, 0.3),
                        rotation = vector3(0.0, 0.0, 90.0),
                    }
                }
            },
            [15] = {
                id = 15,
                taken = false,
                busy = false,
                create = true,
                type = "safe",
                animation = {
                    type = 'safe'
                },
                art = {
                    model = "ch_prop_vault_painting_01j",
                    coords = vector3(351.055, -1007.392, -98.911),
                    rotation = vector3(0.0, 0.0, 270),
                },
                prop = {
                    coords = vector3(351.055, -1007.392, -98.911),
                    rotation = vector3(0.0, 0.0, 270),
                    model = "ch_prop_ch_arcade_safe_door",
                },
                furniture = 'safe',
            },
            [16] = {
                id = 16,
                taken = false,
                busy = false,
                create = true,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "vw_prop_vw_watch_case_01b",
                    coords = vector3(341.19, -996.65, -99.657),
                    rotation = vector3(0.0, 0.0, 312.3),
                },
                item = {
                    [1] = {
                        name = "smartwatch",
                        amount = 1,
                        random = true,
                        min = 1,
                        max = 3,
                    },
                    [2] = {
                        name = "rolex",
                        amount = 1,
                        random = true,
                        min = 1,
                        max = 3,
                    }
                },
            },
            [17] = {
                id = 17,
                taken = false,
                busy = false,
                create = true,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "ex_office_swag_electronic2",
                    coords = vector3(352.567, -998.855, -99.535),
                    rotation = vector3(0.0, 0.0, 312.3),
                },
                item = {
                    name = "electronickit",
                    amount = 1,
                    random = true,
                    min = 1,
                    max = 3,
                },
            },
            [18] = {
                id = 18,
                taken = false,
                busy = false,
                create = true,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "3fe_prop_meth_smallbag_01a",
                    coords = vector3(349.34, -996.82, -99.53),
                    rotation = vector3(0.0, 0.0, 90.0),
                },
                item = {
                    name = "meth",
                    amount = 3,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
            [19] = {
                id = 19,
                taken = false,
                busy = false,
                create = true,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "ex_office_swag_drugbags",
                    coords = vector3(338.59, -1001.75, -99.463),
                    rotation = vector3(0.0, 0.0, 308.7),
                },
                item = {
                    name = "cokebaggy",
                    amount = 3,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
            [20] = {
                id = 20,
                taken = false,
                busy = false,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "p_whiskey_bottle_s",
                    coords = vector3(341.94, -1001.43, -99.14),
                },
                item = {
                    name = "whiskey",
                    amount = 1,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
        }
    },
    [23] = {
        id = 23,
        name = 'Vespucci Beach House 3',
        description = 'Big, beautiful and magnificent house',
        image = 'house-23',
        coords = {
            enter = vector3(-1118.44, -1619.0, 4.4),
            exit = vector4(346.56, -1012.84, -99.2, 358.05),
            lock = vector4(-1117.638, -1618.751, 4.863, 33.900),
        },
        tier = 2,
        level = 12,
        opened = false,
        objectRewards = {
            money = 1300,
            xp = 1300,
        },
        reward = 1300,
        loot = {
            [1] = {
                id = 1,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(351.3, -993.51, -99.2),
                },
                furniture = 'cabin',
            },
            [2] = {
                id = 2,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(350.08, -993.49, -99.2),
                },
                furniture = 'cabin',
            },
            [3] = {
                id = 3,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(349.2, -994.79, -99.2),
                },
                furniture = 'livingroom',
            },
            [4] = {
                id = 4,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(351.21, -999.28, -99.2),
                },
                furniture = 'livingroom',
            },
            [5] = {
                id = 5,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(351.96, -998.79, -99.2),
                },
                furniture = 'livingroom',
            },
            [6] = {
                id = 6,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(346.11, -1001.76, -99.2),
                },
                furniture = 'chest',
            },
            [7] = {
                id = 7,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(338.14, -994.98, -99.2),
                },
                furniture = 'chest',
            },
            [8] = {
                id = 8,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(343.76, -1003.27, -99.2),
                },
                furniture = 'kitchen',
            },
            [9] = {
                id = 9,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(344.03, -1001.25, -99.2),
                },
                furniture = 'kitchen',
            },
            [10] = {
                id = 10,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(339.25, -1003.43, -99.2),
                },
                furniture = 'livingroom',
            },
            [11] = {
                id = 11,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_micro_01",
                        coords = vector3(344.7, -1002.03, -98.97),
                    },
                    hand = {
                        model = "prop_micro_01",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.05, -0.1),
                        rotation = vector3(0.0, 0.0, 180.0),
                    },
                    vehicle = {
                        model = "prop_micro_01",
                        coords = vector3(0.15, -1.0, 0.3),
                        rotation = vector3(0.0, 0.0, 0.0),
                    }
                }
            },
            [12] = {
                id = 12,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_coffee_mac_02",
                        coords = vector3(342.74, -1003.89, -98.99),
                    },
                    hand = {
                        model = "prop_coffee_mac_02",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.1, -0.08),
                        rotation = vector3(0.0, 90.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_coffee_mac_02",
                        coords = vector3(-0.25, -1.0, 0.3),
                        rotation = vector3(0.0, 0.0, 0.0),
                    }
                }
            },
            [13] = {
                id = 13,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_toaster_01",
                        coords = vector3(341.78, -1003.87, -99.06),
                    },
                    hand = {
                        model = "prop_toaster_01",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.05, -0.05),
                        rotation = vector3(0.0, 0.0, 180.0),
                    },
                    vehicle = {
                        model = "prop_toaster_01",
                        coords = vector3(-0.25, -1.3, 0.3),
                        rotation = vector3(0.0, 0.0, 0.0),
                    }
                }
            },
            [14] = {
                id = 14,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_tapeplayer_01",
                        coords = vector3(341.61, -1001.1, -99.01),
                    },
                    hand = {
                        model = "prop_tapeplayer_01",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.07, -0.1),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_tapeplayer_01",
                        coords = vector3(-0.6, -1.8, 0.3),
                        rotation = vector3(0.0, 0.0, 90.0),
                    }
                }
            },
            [15] = {
                id = 15,
                taken = false,
                busy = false,
                create = true,
                type = "safe",
                animation = {
                    type = 'safe'
                },
                art = {
                    model = "ch_prop_vault_painting_01j",
                    coords = vector3(351.055, -1007.392, -98.911),
                    rotation = vector3(0.0, 0.0, 270),
                },
                prop = {
                    coords = vector3(351.055, -1007.392, -98.911),
                    rotation = vector3(0.0, 0.0, 270),
                    model = "ch_prop_ch_arcade_safe_door",
                },
                furniture = 'safe',
            },
            [16] = {
                id = 16,
                taken = false,
                busy = false,
                create = true,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "vw_prop_vw_watch_case_01b",
                    coords = vector3(341.19, -996.65, -99.657),
                    rotation = vector3(0.0, 0.0, 312.3),
                },
                item = {
                    [1] = {
                        name = "smartwatch",
                        amount = 1,
                        random = true,
                        min = 1,
                        max = 3,
                    },
                    [2] = {
                        name = "rolex",
                        amount = 1,
                        random = true,
                        min = 1,
                        max = 3,
                    }
                },
            },
            [17] = {
                id = 17,
                taken = false,
                busy = false,
                create = true,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "ex_office_swag_electronic2",
                    coords = vector3(352.567, -998.855, -99.535),
                    rotation = vector3(0.0, 0.0, 312.3),
                },
                item = {
                    name = "electronickit",
                    amount = 1,
                    random = true,
                    min = 1,
                    max = 3,
                },
            },
            [18] = {
                id = 18,
                taken = false,
                busy = false,
                create = true,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "3fe_prop_meth_smallbag_01a",
                    coords = vector3(349.32, -996.83, -99.53),
                    rotation = vector3(0.0, 0.0, 90.0),
                },
                item = {
                    name = "meth",
                    amount = 3,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
            [19] = {
                id = 19,
                taken = false,
                busy = false,
                create = true,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "ex_office_swag_drugbags",
                    coords = vector3(338.59, -1001.75, -99.463),
                    rotation = vector3(0.0, 0.0, 308.7),
                },
                item = {
                    name = "cokebaggy",
                    amount = 3,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
            [20] = {
                id = 20,
                taken = false,
                busy = false,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "p_whiskey_bottle_s",
                    coords = vector3(341.94, -1001.43, -99.14),
                },
                item = {
                    name = "whiskey",
                    amount = 1,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
        }
    },
    [24] = {
        id = 24,
        name = 'Vespucci Beach House 4',
        description = 'Big, beautiful and magnificent house',
        image = 'house-24',
        coords = {
            enter = vector3(-1112.34, -1578.4, 8.68),
            exit = vector4(346.56, -1012.84, -99.2, 358.05),
            lock = vector4(-1112.760, -1579.145, 8.975, -145.748),
        },
        tier = 2,
        level = 12,
        opened = false,
        objectRewards = {
            money = 1300,
            xp = 1300,
        },
        reward = 1300,
        loot = {
            [1] = {
                id = 1,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(351.3, -993.51, -99.2),
                },
                furniture = 'cabin',
            },
            [2] = {
                id = 2,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(350.08, -993.49, -99.2),
                },
                furniture = 'cabin',
            },
            [3] = {
                id = 3,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(349.2, -994.79, -99.2),
                },
                furniture = 'livingroom',
            },
            [4] = {
                id = 4,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(351.21, -999.28, -99.2),
                },
                furniture = 'livingroom',
            },
            [5] = {
                id = 5,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(351.96, -998.79, -99.2),
                },
                furniture = 'livingroom',
            },
            [6] = {
                id = 6,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(346.11, -1001.76, -99.2),
                },
                furniture = 'chest',
            },
            [7] = {
                id = 7,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(338.14, -994.98, -99.2),
                },
                furniture = 'chest',
            },
            [8] = {
                id = 8,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(343.76, -1003.27, -99.2),
                },
                furniture = 'kitchen',
            },
            [9] = {
                id = 9,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(344.03, -1001.25, -99.2),
                },
                furniture = 'kitchen',
            },
            [10] = {
                id = 10,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(339.25, -1003.43, -99.2),
                },
                furniture = 'livingroom',
            },
            [11] = {
                id = 11,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_micro_01",
                        coords = vector3(344.7, -1002.03, -98.97),
                    },
                    hand = {
                        model = "prop_micro_01",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.05, -0.1),
                        rotation = vector3(0.0, 0.0, 180.0),
                    },
                    vehicle = {
                        model = "prop_micro_01",
                        coords = vector3(0.15, -1.0, 0.3),
                        rotation = vector3(0.0, 0.0, 0.0),
                    }
                }
            },
            [12] = {
                id = 12,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_coffee_mac_02",
                        coords = vector3(342.74, -1003.89, -98.99),
                    },
                    hand = {
                        model = "prop_coffee_mac_02",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.1, -0.08),
                        rotation = vector3(0.0, 90.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_coffee_mac_02",
                        coords = vector3(-0.25, -1.0, 0.3),
                        rotation = vector3(0.0, 0.0, 0.0),
                    }
                }
            },
            [13] = {
                id = 13,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_toaster_01",
                        coords = vector3(341.78, -1003.87, -99.06),
                    },
                    hand = {
                        model = "prop_toaster_01",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.05, -0.05),
                        rotation = vector3(0.0, 0.0, 180.0),
                    },
                    vehicle = {
                        model = "prop_toaster_01",
                        coords = vector3(-0.25, -1.3, 0.3),
                        rotation = vector3(0.0, 0.0, 0.0),
                    }
                }
            },
            [14] = {
                id = 14,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_tapeplayer_01",
                        coords = vector3(341.61, -1001.1, -99.01),
                    },
                    hand = {
                        model = "prop_tapeplayer_01",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.07, -0.1),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_tapeplayer_01",
                        coords = vector3(-0.6, -1.8, 0.3),
                        rotation = vector3(0.0, 0.0, 90.0),
                    }
                }
            },
            [15] = {
                id = 15,
                taken = false,
                busy = false,
                create = true,
                type = "safe",
                animation = {
                    type = 'safe'
                },
                art = {
                    model = "ch_prop_vault_painting_01j",
                    coords = vector3(351.055, -1007.392, -98.911),
                    rotation = vector3(0.0, 0.0, 270),
                },
                prop = {
                    coords = vector3(351.055, -1007.392, -98.911),
                    rotation = vector3(0.0, 0.0, 270),
                    model = "ch_prop_ch_arcade_safe_door",
                },
                furniture = 'safe',
            },
            [16] = {
                id = 16,
                taken = false,
                busy = false,
                create = true,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "vw_prop_vw_watch_case_01b",
                    coords = vector3(341.19, -996.65, -99.657),
                    rotation = vector3(0.0, 0.0, 312.3),
                },
                item = {
                    [1] = {
                        name = "smartwatch",
                        amount = 1,
                        random = true,
                        min = 1,
                        max = 3,
                    },
                    [2] = {
                        name = "rolex",
                        amount = 1,
                        random = true,
                        min = 1,
                        max = 3,
                    }
                },
            },
            [17] = {
                id = 17,
                taken = false,
                busy = false,
                create = true,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "ex_office_swag_electronic2",
                    coords = vector3(352.567, -998.855, -99.535),
                    rotation = vector3(0.0, 0.0, 312.3),
                },
                item = {
                    name = "electronickit",
                    amount = 1,
                    random = true,
                    min = 1,
                    max = 3,
                },
            },
            [18] = {
                id = 18,
                taken = false,
                busy = false,
                create = true,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "3fe_prop_meth_smallbag_01a",
                    coords = vector3(349.34, -996.82, -99.53),
                    rotation = vector3(0.0, 0.0, 90.0),
                },
                item = {
                    name = "meth",
                    amount = 3,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
            [19] = {
                id = 19,
                taken = false,
                busy = false,
                create = true,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "ex_office_swag_drugbags",
                    coords = vector3(338.59, -1001.75, -99.463),
                    rotation = vector3(0.0, 0.0, 308.7),
                },
                item = {
                    name = "cokebaggy",
                    amount = 3,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
            [20] = {
                id = 20,
                taken = false,
                busy = false,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "p_whiskey_bottle_s",
                    coords = vector3(341.94, -1001.43, -99.14),
                },
                item = {
                    name = "whiskey",
                    amount = 1,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
        }
    },
    [25] = {
        id = 25,
        name = 'Vinewood House 1',
        description = 'Houses of big and rich people',
        image = 'house-25',
        coords = {
            enter = vector3(965.13, -542.03, 59.72),
            exit = vector4(-1289.73, 449.81, 97.9, 185.37),
            lock = vector4(964.290, -542.574, 59.689, 120.336),
        },
        tier = 3,
        level = 13,
        opened = false,
        objectRewards = {
            money = 1400,
            xp = 1400,
        },
        reward = 1400,
        loot = {
            [1] = {
                id = 1,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1287.38, 446.78, 97.89),
                },
                furniture = 'kitchen',
            },
            [2] = {
                id = 2,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1290.34, 432.27, 94.09),
                },
                furniture = 'livingroom',
            },
            [3] = {
                id = 3,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1282.89, 445.53, 94.11),
                },
                furniture = 'livingroom',
            },
            [4] = {
                id = 4,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1282.56, 432.52, 97.5),
                },
                furniture = 'chest',
            },
            [5] = {
                id = 5,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1292.92, 451.46, 90.29),
                },
                furniture = 'chest',
            },
            [6] = {
                id = 6,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1285.86, 456.99, 90.29),
                },
                furniture = 'chest',
            },
            [7] = {
                id = 7,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1287.85, 455.53, 90.29),
                },
                furniture = 'chest',
            },
            [8] = {
                id = 8,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1286.51, 459.14, 90.29),
                },
                furniture = 'chest',
            },
            [9] = {
                id = 9,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1286.08, 438.44, 94.09),
                },
                furniture = 'chest',
            },
            [10] = {
                id = 10,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1283.26, 436.7, 97.69),
                },
                furniture = 'chest',
            },
            [11] = {
                id = 11,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_micro_02",
                        coords = vector3(-1282.16, 444.06, 98.07),
                    },
                    hand = {
                        model = "prop_micro_02",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.1, -0.03),
                        rotation = vector3(0.0, 0.0, 180.0),
                    },
                    vehicle = {
                        model = "prop_micro_02",
                        coords = vector3(0.15, -1.0, 0.27),
                        rotation = vector3(0.0, 0.0, 0.0),
                    }
                }
            },
            [12] = {
                id = 12,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_toaster_01",
                        coords = vector3(-1282.96, 447.72, 98.01),
                    },
                    hand = {
                        model = "prop_toaster_01",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.1, -0.2),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_toaster_01",
                        coords = vector3(-0.2, -1.0, 0.27),
                        rotation = vector3(0.0, 0.0, 90.0),
                    }
                }
            },
            [13] = {
                id = 13,
                taken = false,
                busy = false,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "prop_wine_bot_01",
                    coords = vector3(-1287.37, 444.81, 98.08),
                },
                item = {
                    name = "wine",
                    amount = 1,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
            [14] = {
                id = 14,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_mp3_dock",
                        coords = vector3(-1290.96, 434.4, 97.59),
                    },
                    hand = {
                        model = "prop_mp3_dock",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.1, -0.2),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_mp3_dock",
                        coords = vector3(-0.2, -1.3, 0.27),
                        rotation = vector3(0.0, 0.0, 0.0),
                    }
                }
            },
            [15] = {
                id = 15,
                taken = false,
                busy = false,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "prop_npc_phone",
                    coords = vector3(-1290.92, 434.29, 97.61),
                },
                item = {
                    name = "iphone",
                    amount = 1,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
            [16] = {
                id = 16,
                taken = false,
                busy = false,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "p_whiskey_bottle_s",
                    coords = vector3(-1290.86, 433.23, 97.62),
                },
                item = {
                    name = "whiskey",
                    amount = 1,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
            [17] = {
                id = 17,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_mp3_dock",
                        coords = vector3(-1290.89, 433.54, 94.09),
                    },
                    hand = {
                        model = "prop_mp3_dock",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.1, -0.12),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_mp3_dock",
                        coords = vector3(0.2, -1.3, 0.27),
                        rotation = vector3(0.0, 0.0, 0.0),
                    }
                }
            },
            [18] = {
                id = 18,
                taken = false,
                busy = false,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "prop_npc_phone",
                    coords = vector3(-1290.85, 433.7, 94.07),
                },
                item = {
                    name = "samsungphone",
                    amount = 1,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
            [19] = {
                id = 19,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_monitor_w_large",
                        coords = vector3(-1293.02, 457.31, 90.35),
                    },
                    hand = {
                        model = "prop_monitor_w_large",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.05, -0.3),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_monitor_w_large",
                        coords = vector3(-0.6, -2.0, 0.27),
                        rotation = vector3(0.0, 0.0, 90.0),
                    }
                }
            },
            [20] = {
                id = 20,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_monitor_w_large",
                        coords = vector3(-1293.02, 458.06, 90.33),
                    },
                    hand = {
                        model = "prop_monitor_w_large",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.05, -0.3),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_monitor_w_large",
                        coords = vector3(-0.4, -2.0, 0.27),
                        rotation = vector3(0.0, 0.0, 90.0),
                    }
                }
            },
            [21] = {
                id = 21,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_laptop_01a",
                        coords = vector3(-1291.89, 460.16, 90.05),
                    },
                    hand = {
                        model = "prop_laptop_01a",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.02, -0.18),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_laptop_01a",
                        coords = vector3(-0.3, -1.55, 0.27),
                        rotation = vector3(0.0, 0.0, 0.0),
                    }
                }
            },
            [22] = {
                id = 22,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_printer_01",
                        coords = vector3(-1286.1, 459.97, 90.36),
                    },
                    hand = {
                        model = "prop_printer_01",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.05, -0.18),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_printer_01",
                        coords = vector3(0.15, -1.58, 0.27),
                        rotation = vector3(0.0, 0.0, 0.0),
                    }
                }
            },
            [23] = {
                id = 23,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_keyboard_01b",
                        coords = vector3(-1292.71, 457.58, 90.05),
                    },
                    hand = {
                        model = "prop_keyboard_01b",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.05, -0.18),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_keyboard_01b",
                        coords = vector3(-0.5, -1.65, 0.28),
                        rotation = vector3(0.0, 0.0, 90.0),
                    }
                }
            },
            [24] = {
                id = 24,
                taken = false,
                busy = false,
                create = true,
                type = "money",
                animation = {
                    type = 'grab_cash',
                },
                prop = {
                    coords = vector3(-1284.249, 443.757, 97.856),
                    rotation = vector3(0.0, 0.0, 191.0),
                    model = "h4_prop_h4_cash_stack_01a",
                },
                item = {
                    name = "cash",
                    amount = 20000,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
            [25] = {
                id = 25,
                taken = false,
                busy = false,
                create = true,
                type = "safe",
                animation = {
                    type = 'safe'
                },
                art = {
                    model = "ch_prop_vault_painting_01j",
                    coords = vector3(-1291.15, 439.39, 94.16),
                    rotation = vector3(0.0, 0.0, 88.7),
                },
                prop = {
                    coords = vector3(-1291.15, 439.39, 94.16),
                    rotation = vector3(0.0, 0.0, 88.7),
                    model = "ch_prop_ch_arcade_safe_door",
                },
                furniture = 'safe',
            },
            [26] = {
                id = 26,
                taken = false,
                busy = false,
                type = "item",
                animation = {
                    type = 'tamper',
                },
                prop = {
                    coords = vector3(-1286.21, 432.51, 97.21),
                    model = "prop_bong_01",
                },
                item = {
                    name = "weed_ak47",
                    amount = 1,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
        }
    },
    [26] = {
        id = 26,
        name = 'Vinewood House 2',
        description = 'Houses of big and rich people',
        image = 'house-26',
        coords = {
            enter = vector3(1009.67, -572.42, 60.59),
            exit = vector4(-1289.73, 449.81, 97.9, 185.37),
            lock = vector4(1009.547, -571.663, 61, 85.185),
        },
        tier = 3,
        level = 13,
        opened = false,
        objectRewards = {
            money = 1400,
            xp = 1400,
        },
        reward = 1400,
        loot = {
            [1] = {
                id = 1,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1287.38, 446.78, 97.89),
                },
                furniture = 'kitchen',
            },
            [2] = {
                id = 2,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1290.34, 432.27, 94.09),
                },
                furniture = 'livingroom',
            },
            [3] = {
                id = 3,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1282.89, 445.53, 94.11),
                },
                furniture = 'livingroom',
            },
            [4] = {
                id = 4,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1282.56, 432.52, 97.5),
                },
                furniture = 'chest',
            },
            [5] = {
                id = 5,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1292.92, 451.46, 90.29),
                },
                furniture = 'chest',
            },
            [6] = {
                id = 6,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1285.86, 456.99, 90.29),
                },
                furniture = 'chest',
            },
            [7] = {
                id = 7,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1287.85, 455.53, 90.29),
                },
                furniture = 'chest',
            },
            [8] = {
                id = 8,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1286.51, 459.14, 90.29),
                },
                furniture = 'chest',
            },
            [9] = {
                id = 9,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1286.08, 438.44, 94.09),
                },
                furniture = 'chest',
            },
            [10] = {
                id = 10,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1283.26, 436.7, 97.69),
                },
                furniture = 'chest',
            },
            [11] = {
                id = 11,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_micro_02",
                        coords = vector3(-1282.16, 444.06, 98.07),
                    },
                    hand = {
                        model = "prop_micro_02",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.1, -0.03),
                        rotation = vector3(0.0, 0.0, 180.0),
                    },
                    vehicle = {
                        model = "prop_micro_02",
                        coords = vector3(0.15, -1.0, 0.27),
                        rotation = vector3(0.0, 0.0, 0.0),
                    }
                }
            },
            [12] = {
                id = 12,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_toaster_01",
                        coords = vector3(-1282.96, 447.72, 98.01),
                    },
                    hand = {
                        model = "prop_toaster_01",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.1, -0.2),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_toaster_01",
                        coords = vector3(-0.2, -1.0, 0.27),
                        rotation = vector3(0.0, 0.0, 90.0),
                    }
                }
            },
            [13] = {
                id = 13,
                taken = false,
                busy = false,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "prop_wine_bot_01",
                    coords = vector3(-1287.37, 444.81, 98.08),
                },
                item = {
                    name = "wine",
                    amount = 1,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
            [14] = {
                id = 14,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_mp3_dock",
                        coords = vector3(-1290.96, 434.4, 97.59),
                    },
                    hand = {
                        model = "prop_mp3_dock",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.1, -0.2),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_mp3_dock",
                        coords = vector3(-0.2, -1.3, 0.27),
                        rotation = vector3(0.0, 0.0, 0.0),
                    }
                }
            },
            [15] = {
                id = 15,
                taken = false,
                busy = false,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "prop_npc_phone",
                    coords = vector3(-1290.92, 434.29, 97.61),
                },
                item = {
                    name = "iphone",
                    amount = 1,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
            [16] = {
                id = 16,
                taken = false,
                busy = false,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "p_whiskey_bottle_s",
                    coords = vector3(-1290.86, 433.23, 97.62),
                },
                item = {
                    name = "whiskey",
                    amount = 1,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
            [17] = {
                id = 17,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_mp3_dock",
                        coords = vector3(-1290.89, 433.54, 94.09),
                    },
                    hand = {
                        model = "prop_mp3_dock",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.1, -0.12),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_mp3_dock",
                        coords = vector3(0.2, -1.3, 0.27),
                        rotation = vector3(0.0, 0.0, 0.0),
                    }
                }
            },
            [18] = {
                id = 18,
                taken = false,
                busy = false,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "prop_npc_phone",
                    coords = vector3(-1290.85, 433.7, 94.07),
                },
                item = {
                    name = "samsungphone",
                    amount = 1,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
            [19] = {
                id = 19,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_monitor_w_large",
                        coords = vector3(-1293.02, 457.31, 90.35),
                    },
                    hand = {
                        model = "prop_monitor_w_large",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.05, -0.3),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_monitor_w_large",
                        coords = vector3(-0.6, -2.0, 0.27),
                        rotation = vector3(0.0, 0.0, 90.0),
                    }
                }
            },
            [20] = {
                id = 20,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_monitor_w_large",
                        coords = vector3(-1293.02, 458.06, 90.33),
                    },
                    hand = {
                        model = "prop_monitor_w_large",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.05, -0.3),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_monitor_w_large",
                        coords = vector3(-0.4, -2.0, 0.27),
                        rotation = vector3(0.0, 0.0, 90.0),
                    }
                }
            },
            [21] = {
                id = 21,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_laptop_01a",
                        coords = vector3(-1291.89, 460.16, 90.05),
                    },
                    hand = {
                        model = "prop_laptop_01a",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.02, -0.18),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_laptop_01a",
                        coords = vector3(-0.3, -1.55, 0.27),
                        rotation = vector3(0.0, 0.0, 0.0),
                    }
                }
            },
            [22] = {
                id = 22,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_printer_01",
                        coords = vector3(-1286.1, 459.97, 90.36),
                    },
                    hand = {
                        model = "prop_printer_01",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.05, -0.18),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_printer_01",
                        coords = vector3(0.15, -1.58, 0.27),
                        rotation = vector3(0.0, 0.0, 0.0),
                    }
                }
            },
            [23] = {
                id = 23,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_keyboard_01b",
                        coords = vector3(-1292.71, 457.58, 90.05),
                    },
                    hand = {
                        model = "prop_keyboard_01b",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.05, -0.18),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_keyboard_01b",
                        coords = vector3(-0.5, -1.65, 0.28),
                        rotation = vector3(0.0, 0.0, 90.0),
                    }
                }
            },
            [24] = {
                id = 24,
                taken = false,
                busy = false,
                create = true,
                type = "money",
                animation = {
                    type = 'grab_cash',
                },
                prop = {
                    coords = vector3(-1284.249, 443.757, 97.856),
                    rotation = vector3(0.0, 0.0, 191.0),
                    model = "h4_prop_h4_cash_stack_01a",
                },
                item = {
                    name = "cash",
                    amount = 20000,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
            [25] = {
                id = 25,
                taken = false,
                busy = false,
                create = true,
                type = "safe",
                animation = {
                    type = 'safe'
                },
                art = {
                    model = "ch_prop_vault_painting_01j",
                    coords = vector3(-1291.15, 439.39, 94.16),
                    rotation = vector3(0.0, 0.0, 88.7),
                },
                prop = {
                    coords = vector3(-1291.15, 439.39, 94.16),
                    rotation = vector3(0.0, 0.0, 88.7),
                    model = "ch_prop_ch_arcade_safe_door",
                },
                furniture = 'safe',
            },
            [26] = {
                id = 26,
                taken = false,
                busy = false,
                type = "item",
                animation = {
                    type = 'tamper',
                },
                prop = {
                    coords = vector3(-1286.21, 432.51, 97.21),
                    model = "prop_bong_01",
                },
                item = {
                    name = "weed_ak47",
                    amount = 1,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
        }
    },
    [27] = {
        id = 27,
        name = 'Vinewood House 3',
        description = 'Houses of big and rich people',
        image = 'house-27',
        coords = {
            enter = vector3(1223.11, -697.04, 60.8),
            exit = vector4(-1289.73, 449.81, 97.9, 185.37),
            lock = vector4(1223.159, -696.003, 61.2, -77.272),
        },
        tier = 3,
        level = 14,
        opened = false,
        objectRewards = {
            money = 1500,
            xp = 1500,
        },
        reward = 1500,
        loot = {
            [1] = {
                id = 1,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1287.38, 446.78, 97.89),
                },
                furniture = 'kitchen',
            },
            [2] = {
                id = 2,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1290.34, 432.27, 94.09),
                },
                furniture = 'livingroom',
            },
            [3] = {
                id = 3,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1282.89, 445.53, 94.11),
                },
                furniture = 'livingroom',
            },
            [4] = {
                id = 4,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1282.56, 432.52, 97.5),
                },
                furniture = 'chest',
            },
            [5] = {
                id = 5,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1292.92, 451.46, 90.29),
                },
                furniture = 'chest',
            },
            [6] = {
                id = 6,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1285.86, 456.99, 90.29),
                },
                furniture = 'chest',
            },
            [7] = {
                id = 7,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1287.85, 455.53, 90.29),
                },
                furniture = 'chest',
            },
            [8] = {
                id = 8,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1286.51, 459.14, 90.29),
                },
                furniture = 'chest',
            },
            [9] = {
                id = 9,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1286.08, 438.44, 94.09),
                },
                furniture = 'chest',
            },
            [10] = {
                id = 10,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1283.26, 436.7, 97.69),
                },
                furniture = 'chest',
            },
            [11] = {
                id = 11,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_micro_02",
                        coords = vector3(-1282.16, 444.06, 98.07),
                    },
                    hand = {
                        model = "prop_micro_02",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.1, -0.03),
                        rotation = vector3(0.0, 0.0, 180.0),
                    },
                    vehicle = {
                        model = "prop_micro_02",
                        coords = vector3(0.15, -1.0, 0.27),
                        rotation = vector3(0.0, 0.0, 0.0),
                    }
                }
            },
            [12] = {
                id = 12,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_toaster_01",
                        coords = vector3(-1282.96, 447.72, 98.01),
                    },
                    hand = {
                        model = "prop_toaster_01",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.1, -0.2),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_toaster_01",
                        coords = vector3(-0.2, -1.0, 0.27),
                        rotation = vector3(0.0, 0.0, 90.0),
                    }
                }
            },
            [13] = {
                id = 13,
                taken = false,
                busy = false,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "prop_wine_bot_01",
                    coords = vector3(-1287.37, 444.81, 98.08),
                },
                item = {
                    name = "wine",
                    amount = 1,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
            [14] = {
                id = 14,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_mp3_dock",
                        coords = vector3(-1290.96, 434.4, 97.59),
                    },
                    hand = {
                        model = "prop_mp3_dock",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.1, -0.2),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_mp3_dock",
                        coords = vector3(-0.2, -1.3, 0.27),
                        rotation = vector3(0.0, 0.0, 0.0),
                    }
                }
            },
            [15] = {
                id = 15,
                taken = false,
                busy = false,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "prop_npc_phone",
                    coords = vector3(-1290.92, 434.29, 97.61),
                },
                item = {
                    name = "iphone",
                    amount = 1,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
            [16] = {
                id = 16,
                taken = false,
                busy = false,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "p_whiskey_bottle_s",
                    coords = vector3(-1290.86, 433.23, 97.62),
                },
                item = {
                    name = "whiskey",
                    amount = 1,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
            [17] = {
                id = 17,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_mp3_dock",
                        coords = vector3(-1290.89, 433.54, 94.09),
                    },
                    hand = {
                        model = "prop_mp3_dock",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.1, -0.12),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_mp3_dock",
                        coords = vector3(0.2, -1.3, 0.27),
                        rotation = vector3(0.0, 0.0, 0.0),
                    }
                }
            },
            [18] = {
                id = 18,
                taken = false,
                busy = false,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "prop_npc_phone",
                    coords = vector3(-1290.85, 433.7, 94.07),
                },
                item = {
                    name = "samsungphone",
                    amount = 1,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
            [19] = {
                id = 19,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_monitor_w_large",
                        coords = vector3(-1293.02, 457.31, 90.35),
                    },
                    hand = {
                        model = "prop_monitor_w_large",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.05, -0.3),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_monitor_w_large",
                        coords = vector3(-0.6, -2.0, 0.27),
                        rotation = vector3(0.0, 0.0, 90.0),
                    }
                }
            },
            [20] = {
                id = 20,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_monitor_w_large",
                        coords = vector3(-1293.02, 458.06, 90.33),
                    },
                    hand = {
                        model = "prop_monitor_w_large",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.05, -0.3),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_monitor_w_large",
                        coords = vector3(-0.4, -2.0, 0.27),
                        rotation = vector3(0.0, 0.0, 90.0),
                    }
                }
            },
            [21] = {
                id = 21,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_laptop_01a",
                        coords = vector3(-1291.89, 460.16, 90.05),
                    },
                    hand = {
                        model = "prop_laptop_01a",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.02, -0.18),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_laptop_01a",
                        coords = vector3(-0.3, -1.55, 0.27),
                        rotation = vector3(0.0, 0.0, 0.0),
                    }
                }
            },
            [22] = {
                id = 22,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_printer_01",
                        coords = vector3(-1286.1, 459.97, 90.36),
                    },
                    hand = {
                        model = "prop_printer_01",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.05, -0.18),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_printer_01",
                        coords = vector3(0.15, -1.58, 0.27),
                        rotation = vector3(0.0, 0.0, 0.0),
                    }
                }
            },
            [23] = {
                id = 23,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_keyboard_01b",
                        coords = vector3(-1292.71, 457.58, 90.05),
                    },
                    hand = {
                        model = "prop_keyboard_01b",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.05, -0.18),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_keyboard_01b",
                        coords = vector3(-0.5, -1.65, 0.28),
                        rotation = vector3(0.0, 0.0, 90.0),
                    }
                }
            },
            [24] = {
                id = 24,
                taken = false,
                busy = false,
                create = true,
                type = "money",
                animation = {
                    type = 'grab_cash',
                },
                prop = {
                    coords = vector3(-1284.249, 443.757, 97.856),
                    rotation = vector3(0.0, 0.0, 191.0),
                    model = "h4_prop_h4_cash_stack_01a",
                },
                item = {
                    name = "cash",
                    amount = 20000,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
            [25] = {
                id = 25,
                taken = false,
                busy = false,
                create = true,
                type = "safe",
                animation = {
                    type = 'safe'
                },
                art = {
                    model = "ch_prop_vault_painting_01j",
                    coords = vector3(-1291.15, 439.39, 94.16),
                    rotation = vector3(0.0, 0.0, 88.7),
                },
                prop = {
                    coords = vector3(-1291.15, 439.39, 94.16),
                    rotation = vector3(0.0, 0.0, 88.7),
                    model = "ch_prop_ch_arcade_safe_door",
                },
                furniture = 'safe',
            },
            [26] = {
                id = 26,
                taken = false,
                busy = false,
                type = "item",
                animation = {
                    type = 'tamper',
                },
                prop = {
                    coords = vector3(-1286.21, 432.51, 97.21),
                    model = "prop_bong_01",
                },
                item = {
                    name = "weed_ak47",
                    amount = 1,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
        }
    },
    [28] = {
        id = 28,
        name = 'Vinewood House 4',
        description = 'Houses of big and rich people',
        image = 'house-28',
        coords = {
            enter = vector3(1207.31, -620.33, 66.43),
            exit = vector4(-1289.73, 449.81, 97.9, 185.37),
            lock = vector4(1207.636, -621.198, 66.771, -85.202),
        },
        tier = 3,
        level = 14,
        opened = false,
        objectRewards = {
            money = 1500,
            xp = 1500,
        },
        reward = 1500,
        loot = {
            [1] = {
                id = 1,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1287.38, 446.78, 97.89),
                },
                furniture = 'kitchen',
            },
            [2] = {
                id = 2,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1290.34, 432.27, 94.09),
                },
                furniture = 'livingroom',
            },
            [3] = {
                id = 3,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1282.89, 445.53, 94.11),
                },
                furniture = 'livingroom',
            },
            [4] = {
                id = 4,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1282.56, 432.52, 97.5),
                },
                furniture = 'chest',
            },
            [5] = {
                id = 5,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1292.92, 451.46, 90.29),
                },
                furniture = 'chest',
            },
            [6] = {
                id = 6,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1285.86, 456.99, 90.29),
                },
                furniture = 'chest',
            },
            [7] = {
                id = 7,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1287.85, 455.53, 90.29),
                },
                furniture = 'chest',
            },
            [8] = {
                id = 8,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1286.51, 459.14, 90.29),
                },
                furniture = 'chest',
            },
            [9] = {
                id = 9,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1286.08, 438.44, 94.09),
                },
                furniture = 'chest',
            },
            [10] = {
                id = 10,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1283.26, 436.7, 97.69),
                },
                furniture = 'chest',
            },
            [11] = {
                id = 11,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_micro_02",
                        coords = vector3(-1282.16, 444.06, 98.07),
                    },
                    hand = {
                        model = "prop_micro_02",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.1, -0.03),
                        rotation = vector3(0.0, 0.0, 180.0),
                    },
                    vehicle = {
                        model = "prop_micro_02",
                        coords = vector3(0.15, -1.0, 0.27),
                        rotation = vector3(0.0, 0.0, 0.0),
                    }
                }
            },
            [12] = {
                id = 12,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_toaster_01",
                        coords = vector3(-1282.96, 447.72, 98.01),
                    },
                    hand = {
                        model = "prop_toaster_01",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.1, -0.2),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_toaster_01",
                        coords = vector3(-0.2, -1.0, 0.27),
                        rotation = vector3(0.0, 0.0, 90.0),
                    }
                }
            },
            [13] = {
                id = 13,
                taken = false,
                busy = false,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "prop_wine_bot_01",
                    coords = vector3(-1287.37, 444.81, 98.08),
                },
                item = {
                    name = "wine",
                    amount = 1,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
            [14] = {
                id = 14,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_mp3_dock",
                        coords = vector3(-1290.96, 434.4, 97.59),
                    },
                    hand = {
                        model = "prop_mp3_dock",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.1, -0.2),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_mp3_dock",
                        coords = vector3(-0.2, -1.3, 0.27),
                        rotation = vector3(0.0, 0.0, 0.0),
                    }
                }
            },
            [15] = {
                id = 15,
                taken = false,
                busy = false,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "prop_npc_phone",
                    coords = vector3(-1290.92, 434.29, 97.61),
                },
                item = {
                    name = "iphone",
                    amount = 1,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
            [16] = {
                id = 16,
                taken = false,
                busy = false,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "p_whiskey_bottle_s",
                    coords = vector3(-1290.86, 433.23, 97.62),
                },
                item = {
                    name = "whiskey",
                    amount = 1,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
            [17] = {
                id = 17,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_mp3_dock",
                        coords = vector3(-1290.89, 433.54, 94.09),
                    },
                    hand = {
                        model = "prop_mp3_dock",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.1, -0.12),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_mp3_dock",
                        coords = vector3(0.2, -1.3, 0.27),
                        rotation = vector3(0.0, 0.0, 0.0),
                    }
                }
            },
            [18] = {
                id = 18,
                taken = false,
                busy = false,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "prop_npc_phone",
                    coords = vector3(-1290.85, 433.7, 94.07),
                },
                item = {
                    name = "samsungphone",
                    amount = 1,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
            [19] = {
                id = 19,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_monitor_w_large",
                        coords = vector3(-1293.02, 457.31, 90.35),
                    },
                    hand = {
                        model = "prop_monitor_w_large",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.05, -0.3),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_monitor_w_large",
                        coords = vector3(-0.6, -2.0, 0.27),
                        rotation = vector3(0.0, 0.0, 90.0),
                    }
                }
            },
            [20] = {
                id = 20,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_monitor_w_large",
                        coords = vector3(-1293.02, 458.06, 90.33),
                    },
                    hand = {
                        model = "prop_monitor_w_large",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.05, -0.3),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_monitor_w_large",
                        coords = vector3(-0.4, -2.0, 0.27),
                        rotation = vector3(0.0, 0.0, 90.0),
                    }
                }
            },
            [21] = {
                id = 21,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_laptop_01a",
                        coords = vector3(-1291.89, 460.16, 90.05),
                    },
                    hand = {
                        model = "prop_laptop_01a",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.02, -0.18),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_laptop_01a",
                        coords = vector3(-0.3, -1.55, 0.27),
                        rotation = vector3(0.0, 0.0, 0.0),
                    }
                }
            },
            [22] = {
                id = 22,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_printer_01",
                        coords = vector3(-1286.1, 459.97, 90.36),
                    },
                    hand = {
                        model = "prop_printer_01",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.05, -0.18),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_printer_01",
                        coords = vector3(0.15, -1.58, 0.27),
                        rotation = vector3(0.0, 0.0, 0.0),
                    }
                }
            },
            [23] = {
                id = 23,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_keyboard_01b",
                        coords = vector3(-1292.71, 457.58, 90.05),
                    },
                    hand = {
                        model = "prop_keyboard_01b",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.05, -0.18),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_keyboard_01b",
                        coords = vector3(-0.5, -1.65, 0.28),
                        rotation = vector3(0.0, 0.0, 90.0),
                    }
                }
            },
            [24] = {
                id = 24,
                taken = false,
                busy = false,
                create = true,
                type = "money",
                animation = {
                    type = 'grab_cash',
                },
                prop = {
                    coords = vector3(-1284.249, 443.757, 97.856),
                    rotation = vector3(0.0, 0.0, 191.0),
                    model = "h4_prop_h4_cash_stack_01a",
                },
                item = {
                    name = "cash",
                    amount = 20000,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
            [25] = {
                id = 25,
                taken = false,
                busy = false,
                create = true,
                type = "safe",
                animation = {
                    type = 'safe'
                },
                art = {
                    model = "ch_prop_vault_painting_01j",
                    coords = vector3(-1291.15, 439.39, 94.16),
                    rotation = vector3(0.0, 0.0, 88.7),
                },
                prop = {
                    coords = vector3(-1291.15, 439.39, 94.16),
                    rotation = vector3(0.0, 0.0, 88.7),
                    model = "ch_prop_ch_arcade_safe_door",
                },
                furniture = 'safe',
            },
            [26] = {
                id = 26,
                taken = false,
                busy = false,
                type = "item",
                animation = {
                    type = 'tamper',
                },
                prop = {
                    coords = vector3(-1286.21, 432.51, 97.21),
                    model = "prop_bong_01",
                },
                item = {
                    name = "weed_ak47",
                    amount = 1,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
        }
    },
    [29] = {
        id = 29,
        name = 'Vinewood House 5',
        description = 'Houses of big and rich people',
        image = 'house-29',
        coords = {
            enter = vector3(1006.4, -510.83, 60.99),
            exit = vector4(-1289.73, 449.81, 97.9, 185.37),
            lock = vector4(1006.207, -510.092, 61.365, 24.300),
        },
        tier = 3,
        level = 15,
        opened = false,
        objectRewards = {
            money = 1600,
            xp = 1600,
        },
        reward = 1600,
        loot = {
            [1] = {
                id = 1,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1287.38, 446.78, 97.89),
                },
                furniture = 'kitchen',
            },
            [2] = {
                id = 2,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1290.34, 432.27, 94.09),
                },
                furniture = 'livingroom',
            },
            [3] = {
                id = 3,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1282.89, 445.53, 94.11),
                },
                furniture = 'livingroom',
            },
            [4] = {
                id = 4,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1282.56, 432.52, 97.5),
                },
                furniture = 'chest',
            },
            [5] = {
                id = 5,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1292.92, 451.46, 90.29),
                },
                furniture = 'chest',
            },
            [6] = {
                id = 6,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1285.86, 456.99, 90.29),
                },
                furniture = 'chest',
            },
            [7] = {
                id = 7,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1287.85, 455.53, 90.29),
                },
                furniture = 'chest',
            },
            [8] = {
                id = 8,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1286.51, 459.14, 90.29),
                },
                furniture = 'chest',
            },
            [9] = {
                id = 9,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1286.08, 438.44, 94.09),
                },
                furniture = 'chest',
            },
            [10] = {
                id = 10,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1283.26, 436.7, 97.69),
                },
                furniture = 'chest',
            },
            [11] = {
                id = 11,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_micro_02",
                        coords = vector3(-1282.16, 444.06, 98.07),
                    },
                    hand = {
                        model = "prop_micro_02",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.1, -0.03),
                        rotation = vector3(0.0, 0.0, 180.0),
                    },
                    vehicle = {
                        model = "prop_micro_02",
                        coords = vector3(0.15, -1.0, 0.27),
                        rotation = vector3(0.0, 0.0, 0.0),
                    }
                }
            },
            [12] = {
                id = 12,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_toaster_01",
                        coords = vector3(-1282.96, 447.72, 98.01),
                    },
                    hand = {
                        model = "prop_toaster_01",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.1, -0.2),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_toaster_01",
                        coords = vector3(-0.2, -1.0, 0.27),
                        rotation = vector3(0.0, 0.0, 90.0),
                    }
                }
            },
            [13] = {
                id = 13,
                taken = false,
                busy = false,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "prop_wine_bot_01",
                    coords = vector3(-1287.37, 444.81, 98.08),
                },
                item = {
                    name = "wine",
                    amount = 1,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
            [14] = {
                id = 14,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_mp3_dock",
                        coords = vector3(-1290.96, 434.4, 97.59),
                    },
                    hand = {
                        model = "prop_mp3_dock",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.1, -0.2),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_mp3_dock",
                        coords = vector3(-0.2, -1.3, 0.27),
                        rotation = vector3(0.0, 0.0, 0.0),
                    }
                }
            },
            [15] = {
                id = 15,
                taken = false,
                busy = false,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "prop_npc_phone",
                    coords = vector3(-1290.92, 434.29, 97.61),
                },
                item = {
                    name = "iphone",
                    amount = 1,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
            [16] = {
                id = 16,
                taken = false,
                busy = false,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "p_whiskey_bottle_s",
                    coords = vector3(-1290.86, 433.23, 97.62),
                },
                item = {
                    name = "whiskey",
                    amount = 1,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
            [17] = {
                id = 17,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_mp3_dock",
                        coords = vector3(-1290.89, 433.54, 94.09),
                    },
                    hand = {
                        model = "prop_mp3_dock",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.1, -0.12),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_mp3_dock",
                        coords = vector3(0.2, -1.3, 0.27),
                        rotation = vector3(0.0, 0.0, 0.0),
                    }
                }
            },
            [18] = {
                id = 18,
                taken = false,
                busy = false,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "prop_npc_phone",
                    coords = vector3(-1290.85, 433.7, 94.07),
                },
                item = {
                    name = "samsungphone",
                    amount = 1,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
            [19] = {
                id = 19,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_monitor_w_large",
                        coords = vector3(-1293.02, 457.31, 90.35),
                    },
                    hand = {
                        model = "prop_monitor_w_large",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.05, -0.3),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_monitor_w_large",
                        coords = vector3(-0.6, -2.0, 0.27),
                        rotation = vector3(0.0, 0.0, 90.0),
                    }
                }
            },
            [20] = {
                id = 20,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_monitor_w_large",
                        coords = vector3(-1293.02, 458.06, 90.33),
                    },
                    hand = {
                        model = "prop_monitor_w_large",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.05, -0.3),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_monitor_w_large",
                        coords = vector3(-0.4, -2.0, 0.27),
                        rotation = vector3(0.0, 0.0, 90.0),
                    }
                }
            },
            [21] = {
                id = 21,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_laptop_01a",
                        coords = vector3(-1291.89, 460.16, 90.05),
                    },
                    hand = {
                        model = "prop_laptop_01a",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.02, -0.18),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_laptop_01a",
                        coords = vector3(-0.3, -1.55, 0.27),
                        rotation = vector3(0.0, 0.0, 0.0),
                    }
                }
            },
            [22] = {
                id = 22,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_printer_01",
                        coords = vector3(-1286.1, 459.97, 90.36),
                    },
                    hand = {
                        model = "prop_printer_01",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.05, -0.18),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_printer_01",
                        coords = vector3(0.15, -1.58, 0.27),
                        rotation = vector3(0.0, 0.0, 0.0),
                    }
                }
            },
            [23] = {
                id = 23,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_keyboard_01b",
                        coords = vector3(-1292.71, 457.58, 90.05),
                    },
                    hand = {
                        model = "prop_keyboard_01b",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.05, -0.18),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_keyboard_01b",
                        coords = vector3(-0.5, -1.65, 0.28),
                        rotation = vector3(0.0, 0.0, 90.0),
                    }
                }
            },
            [24] = {
                id = 24,
                taken = false,
                busy = false,
                create = true,
                type = "money",
                animation = {
                    type = 'grab_cash',
                },
                prop = {
                    coords = vector3(-1284.249, 443.757, 97.856),
                    rotation = vector3(0.0, 0.0, 191.0),
                    model = "h4_prop_h4_cash_stack_01a",
                },
                item = {
                    name = "cash",
                    amount = 20000,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
            [25] = {
                id = 25,
                taken = false,
                busy = false,
                create = true,
                type = "safe",
                animation = {
                    type = 'safe'
                },
                art = {
                    model = "ch_prop_vault_painting_01j",
                    coords = vector3(-1291.15, 439.39, 94.16),
                    rotation = vector3(0.0, 0.0, 88.7),
                },
                prop = {
                    coords = vector3(-1291.15, 439.39, 94.16),
                    rotation = vector3(0.0, 0.0, 88.7),
                    model = "ch_prop_ch_arcade_safe_door",
                },
                furniture = 'safe',
            },
            [26] = {
                id = 26,
                taken = false,
                busy = false,
                type = "item",
                animation = {
                    type = 'tamper',
                },
                prop = {
                    coords = vector3(-1286.21, 432.51, 97.21),
                    model = "prop_bong_01",
                },
                item = {
                    name = "weed_ak47",
                    amount = 1,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
        }
    },
    [30] = {
        id = 30,
        name = 'Vinewood House 6',
        description = 'Houses of big and rich people',
        image = 'house-30',
        coords = {
            enter = vector3(1046.38, -498.17, 64.28),
            exit = vector4(-1289.73, 449.81, 97.9, 185.37),
            lock = vector4(1045.166, -497.935, 64.372, 79.183),
        },
        tier = 3,
        level = 15,
        opened = false,
        objectRewards = {
            money = 1600,
            xp = 1600,
        },
        reward = 1600,
        loot = {
            [1] = {
                id = 1,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1287.38, 446.78, 97.89),
                },
                furniture = 'kitchen',
            },
            [2] = {
                id = 2,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1290.34, 432.27, 94.09),
                },
                furniture = 'livingroom',
            },
            [3] = {
                id = 3,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1282.89, 445.53, 94.11),
                },
                furniture = 'livingroom',
            },
            [4] = {
                id = 4,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1282.56, 432.52, 97.5),
                },
                furniture = 'chest',
            },
            [5] = {
                id = 5,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1292.92, 451.46, 90.29),
                },
                furniture = 'chest',
            },
            [6] = {
                id = 6,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1285.86, 456.99, 90.29),
                },
                furniture = 'chest',
            },
            [7] = {
                id = 7,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1287.85, 455.53, 90.29),
                },
                furniture = 'chest',
            },
            [8] = {
                id = 8,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1286.51, 459.14, 90.29),
                },
                furniture = 'chest',
            },
            [9] = {
                id = 9,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1286.08, 438.44, 94.09),
                },
                furniture = 'chest',
            },
            [10] = {
                id = 10,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1283.26, 436.7, 97.69),
                },
                furniture = 'chest',
            },
            [11] = {
                id = 11,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_micro_02",
                        coords = vector3(-1282.16, 444.06, 98.07),
                    },
                    hand = {
                        model = "prop_micro_02",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.1, -0.03),
                        rotation = vector3(0.0, 0.0, 180.0),
                    },
                    vehicle = {
                        model = "prop_micro_02",
                        coords = vector3(0.15, -1.0, 0.27),
                        rotation = vector3(0.0, 0.0, 0.0),
                    }
                }
            },
            [12] = {
                id = 12,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_toaster_01",
                        coords = vector3(-1282.96, 447.72, 98.01),
                    },
                    hand = {
                        model = "prop_toaster_01",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.1, -0.2),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_toaster_01",
                        coords = vector3(-0.2, -1.0, 0.27),
                        rotation = vector3(0.0, 0.0, 90.0),
                    }
                }
            },
            [13] = {
                id = 13,
                taken = false,
                busy = false,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "prop_wine_bot_01",
                    coords = vector3(-1287.37, 444.81, 98.08),
                },
                item = {
                    name = "wine",
                    amount = 1,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
            [14] = {
                id = 14,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_mp3_dock",
                        coords = vector3(-1290.96, 434.4, 97.59),
                    },
                    hand = {
                        model = "prop_mp3_dock",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.1, -0.2),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_mp3_dock",
                        coords = vector3(-0.2, -1.3, 0.27),
                        rotation = vector3(0.0, 0.0, 0.0),
                    }
                }
            },
            [15] = {
                id = 15,
                taken = false,
                busy = false,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "prop_npc_phone",
                    coords = vector3(-1290.92, 434.29, 97.61),
                },
                item = {
                    name = "iphone",
                    amount = 1,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
            [16] = {
                id = 16,
                taken = false,
                busy = false,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "p_whiskey_bottle_s",
                    coords = vector3(-1290.86, 433.23, 97.62),
                },
                item = {
                    name = "whiskey",
                    amount = 1,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
            [17] = {
                id = 17,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_mp3_dock",
                        coords = vector3(-1290.89, 433.54, 94.09),
                    },
                    hand = {
                        model = "prop_mp3_dock",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.1, -0.12),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_mp3_dock",
                        coords = vector3(0.2, -1.3, 0.27),
                        rotation = vector3(0.0, 0.0, 0.0),
                    }
                }
            },
            [18] = {
                id = 18,
                taken = false,
                busy = false,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "prop_npc_phone",
                    coords = vector3(-1290.85, 433.7, 94.07),
                },
                item = {
                    name = "samsungphone",
                    amount = 1,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
            [19] = {
                id = 19,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_monitor_w_large",
                        coords = vector3(-1293.02, 457.31, 90.35),
                    },
                    hand = {
                        model = "prop_monitor_w_large",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.05, -0.3),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_monitor_w_large",
                        coords = vector3(-0.6, -2.0, 0.27),
                        rotation = vector3(0.0, 0.0, 90.0),
                    }
                }
            },
            [20] = {
                id = 20,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_monitor_w_large",
                        coords = vector3(-1293.02, 458.06, 90.33),
                    },
                    hand = {
                        model = "prop_monitor_w_large",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.05, -0.3),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_monitor_w_large",
                        coords = vector3(-0.4, -2.0, 0.27),
                        rotation = vector3(0.0, 0.0, 90.0),
                    }
                }
            },
            [21] = {
                id = 21,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_laptop_01a",
                        coords = vector3(-1291.89, 460.16, 90.05),
                    },
                    hand = {
                        model = "prop_laptop_01a",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.02, -0.18),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_laptop_01a",
                        coords = vector3(-0.3, -1.55, 0.27),
                        rotation = vector3(0.0, 0.0, 0.0),
                    }
                }
            },
            [22] = {
                id = 22,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_printer_01",
                        coords = vector3(-1286.1, 459.97, 90.36),
                    },
                    hand = {
                        model = "prop_printer_01",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.05, -0.18),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_printer_01",
                        coords = vector3(0.15, -1.58, 0.27),
                        rotation = vector3(0.0, 0.0, 0.0),
                    }
                }
            },
            [23] = {
                id = 23,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_keyboard_01b",
                        coords = vector3(-1292.71, 457.58, 90.05),
                    },
                    hand = {
                        model = "prop_keyboard_01b",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.05, -0.18),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_keyboard_01b",
                        coords = vector3(-0.5, -1.65, 0.28),
                        rotation = vector3(0.0, 0.0, 90.0),
                    }
                }
            },
            [24] = {
                id = 24,
                taken = false,
                busy = false,
                create = true,
                type = "money",
                animation = {
                    type = 'grab_cash',
                },
                prop = {
                    coords = vector3(-1284.249, 443.757, 97.856),
                    rotation = vector3(0.0, 0.0, 191.0),
                    model = "h4_prop_h4_cash_stack_01a",
                },
                item = {
                    name = "cash",
                    amount = 20000,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
            [25] = {
                id = 25,
                taken = false,
                busy = false,
                create = true,
                type = "safe",
                animation = {
                    type = 'safe'
                },
                art = {
                    model = "ch_prop_vault_painting_01j",
                    coords = vector3(-1291.15, 439.39, 94.16),
                    rotation = vector3(0.0, 0.0, 88.7),
                },
                prop = {
                    coords = vector3(-1291.15, 439.39, 94.16),
                    rotation = vector3(0.0, 0.0, 88.7),
                    model = "ch_prop_ch_arcade_safe_door",
                },
                furniture = 'safe',
            },
            [26] = {
                id = 26,
                taken = false,
                busy = false,
                type = "item",
                animation = {
                    type = 'tamper',
                },
                prop = {
                    coords = vector3(-1286.21, 432.51, 97.21),
                    model = "prop_bong_01",
                },
                item = {
                    name = "weed_ak47",
                    amount = 1,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
        }
    },
    [31] = {
        id = 31,
        name = 'Vinewood House 7',
        description = 'Houses of big and rich people',
        image = 'house-31',
        coords = {
            enter = vector3(1051.09, -470.33, 64.3),
            exit = vector4(-1289.73, 449.81, 97.9, 185.37),
            lock = vector4(1051.030, -469.508, 64.5, 80.331),
        },
        tier = 3,
        level = 16,
        opened = false,
        objectRewards = {
            money = 1700,
            xp = 1700,
        },
        reward = 1700,
        loot = {}
    },
    [32] = {
        id = 32,
        name = 'Vinewood House 8',
        description = 'Houses of big and rich people',
        image = 'house-32',
        coords = {
            enter = vector3(1389.11, -569.51, 74.5),
            exit = vector4(-1289.73, 449.81, 97.9, 185.37),
            lock = vector4(1389.438, -570.160, 74.809, -155.110),
        },
        tier = 3,
        level = 16,
        opened = false,
        objectRewards = {
            money = 1700,
            xp = 1700,
        },
        reward = 1700,
        loot = {
            [1] = {
                id = 1,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1287.38, 446.78, 97.89),
                },
                furniture = 'kitchen',
            },
            [2] = {
                id = 2,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1290.34, 432.27, 94.09),
                },
                furniture = 'livingroom',
            },
            [3] = {
                id = 3,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1282.89, 445.53, 94.11),
                },
                furniture = 'livingroom',
            },
            [4] = {
                id = 4,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1282.56, 432.52, 97.5),
                },
                furniture = 'chest',
            },
            [5] = {
                id = 5,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1292.92, 451.46, 90.29),
                },
                furniture = 'chest',
            },
            [6] = {
                id = 6,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1285.86, 456.99, 90.29),
                },
                furniture = 'chest',
            },
            [7] = {
                id = 7,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1287.85, 455.53, 90.29),
                },
                furniture = 'chest',
            },
            [8] = {
                id = 8,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1286.51, 459.14, 90.29),
                },
                furniture = 'chest',
            },
            [9] = {
                id = 9,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1286.08, 438.44, 94.09),
                },
                furniture = 'chest',
            },
            [10] = {
                id = 10,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1283.26, 436.7, 97.69),
                },
                furniture = 'chest',
            },
            [11] = {
                id = 11,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_micro_02",
                        coords = vector3(-1282.16, 444.06, 98.07),
                    },
                    hand = {
                        model = "prop_micro_02",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.1, -0.03),
                        rotation = vector3(0.0, 0.0, 180.0),
                    },
                    vehicle = {
                        model = "prop_micro_02",
                        coords = vector3(0.15, -1.0, 0.27),
                        rotation = vector3(0.0, 0.0, 0.0),
                    }
                }
            },
            [12] = {
                id = 12,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_toaster_01",
                        coords = vector3(-1282.96, 447.72, 98.01),
                    },
                    hand = {
                        model = "prop_toaster_01",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.1, -0.2),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_toaster_01",
                        coords = vector3(-0.2, -1.0, 0.27),
                        rotation = vector3(0.0, 0.0, 90.0),
                    }
                }
            },
            [13] = {
                id = 13,
                taken = false,
                busy = false,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "prop_wine_bot_01",
                    coords = vector3(-1287.37, 444.81, 98.08),
                },
                item = {
                    name = "wine",
                    amount = 1,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
            [14] = {
                id = 14,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_mp3_dock",
                        coords = vector3(-1290.96, 434.4, 97.59),
                    },
                    hand = {
                        model = "prop_mp3_dock",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.1, -0.2),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_mp3_dock",
                        coords = vector3(-0.2, -1.3, 0.27),
                        rotation = vector3(0.0, 0.0, 0.0),
                    }
                }
            },
            [15] = {
                id = 15,
                taken = false,
                busy = false,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "prop_npc_phone",
                    coords = vector3(-1290.92, 434.29, 97.61),
                },
                item = {
                    name = "iphone",
                    amount = 1,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
            [16] = {
                id = 16,
                taken = false,
                busy = false,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "p_whiskey_bottle_s",
                    coords = vector3(-1290.86, 433.23, 97.62),
                },
                item = {
                    name = "whiskey",
                    amount = 1,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
            [17] = {
                id = 17,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_mp3_dock",
                        coords = vector3(-1290.89, 433.54, 94.09),
                    },
                    hand = {
                        model = "prop_mp3_dock",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.1, -0.12),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_mp3_dock",
                        coords = vector3(0.2, -1.3, 0.27),
                        rotation = vector3(0.0, 0.0, 0.0),
                    }
                }
            },
            [18] = {
                id = 18,
                taken = false,
                busy = false,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "prop_npc_phone",
                    coords = vector3(-1290.85, 433.7, 94.07),
                },
                item = {
                    name = "samsungphone",
                    amount = 1,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
            [19] = {
                id = 19,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_monitor_w_large",
                        coords = vector3(-1293.02, 457.31, 90.35),
                    },
                    hand = {
                        model = "prop_monitor_w_large",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.05, -0.3),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_monitor_w_large",
                        coords = vector3(-0.6, -2.0, 0.27),
                        rotation = vector3(0.0, 0.0, 90.0),
                    }
                }
            },
            [20] = {
                id = 20,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_monitor_w_large",
                        coords = vector3(-1293.02, 458.06, 90.33),
                    },
                    hand = {
                        model = "prop_monitor_w_large",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.05, -0.3),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_monitor_w_large",
                        coords = vector3(-0.4, -2.0, 0.27),
                        rotation = vector3(0.0, 0.0, 90.0),
                    }
                }
            },
            [21] = {
                id = 21,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_laptop_01a",
                        coords = vector3(-1291.89, 460.16, 90.05),
                    },
                    hand = {
                        model = "prop_laptop_01a",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.02, -0.18),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_laptop_01a",
                        coords = vector3(-0.3, -1.55, 0.27),
                        rotation = vector3(0.0, 0.0, 0.0),
                    }
                }
            },
            [22] = {
                id = 22,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_printer_01",
                        coords = vector3(-1286.1, 459.97, 90.36),
                    },
                    hand = {
                        model = "prop_printer_01",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.05, -0.18),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_printer_01",
                        coords = vector3(0.15, -1.58, 0.27),
                        rotation = vector3(0.0, 0.0, 0.0),
                    }
                }
            },
            [23] = {
                id = 23,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_keyboard_01b",
                        coords = vector3(-1292.71, 457.58, 90.05),
                    },
                    hand = {
                        model = "prop_keyboard_01b",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.05, -0.18),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_keyboard_01b",
                        coords = vector3(-0.5, -1.65, 0.28),
                        rotation = vector3(0.0, 0.0, 90.0),
                    }
                }
            },
            [24] = {
                id = 24,
                taken = false,
                busy = false,
                create = true,
                type = "money",
                animation = {
                    type = 'grab_cash',
                },
                prop = {
                    coords = vector3(-1284.249, 443.757, 97.856),
                    rotation = vector3(0.0, 0.0, 191.0),
                    model = "h4_prop_h4_cash_stack_01a",
                },
                item = {
                    name = "cash",
                    amount = 20000,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
            [25] = {
                id = 25,
                taken = false,
                busy = false,
                create = true,
                type = "safe",
                animation = {
                    type = 'safe'
                },
                art = {
                    model = "ch_prop_vault_painting_01j",
                    coords = vector3(-1291.15, 439.39, 94.16),
                    rotation = vector3(0.0, 0.0, 88.7),
                },
                prop = {
                    coords = vector3(-1291.15, 439.39, 94.16),
                    rotation = vector3(0.0, 0.0, 88.7),
                    model = "ch_prop_ch_arcade_safe_door",
                },
                furniture = 'safe',
            },
            [26] = {
                id = 26,
                taken = false,
                busy = false,
                type = "item",
                animation = {
                    type = 'tamper',
                },
                prop = {
                    coords = vector3(-1286.21, 432.51, 97.21),
                    model = "prop_bong_01",
                },
                item = {
                    name = "weed_ak47",
                    amount = 1,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
        }
    },
    [33] = {
        id = 33,
        name = 'Vinewood House 9',
        description = 'Houses of big and rich people',
        image = 'house-33',
        coords = {
            enter = vector3(1386.3, -593.53, 74.49),
            exit = vector4(-1289.73, 449.81, 97.9, 185.37),
            lock = vector4(1385.841, -594.155, 74.792, 142.498),
        },
        tier = 3,
        level = 17,
        opened = false,
        objectRewards = {
            money = 1800,
            xp = 1800,
        },
        reward = 1800,
        loot = {
            [1] = {
                id = 1,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1287.38, 446.78, 97.89),
                },
                furniture = 'kitchen',
            },
            [2] = {
                id = 2,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1290.34, 432.27, 94.09),
                },
                furniture = 'livingroom',
            },
            [3] = {
                id = 3,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1282.89, 445.53, 94.11),
                },
                furniture = 'livingroom',
            },
            [4] = {
                id = 4,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1282.56, 432.52, 97.5),
                },
                furniture = 'chest',
            },
            [5] = {
                id = 5,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1292.92, 451.46, 90.29),
                },
                furniture = 'chest',
            },
            [6] = {
                id = 6,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1285.86, 456.99, 90.29),
                },
                furniture = 'chest',
            },
            [7] = {
                id = 7,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1287.85, 455.53, 90.29),
                },
                furniture = 'chest',
            },
            [8] = {
                id = 8,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1286.51, 459.14, 90.29),
                },
                furniture = 'chest',
            },
            [9] = {
                id = 9,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1286.08, 438.44, 94.09),
                },
                furniture = 'chest',
            },
            [10] = {
                id = 10,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1283.26, 436.7, 97.69),
                },
                furniture = 'chest',
            },
            [11] = {
                id = 11,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_micro_02",
                        coords = vector3(-1282.16, 444.06, 98.07),
                    },
                    hand = {
                        model = "prop_micro_02",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.1, -0.03),
                        rotation = vector3(0.0, 0.0, 180.0),
                    },
                    vehicle = {
                        model = "prop_micro_02",
                        coords = vector3(0.15, -1.0, 0.27),
                        rotation = vector3(0.0, 0.0, 0.0),
                    }
                }
            },
            [12] = {
                id = 12,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_toaster_01",
                        coords = vector3(-1282.96, 447.72, 98.01),
                    },
                    hand = {
                        model = "prop_toaster_01",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.1, -0.2),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_toaster_01",
                        coords = vector3(-0.2, -1.0, 0.27),
                        rotation = vector3(0.0, 0.0, 90.0),
                    }
                }
            },
            [13] = {
                id = 13,
                taken = false,
                busy = false,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "prop_wine_bot_01",
                    coords = vector3(-1287.37, 444.81, 98.08),
                },
                item = {
                    name = "wine",
                    amount = 1,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
            [14] = {
                id = 14,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_mp3_dock",
                        coords = vector3(-1290.96, 434.4, 97.59),
                    },
                    hand = {
                        model = "prop_mp3_dock",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.1, -0.2),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_mp3_dock",
                        coords = vector3(-0.2, -1.3, 0.27),
                        rotation = vector3(0.0, 0.0, 0.0),
                    }
                }
            },
            [15] = {
                id = 15,
                taken = false,
                busy = false,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "prop_npc_phone",
                    coords = vector3(-1290.92, 434.29, 97.61),
                },
                item = {
                    name = "iphone",
                    amount = 1,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
            [16] = {
                id = 16,
                taken = false,
                busy = false,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "p_whiskey_bottle_s",
                    coords = vector3(-1290.86, 433.23, 97.62),
                },
                item = {
                    name = "whiskey",
                    amount = 1,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
            [17] = {
                id = 17,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_mp3_dock",
                        coords = vector3(-1290.89, 433.54, 94.09),
                    },
                    hand = {
                        model = "prop_mp3_dock",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.1, -0.12),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_mp3_dock",
                        coords = vector3(0.2, -1.3, 0.27),
                        rotation = vector3(0.0, 0.0, 0.0),
                    }
                }
            },
            [18] = {
                id = 18,
                taken = false,
                busy = false,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "prop_npc_phone",
                    coords = vector3(-1290.85, 433.7, 94.07),
                },
                item = {
                    name = "samsungphone",
                    amount = 1,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
            [19] = {
                id = 19,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_monitor_w_large",
                        coords = vector3(-1293.02, 457.31, 90.35),
                    },
                    hand = {
                        model = "prop_monitor_w_large",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.05, -0.3),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_monitor_w_large",
                        coords = vector3(-0.6, -2.0, 0.27),
                        rotation = vector3(0.0, 0.0, 90.0),
                    }
                }
            },
            [20] = {
                id = 20,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_monitor_w_large",
                        coords = vector3(-1293.02, 458.06, 90.33),
                    },
                    hand = {
                        model = "prop_monitor_w_large",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.05, -0.3),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_monitor_w_large",
                        coords = vector3(-0.4, -2.0, 0.27),
                        rotation = vector3(0.0, 0.0, 90.0),
                    }
                }
            },
            [21] = {
                id = 21,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_laptop_01a",
                        coords = vector3(-1291.89, 460.16, 90.05),
                    },
                    hand = {
                        model = "prop_laptop_01a",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.02, -0.18),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_laptop_01a",
                        coords = vector3(-0.3, -1.55, 0.27),
                        rotation = vector3(0.0, 0.0, 0.0),
                    }
                }
            },
            [22] = {
                id = 22,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_printer_01",
                        coords = vector3(-1286.1, 459.97, 90.36),
                    },
                    hand = {
                        model = "prop_printer_01",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.05, -0.18),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_printer_01",
                        coords = vector3(0.15, -1.58, 0.27),
                        rotation = vector3(0.0, 0.0, 0.0),
                    }
                }
            },
            [23] = {
                id = 23,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_keyboard_01b",
                        coords = vector3(-1292.71, 457.58, 90.05),
                    },
                    hand = {
                        model = "prop_keyboard_01b",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.05, -0.18),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_keyboard_01b",
                        coords = vector3(-0.5, -1.65, 0.28),
                        rotation = vector3(0.0, 0.0, 90.0),
                    }
                }
            },
            [24] = {
                id = 24,
                taken = false,
                busy = false,
                create = true,
                type = "money",
                animation = {
                    type = 'grab_cash',
                },
                prop = {
                    coords = vector3(-1284.249, 443.757, 97.856),
                    rotation = vector3(0.0, 0.0, 191.0),
                    model = "h4_prop_h4_cash_stack_01a",
                },
                item = {
                    name = "cash",
                    amount = 20000,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
            [25] = {
                id = 25,
                taken = false,
                busy = false,
                create = true,
                type = "safe",
                animation = {
                    type = 'safe'
                },
                art = {
                    model = "ch_prop_vault_painting_01j",
                    coords = vector3(-1291.15, 439.39, 94.16),
                    rotation = vector3(0.0, 0.0, 88.7),
                },
                prop = {
                    coords = vector3(-1291.15, 439.39, 94.16),
                    rotation = vector3(0.0, 0.0, 88.7),
                    model = "ch_prop_ch_arcade_safe_door",
                },
                furniture = 'safe',
            },
            [26] = {
                id = 26,
                taken = false,
                busy = false,
                type = "item",
                animation = {
                    type = 'tamper',
                },
                prop = {
                    coords = vector3(-1286.21, 432.51, 97.21),
                    model = "prop_bong_01",
                },
                item = {
                    name = "weed_ak47",
                    amount = 1,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
        }
    },
    [34] = {
        id = 34,
        name = 'Vinewood House 10',
        description = 'Houses of big and rich people',
        image = 'house-34',
        coords = {
            enter = vector3(1367.27, -606.59, 74.71),
            exit = vector4(-1289.73, 449.81, 97.9, 185.37),
            lock = vector4(1366.489, -606.722, 75.118, 90.599),
        },
        tier = 3,
        level = 17,
        opened = false,
        objectRewards = {
            money = 1800,
            xp = 1800,
        },
        reward = 1800,
        loot = {
            [1] = {
                id = 1,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1287.38, 446.78, 97.89),
                },
                furniture = 'kitchen',
            },
            [2] = {
                id = 2,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1290.34, 432.27, 94.09),
                },
                furniture = 'livingroom',
            },
            [3] = {
                id = 3,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1282.89, 445.53, 94.11),
                },
                furniture = 'livingroom',
            },
            [4] = {
                id = 4,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1282.56, 432.52, 97.5),
                },
                furniture = 'chest',
            },
            [5] = {
                id = 5,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1292.92, 451.46, 90.29),
                },
                furniture = 'chest',
            },
            [6] = {
                id = 6,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1285.86, 456.99, 90.29),
                },
                furniture = 'chest',
            },
            [7] = {
                id = 7,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1287.85, 455.53, 90.29),
                },
                furniture = 'chest',
            },
            [8] = {
                id = 8,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1286.51, 459.14, 90.29),
                },
                furniture = 'chest',
            },
            [9] = {
                id = 9,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1286.08, 438.44, 94.09),
                },
                furniture = 'chest',
            },
            [10] = {
                id = 10,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1283.26, 436.7, 97.69),
                },
                furniture = 'chest',
            },
            [11] = {
                id = 11,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_micro_02",
                        coords = vector3(-1282.16, 444.06, 98.07),
                    },
                    hand = {
                        model = "prop_micro_02",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.1, -0.03),
                        rotation = vector3(0.0, 0.0, 180.0),
                    },
                    vehicle = {
                        model = "prop_micro_02",
                        coords = vector3(0.15, -1.0, 0.27),
                        rotation = vector3(0.0, 0.0, 0.0),
                    }
                }
            },
            [12] = {
                id = 12,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_toaster_01",
                        coords = vector3(-1282.96, 447.72, 98.01),
                    },
                    hand = {
                        model = "prop_toaster_01",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.1, -0.2),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_toaster_01",
                        coords = vector3(-0.2, -1.0, 0.27),
                        rotation = vector3(0.0, 0.0, 90.0),
                    }
                }
            },
            [13] = {
                id = 13,
                taken = false,
                busy = false,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "prop_wine_bot_01",
                    coords = vector3(-1287.37, 444.81, 98.08),
                },
                item = {
                    name = "wine",
                    amount = 1,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
            [14] = {
                id = 14,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_mp3_dock",
                        coords = vector3(-1290.96, 434.4, 97.59),
                    },
                    hand = {
                        model = "prop_mp3_dock",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.1, -0.2),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_mp3_dock",
                        coords = vector3(-0.2, -1.3, 0.27),
                        rotation = vector3(0.0, 0.0, 0.0),
                    }
                }
            },
            [15] = {
                id = 15,
                taken = false,
                busy = false,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "prop_npc_phone",
                    coords = vector3(-1290.92, 434.29, 97.61),
                },
                item = {
                    name = "iphone",
                    amount = 1,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
            [16] = {
                id = 16,
                taken = false,
                busy = false,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "p_whiskey_bottle_s",
                    coords = vector3(-1290.86, 433.23, 97.62),
                },
                item = {
                    name = "whiskey",
                    amount = 1,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
            [17] = {
                id = 17,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_mp3_dock",
                        coords = vector3(-1290.89, 433.54, 94.09),
                    },
                    hand = {
                        model = "prop_mp3_dock",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.1, -0.12),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_mp3_dock",
                        coords = vector3(0.2, -1.3, 0.27),
                        rotation = vector3(0.0, 0.0, 0.0),
                    }
                }
            },
            [18] = {
                id = 18,
                taken = false,
                busy = false,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "prop_npc_phone",
                    coords = vector3(-1290.85, 433.7, 94.07),
                },
                item = {
                    name = "samsungphone",
                    amount = 1,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
            [19] = {
                id = 19,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_monitor_w_large",
                        coords = vector3(-1293.02, 457.31, 90.35),
                    },
                    hand = {
                        model = "prop_monitor_w_large",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.05, -0.3),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_monitor_w_large",
                        coords = vector3(-0.6, -2.0, 0.27),
                        rotation = vector3(0.0, 0.0, 90.0),
                    }
                }
            },
            [20] = {
                id = 20,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_monitor_w_large",
                        coords = vector3(-1293.02, 458.06, 90.33),
                    },
                    hand = {
                        model = "prop_monitor_w_large",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.05, -0.3),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_monitor_w_large",
                        coords = vector3(-0.4, -2.0, 0.27),
                        rotation = vector3(0.0, 0.0, 90.0),
                    }
                }
            },
            [21] = {
                id = 21,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_laptop_01a",
                        coords = vector3(-1291.89, 460.16, 90.05),
                    },
                    hand = {
                        model = "prop_laptop_01a",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.02, -0.18),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_laptop_01a",
                        coords = vector3(-0.3, -1.55, 0.27),
                        rotation = vector3(0.0, 0.0, 0.0),
                    }
                }
            },
            [22] = {
                id = 22,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_printer_01",
                        coords = vector3(-1286.1, 459.97, 90.36),
                    },
                    hand = {
                        model = "prop_printer_01",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.05, -0.18),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_printer_01",
                        coords = vector3(0.15, -1.58, 0.27),
                        rotation = vector3(0.0, 0.0, 0.0),
                    }
                }
            },
            [23] = {
                id = 23,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_keyboard_01b",
                        coords = vector3(-1292.71, 457.58, 90.05),
                    },
                    hand = {
                        model = "prop_keyboard_01b",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.05, -0.18),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_keyboard_01b",
                        coords = vector3(-0.5, -1.65, 0.28),
                        rotation = vector3(0.0, 0.0, 90.0),
                    }
                }
            },
            [24] = {
                id = 24,
                taken = false,
                busy = false,
                create = true,
                type = "money",
                animation = {
                    type = 'grab_cash',
                },
                prop = {
                    coords = vector3(-1284.249, 443.757, 97.856),
                    rotation = vector3(0.0, 0.0, 191.0),
                    model = "h4_prop_h4_cash_stack_01a",
                },
                item = {
                    name = "cash",
                    amount = 20000,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
            [25] = {
                id = 25,
                taken = false,
                busy = false,
                create = true,
                type = "safe",
                animation = {
                    type = 'safe'
                },
                art = {
                    model = "ch_prop_vault_painting_01j",
                    coords = vector3(-1291.15, 439.39, 94.16),
                    rotation = vector3(0.0, 0.0, 88.7),
                },
                prop = {
                    coords = vector3(-1291.15, 439.39, 94.16),
                    rotation = vector3(0.0, 0.0, 88.7),
                    model = "ch_prop_ch_arcade_safe_door",
                },
                furniture = 'safe',
            },
            [26] = {
                id = 26,
                taken = false,
                busy = false,
                type = "item",
                animation = {
                    type = 'tamper',
                },
                prop = {
                    coords = vector3(-1286.21, 432.51, 97.21),
                    model = "prop_bong_01",
                },
                item = {
                    name = "weed_ak47",
                    amount = 1,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
        }
    },
    [35] = {
        id = 35,
        name = 'Vinewood House 11',
        description = 'Houses of big and rich people',
        image = 'house-35',
        coords = {
            enter = vector3(1323.35, -583.25, 73.25),
            exit = vector4(-1289.73, 449.81, 97.9, 185.37),
            lock = vector4(1322.638, -582.940, 73.626, 67.199),
        },
        tier = 3,
        level = 18,
        opened = false,
        objectRewards = {
            money = 1900,
            xp = 1900,
        },
        reward = 1900,
        loot = {
            [1] = {
                id = 1,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1287.38, 446.78, 97.89),
                },
                furniture = 'kitchen',
            },
            [2] = {
                id = 2,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1290.34, 432.27, 94.09),
                },
                furniture = 'livingroom',
            },
            [3] = {
                id = 3,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1282.89, 445.53, 94.11),
                },
                furniture = 'livingroom',
            },
            [4] = {
                id = 4,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1282.56, 432.52, 97.5),
                },
                furniture = 'chest',
            },
            [5] = {
                id = 5,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1292.92, 451.46, 90.29),
                },
                furniture = 'chest',
            },
            [6] = {
                id = 6,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1285.86, 456.99, 90.29),
                },
                furniture = 'chest',
            },
            [7] = {
                id = 7,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1287.85, 455.53, 90.29),
                },
                furniture = 'chest',
            },
            [8] = {
                id = 8,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1286.51, 459.14, 90.29),
                },
                furniture = 'chest',
            },
            [9] = {
                id = 9,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1286.08, 438.44, 94.09),
                },
                furniture = 'chest',
            },
            [10] = {
                id = 10,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1283.26, 436.7, 97.69),
                },
                furniture = 'chest',
            },
            [11] = {
                id = 11,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_micro_02",
                        coords = vector3(-1282.16, 444.06, 98.07),
                    },
                    hand = {
                        model = "prop_micro_02",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.1, -0.03),
                        rotation = vector3(0.0, 0.0, 180.0),
                    },
                    vehicle = {
                        model = "prop_micro_02",
                        coords = vector3(0.15, -1.0, 0.27),
                        rotation = vector3(0.0, 0.0, 0.0),
                    }
                }
            },
            [12] = {
                id = 12,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_toaster_01",
                        coords = vector3(-1282.96, 447.72, 98.01),
                    },
                    hand = {
                        model = "prop_toaster_01",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.1, -0.2),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_toaster_01",
                        coords = vector3(-0.2, -1.0, 0.27),
                        rotation = vector3(0.0, 0.0, 90.0),
                    }
                }
            },
            [13] = {
                id = 13,
                taken = false,
                busy = false,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "prop_wine_bot_01",
                    coords = vector3(-1287.37, 444.81, 98.08),
                },
                item = {
                    name = "wine",
                    amount = 1,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
            [14] = {
                id = 14,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_mp3_dock",
                        coords = vector3(-1290.96, 434.4, 97.59),
                    },
                    hand = {
                        model = "prop_mp3_dock",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.1, -0.2),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_mp3_dock",
                        coords = vector3(-0.2, -1.3, 0.27),
                        rotation = vector3(0.0, 0.0, 0.0),
                    }
                }
            },
            [15] = {
                id = 15,
                taken = false,
                busy = false,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "prop_npc_phone",
                    coords = vector3(-1290.92, 434.29, 97.61),
                },
                item = {
                    name = "iphone",
                    amount = 1,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
            [16] = {
                id = 16,
                taken = false,
                busy = false,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "p_whiskey_bottle_s",
                    coords = vector3(-1290.86, 433.23, 97.62),
                },
                item = {
                    name = "whiskey",
                    amount = 1,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
            [17] = {
                id = 17,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_mp3_dock",
                        coords = vector3(-1290.89, 433.54, 94.09),
                    },
                    hand = {
                        model = "prop_mp3_dock",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.1, -0.12),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_mp3_dock",
                        coords = vector3(0.2, -1.3, 0.27),
                        rotation = vector3(0.0, 0.0, 0.0),
                    }
                }
            },
            [18] = {
                id = 18,
                taken = false,
                busy = false,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "prop_npc_phone",
                    coords = vector3(-1290.85, 433.7, 94.07),
                },
                item = {
                    name = "samsungphone",
                    amount = 1,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
            [19] = {
                id = 19,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_monitor_w_large",
                        coords = vector3(-1293.02, 457.31, 90.35),
                    },
                    hand = {
                        model = "prop_monitor_w_large",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.05, -0.3),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_monitor_w_large",
                        coords = vector3(-0.6, -2.0, 0.27),
                        rotation = vector3(0.0, 0.0, 90.0),
                    }
                }
            },
            [20] = {
                id = 20,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_monitor_w_large",
                        coords = vector3(-1293.02, 458.06, 90.33),
                    },
                    hand = {
                        model = "prop_monitor_w_large",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.05, -0.3),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_monitor_w_large",
                        coords = vector3(-0.4, -2.0, 0.27),
                        rotation = vector3(0.0, 0.0, 90.0),
                    }
                }
            },
            [21] = {
                id = 21,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_laptop_01a",
                        coords = vector3(-1291.89, 460.16, 90.05),
                    },
                    hand = {
                        model = "prop_laptop_01a",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.02, -0.18),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_laptop_01a",
                        coords = vector3(-0.3, -1.55, 0.27),
                        rotation = vector3(0.0, 0.0, 0.0),
                    }
                }
            },
            [22] = {
                id = 22,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_printer_01",
                        coords = vector3(-1286.1, 459.97, 90.36),
                    },
                    hand = {
                        model = "prop_printer_01",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.05, -0.18),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_printer_01",
                        coords = vector3(0.15, -1.58, 0.27),
                        rotation = vector3(0.0, 0.0, 0.0),
                    }
                }
            },
            [23] = {
                id = 23,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_keyboard_01b",
                        coords = vector3(-1292.71, 457.58, 90.05),
                    },
                    hand = {
                        model = "prop_keyboard_01b",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.05, -0.18),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_keyboard_01b",
                        coords = vector3(-0.5, -1.65, 0.28),
                        rotation = vector3(0.0, 0.0, 90.0),
                    }
                }
            },
            [24] = {
                id = 24,
                taken = false,
                busy = false,
                create = true,
                type = "money",
                animation = {
                    type = 'grab_cash',
                },
                prop = {
                    coords = vector3(-1284.249, 443.757, 97.856),
                    rotation = vector3(0.0, 0.0, 191.0),
                    model = "h4_prop_h4_cash_stack_01a",
                },
                item = {
                    name = "cash",
                    amount = 20000,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
            [25] = {
                id = 25,
                taken = false,
                busy = false,
                create = true,
                type = "safe",
                animation = {
                    type = 'safe'
                },
                art = {
                    model = "ch_prop_vault_painting_01j",
                    coords = vector3(-1291.15, 439.39, 94.16),
                    rotation = vector3(0.0, 0.0, 88.7),
                },
                prop = {
                    coords = vector3(-1291.15, 439.39, 94.16),
                    rotation = vector3(0.0, 0.0, 88.7),
                    model = "ch_prop_ch_arcade_safe_door",
                },
                furniture = 'safe',
            },
            [26] = {
                id = 26,
                taken = false,
                busy = false,
                type = "item",
                animation = {
                    type = 'tamper',
                },
                prop = {
                    coords = vector3(-1286.21, 432.51, 97.21),
                    model = "prop_bong_01",
                },
                item = {
                    name = "weed_ak47",
                    amount = 1,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
        }
    },
    [36] = {
        id = 36,
        name = 'Vinewood House 12',
        description = 'Houses of big and rich people',
        image = 'house-36',
        coords = {
            enter = vector3(1301.0, -574.32, 71.73),
            exit = vector4(-1289.73, 449.81, 97.9, 185.37),
            lock = vector4(1300.286, -574.085, 72.135, 72.299),
        },
        tier = 3,
        level = 18,
        opened = false,
        objectRewards = {
            money = 1900,
            xp = 1900,
        },
        reward = 1900,
        loot = {
            [1] = {
                id = 1,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1287.38, 446.78, 97.89),
                },
                furniture = 'kitchen',
            },
            [2] = {
                id = 2,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1290.34, 432.27, 94.09),
                },
                furniture = 'livingroom',
            },
            [3] = {
                id = 3,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1282.89, 445.53, 94.11),
                },
                furniture = 'livingroom',
            },
            [4] = {
                id = 4,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1282.56, 432.52, 97.5),
                },
                furniture = 'chest',
            },
            [5] = {
                id = 5,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1292.92, 451.46, 90.29),
                },
                furniture = 'chest',
            },
            [6] = {
                id = 6,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1285.86, 456.99, 90.29),
                },
                furniture = 'chest',
            },
            [7] = {
                id = 7,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1287.85, 455.53, 90.29),
                },
                furniture = 'chest',
            },
            [8] = {
                id = 8,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1286.51, 459.14, 90.29),
                },
                furniture = 'chest',
            },
            [9] = {
                id = 9,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1286.08, 438.44, 94.09),
                },
                furniture = 'chest',
            },
            [10] = {
                id = 10,
                taken = false,
                busy = false,
                type = "chest",
                animation = {
                    type = 'search'
                },
                prop = {
                    coords = vector3(-1283.26, 436.7, 97.69),
                },
                furniture = 'chest',
            },
            [11] = {
                id = 11,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_micro_02",
                        coords = vector3(-1282.16, 444.06, 98.07),
                    },
                    hand = {
                        model = "prop_micro_02",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.1, -0.03),
                        rotation = vector3(0.0, 0.0, 180.0),
                    },
                    vehicle = {
                        model = "prop_micro_02",
                        coords = vector3(0.15, -1.0, 0.27),
                        rotation = vector3(0.0, 0.0, 0.0),
                    }
                }
            },
            [12] = {
                id = 12,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_toaster_01",
                        coords = vector3(-1282.96, 447.72, 98.01),
                    },
                    hand = {
                        model = "prop_toaster_01",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.1, -0.2),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_toaster_01",
                        coords = vector3(-0.2, -1.0, 0.27),
                        rotation = vector3(0.0, 0.0, 90.0),
                    }
                }
            },
            [13] = {
                id = 13,
                taken = false,
                busy = false,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "prop_wine_bot_01",
                    coords = vector3(-1287.37, 444.81, 98.08),
                },
                item = {
                    name = "wine",
                    amount = 1,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
            [14] = {
                id = 14,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_mp3_dock",
                        coords = vector3(-1290.96, 434.4, 97.59),
                    },
                    hand = {
                        model = "prop_mp3_dock",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.1, -0.2),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_mp3_dock",
                        coords = vector3(-0.2, -1.3, 0.27),
                        rotation = vector3(0.0, 0.0, 0.0),
                    }
                }
            },
            [15] = {
                id = 15,
                taken = false,
                busy = false,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "prop_npc_phone",
                    coords = vector3(-1290.92, 434.29, 97.61),
                },
                item = {
                    name = "iphone",
                    amount = 1,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
            [16] = {
                id = 16,
                taken = false,
                busy = false,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "p_whiskey_bottle_s",
                    coords = vector3(-1290.86, 433.23, 97.62),
                },
                item = {
                    name = "whiskey",
                    amount = 1,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
            [17] = {
                id = 17,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_mp3_dock",
                        coords = vector3(-1290.89, 433.54, 94.09),
                    },
                    hand = {
                        model = "prop_mp3_dock",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.1, -0.12),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_mp3_dock",
                        coords = vector3(0.2, -1.3, 0.27),
                        rotation = vector3(0.0, 0.0, 0.0),
                    }
                }
            },
            [18] = {
                id = 18,
                taken = false,
                busy = false,
                type = "item",
                animation = {
                    type = 'tamper'
                },
                prop = {
                    model = "prop_npc_phone",
                    coords = vector3(-1290.85, 433.7, 94.07),
                },
                item = {
                    name = "samsungphone",
                    amount = 1,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
            [19] = {
                id = 19,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_monitor_w_large",
                        coords = vector3(-1293.02, 457.31, 90.35),
                    },
                    hand = {
                        model = "prop_monitor_w_large",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.05, -0.3),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_monitor_w_large",
                        coords = vector3(-0.6, -2.0, 0.27),
                        rotation = vector3(0.0, 0.0, 90.0),
                    }
                }
            },
            [20] = {
                id = 20,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_monitor_w_large",
                        coords = vector3(-1293.02, 458.06, 90.33),
                    },
                    hand = {
                        model = "prop_monitor_w_large",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.05, -0.3),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_monitor_w_large",
                        coords = vector3(-0.4, -2.0, 0.27),
                        rotation = vector3(0.0, 0.0, 90.0),
                    }
                }
            },
            [21] = {
                id = 21,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_laptop_01a",
                        coords = vector3(-1291.89, 460.16, 90.05),
                    },
                    hand = {
                        model = "prop_laptop_01a",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.02, -0.18),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_laptop_01a",
                        coords = vector3(-0.3, -1.55, 0.27),
                        rotation = vector3(0.0, 0.0, 0.0),
                    }
                }
            },
            [22] = {
                id = 22,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_printer_01",
                        coords = vector3(-1286.1, 459.97, 90.36),
                    },
                    hand = {
                        model = "prop_printer_01",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.05, -0.18),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_printer_01",
                        coords = vector3(0.15, -1.58, 0.27),
                        rotation = vector3(0.0, 0.0, 0.0),
                    }
                }
            },
            [23] = {
                id = 23,
                taken = false,
                busy = false,
                type = "prop",
                animation = {
                    type = 'tamper'
                },
                props = {
                    place = {
                        model = "prop_keyboard_01b",
                        coords = vector3(-1292.71, 457.58, 90.05),
                    },
                    hand = {
                        model = "prop_keyboard_01b",
                        dict = "anim@heists@box_carry@",
                        anim = "idle",
                        coords = vector3(0.0, -0.05, -0.18),
                        rotation = vector3(0.0, 0.0, 0.0),
                    },
                    vehicle = {
                        model = "prop_keyboard_01b",
                        coords = vector3(-0.5, -1.65, 0.28),
                        rotation = vector3(0.0, 0.0, 90.0),
                    }
                }
            },
            [24] = {
                id = 24,
                taken = false,
                busy = false,
                create = true,
                type = "money",
                animation = {
                    type = 'grab_cash',
                },
                prop = {
                    coords = vector3(-1284.249, 443.757, 97.856),
                    rotation = vector3(0.0, 0.0, 191.0),
                    model = "h4_prop_h4_cash_stack_01a",
                },
                item = {
                    name = "cash",
                    amount = 20000,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
            [25] = {
                id = 25,
                taken = false,
                busy = false,
                create = true,
                type = "safe",
                animation = {
                    type = 'safe'
                },
                art = {
                    model = "ch_prop_vault_painting_01j",
                    coords = vector3(-1291.15, 439.39, 94.16),
                    rotation = vector3(0.0, 0.0, 88.7),
                },
                prop = {
                    coords = vector3(-1291.15, 439.39, 94.16),
                    rotation = vector3(0.0, 0.0, 88.7),
                    model = "ch_prop_ch_arcade_safe_door",
                },
                furniture = 'safe',
            },
            [26] = {
                id = 26,
                taken = false,
                busy = false,
                type = "item",
                animation = {
                    type = 'tamper',
                },
                prop = {
                    coords = vector3(-1286.21, 432.51, 97.21),
                    model = "prop_bong_01",
                },
                item = {
                    name = "weed_ak47",
                    amount = 1,
                    random = false,
                    min = 1,
                    max = 3,
                },
            },
        }
    },
}