local QBCore = exports['qb-core']:GetCoreObject()

if not QBCore then
    print('^1[LB-CraftingTable]^0 qb-core was not found, resource disabled.')
    return
end

local isOpen = false
local isCrafting = false
local nearTable = false
local promptShown = false
local currentTableIndex = 1
local craftProp = nil
local tableObjects = {}
local craftingName = nil
local craftingCancelled = false
local craftGen = 0

local function HasItem(item, amount)
    local items = QBCore.Functions.GetPlayerData().items
    if not items then return false end
    for _, slot in pairs(items) do
        if slot and slot.name == item and slot.amount >= amount then
            return true
        end
    end
    return false
end

local function ItemCount(item)
    local items = QBCore.Functions.GetPlayerData().items
    local count = 0
    if not items then return count end
    for _, slot in pairs(items) do
        if slot and slot.name == item then
            count = count + slot.amount
        end
    end
    return count
end

local function FindRecipe(name)
    for _, list in pairs(Config.Recipes) do
        for _, recipe in pairs(list) do
            if recipe.name == name then
                return recipe
            end
        end
    end
    return nil
end

local function ItemLabel(item)
    local data = QBCore.Shared.Items[item]
    return data and data.label or item
end

local function HasAccess(tbl)
    local job = tbl.job or Config.RequiredJob
    if job then
        local jobData = QBCore.Functions.GetPlayerData().job
        if not jobData or jobData.name ~= job then
            QBCore.Functions.Notify('You do not have the required job', 'error')
            return false
        end
    end
    local keyItem = tbl.keyItem or Config.RequiredKeyItem
    if keyItem and not HasItem(keyItem, 1) then
        QBCore.Functions.Notify('You need a ' .. ItemLabel(keyItem), 'error')
        return false
    end
    return true
end

local function GetCraftLevel()
    local data = QBCore.Functions.GetPlayerData()
    local meta = data.metadata and data.metadata.crafting
    return meta and meta.level or Config.LevelStart, meta and meta.xp or 0
end

local function BuildRecipes(tableIndex)
    local tbl = Config.Tables[tableIndex]
    local allowed = tbl and tbl.categories
    local playerLevel = GetCraftLevel()
    local data = {}
    for _, category in pairs(Config.CategoryOrder or {}) do
        if Config.Recipes[category] and (not allowed or allowed[category]) then
            data[category] = {}
            for _, recipe in pairs(Config.Recipes[category]) do
                local level = recipe.level or 1
                local unlocked = not Config.LevelSystem or playerLevel >= level
                local craftable = unlocked
                local ingredients = {}
                for _, ing in pairs(recipe.ingredients) do
                    local count = ItemCount(ing.item)
                local has = count >= ing.amount
                if not has then craftable = false end
                    table.insert(ingredients, {
                        item = ing.item,
                        label = ItemLabel(ing.item),
                        amount = ing.amount,
                        count = count,
                        has = has,
                    })
                end
                table.insert(data[category], {
                    name = recipe.name,
                    label = recipe.label,
                    itemLabel = ItemLabel(recipe.name),
                    amount = recipe.amount,
                    time = recipe.time,
                    level = level,
                    unlocked = unlocked,
                    ingredients = ingredients,
                    craftable = craftable,
                })
            end
        end
    end
    return data
end

local function SendMenu(action)
    local tbl = Config.Tables[currentTableIndex]
    local level, xp = GetCraftLevel()
    SendNUIMessage({
        action = action,
        recipes = BuildRecipes(currentTableIndex),
        imageUrl = Config.ItemImageURL,
        resourceName = GetCurrentResourceName(),
        menuTitle = Config.MenuTitle,
        menuSubtitle = tbl and tbl.label or Config.MenuSubtitle,
        menuTagline = Config.MenuTagline,
        levelSystem = Config.LevelSystem,
        levelData = {
            level = level,
            xp = xp,
            xpNeeded = Config.XPNeeded(level),
        },
        sortCraftable = Config.SortCraftableFirst,
        maxQty = Config.MaxCraftQty,
        showLocked = Config.ShowLockedRecipes,
    })
end

local function ShowPrompt(text)
    if promptShown then return end
    promptShown = true
    SendNUIMessage({ action = 'showPrompt', text = text })
end

local function HidePrompt()
    if not promptShown then return end
    promptShown = false
    SendNUIMessage({ action = 'hidePrompt' })
end

local function OpenMenu(tableIndex)
    if IsPedDeadOrDying(PlayerPedId()) then return end
    local tbl = Config.Tables[tableIndex]
    if not tbl then return end
    if not HasAccess(tbl) then return end
    isOpen = true
    currentTableIndex = tableIndex
    HidePrompt()
    SetNuiFocus(true, true)
    SendMenu('open')
end

local function RefreshMenu()
    if not isOpen then return end
    SendMenu('recipes')
end

local function CloseMenu()
    if not isOpen then return end
    isOpen = false
    SetNuiFocus(false, false)
    SendNUIMessage({ action = 'close' })
end

local function ClearCraft()
    SendNUIMessage({ action = 'stopProgress' })
    local ped = PlayerPedId()
    if DoesEntityExist(ped) then
        FreezeEntityPosition(ped, false)
        ClearPedTasks(ped)
    end
    if craftProp then
        DetachEntity(craftProp, true, true)
        DeleteEntity(craftProp)
        craftProp = nil
    end
end

local function CancelCraft()
    if not isCrafting then return end
    craftingCancelled = true
    ClearCraft()
    isCrafting = false
    SetNuiFocus(false, false)
    if craftingName then
        TriggerServerEvent('lb-craftingtable:server:cancelcraft', craftingName)
        craftingName = nil
    end
    SetTimeout(350, function()
        if not isOpen and not isCrafting and nearTable and not IsPedDeadOrDying(PlayerPedId()) then
            OpenMenu(currentTableIndex)
        end
    end)
end

local function StartBar(duration, label, cb)
    SendNUIMessage({ action = 'startProgress', label = label, duration = duration })
    SetTimeout(duration, function()
        SendNUIMessage({ action = 'stopProgress' })
        cb()
    end)
end

local function StartCraft(recipe, qty)
    isCrafting = true
    craftingCancelled = false
    craftingName = recipe.name
    craftGen = craftGen + 1
    local myGen = craftGen
    CloseMenu()
    SetNuiFocus(true, true)
    local duration = (Config.CraftTime or recipe.time) * 1000
    TriggerServerEvent('lb-craftingtable:server:startcraft', recipe.name, qty, duration)
    local ped = PlayerPedId()
    local anim = Config.CraftAnimation

    if Config.CraftScenario then
        TaskStartScenarioInPlace(ped, Config.CraftScenario, -1, true)
        Wait(250)
        FreezeEntityPosition(ped, true)
    else
        FreezeEntityPosition(ped, true)
        local propModel = recipe.prop or Config.CraftProp

        if anim.dict then
            RequestAnimDict(anim.dict)
            local loadTries = 0
            while not HasAnimDictLoaded(anim.dict) and loadTries < 100 do
                loadTries = loadTries + 1
                Wait(10)
            end
        end

        if propModel then
            RequestModel(propModel)
            local loadTries = 0
            while not HasModelLoaded(propModel) and loadTries < 100 do
                loadTries = loadTries + 1
                Wait(10)
            end
            if HasModelLoaded(propModel) then
                local pX, pY, pZ = GetEntityCoords(ped)
                craftProp = CreateObject(propModel, pX, pY, pZ, false, false, false)
                SetEntityAsMissionEntity(craftProp, true, true)
                SetEntityCollision(craftProp, false, false)
                local o = Config.CraftPropOffset
                AttachEntityToEntity(craftProp, ped, GetPedBoneIndex(ped, 57005), o.x, o.y, o.z, o.rotx, o.roty, o.rotz, false, true, false, true, 2, true)
            end
        end

        if anim.dict and anim.anim then
            TaskPlayAnim(ped, anim.dict, anim.anim, 8.0, -8.0, -1, anim.flags or 16, 0, false, false, false)
        end
    end

    if Config.CraftSound and Config.CraftSoundSet then
        PlaySoundFrontend(-1, Config.CraftSound, Config.CraftSoundSet, false)
    end

    local function Finish()
        if myGen ~= craftGen then return end
        ClearCraft()
        isCrafting = false
        craftingName = nil
        SetNuiFocus(false, false)
        if not craftingCancelled then
            TriggerServerEvent('lb-craftingtable:server:craft', recipe.name, qty)
            SetTimeout(600, function()
                if not isOpen and not isCrafting and nearTable and not IsPedDeadOrDying(PlayerPedId()) then
                    OpenMenu(currentTableIndex)
                end
            end)
        end
    end

    StartBar(duration, 'Crafting ' .. recipe.label .. '...', Finish)
end

RegisterNUICallback('craft', function(data, cb)
    cb('ok')
    if isCrafting or not isOpen then return end
    local name = data and data.item
    if not name then return end
    local qty = math.floor(tonumber(data and data.qty) or 1)
    qty = math.max(1, math.min(qty, Config.MaxCraftQty))
    local recipe = FindRecipe(name)
    if not recipe then return end
    local tbl = Config.Tables[currentTableIndex]
    if not HasAccess(tbl) then
        CloseMenu()
        return
    end
    for _, ing in pairs(recipe.ingredients) do
        if ItemCount(ing.item) < ing.amount * qty then
            QBCore.Functions.Notify('You are missing ingredients', 'error')
            return
        end
    end
    StartCraft(recipe, qty)
end)

RegisterNUICallback('close', function(_, cb)
    cb('ok')
    CloseMenu()
end)

RegisterNUICallback('cancelCraft', function(_, cb)
    cb('ok')
    CancelCraft()
end)

RegisterNUICallback('nuiReady', function(_, cb)
    cb('ok')
    if isOpen then
        SendMenu('open')
    end
end)

RegisterNetEvent('lb-craftingtable:client:open', function(data)
    local idx = data and data.tableIndex
    if idx and Config.Tables[idx] then
        OpenMenu(idx)
    end
end)

CreateThread(function()
    while true do
        local sleep = 1000
        local ped = PlayerPedId()
        local coords = GetEntityCoords(ped)
        local foundIndex = nil
        for i, tbl in pairs(Config.Tables) do
            if #(coords - tbl.coords) < Config.Range then
                foundIndex = i
                break
            end
        end
        nearTable = foundIndex ~= nil
        if nearTable and not isOpen and not isCrafting and not Config.UseTarget and not IsPedDeadOrDying(ped) then
            currentTableIndex = foundIndex
            sleep = 0
            ShowPrompt(Config.Prompt)
        elseif not nearTable or isCrafting or IsPedDeadOrDying(ped) then
            HidePrompt()
        end
        Wait(sleep)
    end
end)

CreateThread(function()
    while true do
        Wait(0)
        if IsControlJustPressed(0, Config.EKey) and nearTable and not isOpen and not isCrafting then
            OpenMenu(currentTableIndex)
        end
        if IsControlJustPressed(0, Config.DKey) and isOpen then
            CloseMenu()
        end
        if isCrafting and IsControlJustPressed(0, Config.CancelKey or 177) then
            CancelCraft()
        end
    end
end)

if Config.CloseOnDeath then
    CreateThread(function()
        while true do
            Wait(500)
            local dead = IsPedDeadOrDying(PlayerPedId())
            if dead then
                if isCrafting then
                    CancelCraft()
                end
                if isOpen then
                    CloseMenu()
                end
            end
        end
    end)
end

local function SetupTargets()
    if not Config.UseTarget then return end
    if GetResourceState('qb-target') == 'started' then
        for i, obj in pairs(tableObjects) do
            exports['qb-target']:AddTargetEntity(obj, {
                options = {
                    {
                        type = 'client',
                        event = 'lb-craftingtable:client:open',
                        icon = 'fas fa-hammer',
                        label = Config.Tables[i].label or Config.TargetLabels.open,
                        data = { tableIndex = i },
                        distance = Config.TargetDistance,
                    },
                },
            })
        end
    elseif GetResourceState('ox_target') == 'started' then
        for i, obj in pairs(tableObjects) do
            exports['ox_target']:addLocalEntity(obj, {
                {
                    name = 'lb_crafting_open',
                    event = 'lb-craftingtable:client:open',
                    icon = 'fas:hammer',
                    label = Config.Tables[i].label or Config.TargetLabels.open,
                    data = { tableIndex = i },
                    distance = Config.TargetDistance,
                },
            })
        end
    end
end

if Config.Blips.enabled then
    for i, tbl in ipairs(Config.Tables) do
        if tbl.blip ~= false then
            local blip = AddBlipForCoord(tbl.coords.x, tbl.coords.y, tbl.coords.z)
            SetBlipSprite(blip, Config.Blips.sprite)
            SetBlipDisplay(blip, 4)
            SetBlipScale(blip, Config.Blips.scale)
            SetBlipColour(blip, Config.Blips.color)
            SetBlipAsShortRange(blip, true)
            BeginTextCommandSetBlipName('STRING')
            AddTextComponentSubstringPlayerName(tbl.blipLabel or Config.Blips.label)
            EndTextCommandSetBlipName(blip)
        end
    end
end

CreateThread(function()
    local attemptsToWait = 0
    local playerLoaded = false
    while not playerLoaded and attemptsToWait < 300 do
        local ped = PlayerPedId()
        if ped ~= 0 and DoesEntityExist(ped) then
            playerLoaded = true
        else
            attemptsToWait = attemptsToWait + 1
            Wait(100)
        end
    end
    if not playerLoaded then return end

    for _, obj in pairs(tableObjects) do
        if DoesEntityExist(obj) then
            DeleteEntity(obj)
        end
    end
    tableObjects = {}

    local model = joaat(Config.TableModel)
    RequestModel(model)
    local attempts = 0
    while not HasModelLoaded(model) and attempts < 200 do
        attempts = attempts + 1
        Wait(10)
    end
    if not HasModelLoaded(model) then
        return
    end
    for i, tbl in ipairs(Config.Tables) do
        local obj = CreateObject(model, tbl.coords.x, tbl.coords.y, tbl.coords.z + 0.5, false, false, false)
        if DoesEntityExist(obj) then
            SetEntityHeading(obj, tbl.heading or 0.0)
            PlaceObjectOnGroundProperly(obj)
            Wait(100)
            FreezeEntityPosition(obj, true)
            tableObjects[i] = obj
        end

        for _, p in pairs(tbl.props or {}) do
            local pModel = joaat(p.model)
            RequestModel(pModel)
            while not HasModelLoaded(pModel) do
                Wait(10)
            end
            local po = CreateObject(pModel, tbl.coords.x, tbl.coords.y, tbl.coords.z, false, false, false)
            SetEntityHeading(po, tbl.heading or 0.0)
            local o = p.offset
            AttachEntityToEntity(po, obj, 0, o.x, o.y, o.z, o.rotx or 0.0, o.roty or 0.0, o.rotz or 0.0, false, false, false, false, 2, true)
            FreezeEntityPosition(po, true)
            SetModelAsNoLongerNeeded(pModel)
        end
    end
    SetModelAsNoLongerNeeded(model)
    SetupTargets()
end)

AddEventHandler('onResourceStop', function(resName)
    if resName ~= GetCurrentResourceName() then return end
    for _, obj in pairs(tableObjects) do
        if DoesEntityExist(obj) then
            DeleteEntity(obj)
        end
    end
    tableObjects = {}
end)
