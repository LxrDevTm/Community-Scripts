Config = {}

Config.MenuTitle = 'LB CRAFTING TABLE'
Config.MenuSubtitle = 'Workshop Menu'
Config.MenuTagline = 'PREMIUM'

Config.TableModel = 'gr_prop_gr_bench_04b'

Config.Tables = {
    {
        coords = vector3(104.49, -872.65, 137.95),
        heading = 261.5,
        label = 'Crafting Table',
        categories = nil,
        job = nil,
        keyItem = nil,
        blip = true,
    },
}

Config.EKey = 38
Config.DKey = 68
Config.CancelKey = 177

Config.Range = 3.0
Config.ServerRange = 4.0

Config.Prompt = 'Open the Crafting Table'

Config.CloseOnDeath = true

Config.CraftProp = 'prop_tool_hammer'
Config.CraftPropOffset = {
    x = 0.14,
    y = 0.02,
    z = 0.0,
    rotx = -80.0,
    roty = 0.0,
    rotz = 0.0,
}

Config.CraftScenario = 'WORLD_HUMAN_HAMMERING'

Config.CraftAnimation = {
    dict = 'amb@world_human_hammering@male@base',
    anim = 'base',
    flags = 1,
}

Config.ServerCooldown = 1000
Config.MaxCraftsPerMinute = 30
Config.CraftTime = 60

Config.ItemImageURL = 'https://qb-inventory/html/images'

Config.BarType = 'progressbar'

Config.UseTarget = false
Config.TargetDistance = 2.5
Config.TargetLabels = {
    open = 'Open Crafting Table',
}

Config.Blips = {
    enabled = true,
    sprite = 566,
    color = 1,
    scale = 0.8,
    label = 'Crafting Table',
}

Config.SortCraftableFirst = true
Config.Pagination = 12
Config.MaxCraftQty = 999

Config.CategoryOrder = { 'Basic', 'Weapons', 'Supplies' }

Config.LevelSystem = true
Config.LevelStart = 1
Config.XPPerLevel = 100
Config.XPPerCraft = 10
Config.LevelNotify = true
Config.ShowLockedRecipes = true

Config.XPNeeded = function(level)
    if type(Config.XPPerLevel) == 'table' then
        local t = Config.XPPerLevel
        return t[level] or t[#t]
    end
    return Config.XPPerLevel * level
end

Config.ShowItemBox = true

Config.RequiredJob = nil
Config.RequiredKeyItem = nil

Config.CraftSound = 'select'
Config.CraftSoundSet = 'DLC_MP_Heists@Mission_Complete'

Config.Recipes = {
    ['Basic'] = {
        {
            name = 'water_bottle',
            label = 'Water Bottle',
            amount = 1,
            time = 2,
            level = 1,
            xp = 10,
            ingredients = {
                { item = 'plastic', amount = 2 },
            },
        },
        {
            name = 'bandage',
            label = 'Bandage',
            amount = 1,
            time = 2,
            level = 1,
            xp = 10,
            ingredients = {
                { item = 'firstaid', amount = 1 },
            },
        },
        {
            name = 'joint',
            label = 'Joint',
            amount = 1,
            time = 3,
            level = 1,
            xp = 15,
            ingredients = {
                { item = 'plastic', amount = 1 },
            },
        },
        {
            name = 'lockpick',
            label = 'Lockpick',
            amount = 1,
            time = 4,
            level = 2,
            xp = 25,
            ingredients = {
                { item = 'metalscrap', amount = 2 },
                { item = 'screwdriverset', amount = 1 },
            },
        },
        {
            name = 'advancedlockpick',
            label = 'Advanced Lockpick',
            amount = 1,
            time = 5,
            level = 3,
            xp = 40,
            ingredients = {
                { item = 'lockpick', amount = 1 },
                { item = 'electronickit', amount = 1 },
            },
        },
    },
    ['Weapons'] = {
        {
            name = 'weapon_knife',
            label = 'Knife',
            amount = 1,
            time = 5,
            level = 4,
            xp = 50,
            ingredients = {
                { item = 'steel', amount = 2 },
                { item = 'metalscrap', amount = 2 },
            },
        },
        {
            name = 'weapon_bat',
            label = 'Baseball Bat',
            amount = 1,
            time = 5,
            level = 5,
            xp = 60,
            ingredients = {
                { item = 'steel', amount = 2 },
                { item = 'rubber', amount = 1 },
            },
        },
    },
    ['Supplies'] = {
        {
            name = 'electronickit',
            label = 'Electronic Kit',
            amount = 1,
            time = 5,
            level = 3,
            xp = 30,
            ingredients = {
                { item = 'metalscrap', amount = 2 },
                { item = 'copper', amount = 2 },
                { item = 'steel', amount = 1 },
            },
        },
        {
            name = 'repairkit',
            label = 'Repair Kit',
            amount = 1,
            time = 4,
            level = 4,
            xp = 35,
            ingredients = {
                { item = 'metalscrap', amount = 2 },
                { item = 'screwdriverset', amount = 1 },
                { item = 'rubber', amount = 1 },
            },
        },
        {
            name = 'radio',
            label = 'Radio',
            amount = 1,
            time = 5,
            level = 5,
            xp = 45,
            ingredients = {
                { item = 'electronickit', amount = 1 },
                { item = 'copper', amount = 2 },
                { item = 'plastic', amount = 1 },
            },
        },
        {
            name = 'drill',
            label = 'Drill',
            amount = 1,
            time = 8,
            level = 6,
            xp = 80,
            ingredients = {
                { item = 'metalscrap', amount = 4 },
                { item = 'steel', amount = 3 },
                { item = 'electronickit', amount = 2 },
                { item = 'screwdriverset', amount = 2 },
            },
        },
    },
}
