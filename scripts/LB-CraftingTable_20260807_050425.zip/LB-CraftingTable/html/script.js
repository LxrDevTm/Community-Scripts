let recipesData = {};
let currentCategory = null;
let imageUrl = 'https://qb-inventory/html/images';
let resourceName = 'lb-craftingtable';

const opts = {
    levelSystem: false,
    levelData: { level: 1, xp: 0, xpNeeded: 100 },
    sortCraftable: true,
    showLocked: true,
    maxQty: 25,
};

const panel = document.getElementById('panel');
const tabsEl = document.getElementById('tabs');
const recipesEl = document.getElementById('recipes');
const levelbarEl = document.getElementById('levelbar');

let cpTimer = null;
let sortMode = 'craftable';

document.querySelectorAll('.sort-btn').forEach((btn) => {
    btn.addEventListener('click', () => {
        sortMode = btn.dataset.sort;
        document.querySelectorAll('.sort-btn').forEach((b) => b.classList.toggle('active', b === btn));
        renderRecipes();
    });
});

function showProgress(label, duration) {
    const el = document.getElementById('craft-progress');
    const fill = document.getElementById('cp-fill');
    const pct = document.getElementById('cp-pct');
    const durationMs = Math.max(200, duration || 1000);
    document.getElementById('cp-label').textContent = label || 'Crafting...';
    el.classList.add('show');
    fill.style.transition = 'none';
    fill.style.width = '0%';
    void fill.offsetWidth;
    fill.style.transition = `width ${durationMs}ms linear`;
    fill.style.width = '100%';
    if (cpTimer) cancelAnimationFrame(cpTimer);
    const start = performance.now();
    const tick = (now) => {
        const p = Math.max(0, Math.min(100, Math.floor(((now - start) / durationMs) * 100)));
        pct.textContent = p + '%';
        if (p < 100) {
            cpTimer = requestAnimationFrame(tick);
        } else {
            cpTimer = null;
        }
    };
    cpTimer = requestAnimationFrame(tick);
}

function hideProgress() {
    const el = document.getElementById('craft-progress');
    if (el.classList.contains('show')) {
        el.classList.remove('show');
    }
    if (cpTimer) {
        cancelAnimationFrame(cpTimer);
        cpTimer = null;
    }
}

const PALETTE = [
    { c1: '#c05780', c2: '#a0284a', dark: '#3f0616' },
    { c1: '#b3425f', c2: '#800020', dark: '#30000e' },
    { c1: '#d98eae', c2: '#b3425f', dark: '#3f0616' },
    { c1: '#a0284a', c2: '#6e0d25', dark: '#24050c' },
    { c1: '#e0a4bf', c2: '#c05780', dark: '#30000e' },
    { c1: '#8a1c3c', c2: '#5c0a1e', dark: '#1a0206' },
];

function categoryColors(category) {
    const keys = Object.keys(recipesData);
    let index = keys.indexOf(category);
    if (index < 0) index = 0;
    const p = PALETTE[index % PALETTE.length];
    return { c1: p.c1, c2: p.c2, dark: p.dark };
}

function send(name, data = {}) {
    fetch(`https://${resourceName}/${name}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json; charset=UTF-8' },
        body: JSON.stringify(data),
    });
}

function loadItemImage(img, item, onFail) {
    if (window.ITEM_IMAGES && ITEM_IMAGES[item]) {
        img.src = ITEM_IMAGES[item];
        return;
    }
    const sources = [
        `https://${resourceName}/html/images/${item}.png`,
        `${imageUrl}/${item}.png`,
    ];
    let i = 0;
    img.onerror = () => {
        i++;
        if (i < sources.length) {
            img.src = sources[i];
        } else {
            img.remove();
            if (onFail) onFail();
        }
    };
    img.src = sources[0];
}

function renderLevel() {
    if (!opts.levelSystem) {
        levelbarEl.style.display = 'none';
        return;
    }
    levelbarEl.style.display = 'flex';
    document.getElementById('level-num').textContent = opts.levelData.level;
    const pct = Math.max(0, Math.min(100, Math.floor((opts.levelData.xp / Math.max(1, opts.levelData.xpNeeded)) * 100)));
    document.getElementById('xp-fill').style.width = pct + '%';
    document.getElementById('xp-text').textContent = `${opts.levelData.xp} / ${opts.levelData.xpNeeded} XP`;
}

window.addEventListener('message', (event) => {
    const data = event.data;
    if (!data || !data.action) return;

    if (data.imageUrl) imageUrl = data.imageUrl;
    if (data.resourceName) resourceName = data.resourceName;
    if (data.menuTitle) document.querySelector('.panel-title h1').textContent = data.menuTitle;
    if (data.menuSubtitle) document.querySelector('.subtitle').textContent = data.menuSubtitle;
    if (data.menuTagline) {
        document.querySelector('.panel-ribbon').textContent = data.menuTagline;
    }
    if (data.levelSystem != null) opts.levelSystem = data.levelSystem;
    if (data.levelData) opts.levelData = data.levelData;
    if (data.sortCraftable != null) opts.sortCraftable = data.sortCraftable;
    if (data.showLocked != null) opts.showLocked = data.showLocked;
    if (data.maxQty != null) opts.maxQty = data.maxQty;

    if (data.action === 'open') {
        recipesData = data.recipes || {};
        currentCategory = Object.keys(recipesData)[0] || null;
        panel.classList.remove('out');
        panel.classList.add('visible');
        document.getElementById('backdrop').classList.add('show');
        render();
    } else if (data.action === 'recipes') {
        recipesData = data.recipes || {};
        if (currentCategory && !recipesData[currentCategory]) {
            currentCategory = Object.keys(recipesData)[0] || null;
        }
        render();
    } else if (data.action === 'close') {
        panel.classList.add('out');
        setTimeout(() => {
            panel.classList.remove('visible', 'out');
        }, 180);
        document.getElementById('backdrop').classList.remove('show');
    } else if (data.action === 'showPrompt') {
        const promptEl = document.getElementById('prompt');
        if (data.text) {
            promptEl.querySelector('.prompt-text').textContent = data.text;
        }
        promptEl.classList.add('show');
    } else if (data.action === 'hidePrompt') {
        document.getElementById('prompt').classList.remove('show');
    } else if (data.action === 'startProgress') {
        showProgress(data.label, data.duration);
    } else if (data.action === 'stopProgress') {
        hideProgress();
    }
});

document.addEventListener('keydown', (event) => {
    if (event.key === 'd' || event.key === 'D' || event.key === 'Escape') {
        if (panel.classList.contains('visible')) {
            send('close');
        } else if (document.getElementById('craft-progress').classList.contains('show')) {
            send('cancelCraft');
        }
    }
});

document.getElementById('close-btn').addEventListener('click', () => send('close'));
const cpCancelBtn = document.getElementById('cp-cancel');
if (cpCancelBtn) {
    cpCancelBtn.addEventListener('click', () => send('cancelCraft'));
}

function render() {
    renderLevel();
    renderTabs();
    renderRecipes();
}

function renderTabs() {
    tabsEl.innerHTML = '';
    const keys = Object.keys(recipesData);
    if (!keys.length) return;
    keys.forEach((key, i) => {
        const list = recipesData[key] || [];
        const craftable = list.filter((r) => r.craftable).length;

        const tab = document.createElement('button');
        tab.className = 'tab' + (key === currentCategory ? ' active' : '');
        const c = categoryColors(key);
        tab.style.setProperty('--tab-1', c.c1);
        tab.style.setProperty('--tab-2', c.c2);
        tab.style.setProperty('--tab-dark', c.dark);

        const ico = document.createElement('span');
        ico.className = 'tab-ico';
        ico.textContent = (key || '?').trim().charAt(0).toUpperCase();
        tab.appendChild(ico);

        const label = document.createElement('span');
        label.textContent = key;
        tab.appendChild(label);

        const badge = document.createElement('span');
        badge.className = 'tab-badge';
        badge.textContent = craftable;
        tab.appendChild(badge);

        tab.addEventListener('click', () => {
            currentCategory = key;
            render();
        });
        tabsEl.appendChild(tab);
    });
}

function renderRecipes() {
    recipesEl.innerHTML = '';
    if (!currentCategory || !recipesData[currentCategory]) return;

    let list = recipesData[currentCategory];
    if (!opts.showLocked) {
        list = list.filter((r) => r.unlocked);
    }
    if (!list.length) {
        const empty = document.createElement('div');
        empty.className = 'empty';
        empty.textContent = 'No recipes in this category.';
        recipesEl.appendChild(empty);
        return;
    }
    if (sortMode === 'level') {
        list = [...list].sort((a, b) => {
            if (a.level !== b.level) return a.level - b.level;
            return a.craftable === b.craftable ? 0 : a.craftable ? -1 : 1;
        });
    } else if (sortMode === 'alpha') {
        list = [...list].sort((a, b) => (a.label || '').localeCompare(b.label || ''));
    } else {
        list = [...list].sort((a, b) => {
            if (a.craftable !== b.craftable) return a.craftable ? -1 : 1;
            if (a.level !== b.level) return a.level - b.level;
            return (a.label || '').localeCompare(b.label || '');
        });
    }

    const statsEl = document.getElementById('stats');
    if (statsEl) {
        const total = list.length;
        const craftable = list.filter((r) => r.craftable).length;
        statsEl.innerHTML = `<b>${craftable}</b> CRAFTABLE &middot; <b>${total}</b> RECIPES`;
    }

    list.forEach((recipe, i) => {
        recipesEl.appendChild(createRecipeCard(recipe));
    });
}

function createFallback(label) {
    const el = document.createElement('span');
    el.className = 'item-fallback';
    el.textContent = (label || '?').trim().charAt(0).toUpperCase();
    return el;
}

function createItemChip(item) {
    const chip = document.createElement('div');
    chip.className = `item-chip ${item.has ? 'has' : 'missing'}`;
    chip.title = item.label;

    const img = document.createElement('img');
    img.className = 'item-chip-img';
    loadItemImage(img, item.item, () => {
        img.remove();
        chip.insertBefore(createFallback(item.label), chip.firstChild);
    });

    const count = document.createElement('span');
    count.className = 'item-chip-count';
    count.textContent = `${item.amount}×`;

    const label = document.createElement('span');
    label.className = 'item-chip-label';
    label.textContent = item.label;

    chip.appendChild(img);
    chip.appendChild(count);
    chip.appendChild(label);
    return chip;
}

function createRecipeCard(recipe) {
    const card = document.createElement('div');
    card.className = 'recipe-card';
    const c = categoryColors(currentCategory);
    card.style.setProperty('--cat-1', c.c1);
    card.style.setProperty('--cat-2', c.c2);
    card.style.setProperty('--cat-dark', c.dark);

    const resultWrap = document.createElement('div');
    resultWrap.className = 'result-wrap';

    if (!recipe.unlocked) {
        card.classList.add('locked');
        const lock = document.createElement('span');
        lock.className = 'lock-badge';
        lock.textContent = `LVL ${recipe.level}`;
        resultWrap.appendChild(lock);
    } else if (recipe.craftable) {
        const ok = document.createElement('span');
        ok.className = 'ok-badge';
        ok.textContent = 'READY';
        resultWrap.appendChild(ok);
    }

    const resultImg = document.createElement('img');
    resultImg.className = 'result-img';
    resultWrap.appendChild(resultImg);
    loadItemImage(resultImg, recipe.name, () => resultWrap.appendChild(createFallback(recipe.itemLabel || recipe.name)));

    const info = document.createElement('div');
    info.className = 'recipe-info';

    const nameEl = document.createElement('div');
    nameEl.className = 'recipe-name';
    nameEl.textContent = recipe.label;
    const metaEl = document.createElement('div');
    metaEl.className = 'recipe-meta';
    metaEl.textContent = `Result: ${recipe.amount}× ${recipe.itemLabel || recipe.name}`;
    if (recipe.time && recipe.time > 0) {
        const timeEl = document.createElement('span');
        timeEl.className = 'meta-time';
        timeEl.textContent = `\u00B7 TIME: ${recipe.time}s`;
        metaEl.appendChild(timeEl);
    }
    info.appendChild(nameEl);
    info.appendChild(metaEl);

    const head = document.createElement('div');
    head.className = 'recipe-head';
    head.appendChild(resultWrap);
    head.appendChild(info);

    const ingEl = document.createElement('div');
    ingEl.className = 'recipe-ing';
    recipe.ingredients.forEach((ing) => ingEl.appendChild(createItemChip(ing)));

    let maxQty = Math.max(1, opts.maxQty || 1);
    let maxPossible = maxQty;
    if (recipe.ingredients.length) {
        let m = Infinity;
        recipe.ingredients.forEach((ing) => {
            const per = Math.max(1, ing.amount || 1);
            const n = Math.floor((ing.count || 0) / per);
            if (n < m) m = n;
        });
        maxPossible = m;
    }
    maxPossible = Math.max(1, Math.min(maxQty, maxPossible));

    const controls = document.createElement('div');
    controls.className = 'card-controls';

    const stepper = document.createElement('div');
    stepper.className = 'stepper';
    const minus = document.createElement('button');
    minus.className = 'step-btn';
    minus.textContent = '−';
    const qtyInput = document.createElement('input');
    qtyInput.type = 'number';
    qtyInput.className = 'qty-input';
    qtyInput.min = '1';
    qtyInput.max = String(maxQty);
    qtyInput.value = '1';
    const plus = document.createElement('button');
    plus.className = 'step-btn';
    plus.textContent = '+';
    stepper.appendChild(minus);
    stepper.appendChild(qtyInput);
    stepper.appendChild(plus);

    const maxBtn = document.createElement('button');
    maxBtn.className = 'max-btn';
    maxBtn.textContent = 'MAX';
    maxBtn.title = 'Craft the maximum possible amount';
    maxBtn.addEventListener('click', () => {
        qty = maxPossible;
        qtyInput.value = qty;
        updateStepper();
    });

    const btn = document.createElement('button');
    btn.className = 'craft-btn';
    btn.textContent = 'CRAFT';

    let qty = 1;
    const locked = !recipe.unlocked;
    const readQty = () => Math.max(1, Math.min(maxQty, Math.floor(parseInt(qtyInput.value, 10) || 1)));
    const updateStepper = () => {
        minus.disabled = locked || qty <= 1;
        plus.disabled = locked || qty >= maxQty;
        maxBtn.disabled = locked || maxPossible <= 1;
    };
    qtyInput.addEventListener('input', () => {
        qty = readQty();
    });
    qtyInput.addEventListener('blur', () => {
        qtyInput.value = qty;
        updateStepper();
    });
    qtyInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
            e.preventDefault();
            qtyInput.blur();
        }
    });

    const setCrafting = (state) => {
        const on = state === true;
        btn.classList.toggle('crafting', on);
        btn.textContent = on ? 'CRAFTING...' : 'CRAFT';
        btn.disabled = on;
        minus.disabled = on;
        plus.disabled = on;
        qtyInput.disabled = on;
        maxBtn.disabled = on;
    };

    if (locked) {
        btn.classList.add('locked');
        btn.textContent = 'LOCKED';
        btn.disabled = true;
        minus.disabled = true;
        plus.disabled = true;
        qtyInput.disabled = true;
        maxBtn.disabled = true;
    } else {
        if (!recipe.craftable) {
            btn.classList.add('disabled');
            btn.textContent = 'CRAFT';
        }
        minus.addEventListener('click', () => {
            qty = Math.max(1, qty - 1);
            qtyInput.value = qty;
            updateStepper();
        });
        plus.addEventListener('click', () => {
            qty = Math.min(maxQty, qty + 1);
            qtyInput.value = qty;
            updateStepper();
        });
        btn.addEventListener('click', () => {
            setCrafting(true);
            send('craft', { item: recipe.name, qty: qty });
        });
    }
    updateStepper();

    controls.appendChild(stepper);
    controls.appendChild(maxBtn);
    controls.appendChild(btn);

    card.appendChild(head);
    card.appendChild(ingEl);
    card.appendChild(controls);
    return card;
}

send('nuiReady');
