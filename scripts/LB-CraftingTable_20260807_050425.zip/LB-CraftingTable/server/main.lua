local QBCore = exports['qb-core']:GetCoreObject()

if not QBCore then
    print('^1[LB-CraftingTable]^0 qb-core was not found, resource disabled.')
    return
end

local function FindRecipe(name)
    for _, list in pairs(Config.Recipes) do
        for _, recipe in pairs(list) do
            if recipe.name == name then
                return recipe
            end
        end
    end
    return nil
end

local function NearTable(src)
    local ped = GetPlayerPed(src)
    if not ped then return false end
    local coords = GetEntityCoords(ped)
    for _, tbl in pairs(Config.Tables) do
        if #(coords - tbl.coords) < Config.ServerRange then
            return true
        end
    end
    return false
end

local function HasAccess(Player, tbl)
    tbl = tbl or {}
    local job = tbl.job or Config.RequiredJob
    if job and Player.PlayerData.job.name ~= job then
        return false, 'You do not have the required job'
    end
    local keyItem = tbl.keyItem or Config.RequiredKeyItem
    if keyItem then
        local item = Player.Functions.GetItemByName(keyItem)
        if not item or item.amount < 1 then
            return false, 'You need a ' .. (QBCore.Shared.Items[keyItem] and QBCore.Shared.Items[keyItem].label or keyItem)
        end
    end
    return true
end

local craftCooldown = {}
local craftLog = {}
local craftLocks = {}

local function GetAvailable(src, item)
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return 0 end
    local total = 0
    local slots = Player.Functions.GetItemsByName(item)
    if slots then
        for _, it in pairs(slots) do
            total = total + (it.amount or 0)
        end
    end
    local now = GetGameTimer()
    local locks = craftLocks[src]
    if locks then
        for _, entry in pairs(locks) do
            if entry["until"] > now and entry.ingredients[item] then
                total = total - entry.ingredients[item]
            end
        end
    end
    return total
end

RegisterNetEvent('lb-craftingtable:server:startcraft', function(name, qty, duration)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return end
    if not NearTable(src) then return end

    qty = math.floor(tonumber(qty) or 1)
    if qty < 1 or qty > (Config.MaxCraftQty or 25) then qty = 1 end

    local recipe = FindRecipe(name)
    if not recipe then return end

    if Config.LevelSystem then
        local meta = Player.PlayerData.metadata.crafting or { level = Config.LevelStart }
        local level = meta.level or Config.LevelStart
        if level < (recipe.level or 1) then
            TriggerClientEvent('QBCore:Notify', src, 'You need Crafting Level ' .. (recipe.level or 1), 'error')
            return
        end
    end

    local tbl = nil
    local ped = GetPlayerPed(src)
    for _, t in pairs(Config.Tables) do
        if #(GetEntityCoords(ped) - t.coords) < Config.ServerRange then
            tbl = t
            break
        end
    end
    local access, reason = HasAccess(Player, tbl)
    if not access then
        TriggerClientEvent('QBCore:Notify', src, reason, 'error')
        return
    end

    for _, ing in pairs(recipe.ingredients) do
        if GetAvailable(src, ing.item) < ing.amount * qty then
            TriggerClientEvent('QBCore:Notify', src, 'You are missing ' .. (QBCore.Shared.Items[ing.item] and QBCore.Shared.Items[ing.item].label or ing.item), 'error')
            return
        end
    end

    craftLocks[src] = craftLocks[src] or {}
    craftLocks[src][name] = {
        ["until"] = GetGameTimer() + (duration or (Config.CraftTime or 60) * 1000),
        ingredients = {},
    }
    for _, ing in pairs(recipe.ingredients) do
        craftLocks[src][name].ingredients[ing.item] = (craftLocks[src][name].ingredients[ing.item] or 0) + ing.amount * qty
    end
end)

RegisterNetEvent('lb-craftingtable:server:cancelcraft', function(name)
    local src = source
    if craftLocks[src] and name then
        craftLocks[src][name] = nil
    end
end)

RegisterNetEvent('lb-craftingtable:server:craft', function(name, qty)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return end
    if not NearTable(src) then
        print(string.format('^1[LB-CraftingTable]^0 craft REJECTED: not near table (src=%s)', tostring(src)))
        return
    end

    local now = GetGameTimer()
    if (now - (craftCooldown[src] or 0)) < Config.ServerCooldown then return end
    craftCooldown[src] = now

    qty = math.floor(tonumber(qty) or 1)
    if qty < 1 or qty > (Config.MaxCraftQty or 25) then qty = 1 end

    local recipe = FindRecipe(name)
    if not recipe then
        print(string.format('^1[LB-CraftingTable]^0 craft REJECTED: invalid recipe %s', tostring(name)))
        TriggerClientEvent('QBCore:Notify', src, 'Invalid recipe', 'error')
        return
    end

    if Config.LevelSystem then
        local meta = Player.PlayerData.metadata.crafting or { level = Config.LevelStart }
        local level = meta.level or Config.LevelStart
        if level < (recipe.level or 1) then
            TriggerClientEvent('QBCore:Notify', src, 'You need Crafting Level ' .. (recipe.level or 1), 'error')
            return
        end
    end

    local tbl = nil
    local ped = GetPlayerPed(src)
    for _, t in pairs(Config.Tables) do
        if #(GetEntityCoords(ped) - t.coords) < Config.ServerRange then
            tbl = t
            break
        end
    end
    local access, reason = HasAccess(Player, tbl)
    if not access then
        TriggerClientEvent('QBCore:Notify', src, reason, 'error')
        return
    end

    local log = craftLog[src] or {}
    local cutoff = now - 60000
    local count = 0
    for i = #log, 1, -1 do
        if log[i] < cutoff then
            table.remove(log, i)
        else
            count = count + 1
        end
    end
    craftLog[src] = log
    if count >= (Config.MaxCraftsPerMinute or 30) then
        TriggerClientEvent('QBCore:Notify', src, 'You are crafting too fast', 'error')
        return
    end
    table.insert(log, now)

    local resultItem = QBCore.Shared.Items[recipe.name]
    local addWeight = (resultItem and resultItem.weight or 0) * recipe.amount * qty

    local freeWeight = nil
    if GetResourceState('qb-inventory') == 'started' then
        local ok, export = pcall(function()
            return exports['qb-inventory']:GetFreeWeight(src)
        end)
        if ok and type(export) == 'number' then
            freeWeight = export
        end
    end

    if freeWeight == nil then
        local maxWeight = Player.PlayerData.metadata.maxweight
            or (QBCore.Config and QBCore.Config.Player and QBCore.Config.Player.MaxWeight)
            or 120000
        local totalWeight = 0
        if Player.Functions.GetTotalWeight then
            totalWeight = Player.Functions.GetTotalWeight()
        else
            for _, item in pairs(Player.PlayerData.items) do
                if item and item.amount and item.name then
                    local w = item.weight
                    if not w and QBCore.Shared.Items[item.name] then
                        w = QBCore.Shared.Items[item.name].weight
                    end
                    totalWeight = totalWeight + ((w or 0) * item.amount)
                end
            end
        end
        freeWeight = maxWeight - totalWeight
    end

    if freeWeight < addWeight then
        TriggerClientEvent('QBCore:Notify', src, 'You are carrying too much', 'error')
        return
    end

    local resultInfo = QBCore.Shared.Items[recipe.name]
    local maxSlots = (QBCore.Config and QBCore.Config.Player and QBCore.Config.Player.PlayerSlots) or 41
    local usedSlots = 0
    for _, item in pairs(Player.PlayerData.items) do
        if item and item.name and item.amount and item.amount > 0 then
            usedSlots = usedSlots + 1
        end
    end
    local freeSlots = maxSlots - usedSlots
    local hasResultStack = false
    if resultInfo and not resultInfo.unique then
        for _, item in pairs(Player.PlayerData.items) do
            if item and item.name == recipe.name and item.amount and item.amount > 0 then
                hasResultStack = true
                break
            end
        end
    end
    if freeSlots < 1 and not hasResultStack then
        print(string.format('^1[LB-CraftingTable]^0 craft REJECTED: inventory full (freeSlots=%s)', tostring(freeSlots)))
        TriggerClientEvent('QBCore:Notify', src, 'Your inventory is full', 'error')
        return
    end

    for _, ing in pairs(recipe.ingredients) do
        local need = ing.amount * qty
        local have = 0
        local slots = Player.Functions.GetItemsByName(ing.item)
        if slots then
            for _, it in pairs(slots) do
                have = have + (it.amount or 0)
            end
        end
        if have < need then
            print(string.format('^1[LB-CraftingTable]^0 craft REJECTED: missing %s (need %s)', tostring(ing.item), tostring(need)))
            TriggerClientEvent('QBCore:Notify', src, 'You are missing ' .. (QBCore.Shared.Items[ing.item] and QBCore.Shared.Items[ing.item].label or ing.item), 'error')
            return
        end
    end

    local added = Player.Functions.AddItem(recipe.name, recipe.amount * qty)
    if not added then
        print(string.format('^1[LB-CraftingTable]^0 craft REJECTED: AddItem failed for %s (freeSlots=%s, hasStack=%s)', tostring(recipe.name), tostring(freeSlots), tostring(hasResultStack)))
        TriggerClientEvent('QBCore:Notify', src, 'Unable to add item, check your inventory', 'error')
        return
    end

    for _, ing in pairs(recipe.ingredients) do
        local need = ing.amount * qty
        local slots = Player.Functions.GetItemsByName(ing.item)
        if slots then
            for _, it in pairs(slots) do
                if need <= 0 then break end
                local remove = math.min(it.amount or 0, need)
                if remove > 0 then
                    Player.Functions.RemoveItem(ing.item, remove, it.slot)
                    if Config.ShowItemBox and QBCore.Shared.Items[ing.item] then
                        TriggerClientEvent('qb-inventory:client:ItemBox', src, QBCore.Shared.Items[ing.item], 'remove')
                    end
                    need = need - remove
                end
            end
        end
    end

    print(string.format('^2[LB-CraftingTable]^0 craft OK: %s x%s -> added for src=%s', tostring(recipe.name), tostring(qty), tostring(src)))
    if Config.ShowItemBox and QBCore.Shared.Items[recipe.name] then
        TriggerClientEvent('qb-inventory:client:ItemBox', src, QBCore.Shared.Items[recipe.name], 'add')
    end

    if craftLocks[src] then
        craftLocks[src][name] = nil
    end

    if Config.LevelSystem then
        local meta = Player.PlayerData.metadata.crafting or { level = Config.LevelStart, xp = 0 }
        local level = meta.level or Config.LevelStart
        local xp = (meta.xp or 0) + (recipe.xp or Config.XPPerCraft) * qty
        local leveled = false
        while xp >= Config.XPNeeded(level) do
            xp = xp - Config.XPNeeded(level)
            level = level + 1
            leveled = true
        end
        Player.Functions.SetMetaData('crafting', { level = level, xp = xp })
        if leveled and Config.LevelNotify then
            TriggerClientEvent('QBCore:Notify', src, 'Level Up! You are now Crafting Level ' .. level, 'success')
        end
    end

    if qty > 1 then
        TriggerClientEvent('QBCore:Notify', src, 'Crafted: ' .. recipe.label .. ' x' .. qty, 'success')
    else
        TriggerClientEvent('QBCore:Notify', src, 'Crafted: ' .. recipe.label, 'success')
    end
end)
