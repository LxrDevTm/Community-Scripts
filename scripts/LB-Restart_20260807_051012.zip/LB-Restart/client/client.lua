local function notify(msg)
    if lib and lib.notify then
        lib.notify({ description = msg, position = 'top-right' })
    elseif QBCore and QBCore.Functions and QBCore.Functions.Notify then
        QBCore.Functions.Notify(msg)
    elseif GetResourceState('chat') == 'started' then
        TriggerEvent('chat:addMessage', { args = { 'LB-Restart', msg }, color = { 231, 76, 60 } })
    end
end

local function closeMenu()
    SetNuiFocus(false, false)
    SendNUIMessage({ action = 'close' })
end

local function openMenu()
    if not Config.ShowMenu then return end
    SetNuiFocus(true, true)
    SendNUIMessage({
        action = 'open',
        locale = Config.Locale,
        accent = Config.AccentColor,
    })
    TriggerServerEvent('lb-restart:status')
end

RegisterNUICallback('restart', function(data, cb)
    local minutes = tonumber(data.minutes) or 0
    TriggerServerEvent('lb-restart:restart', minutes * 60)
    closeMenu()
    cb('ok')
end)

RegisterNUICallback('schedule', function(data, cb)
    TriggerServerEvent('lb-restart:schedule', tostring(data.time or ''))
    closeMenu()
    cb('ok')
end)

RegisterNUICallback('cancel', function(_, cb)
    TriggerServerEvent('lb-restart:cancel')
    cb('ok')
end)

RegisterNUICallback('status', function(_, cb)
    TriggerServerEvent('lb-restart:status')
    cb('ok')
end)

RegisterNUICallback('close', function(_, cb)
    closeMenu()
    cb('ok')
end)

RegisterNetEvent('lb-restart:statusResult', function(info)
    SendNUIMessage({ action = 'status', info = info })
end)

RegisterNetEvent('lb-restart:notify', function(msg)
    notify(msg)
end)

RegisterNUICallback('dizzy', function(_, cb)
    SetTimecycleModifier('Drunk')
    SetTimecycleModifierStrength(0.45)
    StartScreenEffect('DrunkDrunk01', 0, 0)
    cb('ok')
end)

RegisterNUICallback('dizzyOff', function(_, cb)
    StopScreenEffect('DrunkDrunk01')
    ClearTimecycleModifier()
    cb('ok')
end)

local stormActive = false

RegisterNetEvent('lb-restart:storm', function()
    stormActive = true
    local p = PlayerPedId()
    local x, y, z = table.unpack(GetEntityCoords(p))
    pcall(PlaySoundFromCoord, -1, 'Beep_Red', x, y, z + 30.0, 0, 0, 0)
    pcall(PlaySoundFromCoord, -1, 'EXPLOSION_PROPANE_TANK', x, y, z + 20.0, 0, 0, 0)
    pcall(PlaySoundFrontend, -1, 'Event_Message_Purple', 'GTAO_FM_Events_Soundset', true)
    pcall(StartAlarm, 'AGENCY_HEIST_FIB_MULTI_LOOP_BEEPING', true)
    pcall(StartAlarm, 'BURGLAR_ALARM', true)
end)

CreateThread(function()
    local tick = 0
    while true do
        if stormActive then
            pcall(SetWeatherTypeNowPersist, 'THUNDER')
            tick = tick + 1
            local p = PlayerPedId()
            local x, y, z = table.unpack(GetEntityCoords(p))
            pcall(PlaySoundFromCoord, -1, 'VEHICLES_HORNS_SIREN_1', x, y, z, 0, 0, 0)
            pcall(ShakeGameplayCam, 'MEDIUM_EXPLOSION_SHAKE', 0.15)
            if tick % 4 == 0 then
                pcall(PlaySoundFromCoord, -1, 'EXPLOSION_PROPANE_TANK', x, y, z + 20.0, 0, 0, 0)
            end
            if tick % 3 == 0 then
                local dist = 60.0 + math.random() * 100.0
                local ang = math.random() * 360.0
                local mx = x + math.cos(math.rad(ang)) * dist
                local my = y + math.sin(math.rad(ang)) * dist
                local mz = z + 40.0
                pcall(AddExplosion, mx, my, mz, 4, 0.0, true, false, 1.0)
                pcall(StartScriptFire, mx, my, mz, 3, false)
                pcall(AddExplosion, x + math.cos(math.rad(ang + 40)) * (dist - 30.0), y + math.sin(math.rad(ang + 40)) * (dist - 30.0), z + 20.0, 20, 0.0, true, false, 0.5)
            end
        else
            tick = 0
            pcall(StopGameplayCamShaking, true)
        end
        Wait(1000)
    end
end)

RegisterNetEvent('lb-restart:openMenu', function()
    openMenu()
end)

RegisterNetEvent('lb-restart:warning', function(seconds)
    SendNUIMessage({ action = 'warning', seconds = seconds })
end)

RegisterNetEvent('lb-restart:clearWarning', function()
    stormActive = false
    pcall(StopAlarm, 'AGENCY_HEIST_FIB_MULTI_LOOP_BEEPING', true)
    pcall(StopAlarm, 'BURGLAR_ALARM', true)
    SendNUIMessage({ action = 'clearWarning' })
end)
