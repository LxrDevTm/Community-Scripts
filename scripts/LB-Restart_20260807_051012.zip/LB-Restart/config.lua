Config = Config or {}

Config.Command = 'lbrestart'

Config.ShowMenu = true

Config.AutoOpenMenu = false

Config.Countdown = 30

Config.AccentColor = '#9b1b30'

Config.Locale = {
    MenuTitle = 'LB-Restart',
    Badge = 'PRO',
    StatusLoading = 'Loading status...',
    RestartOptionsLabel = 'Restart options',
    RestartNow = 'Restart now',
    InMinute = 'In 1 minute',
    InMinutes = 'In %s minutes',
    CustomMinutes = 'Restart in (minutes)',
    CustomMinutePlaceholder = 'e.g. 15',
    ScheduleTime = 'Schedule at (HH:MM)',
    ScheduleTimePlaceholder = 'e.g. 04:00',
    Schedule = 'Schedule',
    CancelPending = 'Cancel pending restart',
    Close = 'Close',
    NoPending = 'No pending restart',
    Pending = 'Pending: %s',
    Uptime = 'Uptime: %s',
    Players = 'Players: %s',
    ScheduledTimes = 'Scheduled: %s',
    NoPerms = 'You do not have permission to use this command.',
    RestartCountdown = 'The server will restart in %s seconds. Please save your progress.',
    RestartingMsg = 'The server is restarting now.',
    RestartKickMsg = 'Server is restarting. Please reconnect in a moment.',
    Cancelled = 'Restart cancelled.',
    ScheduledReason = 'Scheduled restart',
    PendingReply = 'A restart is already pending.',
    ScheduledReply = 'Server restart scheduled in ',
    ScheduleAddedReply = 'Scheduled restart added at ',
    NoPendingReply = 'No restart is pending.',
    CancelledReply = 'Pending restart cancelled.',
}
