fx_version 'cerulean'
game 'gta5'
lua54 'yes'

description 'Restart System'
author 'LB'
version '1.0.0'

ui_page 'ui/index.html'

files {
    'ui/index.html',
    'ui/style.css',
    'ui/app.js',
}

shared_scripts {
    'config.lua',
}

server_scripts {
    'server/config_server.lua',
    'server/server.lua',
}

client_scripts {
    'client/client.lua',
}
