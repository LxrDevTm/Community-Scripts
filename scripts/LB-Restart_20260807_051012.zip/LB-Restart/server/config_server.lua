Config = Config or {}

Config.Discord = {
    Webhook = 'PASTE_YOUR_WEBHOOK_URL',
}

Config.ScheduledRestarts = { '02:00', '14:00' }

Config.RestartExitCode = 42

Config.RestartMethod = 'quit'
