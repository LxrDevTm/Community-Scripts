RestartManager = {}

local serverStartTime = os.time()
local pendingId = 0
local pendingTimer = nil
local pendingReason = nil
local stormTimer = nil
local stormTriggered = false
local announceThread = nil
local runtimeSchedules = {}
local fired = {}

local function log(msg)
    print('[LB-Restart] ' .. msg)
end

local function hasPerm(src)
    if src == 0 then return true end
    return IsPlayerAceAllowed(src, 'command.' .. Config.Command)
end

local function sendWebhook(content)
    local wh = Config.Discord and Config.Discord.Webhook
    if not wh or wh == '' or tostring(wh):find('PASTE_YOUR') then return end
    PerformHttpRequest(
        wh,
        function() end,
        'POST',
        json.encode({ content = content }),
        { ['Content-Type'] = 'application/json' }
    )
end

function RestartManager.broadcast(msg)
    TriggerClientEvent('lb-restart:notify', -1, msg)
end

local function kickAllPlayers()
    local players = GetPlayers()
    for i = 1, #players do
        DropPlayer(players[i], Config.Locale.RestartKickMsg or 'Server is restarting.')
    end
    log('Kicked ' .. tostring(#players) .. ' player(s).')
end

function RestartManager.shutdown()
    SetTimeout(1500, function()
        kickAllPlayers()
        local method = Config.RestartMethod or 'quit'
        if method == 'crash' then
            log('Shutting down server (crash) with exit code ' .. tostring(Config.RestartExitCode or 42) .. '...')
            local ok, err = pcall(os.exit, Config.RestartExitCode or 42)
            if not ok then
                log('os.exit failed, using quit command: ' .. tostring(err))
                ExecuteCommand('quit')
            end
        else
            log('Shutting down server (quit)...')
            ExecuteCommand('quit')
        end
    end)
end

function RestartManager.startRestart(reason)
    log('Starting restart. Reason: ' .. tostring(reason))
    RestartManager.broadcast(Config.Locale.RestartingMsg)
    sendWebhook('**Server restarting** - ' .. tostring(reason))
    RestartManager.shutdown()
end

function RestartManager.triggerStorm()
    stormTriggered = true
    local ok, err = pcall(SetWeatherTypeNowPersist, 'THUNDER')
    log('Storm triggered. Weather set ok=' .. tostring(ok) .. (err and ' err=' .. tostring(err) or ''))
    TriggerClientEvent('lb-restart:storm', -1)
end

function RestartManager.scheduleRestart(seconds, reason)
    if pendingTimer then return false, Config.Locale.PendingReply end
    pendingId = pendingId + 1
    local id = pendingId
    pendingReason = reason
    RestartManager.broadcast(string.format(Config.Locale.RestartCountdown, seconds))
    TriggerClientEvent('lb-restart:warning', -1, seconds)
    sendWebhook('**Server restart scheduled** - ' .. tostring(reason) .. ' in ' .. tostring(seconds) .. ' seconds.')
    if seconds > 60 then
        stormTimer = SetTimeout((seconds - 60) * 1000, function()
            if pendingId ~= id then return end
            RestartManager.triggerStorm()
        end)
    else
        RestartManager.triggerStorm()
    end
    local remaining = seconds
    local lastMinute = math.ceil(remaining / 60)
    announceThread = CreateThread(function()
        while pendingId == id do
            Wait(1000)
            if pendingId ~= id then break end
            remaining = remaining - 1
            if remaining <= 0 then break end
            local curMinute = math.ceil(remaining / 60)
            if remaining <= 10 then
                RestartManager.broadcast(string.format(Config.Locale.RestartCountdown, remaining))
            elseif curMinute ~= lastMinute then
                lastMinute = curMinute
                RestartManager.broadcast(string.format(Config.Locale.RestartCountdown, curMinute * 60))
            end
        end
        announceThread = nil
    end)
    pendingTimer = SetTimeout(seconds * 1000, function()
        if pendingId ~= id then return end
        pendingTimer = nil
        RestartManager.startRestart(reason)
    end)
    return true, Config.Locale.ScheduledReply .. tostring(seconds) .. ' seconds.'
end

function RestartManager.restartNow(reason)
    return RestartManager.scheduleRestart(Config.Countdown or 30, reason)
end

function RestartManager.scheduleTime(hhmm)
    runtimeSchedules[hhmm] = true
    log('Runtime schedule added: ' .. hhmm)
end

function RestartManager.cancelPending()
    if not pendingTimer then return false, Config.Locale.NoPendingReply end
    pendingId = pendingId + 1
    pendingTimer = nil
    pendingReason = nil
    if stormTimer then
        stormTimer = nil
    end
    if stormTriggered then
        stormTriggered = false
        pcall(SetWeatherTypeNowPersist, 'CLEAR')
    end
    TriggerClientEvent('lb-restart:clearWarning', -1)
    log('Pending restart cancelled.')
    sendWebhook('**Scheduled restart cancelled.**')
    return true, Config.Locale.CancelledReply
end

function RestartManager.getStatus()
    local all = {}
    for t in pairs(runtimeSchedules) do all[#all + 1] = t end
    for _, t in ipairs(Config.ScheduledRestarts) do all[#all + 1] = t end
    table.sort(all)
    return {
        pending = pendingTimer ~= nil,
        reason = pendingReason,
        scheduled = all,
        players = GetNumPlayerIndices(),
        uptime = os.time() - serverStartTime,
    }
end

local function checkScheduled()
    local now = os.date('%H:%M')
    local all = {}
    for t in pairs(runtimeSchedules) do all[t] = true end
    for _, t in ipairs(Config.ScheduledRestarts) do all[t] = true end
    for t in pairs(all) do
        if t == now and not fired[t] then
            fired[t] = true
            RestartManager.scheduleRestart(Config.Countdown or 30, Config.Locale.ScheduledReason .. ' ' .. t)
        end
    end
    for t in pairs(fired) do
        if t ~= now then fired[t] = nil end
    end
end

CreateThread(function()
    while true do
        Wait(20000)
        checkScheduled()
    end
end)

RegisterCommand(Config.Command, function(source, args)
    if not hasPerm(source) then
        if source ~= 0 then
            TriggerClientEvent('lb-restart:notify', source, Config.Locale.NoPerms)
        end
        return
    end
    if source == 0 then
        RestartManager.restartNow('Console command')
        return
    end
    TriggerClientEvent('lb-restart:openMenu', source)
end, false)

RegisterNetEvent('lb-restart:restart', function(seconds)
    local src = source
    if not hasPerm(src) then return end
    local reason = 'In-game menu by ' .. GetPlayerName(src)
    if seconds and seconds > 0 then
        RestartManager.scheduleRestart(seconds, reason)
    else
        RestartManager.restartNow(reason)
    end
end)

RegisterNetEvent('lb-restart:schedule', function(hhmm)
    local src = source
    if not hasPerm(src) then return end
    if hhmm and hhmm:match('^%d%d:%d%d$') then
        RestartManager.scheduleTime(hhmm)
    end
end)

RegisterNetEvent('lb-restart:cancel', function()
    local src = source
    if not hasPerm(src) then return end
    RestartManager.cancelPending()
end)

RegisterNetEvent('lb-restart:status', function()
    local src = source
    if not hasPerm(src) then return end
    TriggerClientEvent('lb-restart:statusResult', src, RestartManager.getStatus())
end)

AddEventHandler('onResourceStart', function(resName)
    if resName ~= GetCurrentResourceName() then return end
    log('Started. Scheduled restarts: ' .. table.concat(Config.ScheduledRestarts, ', '))
end)

AddEventHandler('playerJoining', function()
    local src = source
    SetTimeout(4000, function()
        if not Config.ShowMenu or not Config.AutoOpenMenu then return end
        if IsPlayerAceAllowed(src, 'command.' .. Config.Command) then
            TriggerClientEvent('lb-restart:openMenu', src)
        end
    end)
end)
