const app = document.getElementById('app');
const menu = document.getElementById('menu');

const $ = (id) => document.getElementById(id);

const els = {
    statusLine: $('status-line'),
    pendingLine: $('pending-line'),
    scheduledLine: $('scheduled-line'),
    uptimeLine: $('uptime-line'),
    playersLine: $('players-line'),
    lblOptions: $('lbl-options'),
    lblSchedule: $('lbl-schedule'),
    min0: $('min0'),
    min1: $('min1'),
    min5: $('min5'),
    min10: $('min10'),
    min30: $('min30'),
    customMin: $('custom-min'),
    btnCustomMin: $('btn-custom-min'),
    btnCustomToggle: $('btn-custom-toggle'),
    customWrap: $('custom-wrap'),
    scheduleTime: $('schedule-time'),
    btnSchedule: $('btn-schedule'),
    btnCancelPending: $('btn-cancel-pending'),
    btnClose: $('btn-close'),
    btnCloseX: $('btn-close-x'),
    warningBanner: $('warning-banner'),
    warningText: $('warning-text'),
    flashOverlay: $('flash-overlay'),
    darkenOverlay: $('darken-overlay'),
};

let warnEnd = 0;
let warnTimer = null;
let dizzyStarted = false;

function startWarning(seconds) {
    warnEnd = Date.now() + Math.max(seconds, 0) * 1000;
    els.warningBanner.hidden = false;
    if (!warnTimer) warnTimer = setInterval(updateWarning, 250);
    updateWarning();
}

function updateWarning() {
    const rem = Math.max(0, Math.round((warnEnd - Date.now()) / 1000));
    const m = Math.floor(rem / 60);
    const s = rem % 60;
    els.warningText.textContent = 'SERVER RESTARTING IN ' + m + ':' + (s < 10 ? '0' + s : s);
    if (rem <= 60 && rem > 0) {
        els.warningBanner.classList.add('alarm');
        els.flashOverlay.classList.add('alarm');
        els.darkenOverlay.style.opacity = ((60 - rem) / 60 * 0.65).toFixed(3);
        if (!dizzyStarted) {
            dizzyStarted = true;
            call('dizzy');
        }
    } else if (rem > 60) {
        els.warningBanner.classList.remove('alarm');
        els.flashOverlay.classList.remove('alarm');
        els.darkenOverlay.style.opacity = '0';
    } else if (rem <= 0) {
        els.warningText.textContent = 'SERVER RESTARTING NOW';
        clearWarning();
    }
}

function clearWarning() {
    if (warnTimer) { clearInterval(warnTimer); warnTimer = null; }
    warnEnd = 0;
    if (dizzyStarted) {
        dizzyStarted = false;
        call('dizzyOff');
    }
    els.warningBanner.classList.remove('alarm');
    els.flashOverlay.classList.remove('alarm');
    els.darkenOverlay.style.opacity = '0';
    els.warningBanner.hidden = true;
}

let locale = {};

function setAccent(color) {
    const root = document.documentElement;
    root.style.setProperty('--accent', color);
    const r = parseInt(color.slice(1, 3), 16);
    const g = parseInt(color.slice(3, 5), 16);
    const b = parseInt(color.slice(5, 7), 16);
    root.style.setProperty('--accent-rgb', r + ', ' + g + ', ' + b);
}

function call(cbName, body) {
    fetch('https://' + GetParentResourceName() + '/' + cbName, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body || {}),
    });
}

function formatUptime(seconds) {
    seconds = seconds || 0;
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    return h + 'h ' + m + 'm';
}

function renderStatus(info) {
    if (!info) return;
    const pending = info.pending ? (locale.Pending || 'Pending: %s').replace('%s', info.reason || '') : (locale.NoPending || 'No pending restart');
    els.pendingLine.textContent = pending;
    els.pendingLine.dataset.pending = info.pending ? 'true' : 'false';
    els.uptimeLine.textContent = (locale.Uptime || 'Uptime: %s').replace('%s', formatUptime(info.uptime));
    els.playersLine.textContent = (locale.Players || 'Players: %s').replace('%s', info.players || 0);
    const scheduled = (info.scheduled || []).join(', ');
    els.scheduledLine.textContent = (locale.ScheduledTimes || 'Scheduled: %s').replace('%s', scheduled || '-');
}

window.addEventListener('message', (event) => {
    const data = event.data || {};
    if (data.action === 'open') {
        locale = data.locale || {};
        try {
            els.statusLine.textContent = locale.StatusLoading || 'Loading status...';
            els.lblOptions.textContent = locale.RestartOptionsLabel || 'Restart options';
            els.lblSchedule.textContent = locale.ScheduleTime || 'Schedule at (HH:MM)';
            els.min0.textContent = locale.RestartNow || 'Restart now';
            els.min1.textContent = locale.InMinute || 'In 1 minute';
            els.min5.textContent = (locale.InMinutes || 'In %s minutes').replace('%s', 5);
            els.min10.textContent = (locale.InMinutes || 'In %s minutes').replace('%s', 10);
            els.min30.textContent = (locale.InMinutes || 'In %s minutes').replace('%s', 30);
            els.btnCustomToggle.textContent = locale.CustomTime || 'Custom time';
            els.customMin.placeholder = locale.CustomMinutePlaceholder || 'e.g. 15';
            els.scheduleTime.placeholder = locale.ScheduleTimePlaceholder || 'e.g. 04:00';
            els.btnCustomMin.textContent = 'Restart';
            els.btnSchedule.textContent = locale.Schedule || 'Schedule';
            els.btnCancelPending.textContent = locale.CancelPending || 'Cancel pending restart';
            els.btnClose.textContent = locale.Close || 'Close';
            els.pendingLine.textContent = locale.StatusLoading || 'Loading status...';
            setAccent(data.accent || '#9b1b30');
        } catch (e) {}
        app.classList.remove('hidden');
        app.classList.remove('fading-out');
        app.classList.add('visible');
    } else if (data.action === 'status') {
        renderStatus(data.info);
    } else if (data.action === 'warning') {
        startWarning(data.seconds || 30);
    } else if (data.action === 'clearWarning') {
        clearWarning();
    } else if (data.action === 'close') {
        hideMenu();
    }
});

els.btnCustomToggle.addEventListener('click', () => {
    els.customWrap.hidden = !els.customWrap.hidden;
    if (!els.customWrap.hidden) els.customMin.focus();
});

els.btnCustomMin.addEventListener('click', () => {
    const v = parseInt(els.customMin.value, 10);
    if (v && v > 0) call('restart', { minutes: v });
});

els.btnSchedule.addEventListener('click', () => {
    const t = (els.scheduleTime.value || '').trim();
    if (t) call('schedule', { time: t });
});

els.btnCancelPending.addEventListener('click', () => call('cancel'));
els.btnClose.addEventListener('click', () => call('close'));
els.btnCloseX.addEventListener('click', () => call('close'));

document.querySelectorAll('.opt[data-minutes]').forEach((btn) => {
    btn.addEventListener('click', () => call('restart', { minutes: parseInt(btn.dataset.minutes, 10) || 0 }));
});

document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
        call('close');
    }
});

function hideMenu() {
    app.classList.remove('visible');
    app.classList.add('fading-out');
    setTimeout(() => {
        app.classList.remove('fading-out');
        app.classList.add('hidden');
    }, 300);
}
