local QBCore = exports['qb-core']:GetCoreObject()

local isBusy = false
local hackCode = 0
local hackAttempts = 0
local currentATM = 0
local currentType = 'atm'
local nearTarget = false

local ATMHashes = {}
for _, prop in pairs(Config.ATMProps) do
    ATMHashes[#ATMHashes + 1] = GetHashKey(prop)
end

local ShopHashes = {}
for _, prop in pairs(Config.ShopProps) do
    ShopHashes[#ShopHashes + 1] = GetHashKey(prop)
end

local policeBlips = {}

RegisterNetEvent('lb-bankrobbery:client:PoliceAlertBlip', function(coords, msg, robberSrc)
    local entry = policeBlips[robberSrc]
    if entry then
        SetBlipCoords(entry.marker, coords.x, coords.y, coords.z)
        if DoesBlipExist(entry.radius) then SetBlipCoords(entry.radius, coords.x, coords.y, coords.z) end
        return
    end

    local radius = AddBlipForRadius(coords.x, coords.y, coords.z, 30.0)
    SetBlipColour(radius, 1)
    SetBlipAlpha(radius, 160)
    SetBlipHighDetail(radius, true)

    local marker = AddBlipForCoord(coords.x, coords.y, coords.z)
    SetBlipSprite(marker, 162)
    SetBlipColour(marker, 1)
    SetBlipScale(marker, 1.2)
    SetBlipHighDetail(marker, true)
    BeginTextCommandSetBlipName('STRING')
    AddTextComponentString(msg)
    EndTextCommandSetBlipName(marker)

    policeBlips[robberSrc] = { marker = marker, radius = radius }

    SetTimeout(Config.PoliceAlertDuration * 1000, function()
        local e = policeBlips[robberSrc]
        if e then
            if DoesBlipExist(e.marker) then RemoveBlip(e.marker) end
            if e.radius and DoesBlipExist(e.radius) then RemoveBlip(e.radius) end
            policeBlips[robberSrc] = nil
        end
    end)
end)

local function GetClosestATM()
    local pedCoords = GetEntityCoords(PlayerPedId())
    local closest = 0
    local closestDist = Config.Distance
    for _, hash in pairs(ATMHashes) do
        local atm = GetClosestObjectOfType(pedCoords, Config.Distance, hash, false, false, false)
        if atm ~= 0 then
            local dist = #(GetEntityCoords(atm) - pedCoords)
            if dist < closestDist then
                closestDist = dist
                closest = atm
            end
        end
    end
    return closest
end

local function GetClosestShop()
    local pedCoords = GetEntityCoords(PlayerPedId())
    local closest = 0
    local closestDist = Config.ShopDistance
    for _, hash in pairs(ShopHashes) do
        local reg = GetClosestObjectOfType(pedCoords, Config.ShopDistance, hash, false, false, false)
        if reg ~= 0 then
            local dist = #(GetEntityCoords(reg) - pedCoords)
            if dist < closestDist then
                closestDist = dist
                closest = reg
            end
        end
    end
    return closest
end

local function AlertPolice(msg, coords, notify)
    if not Config.NotifyPolice then return end
    if notify == nil then notify = true end
    TriggerServerEvent('lb-bankrobbery:server:PoliceAlert', msg, coords, notify)
end

CreateThread(function()
    while true do
        local sleep = 1000
        local pedCoords = GetEntityCoords(PlayerPedId())
        local atm = GetClosestATM()
        local shop = GetClosestShop()
        local target = 0
        local ttype = 'atm'

        if atm ~= 0 and shop ~= 0 then
            local dA = #(GetEntityCoords(atm) - pedCoords)
            local dS = #(GetEntityCoords(shop) - pedCoords)
            if dS < dA then
                target, ttype = shop, 'shop'
            else
                target, ttype = atm, 'atm'
            end
        elseif shop ~= 0 then
            target, ttype = shop, 'shop'
        elseif atm ~= 0 then
            target, ttype = atm, 'atm'
        end

        if target ~= 0 and not isBusy then
            sleep = 0
            currentATM = target
            currentType = ttype

            if not nearTarget then
                nearTarget = true
                SendNUIMessage({ action = 'showPrompt', type = ttype })
            end

            if IsControlJustReleased(0, 38) then
                local item = QBCore.Functions.HasItem(Config.LockpickItem)
                if not item then
                    QBCore.Functions.Notify('You need a ' .. Config.LockpickItem .. '!', 'error', 3500)
                    Wait(500)
                else
                    local cbName = ttype == 'shop' and 'lb-bankrobbery:server:ShopCanRob' or 'lb-bankrobbery:server:CanRob'
                    QBCore.Functions.TriggerCallback(cbName, function(canRob, payout)
                        if canRob then
                            StartHack(payout, ttype)
                        elseif payout and payout > 0 then
                            currentATM = target
                            currentType = ttype
                            OpenLockNUI(ttype, payout)
                        else
                            QBCore.Functions.Notify(ttype == 'shop' and 'This register was recently emptied...' or 'This ATM was recently robbed...', 'error', 3500)
                        end
                    end, GetEntityCoords(target))
                end
            end
        else
            if nearTarget then
                nearTarget = false
                SendNUIMessage({ action = 'hidePrompt' })
            end
        end

        Wait(sleep)
    end
end)

function StartHack(payout, hackType)
    hackType = hackType or 'atm'
    local coords = GetEntityCoords(currentATM)

    isBusy = true

    OpenHackNUI(payout, hackType)

    AlertPolice(hackType == 'shop' and 'Shop robbery in progress!' or 'ATM robbery in progress!', coords)

    CreateThread(function()
        local endTime = GetGameTimer() + Config.PoliceAlertDuration * 1000
        while GetGameTimer() < endTime do
            Wait(math.max(0.5, Config.PoliceTrackInterval or 4.0) * 1000)
            AlertPolice('Robbery in progress!', GetEntityCoords(PlayerPedId()), false)
        end
    end)
end

function OpenHackNUI(payout, hackType)
    isBusy = true
    hackCode = math.random(Config.MinCode, Config.MaxCode)
    hackAttempts = Config.CodeAttempts

    SetNuiFocus(true, true)
    SetNuiFocusKeepInput(true)
    SetCursorLocation(0.5, 0.5)
    SetGameplayCamRelativeHeading(0.0)

    FreezeEntityPosition(PlayerPedId(), true)
    SendNUIMessage({ action = 'hidePrompt' })

    local isShop = hackType == 'shop'
    local hackTime = isShop and Config.ShopHackTime or Config.HackTime
    local minPayout = isShop and Config.ShopPayoutMin or Config.MinPayout
    local maxPayout = isShop and Config.ShopPayoutMax or Config.MaxPayout

    SendNUIMessage({
        action = 'openBoot',
        type = hackType,
        code = hackCode,
        attempts = hackAttempts,
        hackTime = hackTime,
        codeLength = Config.CodeLength,
        minPayout = minPayout,
        maxPayout = maxPayout,
        payout = payout,
        bootTime = Config.BootTime,
    })
end

function OpenLockNUI(hackType, waitTime)
    isBusy = true

    SetNuiFocus(true, true)
    SetNuiFocusKeepInput(true)
    SetCursorLocation(0.5, 0.5)
    SetGameplayCamRelativeHeading(0.0)
    FreezeEntityPosition(PlayerPedId(), true)
    SendNUIMessage({ action = 'hidePrompt' })

    SendNUIMessage({
        action = 'openLock',
        type = hackType,
        waitTime = math.ceil(waitTime),
    })
end

RegisterNUICallback('lockDone', function(_, cb)
    cb('ok')
    if not isBusy then return end
    local coords = GetEntityCoords(currentATM)
    local cbName = currentType == 'shop' and 'lb-bankrobbery:server:ShopCanRob' or 'lb-bankrobbery:server:CanRob'
    QBCore.Functions.TriggerCallback(cbName, function(canRob, payout)
        if not isBusy then return end
        if canRob then
            StartHack(payout, currentType)
        elseif payout and payout > 0 then
            OpenLockNUI(currentType, payout)
        else
            CloseNUI()
        end
    end, coords)
end)

RegisterNUICallback('hackSuccess', function(_, cb)
    cb('ok')
    CloseNUI()
    local coords = GetEntityCoords(currentATM)
    if currentType == 'shop' then
        TriggerServerEvent('lb-bankrobbery:server:ShopRobberySuccess', coords)
    else
        TriggerServerEvent('lb-bankrobbery:server:RobberySuccess', coords)
    end
end)

RegisterNUICallback('hackFail', function(_, cb)
    cb('ok')
    CloseNUI()
    QBCore.Functions.Notify('Hack failed! The ATM is locked down.', 'error', 5000)
    if Config.WantedLevel > 0 then
        SetPlayerWantedLevel(PlayerId(), Config.WantedLevel, false)
        SetPlayerWantedLevelNow(PlayerId(), false)
    end
end)

RegisterNUICallback('hackTimeout', function(_, cb)
    cb('ok')
    CloseNUI()
    QBCore.Functions.Notify('Connection lost... Hack failed.', 'error', 5000)
end)

RegisterNUICallback('closeMenu', function(_, cb)
    cb('ok')
    CloseNUI()
end)

function CloseNUI()
    SetNuiFocus(false, false)
    SetNuiFocusKeepInput(false)
    FreezeEntityPosition(PlayerPedId(), false)
    isBusy = false
end

CreateThread(function()
    local scenarioPlaying = false
    while true do
        if isBusy then
            local ped = PlayerPedId()
            FreezeEntityPosition(ped, true)
            if not scenarioPlaying then
                local scenario = currentType == 'shop' and Config.RobScenarioShop or Config.RobScenarioATM
                TaskStartScenarioInPlace(ped, scenario, 0, true)
                scenarioPlaying = true
            end
            DisableControlAction(0, 1, true)
            DisableControlAction(0, 2, true)
            DisableControlAction(0, 21, true)
            DisableControlAction(0, 22, true)
            DisableControlAction(0, 23, true)
            DisableControlAction(0, 24, true)
            DisableControlAction(0, 25, true)
            DisableControlAction(0, 32, true)
            DisableControlAction(0, 33, true)
            DisableControlAction(0, 34, true)
            DisableControlAction(0, 35, true)
            DisableControlAction(0, 36, true)
            Wait(0)
        else
            local ped = PlayerPedId()
            FreezeEntityPosition(ped, false)
            if scenarioPlaying then
                ClearPedTasksImmediately(ped)
                scenarioPlaying = false
            end
            Wait(500)
        end
    end
end)

RegisterKeyMapping('+closehack', 'Close Hack Menu', 'keyboard', 'ESCAPE')
RegisterCommand('+closehack', function()
    if isBusy then
        CloseNUI()
        SendNUIMessage({ action = 'closeMenu' })
    end
end, false)
