Config = {}

Config.LockpickItem = 'lockpick'
Config.LockpickRemove = true
Config.PayoutType = 'cash'
Config.MinPayout = 500
Config.MaxPayout = 2000
Config.PayoutStep = 500
Config.Cooldown = 300
Config.Distance = 3.0

Config.CodeLength = 4
Config.MinCode = 1000
Config.MaxCode = 9999
Config.CodeAttempts = 3
Config.HackTime = 20

Config.WireCount = 5

Config.NotifyPolice = true
Config.PoliceJobs = { 'police', 'sheriff', 'state' }
Config.WantedLevel = 3
Config.PoliceAlertCoords = true
Config.PoliceCustomBlip = true
Config.PoliceTracking = true
Config.PoliceTrackInterval = 4.0
Config.PoliceAlertDuration = 120

Config.ATMProps = {
    'prop_atm_01',
    'prop_atm_02',
    'prop_atm_03',
    'prop_fleeca_atm',
}

Config.ShopProps = {
    'prop_till_01',
    'prop_till_02',
    'prop_cash_register_01',
}
Config.ShopDistance = 2.5
Config.ShopPayoutMin = 300
Config.ShopPayoutMax = 1500
Config.ShopPayoutStep = 100
Config.ShopCooldown = 600
Config.ShopHackTime = 18

Config.BootTime = 2.5

Config.RobScenarioATM = 'WORLD_HUMAN_WELDING'
Config.RobScenarioShop = 'WORLD_HUMAN_WELDING'
