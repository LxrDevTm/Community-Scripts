let hackCode = 0;
let hackAttempts = 0;
let codeLength = 4;
let hackTime = 20;
let minPayout = 0;
let maxPayout = 0;
let payout = 0;
let hackType = 'code';
let initialAttempts = 3;

let timerInterval = null;
let timeLeft = 0;
let currentDigits = [];
let activeSlot = 0;
let phase = 'idle';

let memSequence = [];
let memStep = 0;
let memPhase = 'idle';
let timingPos = 0;
let timingDir = 1;
let timingHits = 0;
let timingInterval = null;

let hackTypeGlobal = 'atm';
let cipherRound = 1;
let cipherMatched = 0;
let cipherTarget = '';

const ATM_STEPS = ['1 · CODE', '2 · WIRES', '3 · MEMORY', '4 · TIMING', '5 · TRANSFER'];
const SHOP_STEPS = ['1 · PIN', '2 · CIPHER', '3 · TIMING', '4 · CASH OUT'];

const isNUI = typeof GetParentResourceName === 'function';

const $ = (id) => document.getElementById(id);

const ICON_SUCCESS = '<svg width="64" height="64" viewBox="0 0 64 64" fill="none" stroke="currentColor" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"><circle cx="32" cy="32" r="23"></circle><path d="M20 33.5 L28 41.5 L44 24"></path></svg>';
const ICON_FAIL = '<svg width="64" height="64" viewBox="0 0 64 64" fill="none" stroke="currentColor" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"><circle cx="32" cy="32" r="23"></circle><line x1="24" y1="24" x2="40" y2="40"></line><line x1="40" y1="24" x2="24" y2="40"></line></svg>';

window.addEventListener('message', (event) => {
    const data = event.data;
    switch (data.action) {
        case 'openHack':
            startHack(data);
            break;
        case 'openBoot':
            startBoot(data);
            break;
        case 'openLock':
            startLock(data);
            break;
        case 'showPrompt':
            showPrompt(data.type);
            break;
        case 'hidePrompt':
            hidePrompt();
            break;
        case 'closeMenu':
            resetUI();
            break;
    }
});

function sendNUI(callbackName) {
    if (!isNUI) return;
    fetch('https://' + GetParentResourceName() + '/' + callbackName, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json; charset=UTF-8' },
        body: JSON.stringify({}),
    }).catch(() => {});
}

let audioCtx = null;

function ensureAudio() {
    if (!isNUI) return null;
    try {
        if (!audioCtx) {
            const AC = window.AudioContext || window.webkitAudioContext;
            if (!AC) return null;
            audioCtx = new AC();
        }
        if (audioCtx.state === 'suspended') audioCtx.resume();
        return audioCtx;
    } catch (e) {
        return null;
    }
}

function playTone(freq, dur, type, vol, when, slideTo) {
    const ctx = ensureAudio();
    if (!ctx) return;
    const t0 = ctx.currentTime + (when || 0);
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = type || 'square';
    osc.frequency.setValueAtTime(freq, t0);
    if (slideTo) osc.frequency.exponentialRampToValueAtTime(slideTo, t0 + dur);
    gain.gain.setValueAtTime(vol || 0.03, t0);
    gain.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(t0);
    osc.stop(t0 + dur + 0.02);
}

function sndKey()    { playTone(880, 0.05, 'square', 0.025); }
function sndBack()   { playTone(520, 0.05, 'square', 0.02); }
function sndStep()   { playTone(660, 0.06, 'square', 0.03); }
function sndDenied() { playTone(420, 0.07, 'square', 0.03); playTone(300, 0.12, 'sawtooth', 0.03, 0.07, 200); }
function sndSuccess(){ playTone(523, 0.09, 'square', 0.035); playTone(659, 0.09, 'square', 0.035, 0.09); playTone(784, 0.14, 'square', 0.04, 0.18); }
function sndFail()   { playTone(392, 0.12, 'sawtooth', 0.035); playTone(262, 0.16, 'sawtooth', 0.035, 0.12); playTone(196, 0.2, 'sawtooth', 0.03, 0.28); }

function startHack(data) {
    hackTypeGlobal = data.type === 'shop' ? 'shop' : 'atm';
    buildSteps(hackTypeGlobal === 'shop' ? SHOP_STEPS : ATM_STEPS);
    $('sb-left').textContent = hackTypeGlobal === 'shop' ? 'LB-MART//REGISTER' : 'LB-BANK//ATM';

    hackCode = data.code;
    hackAttempts = data.attempts;
    codeLength = data.codeLength;
    hackTime = data.hackTime;
    minPayout = data.minPayout;
    maxPayout = data.maxPayout;
    payout = data.payout;
    initialAttempts = data.attempts;
    currentDigits = [];
    activeSlot = 0;
    phase = 'reveal';

    resetUI();
    buildSteps(hackTypeGlobal === 'shop' ? SHOP_STEPS : ATM_STEPS);
    $('sb-left').textContent = hackTypeGlobal === 'shop' ? 'LB-MART//REGISTER' : 'LB-BANK//ATM';
    $('tablet').classList.remove('hidden');
    $('download').classList.add('hidden');
    $('transfer').classList.add('hidden');
    $('overlay').classList.add('hidden');
    $('statusbar-live').classList.remove('hidden');

    setupAttempts();
    setupPayout();
    $('atm-id').textContent = randomHex(4);
    $('timer').textContent = formatTime(hackTime);
    timeLeft = hackTime;

    $('hack').classList.remove('hidden');
    revealCode();
}

function showPrompt(type) {
    $('prompt-label').textContent = type === 'shop' ? 'ROB REGISTER' : 'HACK ATM';
    $('prompt').classList.remove('hidden');
}

function hidePrompt() {
    $('prompt').classList.add('hidden');
}

function startBoot(data) {
    hackTypeGlobal = data.type === 'shop' ? 'shop' : 'atm';
    resetUI();
    phase = 'boot';

    $('download').classList.remove('hidden');
    $('dl-status').textContent = hackTypeGlobal === 'shop' ? 'ROB REGISTER' : 'HACK ATM';

    const lines = Array.from(document.querySelectorAll('#download .dl-line'));
    lines.forEach((l, i) => {
        l.style.animation = 'none';
        l.style.opacity = '0';
        void l.offsetWidth;
        l.style.animation = 'fadeIn 0.25s forwards';
        l.style.animationDelay = (i * 380) + 'ms';
        playTone(520 + i * 90, 0.06, 'square', 0.025, (i * 0.38));
    });
    playTone(720, 0.08, 'square', 0.03, 0.05);

    const fill = $('dl-fill');
    fill.style.transition = 'none';
    fill.style.width = '0%';
    $('dl-pct').textContent = '0%';
    void fill.offsetWidth;

    const totalMs = Math.max(800, (data.bootTime || 2.5) * 1000);
    const start = Date.now();
    const interval = setInterval(() => {
        const pct = Math.min(100, Math.round(((Date.now() - start) / totalMs) * 100));
        fill.style.transition = 'width 0.09s linear';
        fill.style.width = pct + '%';
        $('dl-pct').textContent = pct + '%';
        if (pct >= 100) {
            clearInterval(interval);
            setTimeout(() => {
                if (phase !== 'boot') return;
                startHack(data);
            }, 350);
        }
    }, 90);
}

function startLock(data) {
    hackTypeGlobal = data.type === 'shop' ? 'shop' : 'atm';
    resetUI();
    phase = 'lock';

    $('tablet').classList.remove('hidden');
    $('lock').classList.remove('hidden');
    $('statusbar-live').classList.add('hidden');
    $('sb-left').textContent = hackTypeGlobal === 'shop' ? 'LB-MART//REGISTER' : 'LB-BANK//ATM';

    const total = Math.max(1, Math.round(data.waitTime || 0));
    let remaining = total;
    const fill = $('lock-fill');
    fill.style.width = '0%';

    function render() {
        const m = Math.floor(remaining / 60);
        const s = remaining % 60;
        $('lock-time').textContent = m + ':' + String(s).padStart(2, '0');
        fill.style.width = ((total - remaining) / total) * 100 + '%';
    }
    render();

    const interval = setInterval(() => {
        remaining--;
        if (remaining <= 0) {
            clearInterval(interval);
            fill.style.width = '100%';
            $('lock-time').textContent = 'READY';
            $('lock-hint').textContent = 'SYSTEM ONLINE';
            sndSuccess();
            setTimeout(() => {
                if (phase !== 'lock') return;
                sendNUI('lockDone');
            }, 700);
        } else {
            render();
        }
    }, 1000);
}

function buildSteps(list) {
    const box = $('steps');
    box.innerHTML = '';
    list.forEach((label, i) => {
        const el = document.createElement('span');
        el.className = 'step';
        el.textContent = label;
        if (i === 0) el.classList.add('active');
        box.appendChild(el);
    });
}

function revealCode() {
    const display = $('code-display');
    display.classList.add('glitch-text');

    let count = 0;
    const scrambleTimer = setInterval(() => {
        if (count < 14) {
            const scrambled = String(hackCode).split('').map((d) =>
                Math.random() < 0.5 ? Math.floor(Math.random() * 10) : d
            ).join('');
            display.textContent = scrambled;
            display.setAttribute('data-text', scrambled);
            count++;
        } else {
            clearInterval(scrambleTimer);
            $('code-input-area').classList.remove('hidden');
            display.textContent = String(hackCode);
            display.setAttribute('data-text', String(hackCode));
            phase = 'input';
            startTimer();
        }
    }, 90);
}

function startTimer() {
    if (timerInterval) clearInterval(timerInterval);
    timeLeft = hackTime;
    const timerEl = $('timer');
    const progress = $('progress');
    progress.style.transition = 'none';
    progress.style.width = '100%';
    requestAnimationFrame(() => { progress.style.transition = 'width 1s linear'; });

    timerInterval = setInterval(() => {
        timeLeft--;
        timerEl.textContent = formatTime(timeLeft);
        progress.style.width = (timeLeft / hackTime) * 100 + '%';

        if (timeLeft <= 10) timerEl.classList.add('low');
        if (timeLeft <= hackTime * 0.3) progress.classList.add('danger');

        if (timeLeft <= 0) {
            clearInterval(timerInterval);
            failHack('TIMEOUT');
        }
    }, 1000);
}

function formatTime(s) {
    const m = Math.floor(s / 60);
    const sec = s % 60;
    return String(m).padStart(2, '0') + ':' + String(sec).padStart(2, '0');
}

const SVGNS = 'http://www.w3.org/2000/svg';
const WIRE_COLORS = ['#e0203a', '#ff465c', '#ff5a6e', '#ffd700', '#ff2b2b'];
let wireList = [];
let selectedWire = null;
let wireCount = 5;

function startWires() {
    phase = 'reveal';
    buildWireBoard();
    setTimeout(() => {
        if (phase !== 'reveal') return;
        phase = 'input';
        startTimer();
    }, 900);
}

function buildWireBoard() {
    const svg = $('wire-svg');
    svg.innerHTML = '';
    wireList = [];
    selectedWire = null;

    const n = wireCount;
    const leftYs = [];
    const rightYs = [];
    const spacing = 290 / (n + 1);
    for (let i = 0; i < n; i++) {
        leftYs.push(spacing * (i + 1));
        rightYs.push(spacing * (i + 1));
    }
    for (let i = rightYs.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        const t = rightYs[i]; rightYs[i] = rightYs[j]; rightYs[j] = t;
    }

    for (let i = 0; i < n; i++) {
        const lx = 22, rx = 338;
        const ly = leftYs[i], ry = rightYs[i];
        const color = WIRE_COLORS[i % WIRE_COLORS.length];
        const cp = 180;

        const path = document.createElementNS(SVGNS, 'path');
        path.setAttribute('d', 'M ' + lx + ' ' + ly + ' C ' + (lx + cp) + ' ' + ly + ', ' + (rx - cp) + ' ' + ry + ', ' + rx + ' ' + ry);
        path.setAttribute('stroke', color);
        path.setAttribute('stroke-width', '4');
        path.setAttribute('fill', 'none');
        path.setAttribute('opacity', '0.28');
        path.classList.add('wire-line');

        const lp = makePin(lx, ly, i, 'left', color);
        const rp = makePin(rx, ry, i, 'right', color);

        wireList.push({ id: i, color, path, lp, rp, done: false });
        svg.appendChild(path);
        svg.appendChild(lp);
        svg.appendChild(rp);
    }
}

function makePin(x, y, i, side, color) {
    const c = document.createElementNS(SVGNS, 'circle');
    c.setAttribute('cx', x);
    c.setAttribute('cy', y);
    c.setAttribute('r', '12');
    c.setAttribute('fill', '#2b0509');
    c.setAttribute('stroke', '#e0203a');
    c.setAttribute('stroke-width', '3');
    c.setAttribute('data-wire', i);
    c.setAttribute('data-side', side);
    c.classList.add('wire-pin');
    c.addEventListener('click', () => onWirePinClick(i, side, c));
    return c;
}

function onWirePinClick(i, side, el) {
    if (phase !== 'input') return;
    const w = wireList[i];
    if (w.done) return;

    if (selectedWire === null) {
        if (side !== 'left') return;
        selectedWire = i;
        w.path.setAttribute('opacity', '1');
        w.lp.setAttribute('stroke', w.color);
        w.lp.classList.add('selected');
    } else if (side === 'left') {
        if (i === selectedWire) return;
        wireList[selectedWire].path.setAttribute('opacity', '0.25');
        wireList[selectedWire].lp.setAttribute('stroke', '#7a0f22');
        wireList[selectedWire].lp.classList.remove('selected');
        selectedWire = i;
        w.path.setAttribute('opacity', '1');
        w.lp.setAttribute('stroke', w.color);
        w.lp.classList.add('selected');
    } else {
        if (i === selectedWire) {
            w.done = true;
            w.path.setAttribute('opacity', '1');
            w.path.setAttribute('stroke-width', '4');
            w.lp.setAttribute('fill', w.color);
            w.lp.setAttribute('stroke', w.color);
            w.lp.classList.remove('selected');
            w.rp.setAttribute('fill', w.color);
            w.rp.setAttribute('stroke', w.color);
            selectedWire = null;
            checkWiresDone();
        } else {
            el.classList.add('wrong');
            setTimeout(() => el.classList.remove('wrong'), 400);
            hackAttempts--;
            setupAttempts();
            if (hackAttempts <= 0) {
                clearInterval(timerInterval);
                setTimeout(() => failHack('FAILED'), 700);
            } else {
                wireList[selectedWire].path.setAttribute('opacity', '0.25');
                wireList[selectedWire].lp.setAttribute('stroke', '#7a0f22');
                wireList[selectedWire].lp.classList.remove('selected');
                selectedWire = null;
            }
        }
    }
}

function checkWiresDone() {
    for (let i = 0; i < wireList.length; i++) {
        if (!wireList[i].done) return;
    }
    clearInterval(timerInterval);
    startMemoryPhase();
}

document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && phase !== 'idle') {
        resetUI();
        sendNUI('closeMenu');
        return;
    }
    if (phase !== 'input') return;

    if (!$('timing').classList.contains('hidden')) {
        if (e.key === 'Enter') tryTimingHit();
        e.preventDefault();
        return;
    }

    if (!$('hack').classList.contains('hidden')) {
        if (e.key >= '0' && e.key <= '9') {
            typeDigit(e.key);
            e.preventDefault();
        } else if (e.key === 'Backspace') {
            backspace();
            e.preventDefault();
        } else if (e.key === 'Enter') {
            submitCode();
            e.preventDefault();
        }
    }
});

function typeDigit(d) {
    if (activeSlot >= codeLength) return;
    currentDigits.push(d);
    renderDigits();
    sndKey();
    activeSlot++;
    if (activeSlot === codeLength) {
        setTimeout(submitCode, 300);
    }
}

function backspace() {
    if (activeSlot <= 0) return;
    currentDigits.pop();
    activeSlot--;
    renderDigits();
    sndBack();
}

function renderDigits() {
    const container = $('code-input');
    container.innerHTML = '';
    for (let i = 0; i < codeLength; i++) {
        const el = document.createElement('span');
        el.classList.add('digit');
        if (i < currentDigits.length) {
            el.textContent = currentDigits[i];
            el.classList.add('filled');
        } else if (i === activeSlot) {
            el.textContent = '_';
            el.classList.add('active');
        } else {
            el.textContent = '_';
        }
        container.appendChild(el);
    }
}

function submitCode() {
    if (phase !== 'input') return;
    phase = 'checking';

    const input = parseInt(currentDigits.join(''), 10);
    const feedback = $('feedback');
    feedback.classList.remove('hidden');

    if (input === hackCode) {
        clearInterval(timerInterval);
        feedbackText('CORRECT', 'correct');
        setTimeout(() => {
            if (hackTypeGlobal === 'shop') startCipherPhase();
            else startWiresPhase();
        }, 700);
    } else {
        hackAttempts--;
        feedbackText('WRONG CODE', 'wrong');
        setupAttempts();

        if (hackAttempts <= 0) {
            clearInterval(timerInterval);
            setTimeout(() => failHack('FAILED'), 1100);
        } else {
            setTimeout(() => {
                currentDigits = [];
                activeSlot = 0;
                phase = 'input';
                renderDigits();
                feedback.classList.add('hidden');
            }, 1200);
        }
    }
}

function feedbackText(txt, cls) {
    const el = $('feedback-text');
    el.textContent = txt;
    el.setAttribute('data-text', txt);
    el.className = cls;
    $('feedback').classList.remove('hidden');
}

const VIEW_IDS = ['hack', 'wires', 'cipher', 'memory', 'timing', 'transfer'];

function viewStep(viewId) {
    if (hackTypeGlobal === 'shop') {
        return { hack: 0, cipher: 1, timing: 2, transfer: 3 }[viewId];
    }
    return { hack: 0, wires: 1, memory: 2, timing: 3, transfer: 4 }[viewId];
}

function switchView(showId) {
    VIEW_IDS.forEach((id) => {
        const el = $(id);
        if (el) el.classList.toggle('hidden', id !== showId);
    });
    setStep(viewStep(showId));
    sndStep();
}

function setStep(idx) {
    const steps = document.querySelectorAll('.step');
    steps.forEach((el, i) => {
        el.classList.toggle('active', i === idx);
        el.classList.toggle('done', i < idx);
    });
}

function startWiresPhase() {
    phase = 'reveal';
    switchView('wires');
    hackAttempts = initialAttempts;
    setupAttempts();
    startWires();
}

const MEM_COLORS = ['#e0203a', '#ffd700', '#ff5a6e', '#8f1628'];

function startMemoryPhase() {
    phase = 'reveal';
    switchView('memory');
    buildMemorySequence();
}

function buildMemorySequence() {
    const len = 4 + Math.floor(Math.random() * 2);
    memSequence = [];
    for (let i = 0; i < len; i++) memSequence.push(Math.floor(Math.random() * 4));
    memStep = 0;
    memPhase = 'show';

    const panels = document.querySelectorAll('.mem-panel');
    panels.forEach((p, i) => p.style.setProperty('--pc', MEM_COLORS[i]));

    $('mem-status').textContent = 'WATCH THE SEQUENCE...';

    let delay = 500;
    memSequence.forEach((idx) => {
        setTimeout(() => flashMemPanel(idx), delay);
        delay += 600;
    });
    setTimeout(() => {
        if (phase !== 'reveal') return;
        memPhase = 'input';
        phase = 'input';
        $('mem-status').textContent = 'REPEAT IT — 0/' + memSequence.length;
        startTimer();
    }, delay + 300);
}

function flashMemPanel(idx) {
    const panel = document.querySelector('.mem-panel[data-panel="' + idx + '"]');
    panel.classList.add('lit');
    setTimeout(() => panel.classList.remove('lit'), 320);
}

function onMemPanelClick(idx) {
    if (phase !== 'input' || memPhase !== 'input') return;
    flashMemPanel(idx);

    if (idx === memSequence[memStep]) {
        memStep++;
        $('mem-status').textContent = 'REPEAT IT — ' + memStep + '/' + memSequence.length;
        if (memStep >= memSequence.length) {
            phase = 'done';
            clearInterval(timerInterval);
            setTimeout(startTimingPhase, 500);
        }
    } else {
        memStep = 0;
        hackAttempts--;
        setupAttempts();
        $('mem-status').textContent = 'MISMATCH — RETRY';
        if (hackAttempts <= 0) {
            clearInterval(timerInterval);
            setTimeout(() => failHack('FAILED'), 700);
        } else {
            setTimeout(() => {
                if (phase === 'input') $('mem-status').textContent = 'REPEAT IT — 0/' + memSequence.length;
            }, 900);
        }
    }
}

const TIMING_ZONE_L = 38;
const TIMING_ZONE_R = 62;
const TIMING_HITS_NEEDED = 3;

function startTimingPhase() {
    phase = 'reveal';
    switchView('timing');
    timingPos = 0;
    timingDir = 1;
    timingHits = 0;
    updateTimingHits();
    timingInterval = setInterval(() => {
        timingPos += timingDir * 2.2;
        if (timingPos >= 100) { timingPos = 100; timingDir = -1; }
        if (timingPos <= 0) { timingPos = 0; timingDir = 1; }
        $('time-cursor').style.left = timingPos + '%';
    }, 16);
    setTimeout(() => {
        if (phase !== 'reveal') return;
        phase = 'input';
        startTimer();
    }, 1000);
}

function updateTimingHits() {
    $('time-hits').textContent = 'ALIGNMENT ' + timingHits + '/' + TIMING_HITS_NEEDED;
}

function tryTimingHit() {
    if (phase !== 'input') return;
    const cursor = $('time-cursor');
    if (timingPos >= TIMING_ZONE_L && timingPos <= TIMING_ZONE_R) {
        timingHits++;
        updateTimingHits();
        cursor.style.background = '#ffd700';
        cursor.style.boxShadow = '0 0 16px #ffd700, 0 0 34px rgba(255, 215, 0, 0.8)';
        setTimeout(() => {
            cursor.style.background = '#fff';
            cursor.style.boxShadow = '0 0 12px #fff, 0 0 28px var(--burg)';
        }, 250);
        if (timingHits >= TIMING_HITS_NEEDED) {
            clearInterval(timingInterval);
            clearInterval(timerInterval);
            phase = 'done';
            setTimeout(startTransfer, 500);
        }
    } else {
        hackAttempts--;
        setupAttempts();
        cursor.classList.add('miss');
        setTimeout(() => cursor.classList.remove('miss'), 300);
        if (hackAttempts <= 0) {
            clearInterval(timingInterval);
            clearInterval(timerInterval);
            setTimeout(() => failHack('FAILED'), 700);
        }
    }
}

const CIPHER_SYMBOLS = ['▲', '●', '■', '◆', '✚', '✕', '⬢', '◐'];
const CIPHER_ROUNDS = 3;

function startCipherPhase() {
    phase = 'reveal';
    switchView('cipher');
    cipherRound = 1;
    buildCipher();
    setTimeout(() => {
        if (phase !== 'reveal') return;
        phase = 'input';
        startTimer();
    }, 900);
}

function buildCipher() {
    cipherMatched = 0;
    cipherTarget = CIPHER_SYMBOLS[Math.floor(Math.random() * CIPHER_SYMBOLS.length)];
    $('cipher-target').textContent = cipherTarget;

    const grid = $('cipher-grid');
    grid.innerHTML = '';
    const cells = [];
    for (let i = 0; i < 9; i++) {
        if (i < 4) {
            cells.push(cipherTarget);
        } else {
            let sym;
            do { sym = CIPHER_SYMBOLS[Math.floor(Math.random() * CIPHER_SYMBOLS.length)]; } while (sym === cipherTarget);
            cells.push(sym);
        }
    }
    for (let i = cells.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        const t = cells[i]; cells[i] = cells[j]; cells[j] = t;
    }
    cells.forEach((sym) => {
        const el = document.createElement('div');
        el.className = 'cipher-cell';
        el.textContent = sym;
        el.addEventListener('click', () => onCipherClick(el));
        grid.appendChild(el);
    });
    $('cipher-status').textContent = 'ROUND ' + cipherRound + '/' + CIPHER_ROUNDS;
}

function onCipherClick(el) {
    if (phase !== 'input') return;
    if (el.classList.contains('matched')) return;

    if (el.textContent === cipherTarget) {
        el.classList.add('matched');
        cipherMatched++;
        if (cipherMatched >= 4) {
            cipherRound++;
            if (cipherRound > CIPHER_ROUNDS) {
                phase = 'done';
                clearInterval(timerInterval);
                setTimeout(startTimingPhase, 500);
            } else {
                phase = 'reveal';
                buildCipher();
                setTimeout(() => {
                    if (phase !== 'reveal') return;
                    phase = 'input';
                    startTimer();
                }, 700);
            }
        }
    } else {
        if (el.classList.contains('wrong')) return;
        el.classList.add('wrong');
        setTimeout(() => el.classList.remove('wrong'), 400);
        hackAttempts--;
        setupAttempts();
        if (hackAttempts <= 0) {
            clearInterval(timerInterval);
            setTimeout(() => failHack('FAILED'), 700);
        }
    }
}

function startTransfer() {
    phase = 'transfer';
    switchView('transfer');

    const fill = $('transferfill');
    fill.style.width = '0%';
    let pct = 0;
    const transferTimer = setInterval(() => {
        pct += Math.random() * 6 + 3;
        fill.style.width = Math.min(pct, 100) + '%';
        if (pct >= 100) {
            clearInterval(transferTimer);
            setTimeout(() => successHack(), 400);
        }
    }, 120);
}

function setupAttempts() {
    $('attempts').textContent = '•'.repeat(Math.max(0, hackAttempts)) + '·'.repeat(Math.max(0, 3 - hackAttempts));
}

function setupPayout() {
    $('payout').textContent = '$' + formatMoney(payout);
}

function formatMoney(n) {
    return n.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}

function successHack() {
    phase = 'done';
    sndSuccess();
    showOverlay('success', payout);
    sendNUI('hackSuccess');
    setTimeout(resetUI, 2200);
}

function failHack(reason) {
    phase = 'done';
    sndFail();
    if (reason === 'TIMEOUT') {
        sendNUI('hackTimeout');
        setTimeout(resetUI, 900);
    } else {
        showOverlay('fail', 0);
        setTimeout(() => sendNUI('hackFail'), 1600);
        setTimeout(resetUI, 2600);
    }
}

function showOverlay(type, amount) {
    const overlay = $('overlay');
    overlay.classList.remove('hidden');
    overlay.classList.toggle('fail', type === 'fail');
    $('overlay-title').textContent = type === 'success' ? 'ACCESS GRANTED' : 'ACCESS DENIED';
    $('overlay-title').setAttribute('data-text', type === 'success' ? 'ACCESS GRANTED' : 'ACCESS DENIED');
    $('overlay-sub').textContent = type === 'success' ? 'TRANSFER COMPLETE' : 'SECURITY PROTOCOL ENGAGED';
    $('overlay-amount').textContent = type === 'success' ? '+$' + formatMoney(amount) : 'SIGNAL LOST';
    $('overlay-amount').setAttribute('data-text', $('overlay-amount').textContent);
    $('overlay-icon').innerHTML = type === 'success' ? ICON_SUCCESS : ICON_FAIL;
}

function resetUI() {
    if (timerInterval) clearInterval(timerInterval);
    if (timingInterval) clearInterval(timingInterval);
    $('tablet').classList.add('hidden');
    $('download').classList.add('hidden');
    $('lock').classList.add('hidden');
    $('hack').classList.add('hidden');
    $('wires').classList.add('hidden');
    $('cipher').classList.add('hidden');
    $('memory').classList.add('hidden');
    $('timing').classList.add('hidden');
    $('transfer').classList.add('hidden');
    $('overlay').classList.add('hidden');
    $('code-input-area').classList.add('hidden');
    $('feedback').classList.add('hidden');
    $('statusbar-live').classList.add('hidden');
    currentDigits = [];
    activeSlot = 0;
    memSequence = [];
    memStep = 0;
    memPhase = 'idle';
    timingHits = 0;
    cipherRound = 1;
    cipherMatched = 0;
    phase = 'idle';
    buildSteps(hackTypeGlobal === 'shop' ? SHOP_STEPS : ATM_STEPS);
}

function randomHex(len) {
    let s = '';
    for (let i = 0; i < len; i++) s += Math.floor(Math.random() * 16).toString(16).toUpperCase();
    return s;
}

document.querySelectorAll('.mem-panel').forEach((p) => {
    p.addEventListener('click', () => onMemPanelClick(parseInt(p.getAttribute('data-panel'), 10)));
});
$('time-track').addEventListener('click', tryTimingHit);

const tablet = $('tablet');

function makeTestData() {
    const isShop = window.__forceType === 'shop';
    return {
        type: window.__forceType || 'atm',
        code: Math.floor(1000 + Math.random() * 9000),
        attempts: 3,
        codeLength: 4,
        hackTime: isShop ? 18 : 20,
        minPayout: isShop ? 300 : 500,
        maxPayout: isShop ? 1500 : 2000,
        payout: isShop ? (Math.floor(Math.random() * 13) + 3) * 100 : (Math.floor(Math.random() * 4) + 1) * 500,
        bootTime: 2.5,
    };
}

['keydown', 'mousedown', 'touchstart'].forEach((evt) => {
    document.addEventListener(evt, () => {
        const c = ensureAudio();
        if (c) c.resume();
    });
});

if (!isNUI) {
    setTimeout(() => {
        if (window.__forceLock) {
            startLock({ type: window.__forceType || 'atm', waitTime: window.__forceLock });
        } else {
            startBoot(makeTestData());
        }
    }, 400);
    document.addEventListener('click', () => {
        if (phase === 'done' || phase === 'idle') {
            if (window.__forceLock) {
                startLock({ type: window.__forceType || 'atm', waitTime: window.__forceLock });
            } else {
                startBoot(makeTestData());
            }
        }
    });

    const badge = document.createElement('div');
    badge.textContent = 'PREVIEW MODE — ESC to close, click to restart';
    badge.style.cssText = 'position:fixed;bottom:12px;left:50%;transform:translateX(-50%);' +
        'background:rgba(0,0,0,0.75);color:#ff465c;font:11px monospace;letter-spacing:1px;' +
        'padding:6px 14px;border:1px solid #e0203a;border-radius:6px;z-index:99;';
    document.body.appendChild(badge);
}
