local QBCore = exports['qb-core']:GetCoreObject()

local atmCooldowns = {}
local shopCooldowns = {}
local pendingPayouts = {}

QBCore.Functions.CreateCallback('lb-bankrobbery:server:CanRob', function(source, cb, atmCoords)
    local key = json.encode(atmCoords)
    local now = os.time()
    if atmCooldowns[key] and atmCooldowns[key] > now then
        cb(false, atmCooldowns[key] - now)
    else
        local step = Config.PayoutStep or 500
        local minSteps = math.max(1, math.ceil(Config.MinPayout / step))
        local maxSteps = math.max(minSteps, math.floor(Config.MaxPayout / step))
        local payout = math.random(minSteps, maxSteps) * step
        pendingPayouts[source] = payout
        cb(true, payout)
    end
end)

QBCore.Functions.CreateCallback('lb-bankrobbery:server:ShopCanRob', function(source, cb, shopCoords)
    local key = json.encode(shopCoords)
    local now = os.time()
    if shopCooldowns[key] and shopCooldowns[key] > now then
        cb(false, shopCooldowns[key] - now)
    else
        local step = Config.ShopPayoutStep or 100
        local minSteps = math.max(1, math.ceil(Config.ShopPayoutMin / step))
        local maxSteps = math.max(minSteps, math.floor(Config.ShopPayoutMax / step))
        local payout = math.random(minSteps, maxSteps) * step
        pendingPayouts[source] = payout
        cb(true, payout)
    end
end)

RegisterNetEvent('lb-bankrobbery:server:PoliceAlert', function(msg, coords, notify)
    local src = source
    if notify == nil then notify = true end

    local function IsPolice(playerData)
        local job = playerData.job or {}
        for _, j in pairs(Config.PoliceJobs) do
            if job.name == j or job.type == 'leo' or job.type == 'police' then
                return true
            end
        end
        return false
    end

    local players = QBCore.Functions.GetQBPlayers and QBCore.Functions.GetQBPlayers() or QBCore.Functions.GetPlayers()
    for _, p in pairs(players) do
        local pSrc, pData
        if type(p) == 'number' then
            pSrc = p
            local Player = QBCore.Functions.GetPlayer(p)
            if not Player then pData = nil else pData = Player.PlayerData end
        else
            pSrc = p.PlayerData.source or p.source
            pData = p.PlayerData
        end
        if pSrc and pData and IsPolice(pData) then
            if notify then
                TriggerClientEvent('QBCore:Notify', pSrc, msg, 'error', 5000)
            end
            if coords then
                if Config.PoliceCustomBlip then
                    TriggerClientEvent('lb-bankrobbery:client:PoliceAlertBlip', pSrc, coords, msg, src)
                end
                if Config.PoliceAlertCoords then
                    TriggerClientEvent('qb-policejob:client:AddPoliceAlert', pSrc, {
                        coords = coords,
                        message = msg,
                    })
                end
            end
        end
    end
end)

RegisterNetEvent('lb-bankrobbery:server:RobberySuccess', function(atmCoords)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return end

    local key = json.encode(atmCoords)
    local now = os.time()

    if atmCooldowns[key] and atmCooldowns[key] > now then
        TriggerClientEvent('QBCore:Notify', src, 'This ATM is still locked down!', 'error', 3500)
        return
    end

    local lockpick = Player.Functions.GetItemByName(Config.LockpickItem)
    if not lockpick then
        TriggerClientEvent('QBCore:Notify', src, 'You need a ' .. Config.LockpickItem .. '!', 'error', 3500)
        return
    end
    if Config.LockpickRemove then
        Player.Functions.RemoveItem(Config.LockpickItem, 1)
    end

    local payout = pendingPayouts[src]
    if not payout then
        local step = Config.PayoutStep or 500
        local minSteps = math.max(1, math.ceil(Config.MinPayout / step))
        local maxSteps = math.max(minSteps, math.floor(Config.MaxPayout / step))
        payout = math.random(minSteps, maxSteps) * step
    end
    pendingPayouts[src] = nil
    Player.Functions.AddMoney(Config.PayoutType, payout)

    atmCooldowns[key] = now + Config.Cooldown

    TriggerClientEvent('QBCore:Notify', src, ('Robbery successful! +$%s sent to your %s'):format(tostring(payout), Config.PayoutType), 'success', 5000)

    print(('[lb-bankrobbery] %s robbed an ATM and got $%d'):format(Player.PlayerData.name, payout))
end)

RegisterNetEvent('lb-bankrobbery:server:ShopRobberySuccess', function(shopCoords)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return end

    local key = json.encode(shopCoords)
    local now = os.time()

    if shopCooldowns[key] and shopCooldowns[key] > now then
        TriggerClientEvent('QBCore:Notify', src, 'This register is still locked down!', 'error', 3500)
        return
    end

    local lockpick = Player.Functions.GetItemByName(Config.LockpickItem)
    if not lockpick then
        TriggerClientEvent('QBCore:Notify', src, 'You need a ' .. Config.LockpickItem .. '!', 'error', 3500)
        return
    end
    if Config.LockpickRemove then
        Player.Functions.RemoveItem(Config.LockpickItem, 1)
    end

    local payout = pendingPayouts[src]
    if not payout then
        local step = Config.ShopPayoutStep or 100
        local minSteps = math.max(1, math.ceil(Config.ShopPayoutMin / step))
        local maxSteps = math.max(minSteps, math.floor(Config.ShopPayoutMax / step))
        payout = math.random(minSteps, maxSteps) * step
    end
    pendingPayouts[src] = nil
    Player.Functions.AddMoney(Config.PayoutType, payout)

    shopCooldowns[key] = now + Config.ShopCooldown

    TriggerClientEvent('QBCore:Notify', src, ('Register robbed! +$%s sent to your %s'):format(tostring(payout), Config.PayoutType), 'success', 5000)

    print(('[lb-bankrobbery] %s robbed a shop register and got $%d'):format(Player.PlayerData.name, payout))
end)

RegisterNetEvent('lb-bankrobbery:client:ClearWanted', function()
end)
