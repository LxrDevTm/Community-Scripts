# Aimlab

A FiveM aim trainer with multiple gamemodes and a UI written in Svelte.

TP into a training area and practice your aim against configurable target patterns, basically a mini aimlab built for FiveM.

This was one of my first Svelte projects, so the UI doubled as a way to actually learn the framework.

## Features

- Multiple gamemodes (tracking mode, plus a more erratic "wander" variant)
- Configurable distance, speed, tolerance, and fill/decay rates
- Progress meter that fills while on target and decays when you lose it
- Svelte NUI overlay showing live progress
- Works across ESX, QBCore, and QBox (is not dependant on any framework)
- Restores your position and weapon when a session ends

## Dependencies

[ox_lib](https://github.com/overextended/ox_lib)
[oxmysql](https://github.com/overextended/oxmysql)

## How it works

A session starts, your position gets saved, and you're teleported to the training spot with a target spawned in front of you.

## Showcase
[![UI Showcase](showcases/preview.png)
[![Watch the demo](showcases/video_thumbnail.png)]
<sub>Click to watch on YouTube</sub>

## Status

Ready-to-use script, with potential updates in the future.
