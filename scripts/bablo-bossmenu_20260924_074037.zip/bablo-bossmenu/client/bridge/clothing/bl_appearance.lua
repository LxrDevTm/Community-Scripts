
local KEY = 'bl_appearance'
local RESOURCE = 'bl_appearance'

Clothing:RegisterBridge(KEY, RESOURCE, function()
    function Clothing:GetSkin(ped)
        local skin
        pcall(function()
            skin = exports.bl_appearance:GetPedAppearance(ped or PlayerPedId())
        end)
        return skin
    end

    function Clothing:OpenMenu(cb)
        local ok, err = pcall(function()
            exports.bl_appearance:InitialCreation(function()
                if cb then cb(Clothing:GetSkin(PlayerPedId())) end
            end)
        end)
        if not ok then
            print(("^1[ERROR]^0 BossMenu: %s OpenMenu failed: %s"):format(KEY, tostring(err)))
            if cb then cb(nil) end
        end
    end

    function Clothing:ApplyToPed(ped, skin)
        if not skin or not ped or not DoesEntityExist(ped) then return end
        pcall(function()
            exports.bl_appearance:SetPedAppearance(ped, skin)
        end)
    end
end)
