
local KEY = 'crm-appearance'
local RESOURCE = 'crm-appearance'

Clothing:RegisterBridge(KEY, RESOURCE, function()
    function Clothing:GetSkin(ped)
        local skin
        pcall(function()
            skin = exports['crm-appearance']:crm_get_ped_appearance(ped or PlayerPedId())
        end)
        return skin
    end

    function Clothing:OpenMenu(cb)
        TriggerEvent('crm-appearance:show-creator-menu')
        Clothing.AwaitEditorClose(function()
            return Clothing:GetSkin(PlayerPedId())
        end, cb)
    end

    function Clothing:ApplyToPed(ped, skin)
        if not skin or not ped or not DoesEntityExist(ped) then return end
        pcall(function()
            exports['crm-appearance']:crm_set_ped_appearance(ped, skin)
        end)
    end
end)
