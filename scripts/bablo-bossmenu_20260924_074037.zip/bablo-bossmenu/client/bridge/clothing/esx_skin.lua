
local KEY = 'esx_skin'
local RESOURCE = 'esx_skin'

Clothing:RegisterBridge(KEY, RESOURCE, function()
    function Clothing:GetSkin(_ped)
        local skin
        TriggerEvent('skinchanger:getSkin', function(s) skin = s end)
        local timeout = 500
        while not skin and timeout > 0 do
            Wait(10)
            timeout = timeout - 10
        end
        return skin
    end

    function Clothing:OpenMenu(cb)
        TriggerEvent('esx_skin:openSaveableMenu', function()
            if cb then cb(Clothing:GetSkin()) end
        end, function()
            if cb then cb(nil) end
        end)
    end

    function Clothing:ApplyToPed(ped, skin)
        if not skin or not ped or not DoesEntityExist(ped) then return end
        if ped == PlayerPedId() then
            TriggerEvent('skinchanger:loadSkin', skin)
            return
        end
        Clothing.ApplySkinComponents(ped, skin)
    end
end)
