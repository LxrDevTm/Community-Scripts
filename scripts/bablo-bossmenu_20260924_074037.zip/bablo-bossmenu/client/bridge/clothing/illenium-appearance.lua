
local KEY = 'illenium-appearance'
local RESOURCE = 'illenium-appearance'

Clothing:RegisterBridge(KEY, RESOURCE, function()
    function Clothing:OpenMenu(cb)
        local ok, err = pcall(function()
            exports[RESOURCE]:startPlayerCustomization(function(appearance)
                if cb then cb(appearance) end
            end, Clothing.EditorConfig)
        end)
        if not ok then
            print(("^1[ERROR]^0 BossMenu: %s OpenMenu failed: %s"):format(KEY, tostring(err)))
            if cb then cb(nil) end
        end
    end

    function Clothing:GetSkin(ped)
        local skin
        pcall(function()
            skin = exports[RESOURCE]:getPedAppearance(ped or PlayerPedId())
        end)
        return skin
    end

    function Clothing:ApplyToPed(ped, skin)
        if not skin or not ped or not DoesEntityExist(ped) then return end
        pcall(function()
            exports[RESOURCE]:setPedAppearance(ped, skin)
        end)
    end
end)
