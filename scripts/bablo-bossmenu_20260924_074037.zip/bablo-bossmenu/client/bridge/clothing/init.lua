
Clothing = {}
Clothing.System = nil

Clothing.EditorConfig = {
    ped = false,
    headBlend = false,
    faceFeatures = false,
    headOverlays = false,
    components = true,
    componentConfig = {
        masks = true,
        upperBody = true,
        lowerBody = true,
        bags = true,
        shoes = true,
        scarfAndChains = true,
        bodyArmor = true,
        shirts = true,
        decals = true,
        jackets = true
    },
    props = true,
    propConfig = {
        hats = true,
        glasses = true,
        ear = true,
        watches = true,
        bracelets = true
    },
    tattoos = false,
    enableExit = true,
    automaticFade = true
}

local bridges = {}

function Clothing:RegisterBridge(key, resourceName, registerFn)
    bridges[#bridges + 1] = { key = key, resource = resourceName, register = registerFn }
end

function Clothing:OpenMenu(cb)
    if cb then cb(nil) end
end

function Clothing:GetSkin(_ped)
    return nil
end

function Clothing:ApplyToPed(_ped, _skin)
end

local skinComponentMap = {
    { 'tshirt_1', 'tshirt_2', 8 },
    { 'torso_1', 'torso_2', 11 },
    { 'decals_1', 'decals_2', 10 },
    { 'arms', 'arms_2', 3 },
    { 'pants_1', 'pants_2', 4 },
    { 'shoes_1', 'shoes_2', 6 },
    { 'mask_1', 'mask_2', 1 },
    { 'bproof_1', 'bproof_2', 9 },
    { 'chain_1', 'chain_2', 7 },
    { 'bags_1', 'bags_2', 5 },
    { 'hair_1', 'hair_2', 2 },
}

local skinPropMap = {
    { 'helmet_1', 'helmet_2', 0 },
    { 'glasses_1', 'glasses_2', 1 },
    { 'ears_1', 'ears_2', 2 },
    { 'watches_1', 'watches_2', 6 },
    { 'bracelets_1', 'bracelets_2', 7 },
}

function Clothing.ApplySkinComponents(ped, skin)
    for _, map in ipairs(skinComponentMap) do
        local drawable = skin[map[1]]
        if drawable and drawable >= 0 then
            SetPedComponentVariation(ped, map[3], drawable, skin[map[2]] or 0, 2)
        end
    end
    for _, map in ipairs(skinPropMap) do
        local drawable = skin[map[1]]
        if drawable then
            if drawable == -1 then
                ClearPedProp(ped, map[3])
            else
                SetPedPropIndex(ped, map[3], drawable, skin[map[2]] or 0, true)
            end
        end
    end
end

function Clothing.AwaitEditorClose(getSkin, cb)
    CreateThread(function()
        local openDeadline = GetGameTimer() + 15000
        while not IsNuiFocused() do
            if GetGameTimer() > openDeadline then
                if cb then cb(nil) end
                return
            end
            Wait(100)
        end

        while IsNuiFocused() do
            Wait(200)
        end

        Wait(200)
        if cb then cb(getSkin and getSkin() or nil) end
    end)
end

CreateThread(function()
    Wait(500)

    local want = Settings.Appearance or 'auto'
    local deadline = GetGameTimer() + 15000

    local function isWanted(bridge)
        return (want == 'auto') or (want == bridge.key)
    end

    local function findStarted()
        for i = 1, #bridges do
            local bridge = bridges[i]
            if isWanted(bridge) and GetResourceState(bridge.resource) == 'started' then
                return i, bridge
            end
        end
        return nil, nil
    end

    local function betterStillPossible(idx)
        for i = 1, idx - 1 do
            local bridge = bridges[i]
            if isWanted(bridge) and GetResourceState(bridge.resource) ~= 'missing' then
                return true
            end
        end
        return false
    end

    local function activate(bridge)
        Clothing.System = bridge.key
        bridge.register()
        print(("^2[INFO]^0 BossMenu: Using '%s' for the clothing bridge."):format(bridge.key))
    end

    while GetGameTimer() < deadline do
        local idx, bridge = findStarted()
        if bridge and not betterStillPossible(idx) then
            return activate(bridge)
        end
        Wait(200)
    end

    local _, bridge = findStarted()
    if bridge then
        return activate(bridge)
    end

    print("^3[WARNING]^0 BossMenu: No supported clothing resource detected. Outfits will not work.")
end)
