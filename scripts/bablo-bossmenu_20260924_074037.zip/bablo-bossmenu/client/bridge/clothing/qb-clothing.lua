
local KEY = 'qb-clothing'
local RESOURCE = 'qb-clothing'

Clothing:RegisterBridge(KEY, RESOURCE, function()
    function Clothing:GetSkin(ped)
        local skin
        TriggerEvent('qb-clothing:client:getPlayerClothing', function(data) skin = data end, ped or PlayerPedId())
        local timeout = 1000
        while not skin and timeout > 0 do
            Wait(10)
            timeout = timeout - 10
        end
        return skin
    end

    function Clothing:OpenMenu(cb)
        TriggerEvent('qb-clothes:client:CreateFirstCharacter')
        Clothing.AwaitEditorClose(function()
            return Clothing:GetSkin(PlayerPedId())
        end, cb)
    end

    function Clothing:ApplyToPed(ped, skin)
        if not skin or not ped or not DoesEntityExist(ped) then return end
        TriggerEvent('qb-clothing:client:loadPlayerClothing', skin, ped)
    end
end)
