
local KEY = 'rcore_clothing'
local RESOURCE = 'rcore_clothing'

Clothing:RegisterBridge(KEY, RESOURCE, function()
    function Clothing:GetSkin(_ped)
        local skin
        pcall(function()
            skin = exports['rcore_clothing']:getPlayerSkin(true)
        end)
        return skin
    end

    function Clothing:OpenMenu(cb)
        TriggerEvent('rcore_clothing:openChangingRoom')
        Clothing.AwaitEditorClose(function()
            return Clothing:GetSkin()
        end, cb)
    end

    function Clothing:ApplyToPed(ped, skin)
        if not skin or not ped or not DoesEntityExist(ped) then return end
        pcall(function()
            exports['rcore_clothing']:setPedSkin(ped, skin)
        end)
    end
end)
