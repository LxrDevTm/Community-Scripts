
if GetResourceState('es_extended') ~= 'started' then return end

local ESX = {}
ESX.__index = ESX

function ESX.new()
    local self = setmetatable({}, ESX)
    self.Core = exports['es_extended']:getSharedObject()
    return self
end

function ESX:GetPlayerJob()
    local PlayerData = {}
    if self.Core.GetPlayerData then
        PlayerData = self.Core.GetPlayerData()
    else
        PlayerData = self.Core.PlayerData or {}
    end
    return PlayerData.job or {}
end

function ESX:GetPlayerDetails()
    local PlayerData = {}
    if self.Core.GetPlayerData then
        PlayerData = self.Core.GetPlayerData()
    else
        PlayerData = self.Core.PlayerData or {}
    end
    
    return {
        firstName = PlayerData.firstName or "Unknown",
        lastName = PlayerData.lastName or "Unknown"
    }
end

Framework = ESX.new()
