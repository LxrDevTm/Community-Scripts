
if GetResourceState('qb-core') ~= 'started' then return end
if GetResourceState('qbx_core') == 'started' then return end

local QB = {}
QB.__index = QB

function QB.new()
    local self = setmetatable({}, QB)
    self.Core = exports['qb-core']:GetCoreObject()
    return self
end

function QB:GetPlayerJob()
    local PlayerData = self.Core.Functions.GetPlayerData() or {}
    local job = PlayerData.job or {}
    local level = job.grade and job.grade.level or 0

    local isboss = job.isboss or false
    local shared = self.Core.Shared and self.Core.Shared.Jobs and self.Core.Shared.Jobs[job.name]
    local gradeEntry = shared and shared.grades and (shared.grades[tostring(level)] or shared.grades[level])
    if gradeEntry then
        isboss = gradeEntry.isboss or false
    end

    return {
        name = job.name,
        label = job.label,
        grade = level,
        grade_name = job.grade and job.grade.name or "",
        grade_label = job.grade and job.grade.name or "",
        isboss = isboss
    }
end

function QB:GetPlayerDetails()
    local PlayerData = self.Core.Functions.GetPlayerData() or {}
    local charinfo = PlayerData.charinfo or {}
    return {
        firstName = charinfo.firstname or "Unknown",
        lastName = charinfo.lastname or "Unknown"
    }
end

Framework = QB.new()

RegisterNetEvent('QBCore:Client:OnSharedUpdate', function(tableName)
    if tableName ~= 'Jobs' or not Framework or not Framework.Core or not Framework.Core.Shared then return end
    local ok, jobs = pcall(function() return exports['qb-core']:GetSharedJobs() end)
    if ok and type(jobs) == 'table' then Framework.Core.Shared.Jobs = jobs end
end)

RegisterNetEvent('QBCore:Client:OnSharedUpdateMultiple', function(tableName)
    if tableName ~= 'Jobs' or not Framework or not Framework.Core or not Framework.Core.Shared then return end
    local ok, jobs = pcall(function() return exports['qb-core']:GetSharedJobs() end)
    if ok and type(jobs) == 'table' then Framework.Core.Shared.Jobs = jobs end
end)
