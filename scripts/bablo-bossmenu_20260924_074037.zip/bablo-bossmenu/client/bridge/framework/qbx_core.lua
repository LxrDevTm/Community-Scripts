
if GetResourceState('qbx_core') ~= 'started' then return end

local QBX = {}
QBX.__index = QBX

function QBX.new()
    return setmetatable({}, QBX)
end

local function playerData()
    local ok, data = pcall(function()
        return exports.qbx_core:GetPlayerData()
    end)
    if ok and type(data) == 'table' then return data end
    return {}
end

function QBX:GetPlayerJob()
    local PlayerData = playerData()
    local job = PlayerData.job or {}
    local level = job.grade and job.grade.level or 0

    local isboss = job.isboss or false
    local ok, jobs = pcall(function()
        return exports.qbx_core:GetJobs()
    end)
    local shared = ok and type(jobs) == 'table' and jobs[job.name] or nil
    local gradeEntry = shared and shared.grades and (shared.grades[level] or shared.grades[tostring(level)])
    if gradeEntry then
        isboss = gradeEntry.isboss or false
    end

    return {
        name = job.name,
        label = job.label,
        grade = level,
        grade_name = job.grade and job.grade.name or "",
        grade_label = job.grade and job.grade.name or "",
        isboss = isboss
    }
end

function QBX:GetPlayerDetails()
    local PlayerData = playerData()
    local charinfo = PlayerData.charinfo or {}
    return {
        firstName = charinfo.firstname or "Unknown",
        lastName = charinfo.lastname or "Unknown"
    }
end

Framework = QBX.new()
