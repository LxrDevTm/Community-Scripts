
if GetResourceState('es_extended') ~= 'started' then return end

local ESX = exports['es_extended']:getSharedObject()

Notify = {}

function Notify:Show(msg, type)
    ESX.ShowNotification(msg)
end
