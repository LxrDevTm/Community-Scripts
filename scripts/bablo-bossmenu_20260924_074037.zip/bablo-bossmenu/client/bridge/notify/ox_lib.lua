
if GetResourceState('ox_lib') ~= 'started' then return end

Notify = {}

function Notify:Show(msg, type)
    if type == nil then type = 'inform' end
    lib.notify({description = msg, type = type})
end
