
if GetResourceState('qb-core') ~= 'started' then return end
if GetResourceState('qbx_core') == 'started' then return end

Notify = {}

function Notify:Show(msg, type)
    if type == nil then type = 'primary' end
    TriggerEvent('QBCore:Notify', msg, type)
end
