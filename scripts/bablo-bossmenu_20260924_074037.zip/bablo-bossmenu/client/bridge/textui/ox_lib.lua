
if GetResourceState('ox_lib') ~= 'started' then return end

TextUI = {}

function TextUI:Show(text)
    lib.showTextUI(text)
end

function TextUI:Hide()
    lib.hideTextUI()
end
