
if GetResourceState('qb-core') ~= 'started' then return end
if GetResourceState('qbx_core') == 'started' then return end

TextUI = {}

function TextUI:Show(text)
    exports['qb-core']:DrawText(text)
end

function TextUI:Hide()
    exports['qb-core']:HideText()
end
