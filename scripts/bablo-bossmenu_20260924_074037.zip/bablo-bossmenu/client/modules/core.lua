-- Load and push the active locale to the NUI frontend.
-- Reads the ox:locale convar, tries to load that locale file, then falls back to en.json.
local function pushLocale()
    local lang         = GetConvar("ox:locale", "en")
    local resourceName = GetCurrentResourceName()
    local raw          = LoadResourceFile(resourceName, ("locales/%s.json"):format(lang))
                      or LoadResourceFile(resourceName, "locales/en.json")
    if not raw then return end

    local ok, data = pcall(json.decode, raw)
    if ok and type(data) == "table" and type(data.ui) == "table" then
        SendNUIMessage({ action = "setLocale", data = data.ui })
    end
end

-- ─── Net events ───────────────────────────────────────────────────────────────

RegisterNetEvent("bablo-bossmenu:client:openCreator")
AddEventHandler("bablo-bossmenu:client:openCreator", function()
    pushLocale()
    SendNUIMessage({ action = "setAppMode", data = "creator" })
    SetNuiFocus(true, true)
    SendNUIMessage({ action = "setVisible",  data = true })
end)

RegisterNetEvent("bablo-bossmenu:client:syncBossMenus")
AddEventHandler("bablo-bossmenu:client:syncBossMenus", function(menus)
    Spawner.LoadBossMenus(menus)
    SendNUIMessage({ action = "syncBossMenus", data = menus })
end)

RegisterNetEvent("bablo-bossmenu:client:syncBossMenu")
AddEventHandler("bablo-bossmenu:client:syncBossMenu", function(jobDesc)
    if not (jobDesc and jobDesc.name) then return end
    Spawner.LoadJob(jobDesc)
    SendNUIMessage({ action = "syncBossMenu", data = jobDesc })
end)

RegisterNetEvent("bablo-bossmenu:client:removeBossMenu")
AddEventHandler("bablo-bossmenu:client:removeBossMenu", function(jobName)
    if not jobName then return end
    Spawner.RemoveJob(jobName)
    SendNUIMessage({ action = "removeBossMenu", data = jobName })
end)

-- ─── Local openMenu event ─────────────────────────────────────────────────────

AddEventHandler("bablo-bossmenu:client:openMenu", function(menuData)
    if not (menuData and menuData.type) then return end

    -- Stash requests go straight to the server.
    if menuData.type == "stash" then
        TriggerServerEvent("bablo-bossmenu:server:openStash", menuData.job, menuData.locationId)
        return
    end

    pushLocale()

    -- Determine the UI mode: "boss" or "wardrobe".
    local appMode = (menuData.type == "wardrobe") and "wardrobe" or "boss"

    -- Build the MenuPreviewSpot if the location has dedicated preview coords.
    MenuPreviewSpot = nil
    if menuData.previewDedicated and menuData.previewCoords then
        MenuPreviewSpot = { coords = menuData.previewCoords, heading = menuData.previewHeading }
    end

    -- Resolve the player's current job from the framework.
    local playerJob = {}
    if Framework and Framework.GetPlayerJob then
        playerJob = Framework:GetPlayerJob() or {}
    end

    -- Resolve the player's display details.
    local playerDetails = {}
    if Framework and Framework.GetPlayerDetails then
        playerDetails = Framework:GetPlayerDetails() or {}
    end

    SendNUIMessage({ action = "setAppMode", data = appMode })

    -- Build and send the combined player-job payload.
    SendNUIMessage({
        action = "setPlayerJob",
        data   = {
            name       = playerJob.name  or menuData.job,
            grade      = playerJob.grade or 0,
            gradeLabel = playerJob.grade_label or playerJob.grade_name or "",
            firstName  = playerDetails.firstName or "Unknown",
            lastName   = playerDetails.lastName  or "Unknown",
            isboss     = playerJob.isboss or false,
        },
    })

    -- Send preview location data (or nil to clear it).
    if menuData.previewCoords then
        SendNUIMessage({
            action = "setCurrentLocation",
            data   = {
                previewCoords  = menuData.previewCoords,
                previewHeading = menuData.previewHeading,
            },
        })
    else
        SendNUIMessage({ action = "setCurrentLocation", data = nil })
    end

    SetNuiFocus(true, true)
    SendNUIMessage({ action = "setVisible", data = true })
end)

-- ─── Legacy stash compatibility ───────────────────────────────────────────────

RegisterNetEvent("bablo-bossmenu:client:openLegacyStash")
AddEventHandler("bablo-bossmenu:client:openLegacyStash", function(stashId, stashConfig)
    local cfg = stashConfig or {}

    -- codem-inventory path.
    if cfg.kind == "codem" then
        TriggerServerEvent("codem-inventory:server:openstash",
            stashId,
            cfg.slots     or 100,
            cfg.maxweight or 2000000,
            cfg.label     or stashId)
        return
    end

    -- Default ox_inventory / qb-inventory path.
    TriggerEvent("inventory:client:SetCurrentStash", stashId)
    TriggerServerEvent("inventory:server:OpenInventory", "stash", stashId, {
        maxweight = cfg.maxweight or 2000000,
        slots     = cfg.slots    or 100,
    })
end)

-- ─── Boot ─────────────────────────────────────────────────────────────────────

-- On resource start: push locale then fetch and load all existing boss menus.
CreateThread(function()
    Wait(2000)
    pushLocale()
    local menus = lib.callback.await("bablo-bossmenu:server:getBossMenus", false)
    if menus then Spawner.LoadBossMenus(menus) end
end)
