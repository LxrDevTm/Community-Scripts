-- Shared helper: await a server callback and return the result directly.
local function awaitCallback(name, ...)
    return lib.callback.await(name, false, ...)
end

-- ─── Utility ──────────────────────────────────────────────────────────────────

RegisterNUICallback("getCurrentCoords", function(data, cb)
    local ped     = PlayerPedId()
    local coords  = GetEntityCoords(ped)
    local heading = GetEntityHeading(ped)
    cb({ x = coords.x, y = coords.y, z = coords.z, h = heading })
end)

RegisterNUICallback("playSound", function(data, cb)
    PlaySoundFrontend(-1, "NAV_UP_DOWN", "HUD_FRONTEND_DEFAULT_SOUNDSET", true)
    cb({})
end)

RegisterNUICallback("hideUI", function(data, cb)
    Preview:Close()
    SetNuiFocus(false, false)
    SendNUIMessage({ action = "setVisible", data = false })
    cb({})
end)

-- ─── Preview / outfit ─────────────────────────────────────────────────────────

RegisterNUICallback("previewOutfit", function(data, cb)
    print("[BossMenu] previewOutfit callback received")
    if data then
        Preview:Show(data.rect, data.skin, data.type, data.previewCoords, data.previewHeading)
    end
    cb({})
end)

RegisterNUICallback("closeOutfitPreview", function(data, cb)
    Preview:Close()
    cb({})
end)

-- Open the clothing editor to create a new outfit.
-- Saves the player's current position, optionally teleports to MenuPreviewSpot,
-- opens Clothing.OpenMenu, then returns the player and re-opens the NUI on close.
RegisterNUICallback("startOutfitCreation", function(data, cb)
    local outfitName    = data and data.name
    local allowedGrades = data and data.allowedGrades

    cb({ ok = true })  -- acknowledge immediately so the NUI can update

    CreateThread(function()
        local ped          = PlayerPedId()
        local originalSkin = Clothing:GetSkin(ped)
        local originalPos  = GetEntityCoords(ped)
        local originalHead = GetEntityHeading(ped)

        SetNuiFocus(false, false)
        SetNuiFocusKeepInput(false)
        SendNUIMessage({ action = "setVisible", data = false })

        -- Teleport to the dedicated preview spot if one is configured.
        local didTeleport = false
        if MenuPreviewSpot and MenuPreviewSpot.coords then
            didTeleport = true
            DoScreenFadeOut(300)
            while not IsScreenFadedOut() do Wait(10) end

            SetEntityCoords(ped,
                MenuPreviewSpot.coords.x,
                MenuPreviewSpot.coords.y,
                MenuPreviewSpot.coords.z + 1.0,
                false, false, false, false)
            SetEntityHeading(ped, tonumber(MenuPreviewSpot.heading) or originalHead)

            Wait(300)
            DoScreenFadeIn(300)
        end

        Wait(500)

        -- Open the clothing editor. The callback fires when the player closes it.
        Clothing:OpenMenu(function(newSkin)
            local ped2 = PlayerPedId()

            DoScreenFadeOut(300)
            while not IsScreenFadedOut() do Wait(10) end

            -- Restore the original skin onto the ped.
            Clothing:ApplyToPed(ped2, originalSkin)

            -- Return the player to their original position if we teleported them.
            if didTeleport then
                SetEntityCoords(ped2,
                    originalPos.x, originalPos.y, originalPos.z,
                    false, false, false, false)
                SetEntityHeading(ped2, originalHead)
            end

            Wait(400)
            -- Re-apply original skin (in case the position change reset it).
            Clothing:ApplyToPed(PlayerPedId(), originalSkin)

            DoScreenFadeIn(300)
            SetNuiFocus(true, true)
            SendNUIMessage({ action = "setVisible", data = true })
            SendNUIMessage({
                action = "outfitCreated",
                data   = {
                    success       = newSkin ~= nil,
                    skin          = newSkin,
                    name          = outfitName,
                    allowedGrades = allowedGrades,
                },
            })
        end)
    end)
end)

RegisterNUICallback("equipOutfit", function(data, cb)
    if data and data.skin then
        Clothing:ApplyToPed(PlayerPedId(), data.skin)
    end
    cb({})
end)

-- ─── Boss menu data ───────────────────────────────────────────────────────────

RegisterNUICallback("saveJob", function(data, cb)
    TriggerServerEvent("bablo-bossmenu:server:saveJob", data)
    cb({})
end)

RegisterNUICallback("updateBossSettings", function(data, cb)
    TriggerServerEvent("bablo-bossmenu:server:updateBossSettings", data)
    cb({})
end)

RegisterNUICallback("getBossMenus", function(data, cb)
    cb(awaitCallback("bablo-bossmenu:server:getBossMenus"))
end)

RegisterNUICallback("fetchJobGrades", function(data, cb)
    if not (data and data.jobName) then return cb({}) end
    cb(awaitCallback("bablo-bossmenu:server:getJobGrades", data.jobName))
end)

RegisterNUICallback("fetchJobStats", function(data, cb)
    if not (data and data.jobName) then
        return cb({ totalEmployees = 0, totalRanks = 0 })
    end
    cb(awaitCallback("bablo-bossmenu:server:getJobStats", data.jobName))
end)

RegisterNUICallback("fetchJobEmployees", function(data, cb)
    if not (data and data.jobName) then return cb({}) end
    cb(awaitCallback("bablo-bossmenu:server:getJobEmployees", data.jobName))
end)

-- ─── Employee management ──────────────────────────────────────────────────────

RegisterNUICallback("fireEmployee", function(data, cb)
    if not (data and data.identifier) then
        return cb({ success = false })
    end
    cb({ success = awaitCallback("bablo-bossmenu:server:fireEmployee", data.identifier) })
end)

RegisterNUICallback("setEmployeeGrade", function(data, cb)
    if not (data and data.identifier and data.newGrade ~= nil) then
        return cb({ success = false })
    end
    cb({ success = awaitCallback("bablo-bossmenu:server:setEmployeeGrade",
        data.identifier, data.newGrade) })
end)

RegisterNUICallback("getPlayerName", function(data, cb)
    if not (data and data.id) then return cb("Player not found") end
    cb(awaitCallback("bablo-bossmenu:server:getPlayerName", tonumber(data.id)))
end)

-- ─── Finances ─────────────────────────────────────────────────────────────────

RegisterNUICallback("withdrawMoney", function(data, cb)
    if not (data and data.jobName and data.amount) then
        return cb({ success = false })
    end
    cb({ success = awaitCallback("bablo-bossmenu:server:withdrawMoney",
        data.jobName, tonumber(data.amount)) })
end)

RegisterNUICallback("depositMoney", function(data, cb)
    if not (data and data.jobName and data.amount) then
        return cb({ success = false })
    end
    cb({ success = awaitCallback("bablo-bossmenu:server:depositMoney",
        data.jobName, tonumber(data.amount)) })
end)

-- ─── Nearby players ───────────────────────────────────────────────────────────

RegisterNUICallback("getNearbyPlayers", function(data, cb)
    local myPed    = PlayerPedId()
    local myCoords = GetEntityCoords(myPed)
    local nearby   = {}

    for _, playerId in ipairs(GetActivePlayers()) do
        local ped = GetPlayerPed(playerId)
        if ped ~= myPed then
            local dist = #(myCoords - GetEntityCoords(ped))
            if dist <= 10.0 then
                table.insert(nearby, GetPlayerServerId(playerId))
            end
        end
    end

    if #nearby > 0 then
        cb(awaitCallback("bablo-bossmenu:server:getPlayersData", nearby))
    else
        cb({})
    end
end)

RegisterNUICallback("hireEmployee", function(data, cb)
    if not (data and data.id and data.jobName) then
        return cb({ success = false })
    end
    cb({ success = awaitCallback("bablo-bossmenu:server:hireEmployee",
        tonumber(data.id), data.jobName) })
end)

-- ─── Job management (creator) ─────────────────────────────────────────────────

RegisterNUICallback("checkFrameworkJob", function(data, cb)
    if not (data and data.jobName) then return cb(false) end
    cb(awaitCallback("bablo-bossmenu:server:checkFrameworkJob", data.jobName))
end)

RegisterNUICallback("createFrameworkJob", function(data, cb)
    if not (data and data.jobName) then return cb(false) end
    cb(awaitCallback("bablo-bossmenu:server:createFrameworkJob",
        data.jobName, data.jobLabel))
end)

RegisterNUICallback("deleteJob", function(data, cb)
    if data and data.jobId then
        TriggerServerEvent("bablo-bossmenu:server:deleteJob", data.jobId, data.deleteFromFramework)
    end
    cb({})
end)

-- ─── Placement ────────────────────────────────────────────────────────────────

RegisterNUICallback("startPlacement", function(data, cb)
    SetNuiFocus(false, false)
    SendNUIMessage({ action = "setVisible", data = false })
    Raycast:Start(data.type, data.interactionType, data.model)
    cb({})
end)

RegisterNUICallback("startPreviewPlacement", function(data, cb)
    SetNuiFocus(false, false)
    SendNUIMessage({ action = "setVisible", data = false })
    Raycast:StartPreviewPlacement(data and data.heading)
    cb({})
end)

-- ─── Outfits / store / salary ─────────────────────────────────────────────────

RegisterNUICallback("getInventoryItems", function(data, cb)
    local result = awaitCallback("bablo-bossmenu:server:getInventoryItems")
    cb(result or {})
end)

RegisterNUICallback("purchaseStoreItems", function(data, cb)
    if not (data and type(data.items) == "table" and data.jobName) then
        return cb({ success = false })
    end
    local result = awaitCallback("bablo-bossmenu:server:purchaseStoreItems",
        data.jobName, data.items, data.payment)
    if result then
        cb(result)
    else
        cb({ success = false })
    end
end)

RegisterNUICallback("setGradeSalary", function(data, cb)
    if data and data.jobName and data.grade ~= nil and data.salary ~= nil then
        TriggerServerEvent("bablo-bossmenu:server:setGradeSalary",
            data.jobName, data.grade, data.salary)
    end
    cb({})
end)

RegisterNUICallback("updateOutfits", function(data, cb)
    if data and type(data.outfits) == "table" then
        TriggerServerEvent("bablo-bossmenu:server:updateOutfits", data.outfits)
    end
    cb({})
end)

-- ─── Analytics ────────────────────────────────────────────────────────────────

RegisterNUICallback("getTransactionChart", function(data, cb)
    if not (data and data.jobName) then return cb(nil) end
    cb(awaitCallback("bablo-bossmenu:server:getTransactionChart", data.jobName, data.range))
end)

RegisterNUICallback("getAttendanceHistory", function(data, cb)
    if not (data and data.jobName) then return cb({}) end
    local result = awaitCallback("bablo-bossmenu:server:getAttendanceHistory",
        data.jobName, data.days)
    cb(result or {})
end)
