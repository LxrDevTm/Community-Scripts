Preview = {
    Ped      = nil,
    Active   = false,
    Camera   = nil,
    Coords   = nil,
    Heading  = nil,
}

-- Internal state: whether createPreviewPed is currently running (prevents re-entry).
local pedSpawning = false
-- Pending clothing data to apply once the ped is ready.
local pendingClothing = nil

-- Spawn a cloned preview ped at Preview.Coords (or 2 m in front of the player),
-- create a close-up scripted camera, and start two housekeeping threads.
local function createPreviewPed()
    print("[Preview] createPreviewPed called")
    SendNUIMessage({ action = "previewPedLoading", data = true })

    if not Preview.Active then return end

    local playerPed = PlayerPedId()
    local heading   = tonumber(Preview.Heading) or 0.0
    local spawnPos

    if Preview.Coords and Preview.Coords.x then
        spawnPos = Preview.Coords
    else
        -- Default: 2 units in front of the player, facing the player.
        local pos     = GetEntityCoords(playerPed)
        local forward = GetEntityForwardVector(playerPed)
        spawnPos = {
            x = pos.x + forward.x * 2.0,
            y = pos.y + forward.y * 2.0,
            z = pos.z + forward.z * 2.0,
        }
        heading = GetEntityHeading(playerPed) + 180.0
    end

    print(("[Preview] Spawning at %.2f, %.2f, %.2f heading %.1f"):format(
        spawnPos.x, spawnPos.y, spawnPos.z, heading))

    local clonedPed = ClonePed(playerPed, heading, false, false)
    SetEntityCoordsNoOffset(clonedPed,
        spawnPos.x, spawnPos.y, spawnPos.z + 0.98, false, false, false)
    SetEntityHeading(clonedPed, heading)
    SetEntityCollision(clonedPed, false, false)
    FreezeEntityPosition(clonedPed, true)
    SetEntityInvincible(clonedPed, true)
    SetBlockingOfNonTemporaryEvents(clonedPed, true)
    TaskStandStill(clonedPed, -1)

    Preview.Ped = clonedPed

    -- Create a camera positioned 2 units behind the ped, aimed at torso level.
    local camHandle = CreateCam("DEFAULT_SCRIPTED_CAMERA", true)
    local camPos    = GetOffsetFromEntityInWorldCoords(clonedPed, 0.0, 2.0, 0.2)
    local lookAt    = GetOffsetFromEntityInWorldCoords(clonedPed, 0.0, 0.0, 0.1)
    SetCamCoord(camHandle, camPos.x, camPos.y, camPos.z)
    PointCamAtCoord(camHandle, lookAt.x, lookAt.y, lookAt.z)
    SetCamActive(camHandle, true)
    RenderScriptCams(true, true, 500, true, true)
    Preview.Camera = camHandle
    DisplayRadar(false)

    -- Heading-sync thread: keep the ped facing Preview.Heading every frame.
    CreateThread(function()
        while Preview.Active and Preview.Ped do
            if DoesEntityExist(Preview.Ped) then
                SetEntityHeading(Preview.Ped, tonumber(Preview.Heading) or 0.0)
            else
                break
            end
            Wait(0)
        end
    end)

    -- Loading-complete thread: waits for head-blend to finish then clears the spinner.
    CreateThread(function()
        local deadline = GetGameTimer() + 3000
        while GetGameTimer() < deadline and Preview.Active do
            if Preview.Ped and DoesEntityExist(Preview.Ped) then
                if HasPedHeadBlendFinished(Preview.Ped) then break end
            end
            Wait(50)
        end
        Wait(300)
        print("[Preview] Loading complete")
        SendNUIMessage({ action = "previewPedLoading", data = false })
    end)
end

-- Show (or update) the preview ped.
--   rect         – UI rect (passed through)
--   clothingData – skin/outfit table to apply via Clothing.ApplyToPed
--   type         – "boss" | "wardrobe" | etc. (default "boss")
--   coords       – vector3/vector4/table or nil (spawn position override)
--   headingArg   – numeric heading override
function Preview:Show(rect, clothingData, type, coords, headingArg)
    self.Type = type or "boss"

    -- Normalise coords to a plain {x,y,z} table.
    if coords then
        local t = type(coords)
        if t == "vector3" or t == "vector4" then
            self.Coords = { x = coords.x, y = coords.y, z = coords.z }
            -- Use the W component of vector4 as heading when no explicit heading given.
            if t == "vector4" and (headingArg == nil or headingArg == 0) then
                headingArg = coords.w
            end
        elseif t == "table" and coords.x then
            self.Coords = coords
        else
            self.Coords = nil
        end
    else
        self.Coords = nil
    end

    self.Heading = tonumber(headingArg) or 0.0

    if rect then self.Rect = rect end

    -- If a spawn is already in progress, queue the clothing for later and return.
    if pedSpawning then
        pendingClothing = clothingData
        return
    end

    self.Active = true

    -- Spawn the ped if it doesn't already exist.
    if not self.Ped or not DoesEntityExist(self.Ped) then
        pedSpawning = true
        createPreviewPed()
        pedSpawning = false
    end

    -- Apply clothing to the (possibly freshly spawned) ped.
    local skin = pendingClothing or clothingData
    pendingClothing = nil

    if skin and self.Ped and DoesEntityExist(self.Ped) then
        Clothing:ApplyToPed(self.Ped, skin)
    end
end

-- Tear down the preview ped and camera, restore the radar.
function Preview:Close()
    self.Active = false
    self.Rect   = nil
    pendingClothing = nil

    if self.Ped and DoesEntityExist(self.Ped) then
        DeleteEntity(self.Ped)
    end
    self.Ped = nil

    if self.Camera then
        RenderScriptCams(false, true, 500, true, true)
        DestroyCam(self.Camera, false)
        self.Camera = nil
    end

    DisplayRadar(true)
    SendNUIMessage({ action = "previewClosed" })
end

AddEventHandler("onResourceStop", function(resourceName)
    if resourceName == GetCurrentResourceName() then
        Preview:Close()
    end
end)
