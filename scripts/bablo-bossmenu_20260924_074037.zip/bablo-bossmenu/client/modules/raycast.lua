Raycast = {}

-- Cast a ray from the gameplay camera forward by distance units.
-- Returns: hit (bool), hitCoords (vector3), hitEntity (entity), hitNormal (vector3)
local function castRay(distance)
    local camRot   = GetGameplayCamRot()
    local camCoord = GetGameplayCamCoord()

    -- Convert camera rotation to a forward direction vector.
    local forward = vector3(
        -math.sin(math.rad(camRot.z)) * math.abs(math.cos(math.rad(camRot.x))),
         math.cos(math.rad(camRot.z)) * math.abs(math.cos(math.rad(camRot.x))),
         math.sin(math.rad(camRot.x))
    )

    local target = camCoord + forward * distance
    local handle = StartShapeTestRay(
        camCoord.x, camCoord.y, camCoord.z,
        target.x,   target.y,   target.z,
        -1, PlayerPedId(), 0
    )
    local _, hit, endCoords, normal, entity = GetShapeTestResult(handle)
    return hit, endCoords, entity, normal
end

-- ─── Zone placement mode ──────────────────────────────────────────────────────

-- Draw an opaque zone outline (floor marker + side faces) between all recorded points.
local ZONE_COLOUR    = { 122, 173, 255 }
local ZONE_ALPHA     = 50
local CLOSING_COLOUR = { 255, 255, 255 }
local ZONE_HEIGHT    = 2.0

local function drawZonePreview(points, currentPos)
    -- Floor marker at current cursor position.
    DrawMarker(28,
        currentPos.x, currentPos.y, currentPos.z,
        0, 0, 0, 0, 0, 0,
        0.1, 0.1, 0.1,
        ZONE_COLOUR[1], ZONE_COLOUR[2], ZONE_COLOUR[3], 200,
        false, false, 2, false, nil, nil, false)

    for i = 1, #points do
        local a    = points[i]
        local b    = points[i + 1] or currentPos

        DrawLine(a.x, a.y, a.z, b.x, b.y, b.z,
            ZONE_COLOUR[1], ZONE_COLOUR[2], ZONE_COLOUR[3], 255)

        -- Vertical wall between a and b drawn as four triangles.
        local aHi = vector3(a.x, a.y, a.z + ZONE_HEIGHT)
        local aLo = vector3(a.x, a.y, a.z - ZONE_HEIGHT)
        local bHi = vector3(b.x, b.y, b.z + ZONE_HEIGHT)
        local bLo = vector3(b.x, b.y, b.z - ZONE_HEIGHT)
        local r, g, b_, a_ = ZONE_COLOUR[1], ZONE_COLOUR[2], ZONE_COLOUR[3], ZONE_ALPHA

        DrawPoly(aLo.x, aLo.y, aLo.z, aHi.x, aHi.y, aHi.z, bHi.x, bHi.y, bHi.z, r, g, b_, a_)
        DrawPoly(aLo.x, aLo.y, aLo.z, bHi.x, bHi.y, bHi.z, bLo.x, bLo.y, bLo.z, r, g, b_, a_)
        DrawPoly(bHi.x, bHi.y, bHi.z, aHi.x, aHi.y, aHi.z, aLo.x, aLo.y, aLo.z, r, g, b_, a_)
        DrawPoly(bLo.x, bLo.y, bLo.z, bHi.x, bHi.y, bHi.z, aLo.x, aLo.y, aLo.z, r, g, b_, a_)
    end

    -- Closing line from current position back to the first point when ≥ 3 points exist.
    if #points >= 3 then
        local first = points[1]
        DrawLine(currentPos.x, currentPos.y, currentPos.z,
            first.x, first.y, first.z,
            CLOSING_COLOUR[1], CLOSING_COLOUR[2], CLOSING_COLOUR[3], 100)

        -- Closing wall faces (white, more transparent).
        local cHi  = vector3(currentPos.x, currentPos.y, currentPos.z + ZONE_HEIGHT)
        local cLo  = vector3(currentPos.x, currentPos.y, currentPos.z - ZONE_HEIGHT)
        local fHi  = vector3(first.x, first.y, first.z + ZONE_HEIGHT)
        local fLo  = vector3(first.x, first.y, first.z - ZONE_HEIGHT)
        local cr, cg, cb, ca = 255, 255, 255, 20

        DrawPoly(cLo.x, cLo.y, cLo.z, cHi.x, cHi.y, cHi.z, fHi.x, fHi.y, fHi.z, cr, cg, cb, ca)
        DrawPoly(cLo.x, cLo.y, cLo.z, fHi.x, fHi.y, fHi.z, fLo.x, fLo.y, fLo.z, cr, cg, cb, ca)
        DrawPoly(fHi.x, fHi.y, fHi.z, cHi.x, cHi.y, cHi.z, cLo.x, cLo.y, cLo.z, cr, cg, cb, ca)
        DrawPoly(fLo.x, fLo.y, fLo.z, fHi.x, fHi.y, fHi.z, cLo.x, cLo.y, cLo.z, cr, cg, cb, ca)
    end
end

-- ─── Raycast.Start ────────────────────────────────────────────────────────────

-- Begin a placement session.
--   locationType   – e.g. "boss", "wardrobe", etc.  (passed through to the NUI)
--   interactionType – "zone", "ped", "prop", "target"
--   model          – model name string (for ped/prop modes)
function Raycast:Start(locationType, interactionType, model)
    local active         = true   -- loop-alive flag
    local hitPos         = vector3(0, 0, 0)
    local heading        = 0.0
    local previewEntity  = nil    -- ghost ped/prop shown during placement

    -- ── Zone mode ──────────────────────────────────────────────────────────────
    if interactionType == "zone" then
        local points = {}

        TextUI:Show("[E] Add Point | [ENTER] Finish Zone | [BACKSPACE] Cancel")

        CreateThread(function()
            while active do
                Wait(0)
                DisableControlAction(0, 199, true)
                DisableControlAction(0, 200, true)
                DisableControlAction(0, 202, true)

                local ped       = PlayerPedId()
                local pedCoords = GetEntityCoords(ped)
                local cursorPos = vector3(pedCoords.x, pedCoords.y, pedCoords.z - 0.98)

                DrawMarker(28, cursorPos.x, cursorPos.y, cursorPos.z,
                    0, 0, 0, 0, 0, 0, 0.1, 0.1, 0.1,
                    ZONE_COLOUR[1], ZONE_COLOUR[2], ZONE_COLOUR[3], 200,
                    false, false, 2, false, nil, nil, false)

                if #points > 0 then
                    drawZonePreview(points, cursorPos)
                end

                -- [E] – add current position as a zone point.
                if IsControlJustPressed(0, 38) then
                    table.insert(points, cursorPos)
                end

                -- [ENTER] – finish zone if ≥ 4 points.
                if IsControlJustPressed(0, 191) then
                    if #points >= 4 then
                        active = false
                        TextUI:Hide()
                        local exportedPoints = {}
                        for _, pt in ipairs(points) do
                            table.insert(exportedPoints, { x = pt.x, y = pt.y, z = pt.z })
                        end
                        SetNuiFocus(true, true)
                        SendNUIMessage({
                            action = "openPlacementDetails",
                            data   = {
                                type            = locationType,
                                interactionType = interactionType,
                                coords          = exportedPoints,
                                heading         = 0.0,
                                model           = "",
                            },
                        })
                        SendNUIMessage({ action = "setVisible", data = true })
                    end
                end

                -- [BACKSPACE] – cancel.
                if IsControlJustPressed(0, 177) then
                    active = false
                    TextUI:Hide()
                    SetNuiFocus(true, true)
                    SendNUIMessage({ action = "setVisible", data = true })
                end
            end
        end)

        return
    end

    -- ── Ped / prop / target mode ───────────────────────────────────────────────

    -- Load and spawn a ghost preview entity when a model is provided.
    if (interactionType == "ped" or interactionType == "prop") and model and model ~= "" then
        local modelHash = GetHashKey(model)
        RequestModel(modelHash)
        local attempts = 0
        while not HasModelLoaded(modelHash) and attempts < 200 do
            Wait(10)
            attempts = attempts + 1
        end
        if HasModelLoaded(modelHash) then
            if interactionType == "ped" then
                previewEntity = CreatePed(0, modelHash, 0, 0, 0, 0, false, false)
            else
                previewEntity = CreateObject(modelHash, 0, 0, 0, false, false, false)
            end
            SetEntityAlpha(previewEntity, 150, false)
            SetEntityCollision(previewEntity, false, false)
            SetModelAsNoLongerNeeded(modelHash)
        end
    end

    -- No ghost entity: show a dot marker and a direction arrow instead.
    -- Heading arrow offset: 1.5 units in the current heading direction.
    local MARKER_SIZE_TARGET = 0.1
    local MARKER_SIZE_OTHER  = 0.3

    TextUI:Show("[A/D] Rotate | [E] Place | [BACKSPACE] Cancel")

    CreateThread(function()
        while active do
            Wait(0)
            DisableControlAction(0, 199, true)
            DisableControlAction(0, 200, true)
            DisableControlAction(0, 202, true)

            local hit, rayHit = castRay(10.0)
            if hit ~= 0 then hitPos = rayHit end

            if previewEntity then
                -- Z offset: peds stand 0.98 above ground, props sit at ground level.
                local zOffset = (interactionType == "ped") and 0.98 or 0.0
                SetEntityCoordsNoOffset(previewEntity,
                    hitPos.x, hitPos.y, hitPos.z + zOffset, false, false, false)
                SetEntityHeading(previewEntity, heading)

                -- A / D rotate left.
                if IsControlPressed(0, 14) then heading = heading - 2.0 end
                -- D / right rotate right.
                if IsControlPressed(0, 15) then heading = heading + 2.0 end
            else
                -- No ghost entity: draw a sphere marker and a directional line.
                local markerSize = (interactionType == "target") and MARKER_SIZE_TARGET or MARKER_SIZE_OTHER
                DrawMarker(28, hitPos.x, hitPos.y, hitPos.z,
                    0, 0, 0, 0, 0, 0,
                    markerSize, markerSize, markerSize,
                    122, 173, 255, 150,
                    false, false, 2, false, nil, nil, false)

                -- Direction arrow line.
                local arrowOffset = vector3(
                    math.sin(math.rad(heading)) * 1.5,
                    math.cos(math.rad(heading)) * 1.5,
                    0.0)
                DrawLine(hitPos.x, hitPos.y, hitPos.z,
                    hitPos.x - arrowOffset.x, hitPos.y + arrowOffset.y, hitPos.z,
                    255, 0, 0, 255)

                if IsControlPressed(0, 14) then heading = heading - 2.0 end
                if IsControlPressed(0, 15) then heading = heading + 2.0 end
            end

            -- Wrap heading to [0, 360).
            if heading >= 360.0 then heading = 0.0 end
            if heading < 0.0    then heading = 359.0 end

            -- [E] – confirm placement.
            if IsControlJustPressed(0, 38) then
                active = false
                TextUI:Hide()
                if previewEntity and DoesEntityExist(previewEntity) then
                    SetEntityAsMissionEntity(previewEntity, true, true)
                    DeleteEntity(previewEntity)
                end
                SetNuiFocus(true, true)
                SendNUIMessage({
                    action = "openPlacementDetails",
                    data   = {
                        type            = locationType,
                        interactionType = interactionType,
                        coords          = ("vec4(%.2f, %.2f, %.2f, %.2f)"):format(
                            hitPos.x, hitPos.y, hitPos.z, heading),
                        heading         = heading,
                        model           = model or "",
                    },
                })
                SendNUIMessage({ action = "setVisible", data = true })
            end

            -- [BACKSPACE] – cancel.
            if IsControlJustPressed(0, 177) then
                active = false
                TextUI:Hide()
                if previewEntity and DoesEntityExist(previewEntity) then
                    SetEntityAsMissionEntity(previewEntity, true, true)
                    DeleteEntity(previewEntity)
                end
                SetNuiFocus(true, true)
                SendNUIMessage({ action = "setVisible", data = true })
            end
        end
    end)
end

-- ─── Raycast.StartPreviewPlacement ────────────────────────────────────────────

-- Begin a dedicated preview-position capture session (used for setting where
-- the boss-menu preview camera will stand). The player ped's own model is cloned
-- as a ghost at the raycast hit point; confirming sends previewCoordsCaptured.
function Raycast:StartPreviewPlacement(initialHeading)
    local active  = true
    local hitPos  = vector3(0, 0, 0)

    heading = tonumber(initialHeading) or 0.0
    if heading >= 360.0 then heading = heading % 360.0 end
    if heading < 0.0    then heading = heading + 360.0 end

    -- Create a semi-transparent ghost clone of the player's own model.
    local playerModel = GetEntityModel(PlayerPedId())
    RequestModel(playerModel)
    local attempts = 0
    while not HasModelLoaded(playerModel) and attempts < 200 do
        Wait(10)
        attempts = attempts + 1
    end

    local ghostPed = nil
    if HasModelLoaded(playerModel) then
        ghostPed = CreatePed(0, playerModel, 0, 0, 0, 0, false, false)
        SetEntityAlpha(ghostPed, 150, false)
        SetEntityCollision(ghostPed, false, false)
        SetModelAsNoLongerNeeded(playerModel)
    end

    CreateThread(function()
        while active do
            Wait(0)
            DisableControlAction(0, 199, true)
            DisableControlAction(0, 200, true)
            DisableControlAction(0, 202, true)

            TextUI:Show(("[A/D or SCROLL] Rotate Ped (Heading: %.0f°) | [E] Confirm Position | [BACKSPACE] Cancel"):format(heading))

            local hit, rayHit = castRay(10.0)
            if hit ~= 0 then hitPos = rayHit end

            if ghostPed then
                SetEntityCoordsNoOffset(ghostPed,
                    hitPos.x, hitPos.y, hitPos.z + 0.98, false, false, false)
                SetEntityHeading(ghostPed, heading)

                -- A / scroll-up: rotate left.
                if IsControlPressed(0, 14) or IsControlPressed(0, 34) or IsControlPressed(0, 174) then
                    heading = heading - 2.0
                end
                -- D / scroll-down: rotate right.
                if IsControlPressed(0, 15) or IsControlPressed(0, 35) or IsControlPressed(0, 175) then
                    heading = heading + 2.0
                end
            end

            if heading >= 360.0 then heading = 0.0  end
            if heading < 0.0    then heading = 359.0 end

            -- [E] – confirm captured coords.
            if IsControlJustPressed(0, 38) then
                active = false
                TextUI:Hide()
                if ghostPed and DoesEntityExist(ghostPed) then
                    SetEntityAsMissionEntity(ghostPed, true, true)
                    DeleteEntity(ghostPed)
                end
                SetNuiFocus(true, true)
                SendNUIMessage({
                    action = "previewCoordsCaptured",
                    data   = { x = hitPos.x, y = hitPos.y, z = hitPos.z, h = heading },
                })
                SendNUIMessage({ action = "setVisible", data = true })
            end

            -- [BACKSPACE] – cancel.
            if IsControlJustPressed(0, 177) then
                active = false
                TextUI:Hide()
                if ghostPed and DoesEntityExist(ghostPed) then
                    SetEntityAsMissionEntity(ghostPed, true, true)
                    DeleteEntity(ghostPed)
                end
                SetNuiFocus(true, true)
                SendNUIMessage({ action = "setVisible", data = true })
            end
        end
    end)
end
