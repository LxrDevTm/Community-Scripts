lib.locale()

Spawner = {}

-- jobState[jobName] = { entities = {}, targets = {}, zones = {} }
-- Tracks all spawned entities and registered targets/zones per job so they can
-- be cleaned up when a job is reloaded or the resource stops.
local jobState = {}

-- ─── Internal helpers ─────────────────────────────────────────────────────────

local function newJobState()
    return { entities = {}, targets = {}, zones = {} }
end

-- Remove all entities, target zones, and lib.zones for a given job name.
local function cleanupJob(jobName)
    local state = jobState[jobName]
    if not state then return end

    for _, ent in ipairs(state.entities) do
        if DoesEntityExist(ent) then
            if Target and Target.RemoveLocalEntity then
                Target:RemoveLocalEntity(ent)
            end
            SetEntityAsMissionEntity(ent, true, true)
            DeleteEntity(ent)
        end
    end

    for _, zoneId in ipairs(state.targets) do
        if Target and Target.RemoveZone then
            Target:RemoveZone(zoneId)
        end
    end

    for _, zone in ipairs(state.zones) do
        if zone and zone.remove then zone:remove() end
    end

    jobState[jobName] = nil
end

-- Clean up every loaded job (called on resource stop or full reload).
local function cleanupAllJobs()
    for jobName in pairs(jobState) do
        cleanupJob(jobName)
    end
    jobState = {}
end

-- Request a model hash and wait up to 5 s for it to load.
-- Returns the hash on success, nil on failure / invalid model.
local function requestModel(modelName)
    local hash = GetHashKey(modelName)
    if not IsModelValid(hash) then return nil end
    RequestModel(hash)
    local attempts = 0
    while not HasModelLoaded(hash) and attempts < 500 do
        Wait(10)
        attempts = attempts + 1
    end
    return HasModelLoaded(hash) and hash or nil
end

-- Parse a coords string of the form "vec4(x, y, z, w)" or "vec3(x, y, z)"
-- back to the corresponding native type. Passes through non-string values unchanged.
local function parseCoords(raw)
    if type(raw) ~= "string" then return raw end

    if raw:match("vec4") or raw:match("vector4") then
        local x, y, z, w = raw:match("vec%w*%(([^,]+),%s*([^,]+),%s*([^,]+),%s*([^%)]+)%)")
        if x and y and z and w then
            return vec4(tonumber(x), tonumber(y), tonumber(z), tonumber(w))
        end
    end

    if raw:match("vec3") or raw:match("vector3") then
        local x, y, z = raw:match("vec%w*%(([^,]+),%s*([^,]+),%s*([^%)]+)%)")
        if x and y and z then
            return vec3(tonumber(x), tonumber(y), tonumber(z))
        end
    end

    return raw
end

-- Collect all grade numbers that should have boss-menu access for a job descriptor.
-- Merges bossMenuGrades and any grades whose permissions table is non-empty.
local function resolveBossGrades(jobDesc)
    local seen   = {}
    local grades = {}

    local function addGrade(raw)
        local n = tonumber(raw)
        if n and not seen[n] then
            seen[n] = true
            grades[#grades + 1] = n
        end
    end

    if type(jobDesc.bossMenuGrades) == "table" then
        for _, v in pairs(jobDesc.bossMenuGrades) do addGrade(v) end
    end

    if type(jobDesc.grades) == "table" then
        for _, g in ipairs(jobDesc.grades) do
            if type(g.permissions) == "table" and next(g.permissions) ~= nil then
                addGrade(g.grade)
            end
        end
    end

    if #grades > 0 then
        -- Find the highest grade and add all grades up to that threshold.
        local maxGrade = nil
        if type(jobDesc.grades) == "table" then
            for _, g in ipairs(jobDesc.grades) do
                local n = tonumber(g.grade)
                if n and (not maxGrade or maxGrade < n) then maxGrade = n end
            end
        end
        if maxGrade then addGrade(maxGrade) end
    end

    return grades
end

-- Build a target-option table for opening a boss-menu type at a location.
local function buildTargetOption(jobName, menuType, grades, previewCoords, previewHeading,
                                  locationId, isDedicated)
    local actionKey = "open_" .. menuType
    local optionName = ("bablo_bossmenu_%s_%s"):format(jobName, menuType)

    local label = locale("target." .. actionKey)
    if not label then label = "Open " .. menuType end

    local option = {
        name     = optionName,
        icon     = "fas fa-briefcase",
        label    = label,
        job      = jobName,
        distance = 2.0,
        onInteract = function()
            TriggerEvent("bablo-bossmenu:client:openMenu", {
                job             = jobName,
                type            = menuType,
                previewCoords   = previewCoords,
                previewHeading  = previewHeading,
                locationId      = locationId,
                previewDedicated = isDedicated,
            })
        end,
    }

    if menuType == "boss" and type(grades) == "table" then
        option.grades = grades
    end

    return { option }
end

-- ─── Spawner.LoadJob ──────────────────────────────────────────────────────────

-- Load (or reload) all locations for a single job descriptor.
function Spawner.LoadJob(jobDesc)
    if not jobDesc or not jobDesc.name then return end

    local jobName = jobDesc.name
    cleanupJob(jobName)

    local state = newJobState()
    jobState[jobName] = state

    if type(jobDesc.locations) ~= "table" then return end

    local bossGrades = resolveBossGrades(jobDesc)

    for menuType, locationList in pairs(jobDesc.locations) do
        for _, locationDef in ipairs(locationList) do
            local rawCoords      = locationDef.coords
            local parsedCoords   = parseCoords(rawCoords)
            local coordType      = type(parsedCoords)

            -- Resolve heading: prefer the vector4 .w, then explicit heading field.
            local heading = 0.0
            if coordType == "vector4" and parsedCoords.w then
                heading = parsedCoords.w
            else
                heading = tonumber(locationDef.heading) or 0.0
            end

            local model         = locationDef.model or ""
            local previewCoords = locationDef.previewCoords
            local previewHeading = locationDef.previewHeading

            -- Derive default previewCoords from the location's own coords when absent.
            if not previewCoords then
                if coordType == "vector4" or coordType == "vector3" then
                    previewCoords = { x = parsedCoords.x, y = parsedCoords.y, z = parsedCoords.z }
                end
            end
            if previewHeading == nil then previewHeading = heading end

            local isDedicated = (locationDef.previewCoords ~= nil)
            local interactionType = locationDef.interactionType
            local targetOptions = buildTargetOption(
                jobName, menuType, bossGrades,
                previewCoords, previewHeading,
                locationDef.id, isDedicated)

            -- ── Zone interaction ────────────────────────────────────────────────
            if interactionType == "zone" then
                if type(rawCoords) == "table" and #rawCoords >= 3 then
                    local points = {}
                    for _, pt in ipairs(rawCoords) do
                        table.insert(points, vec3(pt.x, pt.y, pt.z))
                    end

                    local zone = lib.zones.poly({
                        points    = points,
                        thickness = 4.0,
                        debug     = false,
                        onEnter   = function()
                            TextUI:Show("[E] " .. targetOptions[1].label)
                        end,
                        onExit    = function()
                            TextUI:Hide()
                        end,
                        inside    = function()
                            if not IsControlJustPressed(0, 38) then return end

                            -- Job restriction check.
                            if targetOptions[1].job then
                                local playerJob = (Framework and Framework.GetPlayerJob)
                                    and Framework:GetPlayerJob() or {}
                                if playerJob.name ~= targetOptions[1].job then
                                    Notify:Show(
                                        locale("notify.no_access") or "You do not have access to this menu.",
                                        "error")
                                    return
                                end
                            end

                            -- Grade restriction check.
                            if targetOptions[1].grades and type(targetOptions[1].grades) == "table"
                                and next(targetOptions[1].grades) ~= nil then
                                local playerJob = Framework:GetPlayerJob()
                                local hasGrade  = false
                                for _, allowedGrade in pairs(targetOptions[1].grades) do
                                    if tonumber(playerJob.grade) == tonumber(allowedGrade) then
                                        hasGrade = true
                                        break
                                    end
                                end
                                if not hasGrade then
                                    Notify:Show(
                                        locale("notify.no_access") or "You don't have access to this menu.",
                                        "error")
                                    return
                                end
                            end

                            if targetOptions[1].onInteract then
                                targetOptions[1].onInteract()
                            end
                        end,
                    })
                    table.insert(state.zones, zone)
                end

            -- ── Sphere target / ped / prop ──────────────────────────────────────
            elseif coordType == "vector3" or coordType == "vector4" then
                if interactionType == "target" then
                    local zoneId = ("zone_%s_%s"):format(jobName, locationDef.id)
                    Target:AddSphereZone(zoneId, parsedCoords, 1.0, targetOptions)
                    table.insert(state.targets, zoneId)

                elseif interactionType == "ped" or interactionType == "prop" then
                    local hash = requestModel(model)

                    -- Abort if the job was already replaced while we were loading.
                    if jobState[jobName] ~= state then
                        if hash then SetModelAsNoLongerNeeded(hash) end
                        return
                    end

                    if hash then
                        local entity
                        if interactionType == "ped" then
                            entity = CreatePed(0, hash,
                                parsedCoords.x, parsedCoords.y, parsedCoords.z, heading,
                                false, false)
                            SetEntityCoordsNoOffset(entity,
                                parsedCoords.x, parsedCoords.y, parsedCoords.z + 0.98,
                                false, false, false)
                        else
                            entity = CreateObject(hash,
                                parsedCoords.x, parsedCoords.y, parsedCoords.z,
                                false, false, false)
                        end

                        SetEntityHeading(entity, tonumber(heading) or 0.0)
                        FreezeEntityPosition(entity, true)
                        SetEntityInvincible(entity, true)
                        SetBlockingOfNonTemporaryEvents(entity, true)
                        Target:AddLocalEntity(entity, targetOptions)
                        table.insert(state.entities, entity)
                        SetModelAsNoLongerNeeded(hash)
                    end
                end
            end
        end
    end
end

-- ─── Spawner.RemoveJob ────────────────────────────────────────────────────────

function Spawner.RemoveJob(jobName)
    cleanupJob(jobName)
end

-- ─── Spawner.LoadBossMenus ────────────────────────────────────────────────────

-- Reload counter: incremented on every LoadBossMenus call so that a superseded
-- batch can detect it has been replaced and abort early.
local loadGeneration = 0

-- Reload all boss menus from a fresh descriptor list. Clears current state first,
-- then loads each job, yielding every 10 jobs to avoid frame spikes.
function Spawner.LoadBossMenus(menus)
    loadGeneration = loadGeneration + 1
    local myGeneration = loadGeneration

    cleanupAllJobs()

    for i, jobDesc in ipairs(menus or {}) do
        -- Abort if a newer LoadBossMenus call has superseded us.
        if loadGeneration ~= myGeneration then return end
        Spawner.LoadJob(jobDesc)
        if i % 10 == 0 then Wait(0) end
    end
end

AddEventHandler("onResourceStop", function(resourceName)
    if resourceName == GetCurrentResourceName() then
        cleanupAllJobs()
    end
end)
