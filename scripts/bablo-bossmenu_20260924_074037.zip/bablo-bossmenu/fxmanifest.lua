
fx_version 'cerulean'
game 'gta5'
lua54 'yes'

author 'Bablo & Windows'
description 'Bablo Boss Menu'
version "1.0.1"

shared_scripts {
	'@ox_lib/init.lua',
	'shared/settings.lua',
	'shared/creator.lua'
}

client_scripts {
	'client/bridge/framework/*.lua',
	'client/bridge/target/*.lua',
	'client/bridge/textui/*.lua',
	'client/bridge/notify/*.lua',
	'client/bridge/clothing/init.lua',
	'client/bridge/clothing/illenium-appearance.lua',
	'client/bridge/clothing/fivem-appearance.lua',
	'client/bridge/clothing/bl_appearance.lua',
	'client/bridge/clothing/crm-appearance.lua',
	'client/bridge/clothing/rcore_clothing.lua',
	'client/bridge/clothing/codem-appearance.lua',
	'client/bridge/clothing/tgiann-clothing.lua',
	'client/bridge/clothing/qb-clothing.lua',
	'client/bridge/clothing/esx_skin.lua',
	'client/bridge/clothing/skinchanger.lua',
	'client/modules/*.lua'
}

server_scripts {
    '@oxmysql/lib/MySQL.lua',
	'server/bridge/framework/*.lua',
	'server/bridge/notify/*.lua',
	'server/bridge/society/detect.lua',
	'server/bridge/society/bablo-banking.lua',
	'server/bridge/society/qb-management.lua',
	'server/bridge/society/esx_addonaccount.lua',
	'server/bridge/inventories/detect.lua',
	'server/bridge/inventories/tgiann-inventory.lua',
	'server/bridge/inventories/qb-inventory.lua',
	'server/bridge/inventories/qs-inventory.lua',
	'server/bridge/inventories/ps-inventory.lua',
	'server/bridge/inventories/ox_inventory.lua',
	'server/bridge/inventories/origen_inventory.lua',
	'server/bridge/inventories/core_inventory.lua',
	'server/bridge/inventories/codem-inventory.lua',
	'server/modules/db.lua',
	'server/modules/core.lua',
	'server/modules/callbacks.lua',
	'server/modules/hours.lua',
	'server/modules/orders.lua',
	'server/modules/paycheck.lua',
	'server/modules/events.lua',
	'server/modules/import.lua'
}

ui_page 'nui/dist/index.html'

files {
	'nui/dist/**',
	'assets/**',
	'locales/*.json'
}

dependency 'ox_lib'

escrow_ignore {
	'client/bridge/**/*.lua',
	'server/bridge/**/*.lua',
	'shared/*.lua'
}

dependency '/assetpacks'
