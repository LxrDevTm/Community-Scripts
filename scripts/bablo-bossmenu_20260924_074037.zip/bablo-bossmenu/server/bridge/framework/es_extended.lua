
if GetResourceState('es_extended') ~= 'started' then return end

local ESX = {}
ESX.__index = ESX

function ESX.new()
    local self = setmetatable({}, ESX)
    self.Core = exports['es_extended']:getSharedObject()
    return self
end

function ESX:GetPlayer(src)
    return self.Core.GetPlayerFromId(src)
end

function ESX:GetName(src)
    local Player = self:GetPlayer(src)
    if Player then
        return Player.getName() or GetPlayerName(src)
    end
    return GetPlayerName(src)
end

function ESX:GetPlayerJob(src)
    local Player = self:GetPlayer(src)
    if Player then
        return Player.getJob()
    end
    return nil
end

function ESX:HasCreatorPermission(src)
    local Player = self:GetPlayer(src)
    if not Player then return false end

    if not Creator.UsePermissions then return true end

    local playerGroup = Player.getGroup()
    for i = 1, #Creator.Permissions do
        if playerGroup == Creator.Permissions[i] then
            return true
        end
    end
    return false
end

function ESX:GetJobGrades(jobName)
    local grades = {}
    local jobs = self.Core.GetJobs and self.Core.GetJobs() or {}
    if jobs[jobName] then
        for grade, gradeData in pairs(jobs[jobName].grades or {}) do
            table.insert(grades, {
                grade = tonumber(grade),
                name = gradeData.name or tostring(grade),
                label = gradeData.label,
                salary = gradeData.salary,
                isboss = gradeData.name == 'boss'
            })
        end
    end

    if #grades == 0 then
        local rows = MySQL.query.await('SELECT grade, name, label, salary FROM job_grades WHERE job_name = ?', { jobName })
        for _, row in ipairs(rows or {}) do
            table.insert(grades, {
                grade = tonumber(row.grade),
                name = row.name or tostring(row.grade),
                label = row.label or row.name or tostring(row.grade),
                salary = row.salary,
                isboss = row.name == 'boss'
            })
        end
    end

    table.sort(grades, function(a, b) return (tonumber(a.grade) or 0) < (tonumber(b.grade) or 0) end)

    return grades
end

local employeeRows = {}
local EMPLOYEE_CACHE_MS = 30000

local function invalidateEmployees(jobName)
    if jobName then
        employeeRows[jobName] = nil
    else
        employeeRows = {}
    end
end

function ESX:FetchJobRows(jobName)
    local cached = employeeRows[jobName]
    if cached and (GetGameTimer() - cached.at) < EMPLOYEE_CACHE_MS then
        return cached.rows
    end
    local rows = MySQL.query.await('SELECT identifier, firstname, lastname, job_grade FROM users WHERE job = ?', { jobName }) or {}
    employeeRows[jobName] = { at = GetGameTimer(), rows = rows }
    return rows
end

function ESX:GetJobStats(jobName)
    local stats = { totalEmployees = 0, totalRanks = 0, totalPayroll = 0 }

    local ranks = self:GetJobGrades(jobName)
    stats.totalRanks = #ranks

    local salaryByGrade = {}
    for _, r in ipairs(ranks) do
        salaryByGrade[tostring(r.grade)] = r.salary or 0
    end

    local employees = self:FetchJobRows(jobName)
    stats.totalEmployees = #employees
    for _, emp in ipairs(employees) do
        local gradeStr = tostring(emp.job_grade)
        if salaryByGrade[gradeStr] then
            stats.totalPayroll = stats.totalPayroll + salaryByGrade[gradeStr]
        end
    end

    if Society and Society.GetBalance then
        stats.societyBalance = Society:GetBalance(jobName)
    else
        stats.societyBalance = 0
    end

    return stats
end

function ESX:GetJobEmployees(jobName)
    local employees = {}

    local ranks = self:GetJobGrades(jobName)
    local rankData = {}
    for _, r in ipairs(ranks) do
        rankData[tostring(r.grade)] = r
    end

    local hoursByIdentifier = {}
    local hourRows = MySQL.query.await('SELECT identifier, SUM(seconds) AS total FROM bablo_bossmenu_hours WHERE job_name = ? GROUP BY identifier', { jobName })
    if hourRows then
        for _, hr in ipairs(hourRows) do
            hoursByIdentifier[hr.identifier] = tonumber(hr.total) or 0
        end
    end

    local online = {}
    local xPlayers = self.Core.GetExtendedPlayers and self.Core.GetExtendedPlayers('job', jobName) or {}
    for _, xPlayer in pairs(xPlayers) do
        local id = xPlayer and xPlayer.getIdentifier and xPlayer.getIdentifier()
        if id then online[id] = true end
    end

    local result = self:FetchJobRows(jobName)
    if result then
        for _, row in ipairs(result) do
            local gradeStr = tostring(row.job_grade)
            local rData = rankData[gradeStr] or { name = gradeStr, label = 'Unknown', salary = 0 }

            local isOnline = online[row.identifier] == true

            local name = "Unknown"
            if row.firstname and row.lastname then
                name = row.firstname .. " " .. row.lastname
            elseif row.firstname then
                name = row.firstname
            end

            table.insert(employees, {
                identifier = row.identifier,
                name = name,
                status = isOnline and "Online" or "Offline",
                gradeId = row.job_grade,
                gradeName = rData.label,
                salary = "$ " .. tostring(rData.salary),
                hours = (function()
                    local total = hoursByIdentifier[row.identifier] or 0
                    if Hours and Hours.GetActiveSeconds then
                        total = total + Hours.GetActiveSeconds(row.identifier)
                    end
                    return ('%.1f Hours'):format(total / 3600)
                end)()
            })
        end
    end

    return employees
end

function ESX:GetAllJobs()
    local out = {}
    if self.Core.GetJobs then
        for name, job in pairs(self.Core.GetJobs() or {}) do
            local grades = {}
            for grade, gradeData in pairs(job.grades or {}) do
                grades[#grades + 1] = {
                    grade = tonumber(grade),
                    name = gradeData.name or tostring(grade),
                    label = gradeData.label,
                    salary = gradeData.salary,
                    isboss = gradeData.name == 'boss'
                }
            end
            table.sort(grades, function(a, b) return (tonumber(a.grade) or 0) < (tonumber(b.grade) or 0) end)
            out[name] = { label = job.label or name, grades = grades }
        end
    end
    if next(out) == nil then
        local rows = MySQL.query.await([[
            SELECT j.name AS job_name, j.label AS job_label, g.grade, g.name AS grade_name, g.label AS grade_label, g.salary
            FROM jobs j
            LEFT JOIN job_grades g ON g.job_name = j.name
            ORDER BY j.name, g.grade
        ]])
        for _, row in ipairs(rows or {}) do
            local job = out[row.job_name]
            if not job then
                job = { label = row.job_label or row.job_name, grades = {} }
                out[row.job_name] = job
            end
            if row.grade ~= nil then
                job.grades[#job.grades + 1] = {
                    grade = tonumber(row.grade),
                    name = row.grade_name or tostring(row.grade),
                    label = row.grade_label or row.grade_name or tostring(row.grade),
                    salary = tonumber(row.salary) or 0,
                    isboss = row.grade_name == 'boss'
                }
            end
        end
    end
    return out
end

function ESX:CheckJobExists(jobName)
    if self.Core.GetJobs and self.Core.GetJobs()[jobName] then
        return { exists = true, label = self.Core.GetJobs()[jobName].label or jobName }
    end

    local result = MySQL.single.await('SELECT label FROM jobs WHERE name = ?', {jobName})
    if result then
        return { exists = true, label = result.label or jobName }
    end

    return { exists = false }
end

function ESX:CreateJob(jobName, jobLabel)
    MySQL.insert.await('INSERT IGNORE INTO jobs (name, label) VALUES (?, ?)', {jobName, jobLabel})
    MySQL.insert.await('INSERT IGNORE INTO job_grades (job_name, grade, name, label, salary, skin_male, skin_female) VALUES (?, ?, ?, ?, ?, ?, ?)', {
        jobName, 0, 'recruit', 'Recruit', 500, '{}', '{}'
    })

    if self.Core.RefreshJobs then
        self.Core.RefreshJobs()
    end

    return true
end

function ESX:DeleteJob(jobName)
    MySQL.query.await('DELETE FROM jobs WHERE name = ?', {jobName})
    MySQL.query.await('DELETE FROM job_grades WHERE job_name = ?', {jobName})
    if self.Core.RefreshJobs then
        self.Core.RefreshJobs()
    end
end

local function sameEsxJob(existing, label, grades)
    if not existing then return false end
    if (existing.label or '') ~= (label or '') then return false end
    local prevGrades = existing.grades or {}
    local count = 0
    for _, g in ipairs(grades or {}) do
        count = count + 1
        local prev = prevGrades[tostring(g.grade)] or prevGrades[tonumber(g.grade)]
        if not prev then return false end
        if (prev.name or '') ~= (g.name or '') then return false end
        if (prev.label or '') ~= (g.label or '') then return false end
        if (tonumber(prev.salary) or 0) ~= (tonumber(g.salary) or 0) then return false end
    end
    local prevCount = 0
    for _ in pairs(prevGrades) do prevCount = prevCount + 1 end
    return prevCount == count
end

local function writeJob(oldJobName, newJobName, newLabel, grades)
    if oldJobName ~= newJobName then
        MySQL.update.await('UPDATE jobs SET name = ?, label = ? WHERE name = ?', {newJobName, newLabel, oldJobName})
        MySQL.update.await('UPDATE job_grades SET job_name = ? WHERE job_name = ?', {newJobName, oldJobName})
    else
        MySQL.update.await('UPDATE jobs SET label = ? WHERE name = ?', {newLabel, oldJobName})
    end

    if grades then
        for _, gradeData in ipairs(grades) do
            local affected = MySQL.update.await('UPDATE job_grades SET name = ?, label = ?, salary = ? WHERE job_name = ? AND grade = ?', {
                gradeData.name, gradeData.label, gradeData.salary, newJobName, gradeData.grade
            })
            if (tonumber(affected) or 0) == 0 then
                MySQL.insert.await('INSERT INTO job_grades (job_name, grade, name, label, salary, skin_male, skin_female) VALUES (?, ?, ?, ?, ?, ?, ?)', {
                    newJobName, gradeData.grade, gradeData.name, gradeData.label, gradeData.salary, '{}', '{}'
                })
            end
        end
    end
end

function ESX:UpdateJob(oldJobName, newJobName, newLabel, grades)
    local live = self.Core.GetJobs and self.Core.GetJobs() or {}
    if oldJobName == newJobName and sameEsxJob(live[newJobName], newLabel, grades) then
        return
    end

    writeJob(oldJobName, newJobName, newLabel, grades)

    if self.Core.RefreshJobs then
        self.Core.RefreshJobs()
    end
end

function ESX:UpdateJobs(menus)
    local live = self.Core.GetJobs and self.Core.GetJobs() or {}
    local written = 0
    for i = 1, #menus do
        local menu = menus[i]
        if not sameEsxJob(live[menu.name], menu.label or menu.name, menu.grades) then
            writeJob(menu.name, menu.name, menu.label or menu.name, menu.grades)
            written = written + 1
        end
    end
    if written > 0 and self.Core.RefreshJobs then
        self.Core.RefreshJobs()
    end
    print(("^2[INFO]^0 BossMenu: ESX jobs - %s written, %s already up to date."):format(written, #menus - written))
    return written
end
function ESX:FireEmployee(src, identifier)
    invalidateEmployees()
    local srcPlayer = self:GetPlayer(src)
    if srcPlayer then
        local srcIdentifier = srcPlayer.getIdentifier()
        if srcIdentifier == identifier then
            Notify:Show(src, locale('notify.cannot_fire_self') or 'You cannot fire yourself!', 'error')
            return false
        end
    end

    local xPlayer = self.Core.GetPlayerFromIdentifier(identifier)
    if xPlayer then
        xPlayer.setJob('unemployed', 0)
        Notify:Show(xPlayer.source, locale('notify.you_were_fired') or 'You were fired from your job!', 'error')
    else
        MySQL.update.await('UPDATE users SET job = ?, job_grade = ? WHERE identifier = ?', {'unemployed', 0, identifier})
        invalidateEmployees()
    end
    Notify:Show(src, locale('notify.employee_fired') or 'Employee successfully fired!', 'success')
    return true
end

function ESX:SetEmployeeGrade(src, identifier, newGrade)
    invalidateEmployees()
    -- Check if trying to change own grade
    local srcPlayer = self:GetPlayer(src)
    if srcPlayer then
        local srcIdentifier = srcPlayer.getIdentifier()
        if srcIdentifier == identifier then
            Notify:Show(src, locale('notify.cannot_change_own_grade') or 'You cannot change your own grade!', 'error')
            return false
        end
    end

    local xPlayer = self.Core.GetPlayerFromIdentifier(identifier)
    if xPlayer then
        local jobName = xPlayer.getJob().name
        xPlayer.setJob(jobName, newGrade)
        Notify:Show(xPlayer.source, locale('notify.your_grade_changed') or 'Your grade has been changed!', 'info')
    else
        MySQL.update.await('UPDATE users SET job_grade = ? WHERE identifier = ?', {newGrade, identifier})
        invalidateEmployees()
    end
    Notify:Show(src, locale('notify.employee_grade_changed') or 'Employee grade changed successfully!', 'success')
    return true
end

function ESX:GetPlayerName(src)
    local xPlayer = self.Core.GetPlayerFromId(src)
    if xPlayer then
        return xPlayer.getName() or GetPlayerName(src)
    end
    return nil
end

function ESX:HireEmployee(source, targetId, jobName)
    invalidateEmployees()
    -- Check if hiring self
    if tonumber(source) == tonumber(targetId) then
        Notify:Show(source, locale('notify.cannot_hire_self') or 'You cannot hire yourself!', 'error')
        return false
    end

    local xPlayer = self.Core.GetPlayerFromId(targetId)
    if xPlayer then
        xPlayer.setJob(jobName, 0)
        Notify:Show(targetId, string.format(locale('notify.you_were_hired') or 'You have been hired as %s!', jobName), 'success')
        Notify:Show(source, locale('notify.employee_hired') or 'Employee hired successfully!', 'success')
        return true
    end

    Notify:Show(source, locale('notify.player_not_online') or 'Player is not online!', 'error')
    return false
end

function ESX:RemoveMoney(src, account, amount)
    local xPlayer = self:GetPlayer(src)
    if not xPlayer then return false end

    amount = math.floor(tonumber(amount) or -1)
    if amount < 0 then return false end
    if amount == 0 then return true end

    if account == 'cash' then
        if xPlayer.getMoney() < amount then return false end
        xPlayer.removeMoney(amount)
        return true
    end

    local bank = xPlayer.getAccount('bank')
    if not bank or bank.money < amount then return false end
    xPlayer.removeAccountMoney('bank', amount)
    return true
end

function ESX:DepositMoney(source, jobName, amount)
    local xPlayer = self.Core.GetPlayerFromId(source)
    if not xPlayer then return false end

    if xPlayer.getMoney() >= amount then
        if not Society or not Society.AddMoney then return false end
        if Society:AddMoney(jobName, amount) == false then
            Notify:Show(source, (locale('notify.no_company_account') or 'This company has no account to deposit into.'), 'error')
            return false
        end
        xPlayer.removeMoney(amount)
        Notify:Show(source, locale('notify.money_deposited') or 'Money deposited successfully!', 'success')
        return true
    else
        Notify:Show(source, locale('notify.not_enough_money') or 'You do not have enough money!', 'error')
    end
    return false
end

function ESX:WithdrawMoney(source, jobName, amount)
    local xPlayer = self.Core.GetPlayerFromId(source)
    if not xPlayer then return false end

    if Society and Society.GetBalance and Society.RemoveMoney then
        local balance = Society:GetBalance(jobName)
        if balance >= amount then
            if Society:RemoveMoney(jobName, amount) == false then
                Notify:Show(source, locale('notify.society_not_enough') or 'The society does not have enough money!', 'error')
                return false
            end
            xPlayer.addMoney(amount)
            Notify:Show(source, locale('notify.money_withdrawn') or 'Money withdrawn successfully!', 'success')
            return true
        else
            Notify:Show(source, locale('notify.society_not_enough') or 'The society does not have enough money!', 'error')
        end
    end
    return false
end

function ESX:MigrateEmployeeGrades(jobName, moves, newGrades)
    if type(moves) ~= 'table' or #moves == 0 then return end
    invalidateEmployees(jobName)

    local map = {}
    for _, m in ipairs(moves) do
        local from, to = tonumber(m.from), tonumber(m.to)
        if from and to then map[from] = to end
    end

    local players = {}
    if self.Core.GetExtendedPlayers then
        players = self.Core.GetExtendedPlayers('job', jobName) or {}
    else
        for _, playerId in ipairs(GetPlayers()) do
            local xPlayer = self.Core.GetPlayerFromId(playerId)
            if xPlayer and xPlayer.job and xPlayer.job.name == jobName then
                players[#players + 1] = xPlayer
            end
        end
    end
    for _, xPlayer in pairs(players) do
        local to = map[tonumber(xPlayer.job.grade)]
        if to then
            xPlayer.setJob(jobName, to)
        end
    end

    for from, to in pairs(map) do
        MySQL.update.await('UPDATE users SET job_grade = ? WHERE job = ? AND job_grade = ? AND job_grade < 10000', { to + 10000, jobName, from })
    end
    MySQL.update.await('UPDATE users SET job_grade = job_grade - 10000 WHERE job = ? AND job_grade >= 10000', { jobName })
    invalidateEmployees(jobName)

    print(("^2[INFO]^0 BossMenu: migrated %s grade number change(s) for job %s."):format(#moves, jobName))
end

function ESX:AddPlayerMoney(src, amount, reason)
    local xPlayer = self:GetPlayer(src)
    if not xPlayer then return false end
    xPlayer.addAccountMoney('bank', amount)
    return true
end

function ESX:IsOnDuty(src)
    return true
end

Framework = ESX.new()

AddEventHandler('esx:setJob', function()
    invalidateEmployees()
end)

AddEventHandler('esx:playerLoaded', function()
    invalidateEmployees()
end)
