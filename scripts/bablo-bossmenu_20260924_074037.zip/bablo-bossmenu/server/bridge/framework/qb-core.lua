
if GetResourceState('qb-core') ~= 'started' then return end
if GetResourceState('qbx_core') == 'started' then return end

local QB = {}
QB.__index = QB

local UNEMPLOYED_JOB = '{"name":"unemployed","label":"Civilian","payment":10,"onduty":true,"isboss":false,"grade":{"name":"Freelancer","level":0}}'

local function tr(key, fallback)
    if type(locale) == 'function' then
        local ok, value = pcall(locale, key)
        if ok and type(value) == 'string' and value ~= key then
            return value
        end
    end
    return fallback
end

local function notify(src, msg, type)
    if not Notify then return end
    if Notify.Show then
        Notify:Show(src, msg, type)
    elseif Notify.Send then
        Notify:Send(src, 'Boss Menu', msg, type)
    end
end

function QB.new()
    local self = setmetatable({}, QB)
    self.Core = exports['qb-core']:GetCoreObject()
    return self
end

function QB:GetPlayer(src)
    return self.Core.Functions.GetPlayer(tonumber(src))
end

function QB:GetName(src)
    local Player = self:GetPlayer(src)
    if Player and Player.PlayerData.charinfo then
        return ('%s %s'):format(Player.PlayerData.charinfo.firstname or '', Player.PlayerData.charinfo.lastname or ''):gsub('^%s+', ''):gsub('%s+$', '')
    end
    return GetPlayerName(src)
end

function QB:GetPlayerName(src)
    return self:GetName(src)
end

function QB:GetPlayerJob(src)
    local Player = self:GetPlayer(src)
    if not Player then return nil end
    local job = Player.PlayerData.job or {}
    local level = job.grade and job.grade.level or 0

    local isboss = job.isboss or false
    local shared = self.Core.Shared and self.Core.Shared.Jobs and self.Core.Shared.Jobs[job.name]
    local gradeEntry = shared and shared.grades and (shared.grades[tostring(level)] or shared.grades[level])
    if gradeEntry then
        isboss = gradeEntry.isboss or false
    end

    return {
        name = job.name,
        label = job.label,
        grade = level,
        grade_name = job.grade and job.grade.name or "",
        grade_label = job.grade and job.grade.name or "",
        isboss = isboss
    }
end

function QB:HasCreatorPermission(src)
    local Player = self:GetPlayer(src)
    if not Player then return false end

    if not Creator.UsePermissions then return true end

    local candidates = {}
    for i = 1, #Creator.Permissions do
        candidates[#candidates + 1] = Creator.Permissions[i]
    end
    candidates[#candidates + 1] = 'god'
    candidates[#candidates + 1] = 'admin'
    candidates[#candidates + 1] = 'command'

    for i = 1, #candidates do
        local perm = candidates[i]
        local ok, allowed = pcall(function()
            return self.Core.Functions.HasPermission(src, perm)
        end)
        if ok and allowed then return true end
        if IsPlayerAceAllowed(src, perm) then return true end
        if IsPlayerAceAllowed(src, 'qbcore.' .. perm) then return true end
    end

    return false
end

function QB:GetJobGrades(jobName)
    local grades = {}
    local job = self.Core.Shared.Jobs and self.Core.Shared.Jobs[jobName]
    if job and job.grades then
        for grade, gradeData in pairs(job.grades) do
            table.insert(grades, {
                grade = tonumber(grade),
                name = gradeData.name or tostring(grade),
                label = gradeData.name or tostring(grade),
                salary = gradeData.payment or 0,
                isboss = gradeData.isboss and true or false
            })
        end
        table.sort(grades, function(a, b) return (a.grade or 0) < (b.grade or 0) end)
    end
    return grades
end

local employeeRows = {}
local EMPLOYEE_CACHE_MS = 30000
local onlineCitizens = {}

local function invalidateEmployees(jobName)
    if jobName then
        employeeRows[jobName] = nil
    else
        employeeRows = {}
    end
end

function QB:FetchJobRows(jobName)
    local cached = employeeRows[jobName]
    if cached and (GetGameTimer() - cached.at) < EMPLOYEE_CACHE_MS then
        return cached.rows
    end

    local rows = MySQL.query.await("SELECT citizenid, charinfo, job FROM players WHERE job LIKE ? AND JSON_UNQUOTE(JSON_EXTRACT(job, '$.name')) = ?", { '%"' .. jobName .. '"%', jobName }) or {}
    local out = {}
    for _, row in ipairs(rows) do
        local okJob, job = pcall(json.decode, row.job or '{}')
        local okInfo, charinfo = pcall(json.decode, row.charinfo or '{}')
        out[#out + 1] = {
            citizenid = row.citizenid,
            gradeLevel = (okJob and type(job) == 'table' and job.grade and tonumber(job.grade.level)) or 0,
            firstname = okInfo and type(charinfo) == 'table' and charinfo.firstname or nil,
            lastname = okInfo and type(charinfo) == 'table' and charinfo.lastname or nil
        }
    end
    employeeRows[jobName] = { at = GetGameTimer(), rows = out }
    return out
end

function QB:GetJobStats(jobName)
    local stats = { totalEmployees = 0, totalRanks = 0, totalPayroll = 0 }

    local ranks = self:GetJobGrades(jobName)
    stats.totalRanks = #ranks

    local salaryByGrade = {}
    for _, r in ipairs(ranks) do
        salaryByGrade[tostring(r.grade)] = r.salary or 0
    end

    local rows = self:FetchJobRows(jobName)
    stats.totalEmployees = #rows
    for _, row in ipairs(rows) do
        local salary = salaryByGrade[tostring(row.gradeLevel)]
        if salary then
            stats.totalPayroll = stats.totalPayroll + salary
        end
    end

    if Society and Society.GetBalance then
        stats.societyBalance = Society:GetBalance(jobName)
    else
        stats.societyBalance = 0
    end

    return stats
end

function QB:GetJobEmployees(jobName)
    local employees = {}

    local ranks = self:GetJobGrades(jobName)
    local rankData = {}
    for _, r in ipairs(ranks) do
        rankData[tostring(r.grade)] = r
    end

    local hoursByIdentifier = {}
    local hourRows = MySQL.query.await('SELECT identifier, SUM(seconds) AS total FROM bablo_bossmenu_hours WHERE job_name = ? GROUP BY identifier', { jobName })
    if hourRows then
        for _, hr in ipairs(hourRows) do
            hoursByIdentifier[hr.identifier] = tonumber(hr.total) or 0
        end
    end

    local online = {}
    for _, cid in pairs(onlineCitizens) do
        online[cid] = true
    end

    for _, row in ipairs(self:FetchJobRows(jobName)) do
        local rData = rankData[tostring(row.gradeLevel)] or { name = tostring(row.gradeLevel), label = 'Unknown', salary = 0 }

        local name = "Unknown"
        if row.firstname then
            name = row.firstname .. ' ' .. (row.lastname or '')
        end

        local total = hoursByIdentifier[row.citizenid] or 0
        if Hours and Hours.GetActiveSeconds then
            total = total + Hours.GetActiveSeconds(row.citizenid)
        end

        table.insert(employees, {
            identifier = row.citizenid,
            name = name,
            status = online[row.citizenid] and "Online" or "Offline",
            gradeId = row.gradeLevel,
            gradeName = rData.label,
            salary = "$ " .. tostring(rData.salary),
            hours = ('%.1f Hours'):format(total / 3600)
        })
    end

    return employees
end

function QB:GetSharedJob(jobName)
    return self.Core.Shared and self.Core.Shared.Jobs and self.Core.Shared.Jobs[jobName] or nil
end

function QB:GetAllJobs()
    local out = {}
    local jobs = self.Core.Shared and self.Core.Shared.Jobs or {}
    for name, job in pairs(jobs) do
        out[name] = { label = job.label or name, grades = self:GetJobGrades(name) }
    end
    return out
end

function QB:CheckJobExists(jobName)
    local job = self.Core.Shared.Jobs and self.Core.Shared.Jobs[jobName]
    if job then
        return { exists = true, label = job.label or jobName }
    end
    return { exists = false }
end

local function toQbGrades(grades, existing, bossGrades)
    local out = {}
    local highest = nil
    for _, g in ipairs(grades or {}) do
        local num = tonumber(g.grade)
        if num and (not highest or num > highest) then
            highest = num
        end
    end
    local bossSet = {}
    for _, g in ipairs(bossGrades or {}) do
        local num = tonumber(g)
        if num then bossSet[num] = true end
    end
    for _, g in ipairs(grades or {}) do
        local num = tonumber(g.grade)
        if num then
            local prev = existing and existing.grades and (existing.grades[tostring(num)] or existing.grades[num]) or nil
            local entry = {
                name = g.label or g.name or tostring(num),
                payment = tonumber(g.salary) or 0,
                isboss = (bossSet[num] == true) or (num == highest and (existing == nil or (prev ~= nil and prev.isboss == true)))
            }
            if prev then
                for k, v in pairs(prev) do
                    if entry[k] == nil then
                        entry[k] = v
                    end
                end
            end
            out[tostring(num)] = entry
        end
    end
    return out
end

function QB:CreateJob(jobName, jobLabel)
    if self.Core.Shared.Jobs and self.Core.Shared.Jobs[jobName] then
        return true
    end

    local ok = pcall(function()
        exports['qb-core']:AddJob(jobName, {
            label = jobLabel or jobName,
            defaultDuty = true,
            offDutyPay = false,
            grades = { ['0'] = { name = 'Recruit', payment = 500 } }
        })
    end)
    return ok
end

local function buildJobData(existing, label, grades, bossGrades)
    local defaultDuty = true
    if existing ~= nil and existing.defaultDuty ~= nil then
        defaultDuty = existing.defaultDuty
    end
    return {
        label = label,
        type = existing and existing.type or nil,
        defaultDuty = defaultDuty,
        offDutyPay = (existing ~= nil and existing.offDutyPay) or false,
        grades = toQbGrades(grades, existing, bossGrades)
    }
end

local function sameJob(existing, jobData)
    if not existing then return false end
    if (existing.label or '') ~= (jobData.label or '') then return false end
    if (existing.type or '') ~= (jobData.type or '') then return false end
    if (existing.defaultDuty ~= false) ~= (jobData.defaultDuty ~= false) then return false end
    if (existing.offDutyPay == true) ~= (jobData.offDutyPay == true) then return false end

    local count = 0
    for key, g in pairs(jobData.grades) do
        count = count + 1
        local prev = existing.grades and (existing.grades[key] or existing.grades[tonumber(key)])
        if not prev then return false end
        if (prev.name or '') ~= (g.name or '') then return false end
        if (tonumber(prev.payment) or 0) ~= (tonumber(g.payment) or 0) then return false end
        if (prev.isboss == true) ~= (g.isboss == true) then return false end
    end
    local prevCount = 0
    for _ in pairs(existing.grades or {}) do prevCount = prevCount + 1 end
    return prevCount == count
end

function QB:UpdateJob(oldJobName, newJobName, newLabel, grades, bossGrades)
    if oldJobName ~= newJobName then
        pcall(function()
            exports['qb-core']:RemoveJob(oldJobName)
        end)
    end

    local jobs = self.Core.Shared and self.Core.Shared.Jobs or {}
    local existing = jobs[newJobName] or jobs[oldJobName] or nil
    local jobData = buildJobData(existing, newLabel or newJobName, grades, bossGrades)

    if oldJobName == newJobName and sameJob(jobs[newJobName], jobData) then
        return true
    end

    local ok, res = pcall(function()
        return exports['qb-core']:UpdateJob(newJobName, jobData)
    end)
    if not ok or res == false then
        pcall(function()
            exports['qb-core']:AddJob(newJobName, jobData)
        end)
    end
    return true
end

function QB:UpdateJobs(menus)
    local okFresh, fresh = pcall(function() return exports['qb-core']:GetSharedJobs() end)
    if okFresh and type(fresh) == 'table' then
        self.Core.Shared.Jobs = fresh
    else
        pcall(function() self.Core = exports['qb-core']:GetCoreObject() end)
    end
    local jobs = self.Core.Shared and self.Core.Shared.Jobs or {}
    local toAdd, toUpdate = {}, {}
    local addCount = 0

    for i = 1, #menus do
        local menu = menus[i]
        local existing = jobs[menu.name]
        local jobData = buildJobData(existing, menu.label or menu.name, menu.grades, menu.bossMenuGrades)
        if not existing then
            toAdd[menu.name] = jobData
            addCount = addCount + 1
        elseif not sameJob(existing, jobData) then
            toUpdate[#toUpdate + 1] = { name = menu.name, data = jobData }
        end
    end

    if addCount > 0 then
        local ok, res = pcall(function()
            return exports['qb-core']:AddJobs(toAdd)
        end)
        if not ok or res == false then
            for name, data in pairs(toAdd) do
                pcall(function() exports['qb-core']:AddJob(name, data) end)
                Wait(0)
            end
        end
    end

    for i = 1, #toUpdate do
        pcall(function()
            exports['qb-core']:UpdateJob(toUpdate[i].name, toUpdate[i].data)
        end)
        Wait(0)
    end

    print(("^2[INFO]^0 BossMenu: qb-core jobs - %s added, %s updated, %s already up to date."):format(addCount, #toUpdate, #menus - addCount - #toUpdate))
    return addCount + #toUpdate
end

function QB:DeleteJob(jobName)
    pcall(function()
        exports['qb-core']:RemoveJob(jobName)
    end)
end

function QB:FireEmployee(src, identifier)
    invalidateEmployees()
    local srcPlayer = self:GetPlayer(src)
    if srcPlayer and srcPlayer.PlayerData.citizenid == identifier then
        notify(src, tr('notify.cannot_fire_self', 'You cannot fire yourself!'), 'error')
        return false
    end

    local Player = self.Core.Functions.GetPlayerByCitizenId(identifier)
    if Player then
        Player.Functions.SetJob('unemployed', 0)
        notify(Player.PlayerData.source, tr('notify.you_were_fired', 'You have been fired!'), 'error')
    else
        MySQL.update.await('UPDATE players SET job = ? WHERE citizenid = ?', { UNEMPLOYED_JOB, identifier })
    end
    invalidateEmployees()
    notify(src, tr('notify.employee_fired', 'Employee has been fired.'), 'success')
    return true
end

function QB:SetEmployeeGrade(src, identifier, newGrade)
    invalidateEmployees()
    local srcPlayer = self:GetPlayer(src)
    if srcPlayer and srcPlayer.PlayerData.citizenid == identifier then
        notify(src, tr('notify.cannot_change_own_grade', 'You cannot change your own grade!'), 'error')
        return false
    end

    local Player = self.Core.Functions.GetPlayerByCitizenId(identifier)
    if Player then
        local jobName = Player.PlayerData.job.name
        local ok, res = pcall(function()
            return Player.Functions.SetJob(jobName, tonumber(newGrade) or 0)
        end)
        if not ok or res == false then
            notify(src, tr('notify.grade_change_failed', 'Grade change failed - job is not registered.'), 'error')
            return false
        end
        notify(Player.PlayerData.source, tr('notify.your_grade_changed', 'Your grade has been changed.'), 'info')
    else
        local row = MySQL.single.await('SELECT job FROM players WHERE citizenid = ?', { identifier })
        if not row then return false end

        local ok, job = pcall(json.decode, row.job or '{}')
        if not ok or type(job) ~= 'table' or not job.name then return false end

        local gradeNum = tonumber(newGrade) or 0
        local sharedJob = self.Core.Shared.Jobs and self.Core.Shared.Jobs[job.name]
        local gradeData = sharedJob and sharedJob.grades and sharedJob.grades[tostring(gradeNum)]

        job.grade = {
            level = gradeNum,
            name = gradeData and gradeData.name or tostring(gradeNum)
        }
        job.payment = gradeData and gradeData.payment or job.payment
        job.isboss = gradeData and gradeData.isboss or false

        MySQL.update.await('UPDATE players SET job = ? WHERE citizenid = ?', { json.encode(job), identifier })
    end
    invalidateEmployees()
    notify(src, tr('notify.employee_grade_changed', 'Employee grade has been changed.'), 'success')
    return true
end

function QB:HireEmployee(source, targetId, jobName)
    invalidateEmployees()
    if tonumber(source) == tonumber(targetId) then
        notify(source, tr('notify.cannot_hire_self', 'You cannot hire yourself!'), 'error')
        return false
    end

    local Player = self.Core.Functions.GetPlayer(tonumber(targetId))
    if Player then
        local ok, res = pcall(function()
            return Player.Functions.SetJob(jobName, 0)
        end)
        if not ok or res == false then
            notify(source, tr('notify.hire_failed', 'Hire failed - job is not registered.'), 'error')
            return false
        end
        notify(targetId, tr('notify.you_were_hired', 'You have been hired!'), 'success')
        notify(source, tr('notify.employee_hired', 'Employee has been hired.'), 'success')
        return true
    end

    notify(source, tr('notify.player_not_online', 'Player is not online!'), 'error')
    return false
end

function QB:RemoveMoney(src, account, amount)
    local Player = self:GetPlayer(src)
    if not Player then return false end

    amount = math.floor(tonumber(amount) or -1)
    if amount < 0 then return false end
    if amount == 0 then return true end

    if account ~= 'cash' and account ~= 'bank' then return false end

    local ok, res = pcall(function()
        return Player.Functions.RemoveMoney(account, amount, 'bossmenu-store')
    end)
    return (ok and res == true) and true or false
end

function QB:DepositMoney(source, jobName, amount)
    local Player = self:GetPlayer(source)
    if not Player then return false end

    if Player.PlayerData.money.cash >= amount then
        if not Society or not Society.AddMoney then return false end
        if Society:AddMoney(jobName, amount) == false then
            notify(source, tr('notify.no_company_account', 'This company has no account to deposit into.'), 'error')
            return false
        end
        if not Player.Functions.RemoveMoney('cash', amount, 'bossmenu-deposit') then
            if Society.RemoveMoney then Society:RemoveMoney(jobName, amount) end
            return false
        end
        notify(source, tr('notify.money_deposited', 'Money deposited to society.'), 'success')
        return true
    else
        notify(source, tr('notify.not_enough_money', 'You do not have enough cash!'), 'error')
    end
    return false
end

function QB:WithdrawMoney(source, jobName, amount)
    local Player = self:GetPlayer(source)
    if not Player then return false end

    if Society and Society.GetBalance and Society.RemoveMoney then
        local balance = Society:GetBalance(jobName)
        if balance >= amount then
            if Society:RemoveMoney(jobName, amount) == false then
                notify(source, tr('notify.society_not_enough', 'The society does not have enough money!'), 'error')
                return false
            end
            Player.Functions.AddMoney('cash', amount, 'bossmenu-withdraw')
            notify(source, tr('notify.money_withdrawn', 'Money withdrawn from society.'), 'success')
            return true
        else
            notify(source, tr('notify.society_not_enough', 'The society does not have enough money!'), 'error')
        end
    end
    return false
end

Framework = QB.new()

AddEventHandler('QBCore:Server:UpdateObject', function()
    if not Framework then return end
    local ok, jobs = pcall(function() return exports['qb-core']:GetSharedJobs() end)
    if ok and type(jobs) == 'table' and Framework.Core and Framework.Core.Shared then
        Framework.Core.Shared.Jobs = jobs
    else
        Framework.Core = exports['qb-core']:GetCoreObject()
    end
end)

AddEventHandler('onResourceStart', function(resource)
    if resource ~= 'qb-core' or not Framework then return end
    CreateThread(function()
        Wait(1000)
        pcall(function() Framework.Core = exports['qb-core']:GetCoreObject() end)
    end)
end)

AddEventHandler('QBCore:Server:OnJobUpdate', function(src, job)
    invalidateEmployees()
    if OnPlayerJobChanged then
        OnPlayerJobChanged(src)
    end
    if OnJobChangedAttendance then
        OnJobChangedAttendance(src, job)
    end
end)

AddEventHandler('QBCore:Server:PlayerLoaded', function(Player)
    if not (Player and Player.PlayerData) then return end
    if Player.PlayerData.source and Player.PlayerData.citizenid then
        onlineCitizens[Player.PlayerData.source] = Player.PlayerData.citizenid
    end
    invalidateEmployees()
    if OnJobChangedAttendance then
        OnJobChangedAttendance(Player.PlayerData.source, Player.PlayerData.job)
    end
end)

AddEventHandler('QBCore:Server:OnPlayerUnload', function(src)
    onlineCitizens[src] = nil
end)

AddEventHandler('playerDropped', function()
    onlineCitizens[source] = nil
end)

CreateThread(function()
    Wait(1000)
    local ok, players = pcall(function() return Framework.Core.Functions.GetQBPlayers() end)
    if ok and type(players) == 'table' then
        for src, Player in pairs(players) do
            local cid = Player and Player.PlayerData and Player.PlayerData.citizenid
            if cid then onlineCitizens[tonumber(src) or src] = cid end
        end
    end
end)

function QB:MigrateEmployeeGrades(jobName, moves, newGrades)
    if type(moves) ~= 'table' or #moves == 0 then return end
    invalidateEmployees(jobName)

    local byNum = {}
    local top = nil
    for _, g in ipairs(newGrades or {}) do
        local n = tonumber(g.grade)
        if n then
            byNum[n] = g
            if not top or n > top then top = n end
        end
    end

    local map = {}
    for _, m in ipairs(moves) do
        local from, to = tonumber(m.from), tonumber(m.to)
        if from and to then map[from] = to end
    end

    for _, Player in pairs(self.Core.Functions.GetQBPlayers()) do
        local job = Player.PlayerData.job
        if job and job.name == jobName then
            local lvl = job.grade and tonumber(job.grade.level)
            local to = lvl and map[lvl]
            if to then
                Player.Functions.SetJob(jobName, to)
            end
        end
    end

    for from, to in pairs(map) do
        local target = byNum[to]
        local gradeName = target and (target.label or target.name) or tostring(to)
        MySQL.update.await([[
            UPDATE players
            SET job = JSON_SET(job, '$.grade.level', ?, '$.grade.name', ?, '$.isboss', ?)
            WHERE JSON_UNQUOTE(JSON_EXTRACT(job, '$.name')) = ?
              AND JSON_EXTRACT(job, '$.grade.level') = ?
              AND JSON_EXTRACT(job, '$.grade.level') < 10000
        ]], { to + 10000, gradeName, (to == top) and 1 or 0, jobName, from })
    end
    MySQL.update.await([[
        UPDATE players
        SET job = JSON_SET(job, '$.grade.level', CAST(JSON_EXTRACT(job, '$.grade.level') AS SIGNED) - 10000)
        WHERE JSON_UNQUOTE(JSON_EXTRACT(job, '$.name')) = ? AND JSON_EXTRACT(job, '$.grade.level') >= 10000
    ]], { jobName })

    invalidateEmployees(jobName)
    print(("^2[INFO]^0 BossMenu: migrated %s grade number change(s) for job %s."):format(#moves, jobName))
end

function QB:AddPlayerMoney(src, amount, reason)
    local Player = self:GetPlayer(src)
    if not Player then return false end
    return Player.Functions.AddMoney('bank', amount, reason or 'bossmenu-paycheck') and true or false
end

function QB:IsOnDuty(src)
    local Player = self:GetPlayer(src)
    if not Player then return false end
    local job = Player.PlayerData.job or {}
    if job.onduty then return true end
    local shared = self.Core.Shared and self.Core.Shared.Jobs and self.Core.Shared.Jobs[job.name]
    return (shared and shared.offDutyPay) and true or false
end

function QB:RestorePersistedJob(src)
    local Player = self:GetPlayer(src)
    if not Player then return false end

    local citizenid = Player.PlayerData.citizenid
    if not citizenid then return false end

    local current = Player.PlayerData.job or {}
    if current.name and current.name ~= 'unemployed' then return false end

    local row = MySQL.single.await('SELECT job FROM players WHERE citizenid = ?', { citizenid })
    if not row or not row.job then return false end

    local ok, stored = pcall(json.decode, row.job)
    if not ok or type(stored) ~= 'table' or not stored.name or stored.name == 'unemployed' then return false end

    local storedGrade = (stored.grade and tonumber(stored.grade.level)) or 0

    local shared = self.Core.Shared.Jobs and self.Core.Shared.Jobs[stored.name]
    if not shared or type(shared.grades) ~= 'table' then return false end
    if not (shared.grades[tostring(storedGrade)] or shared.grades[storedGrade]) then return false end

    if Player.Functions.SetJob(stored.name, storedGrade) then
        print(("^2[INFO]^0 BossMenu: restored %s to %s grade %s (job data was cleared during login)."):format(citizenid, stored.name, storedGrade))
        return true
    end
    return false
end
