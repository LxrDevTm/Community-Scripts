
if GetResourceState('qbx_core') ~= 'started' then return end

local QBX = {}
QBX.__index = QBX

local UNEMPLOYED_JOB = '{"name":"unemployed","label":"Civilian","payment":10,"onduty":true,"isboss":false,"grade":{"name":"Freelancer","level":0}}'

local function tr(key, fallback)
    if type(locale) == 'function' then
        local ok, value = pcall(locale, key)
        if ok and type(value) == 'string' and value ~= key then
            return value
        end
    end
    return fallback
end

local function notify(src, msg, type)
    if not Notify then return end
    if Notify.Show then
        Notify:Show(src, msg, type)
    elseif Notify.Send then
        Notify:Send(src, 'Boss Menu', msg, type)
    end
end

function QBX.new()
    return setmetatable({}, QBX)
end

function QBX:GetPlayer(src)
    local ok, player = pcall(function()
        return exports.qbx_core:GetPlayer(tonumber(src))
    end)
    if ok then return player end
    return nil
end

function QBX:GetPlayerByCitizenId(citizenid)
    local ok, player = pcall(function()
        return exports.qbx_core:GetPlayerByCitizenId(citizenid)
    end)
    if ok then return player end
    return nil
end

function QBX:GetJobs()
    local ok, jobs = pcall(function()
        return exports.qbx_core:GetJobs()
    end)
    if ok and type(jobs) == 'table' then return jobs end
    return {}
end

function QBX:GetName(src)
    local Player = self:GetPlayer(src)
    if Player and Player.PlayerData.charinfo then
        return ('%s %s'):format(Player.PlayerData.charinfo.firstname or '', Player.PlayerData.charinfo.lastname or ''):gsub('^%s+', ''):gsub('%s+$', '')
    end
    return GetPlayerName(src)
end

function QBX:GetPlayerName(src)
    return self:GetName(src)
end

function QBX:GetPlayerJob(src)
    local Player = self:GetPlayer(src)
    if not Player then return nil end
    local job = Player.PlayerData.job or {}
    local level = job.grade and job.grade.level or 0

    local isboss = job.isboss or false
    local shared = self:GetJobs()[job.name]
    local gradeEntry = shared and shared.grades and (shared.grades[level] or shared.grades[tostring(level)])
    if gradeEntry then
        isboss = gradeEntry.isboss or false
    end

    return {
        name = job.name,
        label = job.label,
        grade = level,
        grade_name = job.grade and job.grade.name or "",
        grade_label = job.grade and job.grade.name or "",
        isboss = isboss
    }
end

function QBX:HasCreatorPermission(src)
    local Player = self:GetPlayer(src)
    if not Player then return false end

    if not Creator.UsePermissions then return true end

    local candidates = {}
    for i = 1, #Creator.Permissions do
        candidates[#candidates + 1] = Creator.Permissions[i]
    end
    candidates[#candidates + 1] = 'god'
    candidates[#candidates + 1] = 'admin'
    candidates[#candidates + 1] = 'command'

    for i = 1, #candidates do
        local perm = candidates[i]
        local ok, allowed = pcall(function()
            return exports.qbx_core:HasPermission(src, perm)
        end)
        if ok and allowed then return true end
        if IsPlayerAceAllowed(src, perm) then return true end
        if IsPlayerAceAllowed(src, 'group.' .. perm) then return true end
        if IsPlayerAceAllowed(src, 'qbox.' .. perm) then return true end
    end

    return false
end

function QBX:GetJobGrades(jobName)
    local grades = {}
    local job = self:GetJobs()[jobName]
    if job and job.grades then
        for grade, gradeData in pairs(job.grades) do
            table.insert(grades, {
                grade = tonumber(grade),
                name = gradeData.name or tostring(grade),
                label = gradeData.name or tostring(grade),
                salary = gradeData.payment or 0,
                isboss = gradeData.isboss and true or false
            })
        end
        table.sort(grades, function(a, b) return (a.grade or 0) < (b.grade or 0) end)
    end
    return grades
end

local employeeRows = {}
local EMPLOYEE_CACHE_MS = 30000
local onlineCitizens = {}

local function invalidateEmployees(jobName)
    if jobName then
        employeeRows[jobName] = nil
    else
        employeeRows = {}
    end
end

function QBX:FetchJobRows(jobName)
    local cached = employeeRows[jobName]
    if cached and (GetGameTimer() - cached.at) < EMPLOYEE_CACHE_MS then
        return cached.rows
    end

    local rows = MySQL.query.await("SELECT citizenid, charinfo, job FROM players WHERE job LIKE ? AND JSON_UNQUOTE(JSON_EXTRACT(job, '$.name')) = ?", { '%"' .. jobName .. '"%', jobName }) or {}
    local out = {}
    for _, row in ipairs(rows) do
        local okJob, job = pcall(json.decode, row.job or '{}')
        local okInfo, charinfo = pcall(json.decode, row.charinfo or '{}')
        out[#out + 1] = {
            citizenid = row.citizenid,
            gradeLevel = (okJob and type(job) == 'table' and job.grade and tonumber(job.grade.level)) or 0,
            firstname = okInfo and type(charinfo) == 'table' and charinfo.firstname or nil,
            lastname = okInfo and type(charinfo) == 'table' and charinfo.lastname or nil
        }
    end
    employeeRows[jobName] = { at = GetGameTimer(), rows = out }
    return out
end

function QBX:GetJobStats(jobName)
    local stats = { totalEmployees = 0, totalRanks = 0, totalPayroll = 0 }

    local ranks = self:GetJobGrades(jobName)
    stats.totalRanks = #ranks

    local salaryByGrade = {}
    for _, r in ipairs(ranks) do
        salaryByGrade[tostring(r.grade)] = r.salary or 0
    end

    local rows = self:FetchJobRows(jobName)
    stats.totalEmployees = #rows
    for _, row in ipairs(rows) do
        local salary = salaryByGrade[tostring(row.gradeLevel)]
        if salary then
            stats.totalPayroll = stats.totalPayroll + salary
        end
    end

    if Society and Society.GetBalance then
        stats.societyBalance = Society:GetBalance(jobName)
    else
        stats.societyBalance = 0
    end

    return stats
end

function QBX:GetJobEmployees(jobName)
    local employees = {}

    local ranks = self:GetJobGrades(jobName)
    local rankData = {}
    for _, r in ipairs(ranks) do
        rankData[tostring(r.grade)] = r
    end

    local hoursByIdentifier = {}
    local hourRows = MySQL.query.await('SELECT identifier, SUM(seconds) AS total FROM bablo_bossmenu_hours WHERE job_name = ? GROUP BY identifier', { jobName })
    if hourRows then
        for _, hr in ipairs(hourRows) do
            hoursByIdentifier[hr.identifier] = tonumber(hr.total) or 0
        end
    end

    local online = {}
    for _, cid in pairs(onlineCitizens) do
        online[cid] = true
    end

    for _, row in ipairs(self:FetchJobRows(jobName)) do
        local rData = rankData[tostring(row.gradeLevel)] or { name = tostring(row.gradeLevel), label = 'Unknown', salary = 0 }

        local name = "Unknown"
        if row.firstname then
            name = row.firstname .. ' ' .. (row.lastname or '')
        end

        local total = hoursByIdentifier[row.citizenid] or 0
        if Hours and Hours.GetActiveSeconds then
            total = total + Hours.GetActiveSeconds(row.citizenid)
        end

        table.insert(employees, {
            identifier = row.citizenid,
            name = name,
            status = online[row.citizenid] and "Online" or "Offline",
            gradeId = row.gradeLevel,
            gradeName = rData.label,
            salary = "$ " .. tostring(rData.salary),
            hours = ('%.1f Hours'):format(total / 3600)
        })
    end

    return employees
end

function QBX:GetSharedJob(jobName)
    return self:GetJobs()[jobName]
end

function QBX:GetAllJobs()
    local out = {}
    for name, job in pairs(self:GetJobs()) do
        out[name] = { label = job.label or name, grades = self:GetJobGrades(name) }
    end
    return out
end

function QBX:CheckJobExists(jobName)
    local job = self:GetJobs()[jobName]
    if job then
        return { exists = true, label = job.label or jobName }
    end
    return { exists = false }
end

local function toQbxGrades(grades, existing, bossGrades)
    local out = {}
    local highest = nil
    for _, g in ipairs(grades or {}) do
        local num = tonumber(g.grade)
        if num and (not highest or num > highest) then
            highest = num
        end
    end
    local bossSet = {}
    for _, g in ipairs(bossGrades or {}) do
        local num = tonumber(g)
        if num then bossSet[num] = true end
    end
    for _, g in ipairs(grades or {}) do
        local num = tonumber(g.grade)
        if num then
            local prev = existing and existing.grades and (existing.grades[num] or existing.grades[tostring(num)]) or nil
            local entry = {
                name = g.label or g.name or tostring(num),
                payment = tonumber(g.salary) or 0,
                isboss = (bossSet[num] == true) or (num == highest and (existing == nil or (prev ~= nil and prev.isboss == true)))
            }
            if prev then
                for k, v in pairs(prev) do
                    if entry[k] == nil then
                        entry[k] = v
                    end
                end
            end
            out[num] = entry
        end
    end
    return out
end

function QBX:CreateJob(jobName, jobLabel)
    if self:GetJobs()[jobName] then
        return true
    end

    local ok, success = pcall(function()
        return exports.qbx_core:CreateJobs({
            [jobName] = {
                label = jobLabel or jobName,
                defaultDuty = true,
                offDutyPay = false,
                grades = { [0] = { name = 'Recruit', payment = 500 } }
            }
        })
    end)
    return ok and success ~= false
end

local function buildJobData(existing, label, grades, bossGrades)
    local defaultDuty = true
    if existing ~= nil and existing.defaultDuty ~= nil then
        defaultDuty = existing.defaultDuty
    end
    return {
        label = label,
        type = existing and existing.type or nil,
        defaultDuty = defaultDuty,
        offDutyPay = (existing ~= nil and existing.offDutyPay) or false,
        grades = toQbxGrades(grades, existing, bossGrades)
    }
end

function QBX:UpdateJob(oldJobName, newJobName, newLabel, grades, bossGrades)
    local jobs = self:GetJobs()

    if oldJobName ~= newJobName then
        pcall(function()
            exports.qbx_core:RemoveJob(oldJobName)
        end)
    end

    local existing = jobs[newJobName] or jobs[oldJobName] or nil
    local jobData = buildJobData(existing, newLabel or newJobName, grades, bossGrades)

    local ok, success = pcall(function()
        return exports.qbx_core:CreateJobs({ [newJobName] = jobData })
    end)
    if not ok or success == false then
        print(("^1[ERROR]^0 BossMenu: failed to register job '%s' with qbx_core."):format(newJobName))
    end
end

function QBX:UpdateJobs(menus)
    local jobs = self:GetJobs()
    local batch, count = {}, 0
    for i = 1, #menus do
        local menu = menus[i]
        batch[menu.name] = buildJobData(jobs[menu.name], menu.label or menu.name, menu.grades, menu.bossMenuGrades)
        count = count + 1
    end
    if count == 0 then return 0 end

    local ok, success = pcall(function()
        return exports.qbx_core:CreateJobs(batch)
    end)
    if not ok or success == false then
        print('^1[ERROR]^0 BossMenu: qbx_core rejected the job batch - falling back to one by one.')
        for name, data in pairs(batch) do
            pcall(function() exports.qbx_core:CreateJobs({ [name] = data }) end)
            Wait(0)
        end
    end
    return count
end

function QBX:DeleteJob(jobName)
    pcall(function()
        exports.qbx_core:RemoveJob(jobName)
    end)
end

local function setJob(identifier, jobName, grade)
    local ok, res = pcall(function()
        return exports.qbx_core:SetJob(identifier, jobName, tonumber(grade) or 0)
    end)
    return ok and res ~= false
end

function QBX:FireEmployee(src, identifier)
    invalidateEmployees()
    local srcPlayer = self:GetPlayer(src)
    if srcPlayer and srcPlayer.PlayerData.citizenid == identifier then
        notify(src, tr('notify.cannot_fire_self', 'You cannot fire yourself!'), 'error')
        return false
    end

    local Player = self:GetPlayerByCitizenId(identifier)
    if Player then
        setJob(Player.PlayerData.source, 'unemployed', 0)
        notify(Player.PlayerData.source, tr('notify.you_were_fired', 'You have been fired!'), 'error')
    else
        if not setJob(identifier, 'unemployed', 0) then
            MySQL.update.await('UPDATE players SET job = ? WHERE citizenid = ?', { UNEMPLOYED_JOB, identifier })
        end
    end
    invalidateEmployees()
    notify(src, tr('notify.employee_fired', 'Employee has been fired.'), 'success')
    return true
end

function QBX:SetEmployeeGrade(src, identifier, newGrade)
    invalidateEmployees()
    local srcPlayer = self:GetPlayer(src)
    if srcPlayer and srcPlayer.PlayerData.citizenid == identifier then
        notify(src, tr('notify.cannot_change_own_grade', 'You cannot change your own grade!'), 'error')
        return false
    end

    local Player = self:GetPlayerByCitizenId(identifier)
    if Player then
        local jobName = Player.PlayerData.job.name
        if not setJob(Player.PlayerData.source, jobName, newGrade) then
            notify(src, tr('notify.grade_change_failed', 'Grade change failed - job is not registered.'), 'error')
            return false
        end
        notify(Player.PlayerData.source, tr('notify.your_grade_changed', 'Your grade has been changed.'), 'info')
    else
        local row = MySQL.single.await('SELECT job FROM players WHERE citizenid = ?', { identifier })
        if not row then return false end

        local ok, job = pcall(json.decode, row.job or '{}')
        if not ok or type(job) ~= 'table' or not job.name then return false end

        if not setJob(identifier, job.name, newGrade) then
            notify(src, tr('notify.grade_change_failed', 'Grade change failed - job is not registered.'), 'error')
            return false
        end
    end
    invalidateEmployees()
    notify(src, tr('notify.employee_grade_changed', 'Employee grade has been changed.'), 'success')
    return true
end

function QBX:HireEmployee(source, targetId, jobName)
    invalidateEmployees()
    if tonumber(source) == tonumber(targetId) then
        notify(source, tr('notify.cannot_hire_self', 'You cannot hire yourself!'), 'error')
        return false
    end

    local Player = self:GetPlayer(targetId)
    if Player then
        if not setJob(Player.PlayerData.source, jobName, 0) then
            notify(source, tr('notify.hire_failed', 'Hire failed - job is not registered.'), 'error')
            return false
        end
        notify(targetId, tr('notify.you_were_hired', 'You have been hired!'), 'success')
        notify(source, tr('notify.employee_hired', 'Employee has been hired.'), 'success')
        return true
    end

    notify(source, tr('notify.player_not_online', 'Player is not online!'), 'error')
    return false
end

function QBX:RemoveMoney(src, account, amount)
    local Player = self:GetPlayer(src)
    if not Player then return false end

    amount = math.floor(tonumber(amount) or -1)
    if amount < 0 then return false end
    if amount == 0 then return true end

    if account ~= 'cash' and account ~= 'bank' then return false end

    local ok, res = pcall(function()
        return exports.qbx_core:RemoveMoney(tonumber(src), account, amount, 'bossmenu-store')
    end)
    return (ok and res) and true or false
end

function QBX:DepositMoney(source, jobName, amount)
    local Player = self:GetPlayer(source)
    if not Player then return false end

    if (Player.PlayerData.money and Player.PlayerData.money.cash or 0) >= amount then
        if not Society or not Society.AddMoney then return false end
        if Society:AddMoney(jobName, amount) == false then
            notify(source, tr('notify.no_company_account', 'This company has no account to deposit into.'), 'error')
            return false
        end
        local ok, res = pcall(function()
            return exports.qbx_core:RemoveMoney(tonumber(source), 'cash', amount, 'bossmenu-deposit')
        end)
        if not (ok and res) then
            if Society.RemoveMoney then Society:RemoveMoney(jobName, amount) end
            return false
        end
        notify(source, tr('notify.money_deposited', 'Money deposited to society.'), 'success')
        return true
    else
        notify(source, tr('notify.not_enough_money', 'You do not have enough cash!'), 'error')
    end
    return false
end

function QBX:WithdrawMoney(source, jobName, amount)
    local Player = self:GetPlayer(source)
    if not Player then return false end

    if Society and Society.GetBalance and Society.RemoveMoney then
        local balance = Society:GetBalance(jobName)
        if balance >= amount then
            if Society:RemoveMoney(jobName, amount) == false then
                notify(source, tr('notify.society_not_enough', 'The society does not have enough money!'), 'error')
                return false
            end
            pcall(function()
                return exports.qbx_core:AddMoney(tonumber(source), 'cash', amount, 'bossmenu-withdraw')
            end)
            notify(source, tr('notify.money_withdrawn', 'Money withdrawn from society.'), 'success')
            return true
        else
            notify(source, tr('notify.society_not_enough', 'The society does not have enough money!'), 'error')
        end
    end
    return false
end

function QBX:MigrateEmployeeGrades(jobName, moves, newGrades)
    if type(moves) ~= 'table' or #moves == 0 then return end
    invalidateEmployees(jobName)

    local byNum = {}
    local top = nil
    for _, g in ipairs(newGrades or {}) do
        local n = tonumber(g.grade)
        if n then
            byNum[n] = g
            if not top or n > top then top = n end
        end
    end

    local map = {}
    for _, m in ipairs(moves) do
        local from, to = tonumber(m.from), tonumber(m.to)
        if from and to then map[from] = to end
    end

    local okPlayers, players = pcall(function()
        return exports.qbx_core:GetQBPlayers()
    end)
    if okPlayers and type(players) == 'table' then
        for _, Player in pairs(players) do
            local job = Player.PlayerData.job
            if job and job.name == jobName then
                local lvl = job.grade and tonumber(job.grade.level)
                local to = lvl and map[lvl]
                if to then
                    setJob(Player.PlayerData.source, jobName, to)
                end
            end
        end
    end

    for from, to in pairs(map) do
        local target = byNum[to]
        local gradeName = target and (target.label or target.name) or tostring(to)
        MySQL.update.await([[
            UPDATE players
            SET job = JSON_SET(job, '$.grade.level', ?, '$.grade.name', ?, '$.isboss', ?)
            WHERE JSON_UNQUOTE(JSON_EXTRACT(job, '$.name')) = ?
              AND JSON_EXTRACT(job, '$.grade.level') = ?
              AND JSON_EXTRACT(job, '$.grade.level') < 10000
        ]], { to + 10000, gradeName, (to == top) and 1 or 0, jobName, from })
        pcall(function()
            MySQL.update.await([[
                UPDATE player_groups
                SET grade = ?
                WHERE `group` = ? AND `type` = 'job' AND grade = ? AND grade < 10000
            ]], { to + 10000, jobName, from })
        end)
    end
    MySQL.update.await([[
        UPDATE players
        SET job = JSON_SET(job, '$.grade.level', CAST(JSON_EXTRACT(job, '$.grade.level') AS SIGNED) - 10000)
        WHERE JSON_UNQUOTE(JSON_EXTRACT(job, '$.name')) = ? AND JSON_EXTRACT(job, '$.grade.level') >= 10000
    ]], { jobName })
    pcall(function()
        MySQL.update.await([[
            UPDATE player_groups
            SET grade = grade - 10000
            WHERE `group` = ? AND `type` = 'job' AND grade >= 10000
        ]], { jobName })
    end)

    invalidateEmployees(jobName)
    print(("^2[INFO]^0 BossMenu: migrated %s grade number change(s) for job %s."):format(#moves, jobName))
end

function QBX:AddPlayerMoney(src, amount, reason)
    local Player = self:GetPlayer(src)
    if not Player then return false end
    local ok, res = pcall(function()
        return exports.qbx_core:AddMoney(tonumber(src), 'bank', amount, reason or 'bossmenu-paycheck')
    end)
    return (ok and res) and true or false
end

function QBX:IsOnDuty(src)
    local Player = self:GetPlayer(src)
    if not Player then return false end
    local job = Player.PlayerData.job or {}
    if job.onduty then return true end
    local shared = self:GetJobs()[job.name]
    return (shared and shared.offDutyPay) and true or false
end

function QBX:RestorePersistedJob(src)
    local Player = self:GetPlayer(src)
    if not Player then return false end

    local citizenid = Player.PlayerData.citizenid
    if not citizenid then return false end

    local current = Player.PlayerData.job or {}
    if current.name and current.name ~= 'unemployed' then return false end

    local row = MySQL.single.await('SELECT job FROM players WHERE citizenid = ?', { citizenid })
    if not row or not row.job then return false end

    local ok, stored = pcall(json.decode, row.job)
    if not ok or type(stored) ~= 'table' or not stored.name or stored.name == 'unemployed' then return false end

    local storedGrade = (stored.grade and tonumber(stored.grade.level)) or 0

    local shared = self:GetJobs()[stored.name]
    if not shared or type(shared.grades) ~= 'table' then return false end
    if not (shared.grades[storedGrade] or shared.grades[tostring(storedGrade)]) then return false end

    if setJob(src, stored.name, storedGrade) then
        print(("^2[INFO]^0 BossMenu: restored %s to %s grade %s (job data was cleared during login)."):format(citizenid, stored.name, storedGrade))
        return true
    end
    return false
end

Framework = QBX.new()

AddEventHandler('QBCore:Server:OnJobUpdate', function(src, job)
    invalidateEmployees()
    if OnPlayerJobChanged then
        OnPlayerJobChanged(src)
    end
    if OnJobChangedAttendance then
        OnJobChangedAttendance(src, job)
    end
end)

AddEventHandler('QBCore:Server:PlayerLoaded', function(Player)
    if not (Player and Player.PlayerData) then return end
    if Player.PlayerData.source and Player.PlayerData.citizenid then
        onlineCitizens[Player.PlayerData.source] = Player.PlayerData.citizenid
    end
    invalidateEmployees()
    if OnJobChangedAttendance then
        OnJobChangedAttendance(Player.PlayerData.source, Player.PlayerData.job)
    end
end)

AddEventHandler('QBCore:Server:OnPlayerUnload', function(src)
    onlineCitizens[src] = nil
end)

AddEventHandler('playerDropped', function()
    onlineCitizens[source] = nil
end)

CreateThread(function()
    Wait(1000)
    local ok, players = pcall(function() return exports.qbx_core:GetQBPlayers() end)
    if ok and type(players) == 'table' then
        for src, Player in pairs(players) do
            local cid = Player and Player.PlayerData and Player.PlayerData.citizenid
            if cid then onlineCitizens[tonumber(src) or src] = cid end
        end
    end
end)
