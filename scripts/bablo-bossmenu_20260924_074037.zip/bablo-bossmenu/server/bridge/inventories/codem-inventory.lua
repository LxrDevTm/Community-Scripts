
Inventory = Inventory or {}

CreateThread(function()
    while InventoryName == nil do Wait(100) end
    if InventoryName ~= 'codem-inventory' then return end
    while GetResourceState('codem-inventory') ~= 'started' do Wait(100) end

    print("^2[INFO]^0 BossMenu: Using 'codem-inventory' for the inventory bridge.")

    local items = nil

    function Inventory:getItems()
        if not items then
            items = {}

            local ok, list = pcall(function() return exports['codem-inventory']:GetItemList() end)
            if ok and type(list) == 'table' then
                for k, v in pairs(list) do
                    table.insert(items, {
                        name = v.name or k,
                        label = v.label or v.name or k,
                        description = v.description,
                        image = 'nui://codem-inventory/html/itemimages/' .. (v.image or ((v.name or k) .. '.png')),
                        unique = v.unique
                    })
                end
            end
        end

        return items
    end

    function Inventory:getPlayerItemsCount(src)
        local inventory = exports['codem-inventory']:GetInventory(nil, src)

        if not inventory then
            return false
        end

        local items = {}

        for _, v in pairs(inventory) do
            if not items[v.name] then
                items[v.name] = v.amount
            else
                items[v.name] = items[v.name] + v.amount
            end
        end

        return items
    end

    function Inventory:getPlayerInventory(src)
        local inventory = exports['codem-inventory']:GetInventory(nil, src)

        if not inventory then
            return false
        end

        local items = {}

        for _, v in pairs(inventory) do
            table.insert(items, {
                item = v.name,
                slot = v.slot,
                quantity = v.amount,
                metadata = v.info,
            })
        end

        return items
    end

    function Inventory:addPlayerItem(src, item, amount, metadata, options)
        if options then
            metadata = metadata or {}

            if options.description then
                metadata.description = options.description
            end

            if options.label then
                metadata.label = options.label
            end
        end

        return exports['codem-inventory']:AddItem(src, item, amount, nil, metadata)
    end

    function Inventory:removePlayerItem(src, item, amount)
        return exports['codem-inventory']:RemoveItem(src, item, amount)
    end

    function Inventory:getSpecificPlayerItem(src, data)
        local inventory = exports['codem-inventory']:GetInventory(nil, src)

        if not inventory then
            return false
        end

        for _, item in pairs(inventory) do
            if item.name == data.item and item.slot == data.slot then
                return {
                    item = item.name,
                    metadata = item.info,
                }
            end
        end

        return false
    end

    function Inventory:removeSpecificPlayerItem(src, data, amount)
        return exports['codem-inventory']:RemoveItem(src, data.item, amount, data.slot)
    end

    function Inventory:setMetadata(src, data, metadata)
        exports['codem-inventory']:SetItemMetadata(src, data.slot, metadata)

        return true
    end

    function Inventory:canCarryItems(src, list)
        return true
    end

    function Inventory:openStash(src, id, data)
        TriggerClientEvent('bablo-bossmenu:client:openLegacyStash', src, id, {
            kind = 'codem',
            label = (data and data.label) or id,
            slots = (data and data.slots) or 100,
            maxweight = (data and data.maxweight) or 2000000
        })
        return true
    end

    function Inventory:addToStash(id, item, amount, data)
        local okList, list = pcall(function() return exports['codem-inventory']:GetItemList() end)
        if not okList or type(list) ~= 'table' then return false end

        local def = list[item]
        if not def then
            for _, v in pairs(list) do
                if v.name == item then
                    def = v
                    break
                end
            end
        end
        if not def then return false end

        local okGet, stashItems = pcall(function() return exports['codem-inventory']:GetStashItems(id) end)
        if not okGet or type(stashItems) ~= 'table' then stashItems = {} end

        local merged = false
        local used = {}
        for k, v in pairs(stashItems) do
            local slotNum = tonumber(v.slot) or tonumber(k) or 0
            used[slotNum] = true
            if not merged and v.name == item and not (def.unique or v.unique) then
                v.amount = (tonumber(v.amount) or 0) + amount
                merged = true
            end
        end

        if not merged then
            local slot = 1
            while used[slot] do slot = slot + 1 end
            stashItems[tostring(slot)] = {
                name = item,
                label = def.label or item,
                weight = def.weight or 0,
                type = def.type or 'item',
                amount = amount,
                info = {},
                slot = slot,
                image = def.image or (item .. '.png'),
                unique = def.unique or false,
                useable = def.useable or false,
                shouldClose = def.shouldClose,
                description = def.description or ''
            }
        end

        local okUpd = pcall(function() exports['codem-inventory']:UpdateStash(id, stashItems) end)
        return okUpd
    end
end)
