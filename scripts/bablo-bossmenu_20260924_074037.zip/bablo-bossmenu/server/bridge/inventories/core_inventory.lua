
Inventory = Inventory or {}

CreateThread(function()
    while InventoryName == nil do Wait(100) end
    if InventoryName ~= 'core_inventory' then return end
    while GetResourceState('core_inventory') ~= 'started' do Wait(100) end

    print("^2[INFO]^0 BossMenu: Using 'core_inventory' for the inventory bridge.")

    local items = nil

    function Inventory:getItems()
        if not items then
            items = {}

            for _, v in pairs(exports['core_inventory']:getItemsList()) do
                table.insert(items, {
                    name = v.name,
                    label = v.label or v.name,
                    description = v.description or '',
                    image = 'nui://core_inventory/html/images/' .. (v.image or (v.name and v.name .. '.png' or '')),
                    unique = v.stack == false or v.unique
                })
            end
        end

        return items
    end

    function Inventory:getPlayerItemsCount(src)
        local inventory = exports['core_inventory']:getInventory(src)

        if not inventory then
            return false
        end

        local items = {}

        for _, v in pairs(inventory) do
            if not items[v.name] then
                items[v.name] = v.amount
            else
                items[v.name] = items[v.name] + v.amount
            end
        end

        return items
    end

    function Inventory:getPlayerInventory(src)
        local inventory = exports['core_inventory']:getInventory(src)

        if not inventory then
            return false
        end

        local items = {}

        for _, v in pairs(inventory) do
            table.insert(items, {
                item = v.name,
                slot = v.slot,
                quantity = v.amount,
                metadata = v.metadata,
            })
        end

        return items
    end

    function Inventory:addPlayerItem(src, item, amount, metadata, options)
        if options then
            metadata = metadata or {}

            if options.description then
                metadata.description = options.description
            end

            if options.label then
                metadata.label = options.label
            end
        end

        return exports['core_inventory']:addItem(src, item, amount, metadata)
    end

    function Inventory:removePlayerItem(src, item, amount)
        return exports['core_inventory']:removeItem(src, item, amount)
    end

    function Inventory:getSpecificPlayerItem(src, data)
        local inventory = exports['core_inventory']:getInventory(src)

        if not inventory then
            return false
        end

        for _, item in pairs(inventory) do
            if item.name == data.item and item.slot == data.slot then
                return {
                    item = item.name,
                    metadata = item.metadata,
                }
            end
        end

        return false
    end

    function Inventory:removeSpecificPlayerItem(src, data, amount)
        local inventory = exports['core_inventory']:getInventory(src)

        if not inventory then
            return false
        end

        local item

        for _, v in pairs(inventory) do
            if v.name == data.item and v.slot == data.slot then
                item = v
                break
            end
        end

        if not item then
            return false
        end

        return exports['core_inventory']:removeItemExact(src, item.id, amount)
    end

    function Inventory:setMetadata(src, data, metadata)
        exports['core_inventory']:setMetadata(src, data.slot, metadata)

        return true
    end

    function Inventory:canCarryItem(src, item, amount)
        return exports['core_inventory']:canCarry(src, item, amount)
    end

    function Inventory:openStash(src, id, data)
        local ok = pcall(function()
            exports['core_inventory']:openInventory(src, id, 'stash', (data and data.label) or id, nil, true)
        end)
        return ok
    end

    function Inventory:addToStash(id, item, amount, data)
        local ok, res = pcall(function()
            return exports['core_inventory']:addItem(id, item, amount, {}, 'stash')
        end)
        if not ok or res == false then return false end
        pcall(function() exports['core_inventory']:saveInventory(id) end)
        return true
    end
end)
