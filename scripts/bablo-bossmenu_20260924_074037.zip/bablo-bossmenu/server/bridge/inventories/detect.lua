
Inventory = Inventory or {}

local priority = {
    'tgiann-inventory',
    'qb-inventory',
    'qs-inventory',
    'ps-inventory',
    'ox_inventory',
    'origen_inventory',
    'core_inventory',
    'codem-inventory'
}

InventoryName = nil

CreateThread(function()
    local configured = Settings.Inventory
    if configured and configured ~= 'auto' then
        InventoryName = configured
        print(("^2[INFO]^0 BossMenu: Inventory bridge forced to '%s' via Settings.Inventory."):format(configured))
        return
    end

    while true do
        for i = 1, #priority do
            local state = GetResourceState(priority[i])
            if state == 'started' or state == 'starting' then
                InventoryName = priority[i]
                return
            end
        end
        Wait(500)
    end
end)
