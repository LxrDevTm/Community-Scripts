
Inventory = Inventory or {}

CreateThread(function()
    while InventoryName == nil do Wait(100) end
    if InventoryName ~= 'origen_inventory' then return end
    while GetResourceState('origen_inventory') ~= 'started' do Wait(100) end

    print("^2[INFO]^0 BossMenu: Using 'origen_inventory' for the inventory bridge.")

    local items = nil

    function Inventory:getItems()
        if not items then
            items = {}

            for k, v in pairs(exports['origen_inventory']:Items()) do
                table.insert(items, {
                    name = k,
                    label = v.label or k,
                    description = v.description or '',
                    image = 'nui://origen_inventory/html/images/' .. (v.image or k .. '.png'),
                    unique = v.stack == false or v.unique
                })
            end
        end

        return items
    end

    function Inventory:getPlayerItemsCount(src)
        local inventoryData = exports['origen_inventory']:getInventory(src)

        if not inventoryData then
            return false
        end

        local items = {}

        for _, v in pairs(inventoryData.inventory) do
            if not items[v.name] then
                items[v.name] = v.amount
            else
                items[v.name] = items[v.name] + v.amount
            end
        end

        return items
    end

    function Inventory:getPlayerInventory(src)
        local inventoryData = exports['origen_inventory']:getInventory(src)

        if not inventoryData then
            return false
        end

        local items = {}

        for _, v in pairs(inventoryData.inventory) do
            table.insert(items, {
                item = v.name,
                slot = v.slot,
                quantity = v.amount,
                metadata = v.metadata,
            })
        end

        return items
    end

    function Inventory:addPlayerItem(src, item, amount, metadata, options)
        if options then
            metadata = metadata or {}

            if options.description then
                metadata.description = options.description
            end

            if options.label then
                metadata.label = options.label
            end
        end

        return exports['origen_inventory']:addItem(src, item, amount, metadata)
    end

    function Inventory:removePlayerItem(src, item, amount)
        return exports['origen_inventory']:removeItem(src, item, amount)
    end

    function Inventory:getSpecificPlayerItem(src, data)
        local inventoryData = exports['origen_inventory']:getInventory(src)

        if not inventoryData then
            return false
        end

        for _, item in pairs(inventoryData.inventory) do
            if item.name == data.item and item.slot == data.slot then
                return {
                    item = item.name,
                    metadata = item.metadata,
                }
            end
        end

        return false
    end

    function Inventory:removeSpecificPlayerItem(src, data, amount)
        return exports['origen_inventory']:removeItem(src, data.item, amount, false, data.slot)
    end

    function Inventory:setMetadata(src, data, metadata)
        exports['origen_inventory']:AddItemMetadata(src, data.item, data.slot, metadata)

        return true
    end

    function Inventory:canCarryItem(src, item, amount)
        return exports['origen_inventory']:CanCarryItem(src, item, amount)
    end

    local registeredStashes = {}

    local function ensureStash(id, data)
        if registeredStashes[id] then return end
        local ok = pcall(function()
            exports['origen_inventory']:registerStash(id, {
                label = (data and data.label) or id,
                slots = (data and data.slots) or 100,
                maxweight = (data and data.maxweight) or 2000000
            })
        end)
        if not ok then
            pcall(function()
                exports['origen_inventory']:registerStash(id, (data and data.label) or id, (data and data.slots) or 100, (data and data.maxweight) or 2000000)
            end)
        end
        registeredStashes[id] = true
    end

    function Inventory:openStash(src, id, data)
        ensureStash(id, data)
        local ok = pcall(function()
            exports['origen_inventory']:OpenInventory(src, 'stash', id)
        end)
        if not ok then
            ok = pcall(function()
                exports['origen_inventory']:OpenInventory(src, id, {
                    slots = (data and data.slots) or 100,
                    maxweight = (data and data.maxweight) or 2000000
                })
            end)
        end
        return ok
    end

    function Inventory:addToStash(id, item, amount, data)
        ensureStash(id, data)
        local ok = pcall(function()
            exports['origen_inventory']:addItems(id, { { name = item, item = item, amount = amount, metadata = {} } })
        end)
        if not ok then
            local okSingle, res = pcall(function()
                return exports['origen_inventory']:addItem(id, item, amount, {})
            end)
            if not okSingle or res == false then return false end
        end
        pcall(function() exports['origen_inventory']:saveInventory(id) end)
        return true
    end
end)
