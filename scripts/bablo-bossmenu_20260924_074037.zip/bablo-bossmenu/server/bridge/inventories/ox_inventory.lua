
Inventory = Inventory or {}

CreateThread(function()
    while InventoryName == nil do Wait(100) end
    if InventoryName ~= 'ox_inventory' then return end
    while GetResourceState('ox_inventory') ~= 'started' do Wait(100) end

    print("^2[INFO]^0 BossMenu: Using 'ox_inventory' for the inventory bridge.")

    local items = nil

    function Inventory:getItems()
        if items then return items end

        local ok, list = pcall(function() return exports.ox_inventory:Items() end)
        if not ok or type(list) ~= 'table' then
            print(('^1[ERROR]^0 BossMenu: ox_inventory:Items() failed (%s) - the store item list will be empty.'):format(tostring(list)))
            return {}
        end

        items = {}
        for k, v in pairs(list) do
            if type(v) == 'table' then
                local image = (type(v.client) == 'table' and v.client.image) or (k .. '.png')
                items[#items + 1] = {
                    name = k,
                    label = v.label or k,
                    description = v.description,
                    weight = v.weight or 0,
                    image = 'nui://ox_inventory/web/images/' .. image,
                    unique = v.stack == false or v.unique
                }
            end
        end

        print(('^2[INFO]^0 BossMenu: loaded %s item(s) from ox_inventory.'):format(#items))
        return items
    end

    function Inventory:getPlayerItemsCount(src)
        local inventory = exports.ox_inventory:GetInventory(src)

        if not inventory then
            return false
        end

        local items = {}

        for _, v in pairs(inventory.items) do
            if not items[v.name] then
                items[v.name] = v.count
            else
                items[v.name] = items[v.name] + v.count
            end
        end

        return items
    end

    function Inventory:getPlayerInventory(src)
        local inventory = exports.ox_inventory:GetInventory(src)

        if not inventory then
            return false
        end

        local items = {}

        for _, v in pairs(inventory.items) do
            table.insert(items, {
                item = v.name,
                slot = v.slot,
                quantity = v.count,
                metadata = v.metadata,
            })
        end

        return items
    end

    function Inventory:addPlayerItem(src, item, amount, metadata, options)
        if options then
            metadata = metadata or {}

            if options.description then
                metadata.description = options.description
            end

            if options.label then
                metadata.label = options.label
            end
        end

        return exports.ox_inventory:AddItem(src, item, amount, metadata)
    end

    function Inventory:removePlayerItem(src, item, amount)
        return exports.ox_inventory:RemoveItem(src, item, amount)
    end

    function Inventory:getSpecificPlayerItem(src, data)
        local slot = exports.ox_inventory:GetSlot(src, data.slot)

        if slot then
            return {
                item = slot.name,
                metadata = slot.metadata,
            }
        end

        return false
    end

    function Inventory:removeSpecificPlayerItem(src, data, amount)
        return exports.ox_inventory:RemoveItem(src, data.item, amount, nil, data.slot)
    end

    function Inventory:setMetadata(src, data, metadata)
        exports.ox_inventory:SetMetadata(src, data.slot, metadata)

        return true
    end

    function Inventory:canCarryItems(src, list)
        local totalWeight = 0

        for _, v in pairs(list) do
            local name, amount = v.name, v.amount or 1

            for _, item in pairs(self:getItems()) do
                if item.name == name then
                    totalWeight = totalWeight + item.weight * amount
                    break
                end
            end
        end

        local canCarryWeight = exports.ox_inventory:CanCarryWeight(src, totalWeight)

        return canCarryWeight
    end

    local registeredStashes = {}

    local function ensureStash(id, data)
        if registeredStashes[id] then return end
        pcall(function()
            exports.ox_inventory:RegisterStash(id, (data and data.label) or id, (data and data.slots) or 100, (data and data.maxweight) or 2000000)
        end)
        registeredStashes[id] = true
    end

    function Inventory:openStash(src, id, data)
        ensureStash(id, data)
        local ok = pcall(function()
            exports.ox_inventory:forceOpenInventory(src, 'stash', id)
        end)
        return ok
    end

    function Inventory:addToStash(id, item, amount, data)
        ensureStash(id, data)

        amount = math.floor(tonumber(amount) or 0)
        if amount < 1 then return false end

        local def = nil
        local okDef, list = pcall(function() return exports.ox_inventory:Items() end)
        if okDef and type(list) == 'table' then def = list[item] end

        -- non-stackable items (weapons) need one call per unit, each with its own metadata
        local perCall = (def and (def.stack == false or def.unique)) and 1 or amount
        local remaining = amount

        while remaining > 0 do
            local batch = math.min(perCall, remaining)
            local ok, res = pcall(function()
                return exports.ox_inventory:AddItem(id, item, batch)
            end)
            if not ok or res == false then
                print(('^1[ERROR]^0 BossMenu: ox_inventory rejected %sx %s into %s (%s)'):format(batch, item, id, tostring(res)))
                return false
            end
            remaining = remaining - batch
        end

        return true
    end
end)
