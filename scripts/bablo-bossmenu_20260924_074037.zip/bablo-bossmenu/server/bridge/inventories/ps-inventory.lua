
Inventory = Inventory or {}

CreateThread(function()
    while InventoryName == nil do Wait(100) end
    if InventoryName ~= 'ps-inventory' then return end
    while GetResourceState('ps-inventory') ~= 'started' do Wait(100) end

    QBCore = QBCore or exports['qb-core']:GetCoreObject()

    print("^2[INFO]^0 BossMenu: Using 'ps-inventory' for the inventory bridge.")

    local items = nil

    function Inventory:getItems()
        if not items then
            items = {}

            for k, v in pairs(QBCore.Shared.Items) do
                table.insert(items, {
                    name = k,
                    label = v.label or k,
                    description = v.description,
                    image = 'nui://ps-inventory/html/images/' .. (v.image or k .. '.png'),
                    unique = v.unique,
                })
            end
        end

        return items
    end

    function Inventory:getPlayerItemsCount(src)
        local player = QBCore.Functions.GetPlayer(src)

        if not player then
            return false
        end

        local inventory = player.PlayerData.items

        if not inventory then
            return false
        end

        local items = {}

        for _, v in pairs(inventory) do
            if not items[v.name] then
                items[v.name] = v.amount
            else
                items[v.name] = items[v.name] + v.amount
            end
        end

        return items
    end

    function Inventory:getPlayerInventory(src)
        local player = QBCore.Functions.GetPlayer(src)

        if not player then
            return false
        end

        local inventory = player.PlayerData.items

        if not inventory then
            return false
        end

        local items = {}

        for _, v in pairs(inventory) do
            table.insert(items, {
                item = v.name,
                slot = v.slot,
                quantity = v.amount,
                metadata = v.info,
            })
        end

        return items
    end

    function Inventory:addPlayerItem(src, item, amount, metadata, options)
        local player = QBCore.Functions.GetPlayer(src)

        if not player then
            return false
        end

        if options then
            metadata = metadata or {}

            if options.description then
                metadata.description = options.description
            end

            if options.label then
                metadata.label = options.label
            end
        end

        local res = exports['ps-inventory']:AddItem(src, item, amount, metadata or {})

        if not res then
            return false
        end

        TriggerClientEvent('inventory:client:ItemBox', src, QBCore.Shared.Items[item], 'add', amount)

        if Player(src).state.inv_busy then
            TriggerClientEvent('inventory:client:UpdatePlayerInventory', src, false)
        end

        return true
    end

    function Inventory:removePlayerItem(src, item, amount)
        local player = QBCore.Functions.GetPlayer(src)

        if not player then
            return false
        end

        local res = exports['ps-inventory']:RemoveItem(src, item, amount)

        if res then
            TriggerClientEvent('inventory:client:ItemBox', src, QBCore.Shared.Items[item], 'remove', amount)

            if Player(src).state.inv_busy then
                TriggerClientEvent('inventory:client:UpdatePlayerInventory', src, false)
            end
        end

        return res
    end

    function Inventory:getSpecificPlayerItem(src, data)
        local player = QBCore.Functions.GetPlayer(src)

        if not player then
            return false
        end

        local item = exports['ps-inventory']:GetItemBySlot(src, data.slot)

        if not item then
            return false
        end

        return {
            item = item.name,
            metadata = item.info,
        }
    end

    function Inventory:removeSpecificPlayerItem(src, data, amount)
        local player = QBCore.Functions.GetPlayer(src)

        if not player then
            return false
        end

        local res = exports['ps-inventory']:RemoveItem(src, data.item, amount, data.slot)

        if res then
            TriggerClientEvent('inventory:client:ItemBox', src, QBCore.Shared.Items[data.item], 'remove', amount)

            if Player(src).state.inv_busy then
                TriggerClientEvent('inventory:client:UpdatePlayerInventory', src, false)
            end
        end

        return res
    end

    function Inventory:setMetadata(src, data, metadata)
        local player = QBCore.Functions.GetPlayer(src)

        if not player then
            return false
        end

        local item = player.PlayerData.items[data.slot]

        if not item or item.name ~= data.item then
            return false
        end

        item.info = metadata

        player.Functions.SetPlayerData("items", player.PlayerData.items)

        if Player(src).state.inv_busy then
            TriggerClientEvent('inventory:client:UpdatePlayerInventory', src, false)
        end

        return true
    end

    function Inventory:canCarryItems(src, list)
        return true
    end

    function Inventory:openStash(src, id, data)
        local ok = pcall(function()
            exports['ps-inventory']:OpenInventory('stash', id, {
                maxweight = (data and data.maxweight) or 2000000,
                slots = (data and data.slots) or 100
            }, src)
        end)
        if not ok then
            TriggerClientEvent('bablo-bossmenu:client:openLegacyStash', src, id, data)
        end
        return true
    end

    function Inventory:addToStash(id, item, amount, data)
        local shared = QBCore.Shared.Items[item]
        if not shared then return false end

        local row = MySQL.single.await('SELECT items FROM stashitems WHERE stash = ?', { id })
        local stashItems = {}
        if row and row.items then
            local ok, decoded = pcall(json.decode, row.items)
            if ok and type(decoded) == 'table' then
                stashItems = decoded
            end
        end

        local placed = false
        local maxSlot = 0
        for _, it in pairs(stashItems) do
            local slotNum = tonumber(it.slot) or 0
            if slotNum > maxSlot then maxSlot = slotNum end
            if it.name == item and not shared.unique then
                it.amount = (tonumber(it.amount) or 0) + amount
                placed = true
                break
            end
        end

        if not placed then
            stashItems[#stashItems + 1] = {
                name = item,
                amount = amount,
                info = {},
                label = shared.label or item,
                description = shared.description or '',
                weight = shared.weight or 0,
                type = shared.type or 'item',
                unique = shared.unique or false,
                useable = shared.useable or false,
                image = shared.image or (item .. '.png'),
                shouldClose = shared.shouldClose or false,
                slot = maxSlot + 1
            }
        end

        local encoded = json.encode(stashItems)
        MySQL.prepare('INSERT INTO stashitems (stash, items) VALUES (?, ?) ON DUPLICATE KEY UPDATE items = ?', { id, encoded, encoded })
        return true
    end
end)
