
Inventory = Inventory or {}

CreateThread(function()
    while InventoryName == nil do Wait(100) end
    if InventoryName ~= 'qb-inventory' then return end
    while GetResourceState('qb-inventory') ~= 'started' do Wait(100) end

    QBCore = QBCore or exports['qb-core']:GetCoreObject()

    print("^2[INFO]^0 BossMenu: Using 'qb-inventory' for the inventory bridge.")

    local cachedItems = nil

    function Inventory:getItems()
        if cachedItems then return cachedItems end

        cachedItems = {}
        for k, v in pairs(QBCore.Shared.Items) do
            table.insert(cachedItems, {
                name = k,
                label = v.label or k,
                image = 'nui://qb-inventory/html/images/' .. (v.image or k .. '.png'),
            })
        end

        return cachedItems
    end

    function Inventory:getPlayerItemsCount(src)
        local player = QBCore.Functions.GetPlayer(src)

        if not player then
            return false
        end

        local inventory = player.PlayerData.items

        if not inventory then
            return false
        end

        local items = {}

        for _, v in pairs(inventory) do
            if not items[v.name] then
                items[v.name] = v.amount
            else
                items[v.name] = items[v.name] + v.amount
            end
        end

        return items
    end

    function Inventory:getPlayerInventory(src)
        local player = QBCore.Functions.GetPlayer(src)

        if not player then
            return false
        end

        local inventory = player.PlayerData.items

        if not inventory then
            return false
        end

        local items = {}

        for _, v in pairs(inventory) do
            table.insert(items, {
                item = v.name,
                slot = v.slot,
                quantity = v.amount,
                metadata = v.info,
            })
        end

        return items
    end

    function Inventory:addPlayerItem(src, item, amount, metadata, options)
        local player = QBCore.Functions.GetPlayer(src)

        if not player then
            return false
        end

        if options then
            metadata = metadata or {}

            if options.description then
                metadata.description = options.description
            end

            if options.label then
                metadata.label = options.label
            end
        end

        local res = exports['qb-inventory']:AddItem(src, item, amount, false, metadata or false,
            'bablo-bossmenu:addPlayerItem')

        if not res then
            return false
        end

        TriggerClientEvent('qb-inventory:client:ItemBox', src, QBCore.Shared.Items[item], 'add', amount)

        if Player(src).state.inv_busy then
            TriggerClientEvent('qb-inventory:client:updateInventory', src)
        end

        return true
    end

    function Inventory:removePlayerItem(src, item, amount)
        local player = QBCore.Functions.GetPlayer(src)

        if not player then
            return false
        end

        local res = exports['qb-inventory']:RemoveItem(src, item, amount, false, 'bablo-bossmenu:removePlayerItem')

        if res then
            TriggerClientEvent('qb-inventory:client:ItemBox', src, QBCore.Shared.Items[item], 'remove', amount)

            if Player(src).state.inv_busy then
                TriggerClientEvent('qb-inventory:client:updateInventory', src)
            end
        end

        return res
    end

    function Inventory:getSpecificPlayerItem(src, data)
        local player = QBCore.Functions.GetPlayer(src)

        if not player then
            return false
        end

        local item = exports['qb-inventory']:GetItemBySlot(src, data.slot)

        if not item then
            return false
        end

        return {
            item = item.name,
            metadata = item.info,
        }
    end

    function Inventory:removeSpecificPlayerItem(src, data, amount)
        local player = QBCore and QBCore.Functions.GetPlayer(src)

        if not player then
            return false
        end

        local res = exports['qb-inventory']:RemoveItem(src, data.item, amount, data.slot,
            'bablo-bossmenu:removePlayerItem')

        if res then
            TriggerClientEvent('qb-inventory:client:ItemBox', src, QBCore.Shared.Items[data.item], 'remove', amount)

            if Player(src).state.inv_busy then
                TriggerClientEvent('qb-inventory:client:updateInventory', src)
            end
        end

        return res
    end

    function Inventory:setMetadata(src, data, metadata)
        local player = QBCore.Functions.GetPlayer(src)

        if not player then
            return false
        end

        local item = player.PlayerData.items[data.slot]

        if not item or item.name ~= data.item then
            return false
        end

        item.info = metadata

        player.Functions.SetPlayerData("items", player.PlayerData.items)

        if Player(src).state.inv_busy then
            TriggerClientEvent('inventory:client:UpdatePlayerInventory', src, false)
        end

        return true
    end

    function Inventory:canCarryItem(src, item, amount)
        local canAdd, reason = exports['qb-inventory']:CanAddItem(src, item, amount)

        return canAdd
    end

    local function ensureStash(id, data)
        local ok, inv = pcall(function() return exports['qb-inventory']:GetInventory(id) end)
        if ok and inv then return end
        pcall(function()
            exports['qb-inventory']:CreateInventory(id, {
                label = (data and data.label) or id,
                maxweight = (data and data.maxweight) or 2000000,
                slots = (data and data.slots) or 100
            })
        end)
    end

    function Inventory:openStash(src, id, data)
        ensureStash(id, data)
        local ok = pcall(function()
            exports['qb-inventory']:OpenInventory(src, id, {
                label = (data and data.label) or id,
                maxweight = (data and data.maxweight) or 2000000,
                slots = (data and data.slots) or 100
            })
        end)
        return ok
    end

    function Inventory:addToStash(id, item, amount, data)
        ensureStash(id, data)
        local ok, res = pcall(function()
            return exports['qb-inventory']:AddItem(id, item, amount, false, false, 'bablo-bossmenu:delivery')
        end)
        if not ok or not res then return false end

        local okInv, inv = pcall(function() return exports['qb-inventory']:GetInventory(id) end)
        if okInv and inv and inv.items then
            local encoded = json.encode(inv.items)
            MySQL.prepare('INSERT INTO inventories (identifier, items) VALUES (?, ?) ON DUPLICATE KEY UPDATE items = ?', { id, encoded, encoded })
        end
        return true
    end
end)
