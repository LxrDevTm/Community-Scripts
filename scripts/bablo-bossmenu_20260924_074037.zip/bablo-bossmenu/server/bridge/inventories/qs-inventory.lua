
Inventory = Inventory or {}

CreateThread(function()
    while InventoryName == nil do Wait(100) end
    if InventoryName ~= 'qs-inventory' then return end
    while GetResourceState('qs-inventory') ~= 'started' do Wait(100) end

    print("^2[INFO]^0 BossMenu: Using 'qs-inventory' for the inventory bridge.")

    local items = nil

    function Inventory:getItems()
        if not items then
            items = {}

            for k, v in pairs(exports['qs-inventory']:GetItemList()) do
                if v and type(v) == 'table' then
                    table.insert(items, {
                        name = k,
                        label = v.label or k,
                        description = v.description or '',
                        image = 'nui://qs-inventory/html/images/' .. (v.image or k .. '.png'),
                        unique = v.stack == false or v.unique
                    })
                end
            end
        end

        return items
    end

    function Inventory:getPlayerItemsCount(src)
        local inventory = exports['qs-inventory']:GetInventory(src)

        if not inventory then
            return false
        end

        local items = {}

        for _, v in pairs(inventory) do
            if not items[v.name] then
                items[v.name] = v.amount
            else
                items[v.name] = items[v.name] + v.amount
            end
        end

        return items
    end

    function Inventory:getPlayerInventory(src)
        local inventory = exports['qs-inventory']:GetInventory(src)

        if not inventory then
            return false
        end

        local items = {}

        for _, v in pairs(inventory) do
            table.insert(items, {
                item = v.name,
                slot = v.slot,
                quantity = v.amount,
                metadata = v.info,
            })
        end

        return items
    end

    function Inventory:addPlayerItem(src, item, amount, metadata, options)
        if options then
            metadata = metadata or {}

            if options.description then
                metadata.description = options.description
            end

            if options.label then
                metadata.label = options.label
            end
        end

        return exports['qs-inventory']:AddItem(src, item, amount, nil, metadata)
    end

    function Inventory:removePlayerItem(src, item, amount)
        return exports['qs-inventory']:RemoveItem(src, item, amount)
    end

    function Inventory:getSpecificPlayerItem(src, data)
        local inventory = exports['qs-inventory']:GetInventory(src)

        if not inventory then
            return false
        end

        for _, item in pairs(inventory) do
            if item.name == data.item and item.slot == data.slot then
                return {
                    item = item.name,
                    metadata = item.info,
                }
            end
        end

        return false
    end

    function Inventory:removeSpecificPlayerItem(src, data, amount)
        return exports['qs-inventory']:RemoveItem(src, data.item, amount, data.slot)
    end

    function Inventory:setMetadata(src, data, metadata)
        exports['qs-inventory']:SetItemMetadata(src, data.slot, metadata)

        return true
    end

    function Inventory:canCarryItem(src, item, amount)
        return exports['qs-inventory']:CanCarryItem(src, item, amount)
    end

    function Inventory:openStash(src, id, data)
        TriggerClientEvent('bablo-bossmenu:client:openLegacyStash', src, id, data)
        return true
    end

    function Inventory:addToStash(id, item, amount, data)
        local ok, res = pcall(function()
            return exports['qs-inventory']:AddItemIntoStash(id, item, amount, nil, nil, (data and data.slots) or 100, (data and data.maxweight) or 2000000)
        end)
        return (ok and res ~= false) and true or false
    end
end)
