
Inventory = Inventory or {}

CreateThread(function()
    while InventoryName == nil do Wait(100) end
    if InventoryName ~= 'tgiann-inventory' then return end
    while GetResourceState('tgiann-inventory') ~= 'started' do Wait(100) end

    print("^2[INFO]^0 BossMenu: Using 'tgiann-inventory' for the inventory bridge.")

    local items = nil

    function Inventory:getItems()
        if not items then
            items = {}

            for k, v in pairs(exports['tgiann-inventory']:Items()) do
                table.insert(items, {
                    name = k,
                    label = v.label or k,
                    description = v.description,
                    image = 'nui://inventory_images/images/' .. (v.image or (v.name and v.name .. '.png' or '')),
                    unique = v.stack == false or v.unique
                })
            end
        end

        return items
    end

    function Inventory:getPlayerInventory(src)
        local inventory = exports['tgiann-inventory']:GetPlayerItems(src)

        if not inventory then
            return false
        end

        local items = {}

        for _, v in pairs(inventory) do
            table.insert(items, {
                item = v.name,
                slot = v.slot,
                quantity = v.amount,
                metadata = v.metadata or {},
            })
        end
        return items
    end

    function Inventory:getPlayerItemsCount(src)
        local inventory = exports['tgiann-inventory']:GetPlayerItems(src)

        if not inventory then
            return false
        end

        local items = {}

        for _, v in pairs(inventory) do
            if not items[v.name] then
                items[v.name] = v.amount
            else
                items[v.name] = items[v.name] + v.amount
            end
        end

        return items
    end

    function Inventory:addPlayerItem(src, item, amount, metadata, options)
        if options then
            metadata = metadata or {}

            if options.description then
                metadata.description = options.description
            end

            if options.label then
                metadata.label = options.label
            end
        end

        return exports['tgiann-inventory']:AddItem(src, item, amount, nil, metadata) ~= false
    end

    function Inventory:removePlayerItem(src, item, amount)
        return exports['tgiann-inventory']:RemoveItem(src, item, amount) ~= false
    end

    function Inventory:getSpecificPlayerItem(src, data)
        local item = exports['tgiann-inventory']:GetItemBySlot(src, data.slot)

        if not item then
            return false
        end

        return {
            item = item.name,
            metadata = item.metadata or {},
        }
    end

    function Inventory:removeSpecificPlayerItem(src, data, amount)
        return exports['tgiann-inventory']:RemoveItem(src, data.item, amount, data.slot)
    end

    function Inventory:setMetadata(src, data, metadata)
        local item = exports['tgiann-inventory']:GetItemBySlot(src, data.slot, metadata)

        if not item or item.name ~= data.item then
            return false
        end

        item.info = metadata

        return exports['tgiann-inventory']:SetItemData(src, item.name, data.slot, metadata)
    end

    function Inventory:canCarryItems(src, list)
        return exports["tgiann-inventory"]:CanCarryItems(src, list)
    end

    local registeredStashes = {}

    local function ensureStash(id, data)
        if registeredStashes[id] then return end
        pcall(function()
            exports['tgiann-inventory']:RegisterStash({
                stashName = id,
                label = (data and data.label) or id,
                slots = (data and data.slots) or 100,
                maxWeight = (data and data.maxweight) or 2000000
            })
        end)
        registeredStashes[id] = true
    end

    function Inventory:openStash(src, id, data)
        ensureStash(id, data)
        local ok = pcall(function()
            exports['tgiann-inventory']:OpenInventory(src, 'stash', id, {
                label = (data and data.label) or id,
                slots = (data and data.slots) or 100,
                maxWeight = (data and data.maxweight) or 2000000,
                maxweight = (data and data.maxweight) or 2000000
            })
        end)
        return ok
    end

    function Inventory:addToStash(id, item, amount, data)
        ensureStash(id, data)
        local ok, res = pcall(function()
            return exports['tgiann-inventory']:AddItemToSecondaryInventory('stash', id, item, amount)
        end)
        return (ok and res ~= false) and true or false
    end
end)
