
if GetResourceState('es_extended') ~= 'started' then return end

Notify = {}

function Notify:Show(src, msg, type)
    TriggerClientEvent('esx:showNotification', src, msg)
end
