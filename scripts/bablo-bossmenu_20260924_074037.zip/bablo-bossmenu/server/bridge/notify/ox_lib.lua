
if GetResourceState('ox_lib') ~= 'started' then return end

Notify = {}

function Notify:Show(src, msg, type)
    if type == nil then type = 'inform' end
    TriggerClientEvent('ox_lib:notify', src, {description = msg, type = type})
end
