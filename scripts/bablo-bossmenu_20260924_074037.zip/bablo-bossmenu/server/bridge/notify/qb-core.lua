
if GetResourceState('qb-core') ~= 'started' then return end
if GetResourceState('qbx_core') == 'started' then return end

Notify = {}

function Notify:Show(src, msg, type)
    if type == nil then type = 'primary' end
    TriggerClientEvent('QBCore:Notify', src, msg, type)
end
