
CreateThread(function()
    while SocietyName == nil do Wait(100) end
    if SocietyName ~= 'bablo-banking' then return end
    while GetResourceState('bablo-banking') ~= 'started' do Wait(100) end

    Society = {}

    print("^2[INFO]^0 BossMenu: Using 'bablo-banking' for the society bridge.")

    local function accountNumber(jobName)
        local clean = tostring(jobName):upper():gsub('[^A-Z0-9]', '')
        return 'SOC' .. clean:sub(1, 17)
    end

    local function register(jobName)
        local ok, res = pcall(function()
            return exports['bablo-banking']:RegisterSociety(jobName, {
                accountNumber = accountNumber(jobName),
                label = jobName:sub(1, 1):upper() .. jobName:sub(2),
                access = { 'boss' }
            })
        end)
        if not ok or type(res) ~= 'table' or not res.success then return false end
        print(("^2[INFO]^0 BossMenu: registered society account '%s' for job '%s' in bablo-banking."):format(res.accountNumber, jobName))
        return true
    end

    local function succeeded(res)
        return type(res) == 'table' and res.success == true
    end

    local function accountMissing(res)
        return type(res) == 'table' and res.message == 'SOCIETY_ACCOUNT_NOT_FOUND'
    end

    local function deposit(jobName, amount)
        local ok, res = pcall(function()
            return exports['bablo-banking']:AddSocietyMoney(jobName, amount, ('Boss menu deposit [%s]'):format(jobName))
        end)
        return ok and res or nil
    end

    function Society:GetBalance(jobName)
        local ok, balance = pcall(function()
            return exports['bablo-banking']:GetSocietyBalance(jobName)
        end)
        if not ok then return 0 end
        return tonumber(balance) or 0
    end

    function Society:AddMoney(jobName, amount)
        local res = deposit(jobName, amount)
        if accountMissing(res) and register(jobName) then
            res = deposit(jobName, amount)
        end
        return succeeded(res)
    end

    function Society:RemoveMoney(jobName, amount)
        local ok, res = pcall(function()
            return exports['bablo-banking']:RemoveSocietyMoney(jobName, amount, {
                description = ('Boss menu withdrawal [%s]'):format(jobName)
            })
        end)
        if not ok then return false end
        return succeeded(res)
    end
end)
