
local priority = {
    'bablo-banking',
    'qb-management',
    'esx_addonaccount'
}

SocietyName = nil

CreateThread(function()
    local configured = Settings.Society
    if configured and configured ~= 'auto' then
        SocietyName = configured
        print(("^2[INFO]^0 BossMenu: Society bridge forced to '%s' via Settings.Society."):format(configured))
        return
    end

    local deadline = GetGameTimer() + 60000
    local warned = false

    while true do
        for i = 1, #priority do
            local state = GetResourceState(priority[i])
            if state == 'started' or state == 'starting' then
                SocietyName = priority[i]
                return
            end
        end
        if not warned and GetGameTimer() > deadline then
            warned = true
            print('^3[WARNING]^0 BossMenu: no supported society resource found - deposits, withdrawals and society-funded salaries will not work.')
        end
        Wait(500)
    end
end)
