
CreateThread(function()
    while SocietyName == nil do Wait(100) end
    if SocietyName ~= 'esx_addonaccount' then return end
    while GetResourceState('esx_addonaccount') ~= 'started' do Wait(100) end

    Society = {}

    print("^2[INFO]^0 BossMenu: Using 'esx_addonaccount' for the society bridge.")

    local warnedMissing = {}

    local function GetAccount(jobName)
        local p = promise.new()
        TriggerEvent('esx_addonaccount:getSharedAccount', 'society_' .. jobName, function(account)
            p:resolve(account)
        end)
        local account = Citizen.Await(p)
        if not account and not warnedMissing[jobName] then
            warnedMissing[jobName] = true
            print(("^3[WARNING]^0 BossMenu: no addon_account 'society_%s' exists - society money for this job cannot be stored. Add it to the addon_account table."):format(jobName))
        end
        return account
    end

    function Society:GetBalance(jobName)
        local account = GetAccount(jobName)
        return account and account.money or 0
    end

    function Society:AddMoney(jobName, amount)
        local account = GetAccount(jobName)
        if not account then return false end
        account.addMoney(amount)
        return true
    end

    function Society:RemoveMoney(jobName, amount)
        local account = GetAccount(jobName)
        if not account then return false end
        account.removeMoney(amount)
        return true
    end
end)
