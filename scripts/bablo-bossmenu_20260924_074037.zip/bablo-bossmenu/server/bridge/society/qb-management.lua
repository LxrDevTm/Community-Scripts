
CreateThread(function()
    while SocietyName == nil do Wait(100) end
    if SocietyName ~= 'qb-management' then return end
    while GetResourceState('qb-management') ~= 'started' do Wait(100) end

    Society = {}

    print("^2[INFO]^0 BossMenu: Using 'qb-management' for the society bridge.")

    function Society:GetBalance(jobName)
        local account = exports['qb-management']:GetAccount(jobName)
        if account then
            return account
        end
        return 0
    end

    function Society:AddMoney(jobName, amount)
        local ok = pcall(function() exports['qb-management']:AddMoney(jobName, amount) end)
        return ok
    end

    function Society:RemoveMoney(jobName, amount)
        local ok = pcall(function() exports['qb-management']:RemoveMoney(jobName, amount) end)
        return ok
    end
end)
