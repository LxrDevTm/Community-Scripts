-- ─── Shared helpers ───────────────────────────────────────────────────────────

-- Returns true if two players are within maxDist units of each other
function PlayersAreNearby(sourceA, sourceB, maxDist)
    local pedA = GetPlayerPed(sourceA)
    local pedB = GetPlayerPed(sourceB)
    if not (pedA and pedB) or pedB == 0 then return false end
    local dist = #(GetEntityCoords(pedA) - GetEntityCoords(pedB))
    return dist <= (maxDist or 10.0)
end

-- Validates and sanitises a money amount: must be an integer in [1, 10_000_000]
function SanitiseAmount(raw)
    local amount = math.floor(tonumber(raw) or 0)
    if amount < 1 or amount > 10000000 then return nil end
    return amount
end

-- Logs a transaction row to bablo_bossmenu_transactions
function LogTransaction(jobName, source, txType, amount)
    local playerName = (Framework and Framework.GetName and Framework:GetName(source)) or "Unknown"
    MySQL.query([[
        INSERT INTO bablo_bossmenu_transactions (job_name, name, type, amount, date)
        VALUES (?, ?, ?, ?, DATE_FORMAT(NOW(), '%d. %b - %H:%i'))
    ]], { jobName, playerName, txType, amount })
end

-- Finds an employee in the framework's list for a job, matched by identifier
function FindEmployeeByIdentifier(jobName, identifier)
    if not (Framework and Framework.GetJobEmployees) then return nil end
    local employees = Framework:GetJobEmployees(jobName) or {}
    for _, employee in ipairs(employees) do
        if tostring(employee.identifier) == tostring(identifier) then
            return employee
        end
    end
    return nil
end

-- Resolves a player's display name, trying framework first then ESX then native
function ResolvePlayerName(source)
    if Framework and Framework.GetPlayerName then
        return Framework:GetPlayerName(source)
    end
    local ok, ESX = pcall(function()
        return exports.es_extended:getSharedObject()
    end)
    if ok and ESX then
        local player = ESX.GetPlayerFromId(source)
        if player then
            return player.getName() or GetPlayerName(source)
        end
    end
    return GetPlayerName(source)
end

-- ─── Item cache ───────────────────────────────────────────────────────────────

-- Lazily built item list (populated on first call to GetAllInventoryItems)
local cachedInventoryItems = nil

-- Builds and caches a sorted item list from ox_inventory or qb-core
function GetAllInventoryItems()
    if cachedInventoryItems then return cachedInventoryItems end

    -- ox_inventory
    if GetResourceState("ox_inventory") == "started" then
        local ok, rawItems = pcall(function() return exports.ox_inventory:Items() end)
        if ok and type(rawItems) == "table" then
            local items = {}
            for name, data in pairs(rawItems) do
                if type(data) == "table" then
                    local image = (type(data.client) == "table" and data.client.image)
                        or (name .. ".png")
                    items[#items + 1] = {
                        name  = name,
                        label = tostring(data.label or name),
                        image = "nui://ox_inventory/web/images/" .. image,
                    }
                end
            end
            table.sort(items, function(a, b) return a.label < b.label end)
            cachedInventoryItems = items
            return items
        end
    end

    -- qb-core / ps-inventory
    if GetResourceState("qb-core") ~= "started" then return {} end

    local ok, QBCore = pcall(function() return exports["qb-core"]:GetCoreObject() end)
    if not (ok and QBCore and QBCore.Shared and QBCore.Shared.Items) then return {} end

    local imageBase = GetResourceState("ps-inventory") == "started"
        and "nui://ps-inventory/html/images/"
        or  "nui://qb-inventory/html/images/"

    local items = {}
    for name, data in pairs(QBCore.Shared.Items) do
        items[#items + 1] = {
            name  = name,
            label = tostring(data.label or name),
            image = imageBase .. (data.image or (name .. ".png")),
        }
    end
    table.sort(items, function(a, b) return a.label < b.label end)
    cachedInventoryItems = items
    return items
end

-- ─── Time-window presets for transaction chart ────────────────────────────────

local CHART_WINDOWS = {
    ["12h"] = { hours = 12,  bucketHours = 1  },
    ["24h"] = { hours = 24,  bucketHours = 2  },
    ["7d"]  = { hours = 168, bucketHours = 24 },
    ["14d"] = { hours = 336, bucketHours = 24 },
    ["30d"] = { hours = 720, bucketHours = 48 },
}

-- ─── Callbacks ────────────────────────────────────────────────────────────────

lib.callback.register("bablo-bossmenu:server:getBossMenus", function(source)
    return BossMenu.Cache
end)

lib.callback.register("bablo-bossmenu:server:getJobGrades", function(source, jobName)
    if Framework and Framework.GetJobGrades then
        return Framework:GetJobGrades(jobName)
    end
    return {}
end)

lib.callback.register("bablo-bossmenu:server:getJobStats", function(source, jobName)
    local stats = {
        totalEmployees  = 0,
        totalRanks      = 0,
        revenueToday    = 0,
        totalRevenue    = 0,
        revenueHistory  = {},
    }

    local canView = BossMenu.HasPermission(source, jobName, "view_statistics")
        or BossMenu.HasPermission(source, jobName, "view_transactions")
    if not canView then return stats end

    -- Pull framework-level stats (employee count, rank count, etc.)
    if Framework and Framework.GetJobStats then
        local frameworkStats = Framework:GetJobStats(jobName)
        if type(frameworkStats) == "table" then
            for k, v in pairs(frameworkStats) do stats[k] = v end
        end
    end

    -- Revenue today
    local todayRow = MySQL.query.await(
        "SELECT amount FROM bablo_bossmenu_revenue WHERE job_name = ? AND date = CURDATE()",
        { jobName }
    )
    if todayRow and todayRow[1] then
        stats.revenueToday = todayRow[1].amount or 0
    end

    -- Total revenue (all time)
    local totalRow = MySQL.query.await(
        "SELECT SUM(amount) as total FROM bablo_bossmenu_revenue WHERE job_name = ?",
        { jobName }
    )
    if totalRow and totalRow[1] and totalRow[1].total then
        stats.totalRevenue = tonumber(totalRow[1].total) or 0
    end

    -- Revenue history (last 365 days)
    local history = MySQL.query.await(
        "SELECT DATE_FORMAT(date, \"%Y-%m-%d\") as date, amount FROM bablo_bossmenu_revenue WHERE job_name = ? ORDER BY date ASC LIMIT 365",
        { jobName }
    )
    if history then stats.revenueHistory = history end

    -- Attendance history (last 14 days, grouped by day)
    local attendance = MySQL.query.await(
        "SELECT DATE_FORMAT(date, \"%Y-%m-%d\") as date, COUNT(identifier) as amount FROM bablo_bossmenu_attendance WHERE job_name = ? GROUP BY date ORDER BY date ASC LIMIT 14",
        { jobName }
    )
    if attendance then stats.attendanceHistory = attendance end

    -- Recent transactions (last 50)
    local transactions = MySQL.query.await(
        "SELECT name, type, amount, date FROM bablo_bossmenu_transactions WHERE job_name = ? ORDER BY timestamp DESC LIMIT 50",
        { jobName }
    )
    if transactions then stats.transactions = transactions end

    return stats
end)

lib.callback.register("bablo-bossmenu:server:getJobEmployees", function(source, jobName)
    if not BossMenu.HasPermission(source, jobName, nil) then return {} end
    if Framework and Framework.GetJobEmployees then
        return Framework:GetJobEmployees(jobName)
    end
    return {}
end)

lib.callback.register("bablo-bossmenu:server:fireEmployee", function(source, identifier)
    local playerJob = Framework and Framework.GetPlayerJob and Framework:GetPlayerJob(source)

    if not playerJob or not BossMenu.HasPermission(source, playerJob.name, "fire_employees") then
        Notify:Show(source, Tr("notify.no_permission_fire", "You do not have permission to fire employees."), "error")
        return false
    end

    local employee = FindEmployeeByIdentifier(playerJob.name, identifier)
    if not employee then
        Notify:Show(source, Tr("notify.not_your_employee", "That player does not work for your job."), "error")
        return false
    end

    -- Grade check: non-full-access bosses cannot fire someone at or above their rank
    local menu = BossMenu.GetCached(playerJob.name)
    if menu and not BossMenu.IsFullAccess(playerJob, menu) then
        local bossGrade     = tonumber(playerJob.grade) or 0
        local employeeGrade = tonumber(employee.gradeId) or 0
        if bossGrade <= employeeGrade then
            Notify:Show(source, Tr("notify.cannot_fire_same_rank", "You cannot fire someone of your rank or above."), "error")
            return false
        end
    end

    if Framework and Framework.FireEmployee then
        return Framework:FireEmployee(source, identifier)
    end
    return false
end)

lib.callback.register("bablo-bossmenu:server:setEmployeeGrade", function(source, identifier, newGrade)
    local playerJob = Framework and Framework.GetPlayerJob and Framework:GetPlayerJob(source)

    if not playerJob or not BossMenu.HasPermission(source, playerJob.name, "promote_employees") then
        Notify:Show(source, Tr("notify.no_permission_promote", "You do not have permission to promote or demote employees."), "error")
        return false
    end

    newGrade = tonumber(newGrade)
    if not newGrade then return false end

    -- Verify the target grade actually exists in the cached menu
    local menu = BossMenu.GetCached(playerJob.name)
    if menu then
        local gradeExists = false
        for _, g in ipairs(menu.grades or {}) do
            if tonumber(g.grade) == newGrade then gradeExists = true; break end
        end
        if not gradeExists then return false end
    end

    local employee = FindEmployeeByIdentifier(playerJob.name, identifier)
    if not employee then
        Notify:Show(source, Tr("notify.not_your_employee", "That player does not work for your job."), "error")
        return false
    end

    -- Non-full-access bosses can only manage ranks strictly below their own,
    -- and cannot promote someone to their own grade or above
    if menu and not BossMenu.IsFullAccess(playerJob, menu) then
        local bossGrade     = tonumber(playerJob.grade) or 0
        local employeeGrade = tonumber(employee.gradeId) or 0
        if bossGrade <= employeeGrade or newGrade >= bossGrade then
            Notify:Show(source, Tr("notify.manage_below_rank", "You can only manage ranks below your own."), "error")
            return false
        end
    end

    if Framework and Framework.SetEmployeeGrade then
        return Framework:SetEmployeeGrade(source, identifier, newGrade)
    end
    return false
end)

lib.callback.register("bablo-bossmenu:server:checkFrameworkJob", function(source, jobName)
    if Framework and Framework.CheckJobExists then
        return Framework:CheckJobExists(jobName)
    end
    return { exists = true, label = jobName }
end)

lib.callback.register("bablo-bossmenu:server:createFrameworkJob", function(source, jobName, label)
    if Framework and Framework.HasCreatorPermission and not Framework:HasCreatorPermission(source) then
        return false
    end
    if Framework and Framework.CreateJob then
        return Framework:CreateJob(jobName, label)
    end
    return false
end)

lib.callback.register("bablo-bossmenu:server:getPlayerName", function(source, targetSource)
    local playerJob = Framework and Framework.GetPlayerJob and Framework:GetPlayerJob(source)
    if not playerJob or not BossMenu.HasPermission(source, playerJob.name, "hire_employees") then
        return ""
    end

    targetSource = tonumber(targetSource)
    if not targetSource or not PlayersAreNearby(source, targetSource, 10.0) then
        return ""
    end

    return ResolvePlayerName(targetSource)
end)

lib.callback.register("bablo-bossmenu:server:getPlayersData", function(source, sourcesToCheck)
    local result = {}
    local playerJob = Framework and Framework.GetPlayerJob and Framework:GetPlayerJob(source)

    if not playerJob or not BossMenu.HasPermission(source, playerJob.name, "hire_employees") then
        return result
    end

    if type(sourcesToCheck) ~= "table" or #sourcesToCheck > 64 then
        return result
    end

    for _, targetSource in ipairs(sourcesToCheck) do
        local name = ResolvePlayerName(targetSource)
        if name then
            result[#result + 1] = { id = tostring(targetSource), name = name }
        end
    end
    return result
end)

lib.callback.register("bablo-bossmenu:server:hireEmployee", function(source, targetSource, jobName)
    if not BossMenu.HasPermission(source, jobName, "hire_employees") then
        Notify:Show(source, Tr("notify.no_permission_hire", "You do not have permission to hire employees."), "error")
        return false
    end

    targetSource = tonumber(targetSource)
    if not targetSource or not PlayersAreNearby(source, targetSource, 10.0) then
        Notify:Show(source, Tr("notify.player_not_nearby", "That player is not nearby."), "error")
        return false
    end

    if Framework and Framework.HireEmployee then
        return Framework:HireEmployee(source, targetSource, jobName)
    end

    -- ESX fallback: set job directly via ESX player object
    local ok, ESX = pcall(function() return exports.es_extended:getSharedObject() end)
    if ok and ESX then
        local player = ESX.GetPlayerFromId(targetSource)
        if player then
            player.setJob(jobName, 0)
            return true
        end
    end
    return false
end)

lib.callback.register("bablo-bossmenu:server:depositMoney", function(source, jobName, amount)
    if not BossMenu.HasPermission(source, jobName, "deposit_money") then
        Notify:Show(source, Tr("notify.no_permission_deposit", "You do not have permission to deposit money."), "error")
        return false
    end

    amount = SanitiseAmount(amount)
    if not amount then return false end

    if Framework and Framework.DepositMoney then
        local success = Framework:DepositMoney(source, jobName, amount)
        if success then
            MySQL.query([[
                INSERT INTO bablo_bossmenu_revenue (job_name, amount, date)
                VALUES (?, ?, CURDATE())
                ON DUPLICATE KEY UPDATE amount = amount + ?
            ]], { jobName, amount, amount })
            LogTransaction(jobName, source, "Deposit", amount)
        end
        return success
    end
    return false
end)

lib.callback.register("bablo-bossmenu:server:withdrawMoney", function(source, jobName, amount)
    if not BossMenu.HasPermission(source, jobName, "withdraw_money") then
        Notify:Show(source, Tr("notify.no_permission_withdraw", "You do not have permission to withdraw money."), "error")
        return false
    end

    amount = SanitiseAmount(amount)
    if not amount then return false end

    if Framework and Framework.WithdrawMoney then
        local success = Framework:WithdrawMoney(source, jobName, amount)
        if success then
            LogTransaction(jobName, source, "Withdraw", -amount)
        end
        return success
    end
    return false
end)

lib.callback.register("bablo-bossmenu:server:getInventoryItems", function(source)
    -- Try the Inventory bridge first (highest priority, most up-to-date)
    if Inventory and Inventory.getItems then
        local bridgeItems = Inventory:getItems()
        table.sort(bridgeItems, function(a, b) return tostring(a.label) < tostring(b.label) end)
        print(("^2[INFO]^0 BossMenu: getInventoryItems via bridge -> %s items"):format(#bridgeItems))
        if #bridgeItems > 0 then return bridgeItems end
    end
    return GetAllInventoryItems()
end)

lib.callback.register("bablo-bossmenu:server:purchaseStoreItems", function(source, jobName, cartItems, stashId, preferredStashId)
    if not (Inventory and Inventory.addToStash) then
        Notify:Show(source, Tr("notify.no_inventory", "No supported inventory system is running."), "error")
        return { success = false }
    end

    -- Basic input validation
    if type(jobName) ~= "string"
    or type(cartItems) ~= "table"
    or #cartItems == 0
    or #cartItems > 30 then
        return { success = false }
    end

    -- Player must be working the right job
    local playerJob = Framework and Framework.GetPlayerJob and Framework:GetPlayerJob(source)
    if not playerJob or playerJob.name ~= jobName then
        return { success = false }
    end

    -- Permission check: order_items OR manage_upgrades
    if not BossMenu.HasPermission(source, jobName, "order_items")
    and not BossMenu.HasPermission(source, jobName, "manage_upgrades") then
        Notify:Show(source, Tr("notify.no_permission_order", "You do not have permission to order items."), "error")
        return { success = false }
    end

    local menu = BossMenu.GetCached(jobName)
    if not menu then return { success = false } end

    -- Build a lookup table from the menu's allowed store items
    local allowedItems = {}
    for _, item in ipairs(menu.storeItems or {}) do
        allowedItems[item.name] = item
    end

    local defaultDeliveryMinutes = math.max(1, math.floor(tonumber(menu.storeDeliveryMinutes) or 15))
    local totalCost     = 0
    local maxDelivery   = 0
    local validatedCart = {}

    for _, entry in ipairs(cartItems) do
        if type(entry) ~= "table" then return { success = false } end

        local itemName = entry.name
        local quantity = math.floor(tonumber(entry.quantity) or 0)
        local itemDef  = itemName and allowedItems[itemName]

        -- Reject unknown items, zero quantities, or quantities over 100
        if not itemDef or quantity < 1 or quantity > 100 then
            return { success = false }
        end

        -- Grade restriction
        local minGrade = tonumber(itemDef.minGrade)
        if minGrade then
            local playerGrade = tonumber(playerJob.grade) or 0
            if minGrade > playerGrade then
                local label = itemDef.label or itemName
                Notify:Show(source, Tr("notify.rank_too_low_order", "Your rank is too low to order %s."):format(label), "error")
                return { success = false }
            end
        end

        local unitPrice      = math.max(0, math.floor(tonumber(itemDef.price) or 0))
        local itemDelivery   = math.max(1, math.floor(tonumber(itemDef.deliveryMinutes) or defaultDeliveryMinutes))

        totalCost   = totalCost + unitPrice * quantity
        maxDelivery = math.max(maxDelivery, itemDelivery)
        validatedCart[#validatedCart + 1] = { name = itemName, quantity = quantity }
    end

    -- Resolve delivery stash location
    local stashLocation = Orders and Orders.GetStashLocation
        and Orders.GetStashLocation(menu, preferredStashId or menu.deliveryStash)

    if not stashLocation then
        Notify:Show(source, Tr("notify.stash_required", "Your job needs a stash placed before you can order from the store."), "error")
        return { success = false }
    end

    -- Society balance check and deduction
    if Society and Society.GetBalance then
        local balance = tonumber(Society:GetBalance(jobName)) or 0
        if totalCost > balance then
            Notify:Show(source, Tr("notify.society_cannot_afford_order", "The society cannot afford this order."), "error")
            return { success = false }
        end
    end

    if Society and Society.RemoveMoney then
        local removed = Society:RemoveMoney(jobName, totalCost)
        if not removed then
            Notify:Show(source, Tr("notify.society_cannot_afford_order", "The society cannot afford this order."), "error")
            return { success = false }
        end
    end

    -- Create the order and log the transaction
    Orders.Create(jobName, Orders.StashId(jobName, stashLocation), validatedCart, maxDelivery)
    LogTransaction(jobName, source, "Store Order", -totalCost)

    local msg = Tr("notify.order_paid", "Order paid from society funds ($%s). Delivery arrives in the stash in ~%s min.")
        :format(totalCost, maxDelivery)
    Notify:Show(source, msg, "success")
    return { success = true }
end)

lib.callback.register("bablo-bossmenu:server:getTransactionChart", function(source, jobName, windowKey)
    local empty = { buckets = {}, totalDeposit = 0, totalWithdraw = 0 }

    if type(jobName) ~= "string" then return empty end

    local canView = BossMenu.HasPermission(source, jobName, "view_statistics")
        or BossMenu.HasPermission(source, jobName, "view_transactions")
    if not canView then return empty end

    local window     = CHART_WINDOWS[windowKey] or CHART_WINDOWS["24h"]
    local bucketSecs = window.bucketHours * 3600
    local bucketCount = math.floor(window.hours / window.bucketHours)
    local now         = os.time()
    local windowStart = now - (window.hours * 3600)

    -- Pre-build empty bucket array
    local buckets = {}
    for i = 1, bucketCount do
        local bucketStart = windowStart + (i - 1) * bucketSecs
        local label = window.bucketHours < 24
            and os.date("%H:%M", bucketStart)
            or  os.date("%d %b", bucketStart)
        buckets[i] = { label = label, deposit = 0, withdraw = 0 }
    end

    -- Query deposit/withdraw transactions in the window
    local rows = MySQL.query.await([[
        SELECT type, amount, UNIX_TIMESTAMP(`timestamp`) AS ts
        FROM bablo_bossmenu_transactions
        WHERE job_name = ? AND `timestamp` >= DATE_SUB(NOW(), INTERVAL ? HOUR) AND type IN ('Deposit', 'Withdraw')
    ]], { jobName, window.hours })

    local totalDeposit  = 0
    local totalWithdraw = 0

    if rows then
        for _, row in ipairs(rows) do
            local ts = tonumber(row.ts)
            if ts then
                -- Clamp to valid bucket index
                local bucketIndex = math.floor((ts - windowStart) / bucketSecs) + 1
                bucketIndex = math.max(1, math.min(bucketCount, bucketIndex))

                local absAmount = math.abs(tonumber(row.amount) or 0)
                if row.type == "Deposit" then
                    buckets[bucketIndex].deposit = buckets[bucketIndex].deposit + absAmount
                    totalDeposit = totalDeposit + absAmount
                else
                    buckets[bucketIndex].withdraw = buckets[bucketIndex].withdraw + absAmount
                    totalWithdraw = totalWithdraw + absAmount
                end
            end
        end
    end

    return { buckets = buckets, totalDeposit = totalDeposit, totalWithdraw = totalWithdraw }
end)

lib.callback.register("bablo-bossmenu:server:getAttendanceHistory", function(source, jobName, days)
    if type(jobName) ~= "string" then return {} end
    if not BossMenu.HasPermission(source, jobName, "view_statistics") then return {} end

    -- Only 7 or 14 days are valid; default to 14
    days = tonumber(days)
    if days ~= 7 and days ~= 14 then days = 14 end

    local rows = MySQL.query.await([[
        SELECT DATE_FORMAT(date, '%Y-%m-%d') AS date, COUNT(identifier) AS amount
        FROM bablo_bossmenu_attendance
        WHERE job_name = ? AND date >= DATE_SUB(CURDATE(), INTERVAL ? DAY)
        GROUP BY date
        ORDER BY date ASC
    ]], { jobName, days })

    return rows or {}
end)