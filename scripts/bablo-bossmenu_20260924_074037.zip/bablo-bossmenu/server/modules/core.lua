-- Initialise locale from ox_lib
lib.locale()

-- Tr: safe locale lookup with fallback
function Tr(key, fallback)
    local ok, result = pcall(locale, key)
    if ok and type(result) == "string" and result ~= key then
        return result
    end
    return fallback
end

-- All permissions that can be granted to a grade
local ALL_PERMISSIONS = {
    "view_statistics",
    "order_items",
    "deposit_money",
    "withdraw_money",
    "view_transactions",
    "hire_employees",
    "fire_employees",
    "promote_employees",
    "manage_upgrades",
    "edit_permissions",
}

BossMenu = {
    Cache       = {},
    CacheByName = {},
}

-- ─── Cache helpers ────────────────────────────────────────────────────────────

function BossMenu.GetCached(jobName)
    if BossMenu.CacheByName then
        return BossMenu.CacheByName[jobName]
    end
    for _, entry in ipairs(BossMenu.Cache) do
        if entry.name == jobName then
            return entry
        end
    end
    return nil
end

-- Rebuild the name→entry lookup table
function BossMenu.RebuildNameCache()
    local byName = {}
    for _, entry in ipairs(BossMenu.Cache) do
        byName[entry.name] = entry
    end
    BossMenu.CacheByName = byName
end

-- ─── Grade helpers ────────────────────────────────────────────────────────────

-- Returns the highest grade number found in a menu's grades list
function BossMenu.TopGrade(menu)
    local top = 0
    for _, gradeEntry in ipairs(menu.grades or {}) do
        local g = tonumber(gradeEntry.grade) or 0
        if g > top then top = g end
    end
    return top
end

-- Returns true if the given grade number has a specific permission
function BossMenu.GradeHasPerm(menu, gradeNumber, permission)
    gradeNumber = tonumber(gradeNumber)
    if not gradeNumber then return false end

    for _, gradeEntry in ipairs(menu.grades or {}) do
        if tonumber(gradeEntry.grade) == gradeNumber then
            if type(gradeEntry.permissions) ~= "table" then return false end
            for _, perm in pairs(gradeEntry.permissions) do
                if perm == permission then return true end
            end
            return false
        end
    end
    return false
end

-- Returns true if the given grade number has any permissions at all
function BossMenu.GradeHasAnyPerm(menu, gradeNumber)
    gradeNumber = tonumber(gradeNumber)
    if not gradeNumber then return false end

    for _, gradeEntry in ipairs(menu.grades or {}) do
        if tonumber(gradeEntry.grade) == gradeNumber then
            return type(gradeEntry.permissions) == "table"
        end
    end
    return false
end

-- Returns true if playerJob grants full (boss-level) access to menu
function BossMenu.IsFullAccess(playerJob, menu)
    if #(menu.grades or {}) == 0 then return true end
    if playerJob.isboss then return true end

    local grade = tonumber(playerJob.grade) or 0
    if grade >= BossMenu.TopGrade(menu) then return true end

    if type(menu.bossMenuGrades) == "table" then
        for _, allowedGrade in pairs(menu.bossMenuGrades) do
            if tonumber(allowedGrade) == grade then return true end
        end
    end
    return false
end

-- Returns true if source player has permission to act on jobName
-- Pass permission=nil to check whether they have ANY permission
function BossMenu.HasPermission(source, jobName, permission)
    if type(jobName) ~= "string" then return false end

    local playerJob = Framework and Framework.GetPlayerJob and Framework:GetPlayerJob(source)
    if not playerJob or playerJob.name ~= jobName then return false end

    local menu = BossMenu.GetCached(jobName)
    if not menu then return false end

    if BossMenu.IsFullAccess(playerJob, menu) then return true end

    if permission == nil then
        return BossMenu.GradeHasAnyPerm(menu, playerJob.grade)
    end
    return BossMenu.GradeHasPerm(menu, playerJob.grade, permission)
end

-- ─── Grade merging ────────────────────────────────────────────────────────────

-- Merges saved grade config (permissions/salary) with live framework grades.
-- savedGrades:    grades stored in the DB (may be empty)
-- jobName:        job identifier, used to pull live grades from the framework
function BuildMergedGrades(jobName, savedGrades)
    -- If saved grades already exist and are non-empty, apply defaults to the top grade then return
    if type(savedGrades) == "table" and #savedGrades > 0 then
        local topGrade = 0
        for _, g in ipairs(savedGrades) do
            local n = tonumber(g.grade) or 0
            if n > topGrade then topGrade = n end
        end
        for _, g in ipairs(savedGrades) do
            if (tonumber(g.grade) or 0) == topGrade then
                if type(g.permissions) ~= "table" or #g.permissions == 0 then
                    g.permissions = ALL_PERMISSIONS
                end
            end
        end
        return savedGrades
    end

    -- No saved grades — pull from framework
    if not (Framework and Framework.GetJobGrades) then return savedGrades end

    local liveGrades = Framework:GetJobGrades(jobName)
    if not liveGrades or #liveGrades == 0 then return savedGrades end

    -- Build lookup: grade number → saved entry (for permissions)
    local savedByGrade = {}
    for _, g in ipairs(savedGrades or {}) do
        local n = tonumber(g.grade)
        if n then savedByGrade[n] = g end
    end

    -- Find top grade in live list
    local topGrade = 0
    for _, g in ipairs(liveGrades) do
        local n = tonumber(g.grade) or 0
        if n > topGrade then topGrade = n end
    end

    -- Build merged output
    local merged = {}
    for _, liveEntry in ipairs(liveGrades) do
        local gradeNum = tonumber(liveEntry.grade) or 0
        local saved    = savedByGrade[gradeNum]
        local perms    = (saved and saved.permissions) or {}

        -- Top grade gets all permissions by default if none are set
        if gradeNum == topGrade and (type(perms) ~= "table" or #perms == 0) then
            perms = ALL_PERMISSIONS
        end

        merged[#merged + 1] = {
            grade       = liveEntry.grade,
            name        = liveEntry.name,
            label       = liveEntry.label or liveEntry.name,
            salary      = tonumber(liveEntry.salary) or 0,
            permissions = perms,
        }
    end
    return merged
end

-- ─── Row → menu object ────────────────────────────────────────────────────────

-- Converts a raw DB row into a normalised menu table
function ParseMenuRow(row)
    local settings  = json.decode(row.settings  or "{}") or {}
    local locations = json.decode(row.locations or "{}") or {}

    local menu = {
        id       = tostring(row.id),
        name     = row.job_name,
        label    = row.label,
        locations = locations,

        societyName        = settings.societyName or ("society_" .. row.job_name),
        color              = settings.color        or "#3b82f6",
        logo               = settings.logo,
        lockLogo           = settings.lockLogo     or false,

        grades             = BuildMergedGrades(row.job_name, settings.grades or {}),
        bossMenuGrades     = settings.bossMenuGrades  or {},
        outfits            = settings.outfits         or {},
        storeItems         = settings.storeItems      or {},
        storeCategories    = settings.storeCategories or {},

        salarySystem       = not not (Settings.SalarySystem and Settings.SalarySystem.enabled),

        storeDeliveryMinutes = settings.storeDeliveryMinutes,
        deliveryStash        = settings.deliveryStash,
    }
    return menu
end

-- ─── Sync helpers ─────────────────────────────────────────────────────────────

-- Broadcasts all cached menus to every client
function BossMenu.SyncAll()
    TriggerClientEvent("bablo-bossmenu:client:syncBossMenus", -1, BossMenu.Cache)
end

-- Syncs a single job's menu (or removes it if not cached)
function BossMenu.SyncJob(jobName)
    local menu = BossMenu.GetCached(jobName)
    if menu then
        TriggerClientEvent("bablo-bossmenu:client:syncBossMenu", -1, menu)
    else
        TriggerClientEvent("bablo-bossmenu:client:removeBossMenu", -1, jobName)
    end
end

-- ─── DB loading ───────────────────────────────────────────────────────────────

-- Loads all boss menus from the DB, parses them, rebuilds the cache,
-- then calls callback(true/false)
function BossMenu.LoadMenus(callback)
    MySQL.query("SELECT * FROM bablo_bossmenus", {}, function(rows)
        if not rows then
            if callback then callback(false) end
            return
        end

        BossMenu.Cache = {}
        for _, row in ipairs(rows) do
            BossMenu.Cache[#BossMenu.Cache + 1] = ParseMenuRow(row)
        end

        BossMenu.RebuildNameCache()
        if callback then callback(true) end
    end)
end

-- ─── Framework job registration ───────────────────────────────────────────────

-- Pushes all cached menus with grades to the framework.
-- Returns the number of jobs registered.
function BossMenu.RegisterJobs()
    if not Framework then return 0 end

    local validMenus  = {}
    local skippedJobs = {}

    for _, menu in ipairs(BossMenu.Cache) do
        if menu.grades and #menu.grades > 0 then
            validMenus[#validMenus + 1] = menu
        else
            skippedJobs[#skippedJobs + 1] = menu.name
        end
    end

    if #skippedJobs > 0 then
        print(("^3[WARNING]^0 BossMenu: %s job(s) have no grades and were NOT registered: %s")
            :format(#skippedJobs, table.concat(skippedJobs, ", ")))
    end

    -- Bulk update (e.g. QBX)
    if Framework.UpdateJobs then
        return Framework:UpdateJobs(validMenus)
    end

    -- Per-job update (e.g. QBCore/ESX)
    if not Framework.UpdateJob then return 0 end

    for i, menu in ipairs(validMenus) do
        Framework:UpdateJob(menu.name, menu.name, menu.label, menu.grades, menu.bossMenuGrades)
        if i % 5 == 0 then Wait(0) end  -- yield every 5 to avoid hitching
    end
    return #validMenus
end

-- ─── Event handlers ───────────────────────────────────────────────────────────

-- Re-register jobs if a supported framework resource restarts
AddEventHandler("onResourceStart", function(resourceName)
    if resourceName ~= "qb-core" and resourceName ~= "es_extended" and resourceName ~= "qbx_core" then
        return
    end
    if #BossMenu.Cache == 0 then return end

    CreateThread(function()
        Wait(2000)
        local count = BossMenu.RegisterJobs()
        print(("^2[INFO]^0 BossMenu: %s restarted - re-registered %s job(s)."):format(resourceName, count))
    end)
end)

-- Initial startup: load menus once the DB is ready
DB.OnReady(function()
    BossMenu.LoadMenus(function(success)
        if not success then return end
        CreateThread(function()
            local count = BossMenu.RegisterJobs()
            print(("^2[INFO]^0 BossMenu: loaded %s boss menu(s), %s job(s) pushed to the framework.")
                :format(#BossMenu.Cache, count))
            BossMenu.SyncAll()
        end)
    end)
end)
