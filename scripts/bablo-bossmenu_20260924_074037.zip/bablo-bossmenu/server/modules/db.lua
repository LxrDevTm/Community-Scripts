local resourceName = GetCurrentResourceName()

DB = { ready = false }

local pendingCallbacks = {}

-- Queue a function to run once the DB is confirmed ready.
-- If the DB is already ready, runs immediately.
function DB.OnReady(callback)
    if type(callback) ~= "function" then return end
    if DB.ready then
        callback()
    else
        pendingCallbacks[#pendingCallbacks + 1] = callback
    end
end

-- ─── Schema migrations ────────────────────────────────────────────────────────

local migrations = {
    {
        name  = "create bablo_bossmenus",
        query = [[
            CREATE TABLE IF NOT EXISTS `bablo_bossmenus` (
                `id` INT(11) NOT NULL AUTO_INCREMENT,
                `job_name` VARCHAR(50) NOT NULL,
                `label` VARCHAR(50) NOT NULL DEFAULT 'Boss Menu',
                `locations` LONGTEXT DEFAULT NULL,
                `settings` LONGTEXT DEFAULT NULL,
                PRIMARY KEY (`id`),
                KEY `idx_job_name` (`job_name`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
        ]],
    },
    {
        name  = "create bablo_bossmenu_revenue",
        query = [[
            CREATE TABLE IF NOT EXISTS `bablo_bossmenu_revenue` (
                `id` INT(11) NOT NULL AUTO_INCREMENT,
                `job_name` VARCHAR(50) NOT NULL,
                `amount` INT(11) NOT NULL DEFAULT 0,
                `date` DATE NOT NULL,
                PRIMARY KEY (`id`),
                UNIQUE KEY `idx_job_date` (`job_name`, `date`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
        ]],
    },
    {
        name  = "create bablo_bossmenu_attendance",
        query = [[
            CREATE TABLE IF NOT EXISTS `bablo_bossmenu_attendance` (
                `id` INT(11) NOT NULL AUTO_INCREMENT,
                `job_name` VARCHAR(50) NOT NULL,
                `identifier` VARCHAR(60) NOT NULL,
                `date` DATE NOT NULL,
                PRIMARY KEY (`id`),
                UNIQUE KEY `idx_job_ident_date` (`job_name`, `identifier`, `date`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
        ]],
    },
    {
        name  = "create bablo_bossmenu_transactions",
        query = [[
            CREATE TABLE IF NOT EXISTS `bablo_bossmenu_transactions` (
                `id` INT(11) NOT NULL AUTO_INCREMENT,
                `job_name` VARCHAR(50) NOT NULL,
                `name` VARCHAR(100) NOT NULL,
                `type` VARCHAR(50) NOT NULL,
                `amount` INT(11) NOT NULL,
                `date` VARCHAR(50) NOT NULL,
                `timestamp` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (`id`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
        ]],
    },
    {
        name  = "create bablo_bossmenu_orders",
        query = [[
            CREATE TABLE IF NOT EXISTS `bablo_bossmenu_orders` (
                `id` INT(11) NOT NULL AUTO_INCREMENT,
                `job_name` VARCHAR(50) NOT NULL,
                `stash_id` VARCHAR(100) NOT NULL,
                `items` LONGTEXT NOT NULL,
                `deliver_at` TIMESTAMP NOT NULL,
                `delivered` TINYINT(1) NOT NULL DEFAULT 0,
                PRIMARY KEY (`id`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
        ]],
    },
    {
        name  = "create bablo_bossmenu_hours",
        query = [[
            CREATE TABLE IF NOT EXISTS `bablo_bossmenu_hours` (
                `job_name` VARCHAR(50) NOT NULL,
                `identifier` VARCHAR(60) NOT NULL,
                `date` DATE NOT NULL,
                `seconds` INT(11) NOT NULL DEFAULT 0,
                PRIMARY KEY (`job_name`, `identifier`, `date`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
        ]],
    },
}

-- Indexes to add if they are missing (non-fatal if they fail)
local optionalIndexes = {
    { table = "bablo_bossmenu_transactions", name = "idx_job_timestamp", columns = "(`job_name`, `timestamp`)" },
    { table = "bablo_bossmenu_transactions", name = "idx_timestamp",     columns = "(`timestamp`)"             },
    { table = "bablo_bossmenu_revenue",      name = "idx_date",          columns = "(`date`)"                  },
    { table = "bablo_bossmenu_attendance",   name = "idx_date",          columns = "(`date`)"                  },
    { table = "bablo_bossmenu_orders",       name = "idx_delivered_due", columns = "(`delivered`, `deliver_at`)" },
}

-- ─── Cleanup helpers ──────────────────────────────────────────────────────────

-- Deletes rows older than `days` from `tableName`.
-- Logs how many rows were removed.
function PruneOldRecords(tableName, dateColumn, days, label)
    if not days or days <= 0 then return end
    local sql = ("DELETE FROM %s WHERE %s < DATE_SUB(%s, INTERVAL ? DAY)"):format(
        tableName,
        dateColumn,
        dateColumn:find("timestamp") and "NOW()" or "CURDATE()"
    )
    MySQL.query(sql, { days }, function(result)
        local affected = 0
        if type(result) == "table" then
            affected = result.affectedRows or 0
        elseif type(result) == "number" then
            affected = result
        end
        if affected > 0 then
            print(("^3[%s] Cleaned up %s old %s records (older than %s days).^0")
                :format(resourceName, affected, label, days))
        end
    end)
end

-- ─── Startup sequence ─────────────────────────────────────────────────────────

MySQL.ready(function()
    -- Run all schema migrations
    local failCount = 0
    for i, migration in ipairs(migrations) do
        local ok, err = pcall(function()
            MySQL.query.await(migration.query)
        end)
        if not ok then
            failCount = failCount + 1
            print(("^1[%s] Migration %s/%s '%s' failed: %s^0")
                :format(resourceName, i, #migrations, migration.name, err))
        end
    end

    if failCount > 0 then
        print(("^1[%s] Database not ready — %s migration(s) failed. Boss menus will not load until this is resolved.^0")
            :format(resourceName, failCount))
        return
    end

    -- Attempt to add optional performance indexes
    for _, idx in ipairs(optionalIndexes) do
        local ok, err = pcall(function()
            local exists = tonumber(MySQL.scalar.await(
                "SELECT COUNT(*) FROM information_schema.STATISTICS WHERE table_schema = DATABASE() AND table_name = ? AND index_name = ?",
                { idx.table, idx.name }
            )) or 0
            if exists == 0 then
                MySQL.query.await(("ALTER TABLE `%s` ADD INDEX `%s` %s"):format(idx.table, idx.name, idx.columns))
                print(("^2[%s] Added index %s on %s.^0"):format(resourceName, idx.name, idx.table))
            end
        end)
        if not ok then
            print(("^3[%s] Could not add index %s on %s: %s^0"):format(resourceName, idx.name, idx.table, tostring(err)))
        end
    end

    -- Mark DB as ready and fire queued callbacks
    DB.ready = true
    print(("^2[%s] Database ready — %s migration(s) verified.^0"):format(resourceName, #migrations))

    for _, cb in ipairs(pendingCallbacks) do
        local ok, err = pcall(cb)
        if not ok then
            print(("^1[%s] Database ready handler errored: %s^0"):format(resourceName, err))
        end
    end
    pendingCallbacks = {}

    -- Prune old records based on configured retention windows
    local revDays   = tonumber(Settings.RevenueHistoryDays)     or 30
    local attDays   = tonumber(Settings.AttendanceHistoryDays)  or 14
    local transDays = tonumber(Settings.TransactionHistoryDays) or 30

    PruneOldRecords("bablo_bossmenu_revenue",      "date",      revDays,   "revenue")
    PruneOldRecords("bablo_bossmenu_attendance",   "date",      attDays,   "attendance")
    PruneOldRecords("bablo_bossmenu_transactions", "timestamp", transDays, "transaction")
end)
