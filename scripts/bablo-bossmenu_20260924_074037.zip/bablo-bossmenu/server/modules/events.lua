-- ============================================================
--  Helper: detect grade changes between old and new grade lists
--  Returns a list of { from = oldGrade, to = newGrade } pairs
-- ============================================================
function GetGradeChanges(oldGrades, newGrades)
    local changes = {}

    if type(oldGrades) ~= "table" or type(newGrades) ~= "table" or #newGrades == 0 then
        return changes
    end

    local newGradeMap = {}
    for _, entry in ipairs(newGrades) do
        if entry.name then
            newGradeMap[entry.name] = tonumber(entry.grade)
        end
    end

    for _, entry in ipairs(oldGrades) do
        local oldGradeNum = tonumber(entry.grade)
        local newGradeNum = entry.name and newGradeMap[entry.name]

        if oldGradeNum and newGradeNum and oldGradeNum ~= newGradeNum then
            changes[#changes + 1] = { from = oldGradeNum, to = newGradeNum }
        end
    end

    return changes
end

-- ============================================================
--  Helper: clamp all grade salaries to [0, salaryLimit]
-- ============================================================
function ClampGradeSalaries(grades, salaryLimit)
    if type(grades) ~= "table" then return end

    for _, entry in ipairs(grades) do
        local salary = math.floor(tonumber(entry.salary) or 0)
        if salary < 0 then salary = 0 end
        if salary > salaryLimit then salary = salaryLimit end
        entry.salary = salary
    end
end

-- ============================================================
--  Helper: build a grade-number remap table from a changes list
--  { [fromGrade] = toGrade, ... }
-- ============================================================
function BuildGradeRemapTable(changes)
    local remap = {}
    for _, change in ipairs(changes) do
        local from = tonumber(change.from)
        local to   = tonumber(change.to)
        if from and to then
            remap[from] = to
        end
    end
    return remap
end

-- ============================================================
--  Helper: apply a grade remap to bossMenuGrades and outfit
--  allowedGrades arrays inside a settings table.
-- ============================================================
function ApplyGradeRemap(settings, changes)
    if type(changes) ~= "table" or #changes == 0 then return end

    local remap = BuildGradeRemapTable(changes)

    if type(settings.bossMenuGrades) == "table" then
        local remapped = {}
        for _, gradeVal in pairs(settings.bossMenuGrades) do
            local gradeNum = tonumber(gradeVal)
            if gradeNum then
                remapped[#remapped + 1] = remap[gradeNum] or gradeNum
            end
        end
        settings.bossMenuGrades = remapped
    end

    if type(settings.outfits) == "table" then
        for _, outfit in ipairs(settings.outfits) do
            if type(outfit.allowedGrades) == "table" then
                local remapped = {}
                for _, gradeVal in pairs(outfit.allowedGrades) do
                    local gradeNum = tonumber(gradeVal)
                    if gradeNum then
                        remapped[#remapped + 1] = remap[gradeNum] or gradeNum
                    end
                end
                outfit.allowedGrades = remapped
            end
        end
    end
end

-- ============================================================
--  Helper: reload menus then sync a specific job to all clients
-- ============================================================
function ReloadAndSyncJob(jobName)
    BossMenu.LoadMenus(function()
        BossMenu.SyncJob(jobName)
    end)
end

-- ============================================================
--  Command: open the creator UI (creator-permission gated)
-- ============================================================
RegisterCommand(Creator.Command, function(source, args, rawCommand)
    if source == 0 then return end

    if Framework and Framework.HasCreatorPermission then
        if Framework:HasCreatorPermission(source) then
            TriggerClientEvent("bablo-bossmenu:client:openCreator", source)
        else
            print(("^3[WARNING] Player %s tried to use creator command without permissions.^0"):format(source))
        end
    else
        TriggerClientEvent("bablo-bossmenu:client:openCreator", source)
    end
end, false)

-- ============================================================
--  Event: update boss-menu settings (grades, logo, bossMenuGrades)
-- ============================================================
RegisterNetEvent("bablo-bossmenu:server:updateBossSettings")
AddEventHandler("bablo-bossmenu:server:updateBossSettings", function(payload)
    local playerId = source

    if not (payload and payload.id and payload.name) then return end

    local playerJob = Framework and Framework.GetPlayerJob and Framework:GetPlayerJob(playerId)
    if not playerJob or playerJob.name ~= payload.name then
        print(("^3[WARNING] Player %s tried to update boss menu without being in job.^0"):format(playerId))
        return
    end

    local cachedMenu = nil
    for i = 1, #BossMenu.Cache do
        if BossMenu.Cache[i].id == tostring(payload.id) then
            cachedMenu = BossMenu.Cache[i]
            break
        end
    end

    if not cachedMenu or cachedMenu.name ~= payload.name then
        print(("^3[WARNING] Player %s tried to update boss menu with a mismatched id.^0"):format(playerId))
        return
    end

    local hasAccess = BossMenu.IsFullAccess(playerJob, cachedMenu)
    if not hasAccess then
        if not BossMenu.GradeHasPerm(cachedMenu, playerJob.grade, "edit_permissions") then
            print(("^3[WARNING] Player %s tried to update boss menu settings without permission.^0"):format(playerId))
            return
        end
    end

    MySQL.query("SELECT settings FROM bablo_bossmenus WHERE id = ?", { payload.id }, function(rows)
        if not (rows and rows[1]) then return end

        local settings = json.decode(rows[1].settings or "{}") or {}

        if payload.settings then
            if payload.settings.logo ~= nil then
                settings.logo = payload.settings.logo
            end
            if payload.settings.bossMenuGrades ~= nil then
                settings.bossMenuGrades = payload.settings.bossMenuGrades
            end
        end

        if payload.grades ~= nil then
            settings.grades = payload.grades
            ClampGradeSalaries(settings.grades, Settings.SalaryLimit)
        end

        local gradeChanges = {}
        if payload.grades ~= nil then
            gradeChanges = GetGradeChanges(cachedMenu.grades, payload.grades)
        end

        if not gradeChanges then gradeChanges = {} end
        ApplyGradeRemap(settings, gradeChanges)

        MySQL.update("UPDATE bablo_bossmenus SET settings = ? WHERE id = ?",
            { json.encode(settings), payload.id },
            function()
                print(("^2[SUCCESS] Boss menu settings for %s updated by boss %s^0"):format(payload.name, playerId))

                local gradesOrBossGradesChanged = payload.grades ~= nil
                    or (payload.settings and payload.settings.bossMenuGrades ~= nil)

                if gradesOrBossGradesChanged and Framework and Framework.UpdateJob then
                    Framework:UpdateJob(payload.name, payload.name, cachedMenu.label, settings.grades, settings.bossMenuGrades)
                end

                if #gradeChanges > 0 and Framework and Framework.MigrateEmployeeGrades then
                    Framework:MigrateEmployeeGrades(payload.name, gradeChanges, settings.grades)
                end

                ReloadAndSyncJob(payload.name)
            end
        )
    end)
end)

-- ============================================================
--  Event: save (create or update) a boss-menu job entry
-- ============================================================
RegisterNetEvent("bablo-bossmenu:server:saveJob")
AddEventHandler("bablo-bossmenu:server:saveJob", function(payload)
    local playerId = source

    if not (payload and payload.name) then return end

    if Framework and Framework.HasCreatorPermission then
        if not Framework:HasCreatorPermission(playerId) then
            print(("^3[WARNING] Player %s tried to save boss menu without permissions.^0"):format(playerId))
            return
        end
    end

    local settingsToSave = {
        societyName          = payload.societyName,
        color                = payload.color,
        logo                 = payload.logo,
        lockLogo             = payload.lockLogo,
        grades               = payload.grades,
        bossMenuGrades       = payload.bossMenuGrades,
        outfits              = payload.outfits,
        storeItems           = payload.storeItems,
        storeCategories      = payload.storeCategories,
        storeDeliveryMinutes = payload.storeDeliveryMinutes,
        deliveryStash        = payload.deliveryStash,
    }

    ClampGradeSalaries(settingsToSave.grades, Settings.SalaryLimit)

    local existingCache = BossMenu.GetCached(payload.name)
    local gradeChanges  = GetGradeChanges(existingCache and existingCache.grades, settingsToSave.grades)
    ApplyGradeRemap(settingsToSave, gradeChanges)

    MySQL.query(
        "SELECT id, job_name, label FROM bablo_bossmenus WHERE id = ? OR job_name = ?",
        { payload.id or 0, payload.name },
        function(rows)
            if rows and rows[1] then
                local existingId      = rows[1].id
                local existingJobName = rows[1].job_name

                MySQL.update(
                    "UPDATE bablo_bossmenus SET job_name = ?, label = ?, locations = ?, settings = ? WHERE id = ?",
                    {
                        payload.name,
                        payload.label,
                        json.encode(payload.locations or {}),
                        json.encode(settingsToSave),
                        existingId,
                    },
                    function()
                        print(("^2[SUCCESS] Boss menu for %s updated by %s (DB ID: %s)^0"):format(payload.name, playerId, existingId))

                        if Framework and Framework.UpdateJob then
                            Framework:UpdateJob(existingJobName, payload.name, payload.label, settingsToSave.grades, settingsToSave.bossMenuGrades)
                        end

                        if #gradeChanges > 0 and Framework and Framework.MigrateEmployeeGrades then
                            Framework:MigrateEmployeeGrades(payload.name, gradeChanges, settingsToSave.grades)
                        end

                        BossMenu.LoadMenus(function()
                            if existingJobName ~= payload.name then
                                TriggerClientEvent("bablo-bossmenu:client:removeBossMenu", -1, existingJobName)
                            end
                            BossMenu.SyncJob(payload.name)
                        end)
                    end
                )
            else
                MySQL.insert(
                    "INSERT INTO bablo_bossmenus (job_name, label, locations, settings) VALUES (?, ?, ?, ?)",
                    {
                        payload.name,
                        payload.label,
                        json.encode(payload.locations or {}),
                        json.encode(settingsToSave),
                    },
                    function(newId)
                        if not newId then return end

                        print(("^2[SUCCESS] Boss menu for %s created by %s (ID: %s)^0"):format(payload.name, playerId, newId))

                        if Framework and Framework.UpdateJob and settingsToSave.grades and #settingsToSave.grades > 0 then
                            Framework:UpdateJob(payload.name, payload.name, payload.label, settingsToSave.grades, settingsToSave.bossMenuGrades)
                        end

                        ReloadAndSyncJob(payload.name)
                    end
                )
            end
        end
    )
end)

-- ============================================================
--  Event: delete a boss-menu job entry (optionally from framework)
-- ============================================================
RegisterNetEvent("bablo-bossmenu:server:deleteJob")
AddEventHandler("bablo-bossmenu:server:deleteJob", function(menuId, deleteFromFramework)
    local playerId = source

    if Framework and Framework.HasCreatorPermission then
        if not Framework:HasCreatorPermission(playerId) then return end
    end

    MySQL.query("SELECT job_name FROM bablo_bossmenus WHERE id = ?", { menuId }, function(rows)
        if not (rows and rows[1]) then return end

        local jobName = rows[1].job_name

        MySQL.query("DELETE FROM bablo_bossmenus WHERE id = ?", { menuId }, function()
            print(("^1[SUCCESS] Boss menu ID %s deleted by %s^0"):format(menuId, playerId))

            if deleteFromFramework and Framework and Framework.DeleteJob then
                Framework:DeleteJob(jobName)
                print(("^1[SUCCESS] Job %s completely removed from framework by %s^0"):format(jobName, playerId))
            end

            ReloadAndSyncJob(jobName)
        end)
    end)
end)

-- ============================================================
--  Internal: record attendance when a player joins/changes job
-- ============================================================
function RecordAttendance(identifier, jobName)
    if not identifier or not jobName or jobName == "unemployed" then return end

    MySQL.query([[
        INSERT IGNORE INTO bablo_bossmenu_attendance (job_name, identifier, date)
        VALUES (?, ?, CURDATE())
    ]], { jobName, identifier })
end

-- ============================================================
--  ESX: record attendance on player load
-- ============================================================
RegisterNetEvent("esx:playerLoaded")
AddEventHandler("esx:playerLoaded", function(playerId, xPlayer)
    if not xPlayer then return end

    local job = xPlayer.getJob()
    if job and job.name then
        RecordAttendance(xPlayer.identifier, job.name)
    end
end)

-- ============================================================
--  ESX: record attendance when a player's job changes
-- ============================================================
RegisterNetEvent("esx:setJob")
AddEventHandler("esx:setJob", function(playerId, newJob)
    local ESX    = exports.es_extended:getSharedObject()
    local xPlayer = ESX.GetPlayerFromId(playerId)

    if xPlayer and newJob and newJob.name then
        RecordAttendance(xPlayer.identifier, newJob.name)
    end
end)

-- ============================================================
--  General job-change handler (framework-agnostic)
--  Exposed as OnJobChangedAttendance for other scripts
-- ============================================================
function OnJobChangedAttendance(playerId, newJob)
    if not (Framework and Framework.GetPlayer) then return end

    local player = Framework:GetPlayer(playerId)
    if not player then return end

    local identifier = nil
    if player.PlayerData and player.PlayerData.citizenid then
        identifier = player.PlayerData.citizenid
    elseif player.getIdentifier then
        identifier = player.getIdentifier()
    end

    local jobName = newJob and newJob.name
    if not jobName then
        if Framework.GetPlayerJob then
            local job = Framework:GetPlayerJob(playerId)
            jobName = job and job.name
        end
    end

    if identifier and jobName then
        RecordAttendance(identifier, jobName)
    end
end

-- ============================================================
--  Helper: find a cached boss-menu entry by job name
-- ============================================================
function GetCachedMenuByName(jobName)
    for i = 1, #BossMenu.Cache do
        if BossMenu.Cache[i].name == jobName then
            return BossMenu.Cache[i]
        end
    end
    return nil
end

-- ============================================================
--  Helper: check whether a player job represents full (boss) access
--  Returns true if the player's grade is >= the highest grade in the menu
-- ============================================================
function PlayerHasFullAccess(playerJob, cachedMenu)
    if playerJob.isboss then return true end

    local highestGrade = 0
    for _, entry in ipairs(cachedMenu.grades) do
        local gradeNum = tonumber(entry.grade) or 0
        if gradeNum > highestGrade then
            highestGrade = gradeNum
        end
    end

    local playerGrade = tonumber(playerJob.grade) or 0
    return highestGrade <= playerGrade
end

-- ============================================================
--  Event: update a single grade's salary
-- ============================================================
RegisterNetEvent("bablo-bossmenu:server:setGradeSalary")
AddEventHandler("bablo-bossmenu:server:setGradeSalary", function(jobName, gradeNum, newSalary)
    local playerId = source

    if type(jobName) ~= "string" then return end

    gradeNum  = tonumber(gradeNum)
    newSalary = math.floor(tonumber(newSalary) or -1)

    if not gradeNum or newSalary < 0 or newSalary > 1000000 then return end

    local playerJob = Framework and Framework.GetPlayerJob and Framework:GetPlayerJob(playerId)
    if not playerJob or playerJob.name ~= jobName then return end

    local cachedMenu = GetCachedMenuByName(jobName)
    if not cachedMenu then return end

    local hasFullAccess = BossMenu.IsFullAccess(playerJob, cachedMenu)

    if not hasFullAccess then
        if not BossMenu.GradeHasPerm(cachedMenu, playerJob.grade, "edit_permissions") then
            Notify:Show(playerId, Tr("notify.only_boss_salaries", "Only the boss can change salaries."), "error")
            return
        end
    end

    if not hasFullAccess then
        local playerGradeNum = tonumber(playerJob.grade) or 0
        if gradeNum >= playerGradeNum then
            Notify:Show(playerId, Tr("notify.salary_below_rank", "You can only change salaries for ranks below your own."), "error")
            return
        end
    end

    if newSalary > Settings.SalaryLimit then
        Notify:Show(playerId, Tr("notify.salary_limit", "Salaries cannot exceed $%s."):format(Settings.SalaryLimit), "error")
        return
    end

    local gradeFound = false
    for _, entry in ipairs(cachedMenu.grades) do
        if tonumber(entry.grade) == gradeNum then
            entry.salary = newSalary
            gradeFound = true
            break
        end
    end

    if not gradeFound then return end

    MySQL.query("SELECT settings FROM bablo_bossmenus WHERE id = ?", { cachedMenu.id }, function(rows)
        if not (rows and rows[1]) then return end

        local settings = json.decode(rows[1].settings or "{}") or {}
        settings.grades = cachedMenu.grades

        MySQL.update("UPDATE bablo_bossmenus SET settings = ? WHERE id = ?",
            { json.encode(settings), cachedMenu.id },
            function()
                Notify:Show(playerId, Tr("notify.salary_updated", "Salary updated."), "success")

                if Framework and Framework.UpdateJob then
                    Framework:UpdateJob(cachedMenu.name, cachedMenu.name, cachedMenu.label, cachedMenu.grades, cachedMenu.bossMenuGrades)
                end

                ReloadAndSyncJob(cachedMenu.name)
            end
        )
    end)
end)

-- ============================================================
--  Event: update job outfits (boss-only)
-- ============================================================
RegisterNetEvent("bablo-bossmenu:server:updateOutfits")
AddEventHandler("bablo-bossmenu:server:updateOutfits", function(newOutfits)
    local playerId = source

    if type(newOutfits) ~= "table" then return end

    local playerJob = Framework and Framework.GetPlayerJob and Framework:GetPlayerJob(playerId)
    if not (playerJob and playerJob.name) then return end

    local cachedMenu = GetCachedMenuByName(playerJob.name)
    if not cachedMenu then return end

    if not BossMenu.IsFullAccess(playerJob, cachedMenu) then
        Notify:Show(playerId, Tr("notify.only_boss_outfits", "Only the boss can manage outfits."), "error")
        return
    end

    MySQL.query("SELECT settings FROM bablo_bossmenus WHERE id = ?", { cachedMenu.id }, function(rows)
        if not (rows and rows[1]) then return end

        local settings = json.decode(rows[1].settings or "{}") or {}
        settings.outfits = newOutfits

        MySQL.update("UPDATE bablo_bossmenus SET settings = ? WHERE id = ?",
            { json.encode(settings), cachedMenu.id },
            function()
                ReloadAndSyncJob(cachedMenu.name)
            end
        )
    end)
end)

-- ============================================================
--  Debug command: seed fake transactions (server console only)
-- ============================================================
local DEBUG_ID_PREFIX = "BOSSDBG_"

RegisterCommand("bossmenudebugtx", function(source, args)
    if source ~= 0 then return end

    local days = math.floor(tonumber(args[1]) or 30)
    if days < 1  then days = 1  end
    if days > 90 then days = 90 end

    local fakeNames = { "Bablo Resources", "Windows Developer", "Charlie Brown", "John Doe", "Jane Smith", "Nova Innovations" }

    local totalInserted = 0

    for i = 1, #BossMenu.Cache do
        local jobName = BossMenu.Cache[i].name

        for day = 0, days do
            local txCountToday = math.random(0, 4)
            if day == 0 then
                txCountToday = math.random(2, 5)
            end

            for _ = 1, txCountToday do
                local isDeposit = math.random() < 0.55
                local amount    = math.random(2, 120) * 50
                local secondsAgo

                if day == 0 then
                    secondsAgo = math.random(0, 82799)
                else
                    secondsAgo = day * 86400 + math.random(0, 86399)
                end

                if not isDeposit then amount = -amount end

                MySQL.insert([[
                    INSERT INTO bablo_bossmenu_transactions (job_name, name, type, amount, date, `timestamp`)
                    VALUES (?, ?, ?, ?, DATE_FORMAT(DATE_SUB(NOW(), INTERVAL ? SECOND), '%d. %b - %H:%i'), DATE_SUB(NOW(), INTERVAL ? SECOND))
                ]], {
                    jobName,
                    fakeNames[math.random(#fakeNames)],
                    isDeposit and "Deposit" or "Withdraw",
                    math.abs(amount),
                    secondsAgo,
                    secondsAgo,
                })

                totalInserted = totalInserted + 1
            end
        end
    end

    print(("^2[INFO]^0 BossMenu: seeded ~%s debug transactions across %s job(s) over %s days."):format(
        totalInserted, #BossMenu.Cache, days
    ))
end, true)

-- ============================================================
--  Debug command: seed fake hours/attendance (in-game only)
-- ============================================================
RegisterCommand("bossmenudebughours", function(source, args)
    local playerId = source

    if playerId == 0 then
        print("^3[WARNING]^0 BossMenu: run bossmenudebughours in-game - it uses the job you are currently in.")
        return
    end

    if Framework and Framework.HasCreatorPermission then
        if not Framework:HasCreatorPermission(playerId) then
            Notify:Show(playerId, Tr("notify.no_permission_use", "You do not have permission to use this."), "error")
            return
        end
    end

    local playerJob = Framework and Framework.GetPlayerJob and Framework:GetPlayerJob(playerId)
    if not (playerJob and playerJob.name and playerJob.name ~= "unemployed") then
        Notify:Show(playerId, "You need to be in a job to seed debug hours.", "error")
        return
    end

    local jobName = playerJob.name

    if args[1] == "clear" then
        MySQL.query.await("DELETE FROM bablo_bossmenu_hours WHERE job_name = ? AND identifier LIKE ?",
            { jobName, DEBUG_ID_PREFIX .. "%" })
        MySQL.query.await("DELETE FROM bablo_bossmenu_attendance WHERE job_name = ? AND identifier LIKE ?",
            { jobName, DEBUG_ID_PREFIX .. "%" })

        Notify:Show(playerId, ("Removed debug hours and attendance for %s."):format(jobName), "success")
        print(("^2[INFO]^0 BossMenu: cleared debug hours/attendance for %s."):format(jobName))
        return
    end

    local days = math.floor(tonumber(args[1]) or 14)
    if days < 1  then days = 1  end
    if days > 30 then days = 30 end

    local extraPlayers = math.floor(tonumber(args[2]) or 6)
    if extraPlayers < 0  then extraPlayers = 0  end
    if extraPlayers > 20 then extraPlayers = 20 end

    local identifiers = {}

    if Framework and Framework.GetJobEmployees then
        local employees = Framework:GetJobEmployees(jobName) or {}
        for _, emp in ipairs(employees) do
            if emp.identifier then
                identifiers[#identifiers + 1] = tostring(emp.identifier)
            end
        end
    end

    for i = 1, extraPlayers do
        identifiers[#identifiers + 1] = ("%s%s"):format(DEBUG_ID_PREFIX, i)
    end

    if #identifiers == 0 then
        Notify:Show(playerId, "No employees found to seed hours for.", "error")
        return
    end

    local hoursInserted      = 0
    local attendanceInserted = 0

    for day = 0, days - 1 do
        for _, identifier in ipairs(identifiers) do
            if math.random() < 0.75 then
                local seconds = math.random(45, 480) * 60

                MySQL.prepare.await([[
                    INSERT INTO bablo_bossmenu_hours (job_name, identifier, date, seconds)
                    VALUES (?, ?, DATE_SUB(CURDATE(), INTERVAL ? DAY), ?)
                    ON DUPLICATE KEY UPDATE seconds = seconds + VALUES(seconds)
                ]], { jobName, identifier, day, seconds })

                hoursInserted = hoursInserted + 1

                MySQL.prepare.await([[
                    INSERT IGNORE INTO bablo_bossmenu_attendance (job_name, identifier, date)
                    VALUES (?, ?, DATE_SUB(CURDATE(), INTERVAL ? DAY))
                ]], { jobName, identifier, day })

                attendanceInserted = attendanceInserted + 1
            end
        end
    end

    Notify:Show(playerId,
        ("Seeded %s day(s) of hours for %s across %s people. Reopen the menu to see it."):format(days, jobName, #identifiers),
        "success"
    )
    print(("^2[INFO]^0 BossMenu: seeded %s hour row(s) and %s attendance row(s) for %s over %s day(s). Use /bossmenudebughours clear to remove."):format(
        hoursInserted, attendanceInserted, jobName, days
    ))
end, false)