Hours = {}

-- Active tracking sessions keyed by player source ID:
-- activeSessions[source] = { identifier, jobName, startedAt }
local activeSessions = {}

-- ─── Framework helpers ────────────────────────────────────────────────────────

-- Returns identifier and job name for a given source, or nil, nil on failure
function GetPlayerIdentifierAndJob(source)
    if not (Framework and Framework.GetPlayer) then return nil, nil end

    local player = Framework:GetPlayer(source)
    if not player then return nil, nil end

    local identifier
    if player.PlayerData and player.PlayerData.citizenid then
        identifier = player.PlayerData.citizenid
    elseif player.getIdentifier then
        identifier = player.getIdentifier()
    end

    local jobName
    if Framework.GetPlayerJob then
        local job = Framework:GetPlayerJob(source)
        if job then jobName = job.name end
    end

    return identifier, jobName
end

-- ─── Session management ───────────────────────────────────────────────────────

-- Flushes elapsed seconds for a session to the DB and resets its start time
function FlushPlayerHours(source)
    local session = activeSessions[source]
    if not session then return end

    local now     = os.time()
    local elapsed = now - session.startedAt
    session.startedAt = now

    if elapsed <= 0 then return end

    MySQL.insert([[
        INSERT INTO bablo_bossmenu_hours (job_name, identifier, date, seconds)
        VALUES (?, ?, CURDATE(), ?)
        ON DUPLICATE KEY UPDATE seconds = seconds + VALUES(seconds)
    ]], { session.jobName, session.identifier, elapsed })
end

-- Starts (or restarts) tracking for a player.
-- Clears their session if they are unemployed or have no valid identity.
function StartTrackingPlayer(source)
    local identifier, jobName = GetPlayerIdentifierAndJob(source)

    if not identifier or not jobName or jobName == "unemployed" then
        activeSessions[source] = nil
        return
    end

    activeSessions[source] = {
        identifier = identifier,
        jobName    = jobName,
        startedAt  = os.time(),
    }
end

-- ─── Public API ───────────────────────────────────────────────────────────────

-- Returns how many seconds a player (by identifier) has been tracked
-- in the current session (time since their session started)
function Hours.GetActiveSeconds(identifier)
    local now = os.time()
    for _, session in pairs(activeSessions) do
        if session.identifier == identifier then
            return now - session.startedAt
        end
    end
    return 0
end

-- ─── Event handlers ───────────────────────────────────────────────────────────

-- QBCore: player fully loaded
AddEventHandler("QBCore:Server:PlayerLoaded", function(player)
    local source = player and player.PlayerData and player.PlayerData.source
    if not source then return end
    CreateThread(function()
        Wait(1000)
        StartTrackingPlayer(source)
    end)
end)

-- QBCore: job changed
AddEventHandler("QBCore:Server:OnJobUpdate", function(source)
    FlushPlayerHours(source)
    StartTrackingPlayer(source)
end)

-- ESX: player loaded
RegisterNetEvent("esx:playerLoaded", function(source)
    CreateThread(function()
        Wait(1000)
        StartTrackingPlayer(source)
    end)
end)

-- ESX: job changed
RegisterNetEvent("esx:setJob", function(source)
    FlushPlayerHours(source)
    StartTrackingPlayer(source)
end)

-- Player disconnected — flush their remaining hours then clear session
AddEventHandler("playerDropped", function()
    local source = source
    FlushPlayerHours(source)
    activeSessions[source] = nil
end)

-- Initialise tracking for all currently connected players shortly after start
CreateThread(function()
    Wait(5000)
    for _, rawSource in ipairs(GetPlayers()) do
        local source = tonumber(rawSource)
        if source then
            StartTrackingPlayer(source)
        end
    end
end)

-- Periodic flush every 5 minutes to avoid losing data on crash
CreateThread(function()
    while true do
        Wait(300000)
        for source in pairs(activeSessions) do
            FlushPlayerHours(source)
        end
    end
end)

-- Flush all sessions when this resource stops
AddEventHandler("onResourceStop", function(stoppedResource)
    if stoppedResource ~= GetCurrentResourceName() then return end
    for source in pairs(activeSessions) do
        FlushPlayerHours(source)
    end
end)
