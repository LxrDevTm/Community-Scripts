local importRunning = false

-- ─── Utility helpers ──────────────────────────────────────────────────────────

-- Returns true if jobName is in Creator.ImportBlacklist
function IsBlacklisted(jobName)
    for _, entry in ipairs(Creator.ImportBlacklist or {}) do
        if entry == jobName then return true end
    end
    return false
end

-- Prints a message to the console and, if source > 0, sends a notification.
-- Strips FiveM colour codes (^1, ^2, …) from the notification text.
function ImportNotify(source, message, notifyType)
    print(message)
    if source ~= 0 and Notify and Notify.Show then
        local clean = message:gsub("%^%d", "")
        Notify:Show(source, clean, notifyType or "success")
    end
end

-- Returns a set (table keyed by job_name) of jobs already in the DB
function FetchExistingMenuJobs()
    local existing = {}
    local rows = MySQL.query.await("SELECT job_name FROM bablo_bossmenus") or {}
    for _, row in ipairs(rows) do
        existing[row.job_name] = true
    end
    return existing
end

-- Truncates a string to maxChars unicode characters (falls back to byte sub)
function TruncateString(str, maxChars)
    str = tostring(str or "")
    local len = utf8.len(str)
    if not len then
        return str:sub(1, maxChars)
    end
    if maxChars >= len then return str end
    local byteOffset = utf8.offset(str, maxChars + 1) or (#str + 1)
    return str:sub(1, byteOffset - 1)
end

-- Given a grades list, returns a list of grade numbers that have isboss = true
-- but are NOT the highest grade (those are already implicitly boss)
function GetExtraBossGrades(grades)
    local bossGrades = {}
    local topGrade   = nil

    for _, g in ipairs(grades) do
        local n = tonumber(g.grade)
        if n and (not topGrade or n > topGrade) then topGrade = n end
    end

    for _, g in ipairs(grades) do
        local n = tonumber(g.grade)
        if n and g.isboss and n ~= topGrade then
            bossGrades[#bossGrades + 1] = n
        end
    end
    return bossGrades
end

-- ─── Settings decode helpers (used by undo command) ──────────────────────────

-- Safe JSON decode — returns a table or {} on failure
function SafeJsonDecode(raw)
    local ok, result = pcall(json.decode, raw or "{}")
    if ok and type(result) == "table" then return result end
    return {}
end

-- Returns true if value is NOT a table (used to detect "missing" location slots)
function IsNotTable(value)
    return type(value) ~= "table"
end

-- Returns true when a DB row looks like it was never manually configured
-- (i.e. all settings are still at import defaults and locations are empty)
function IsUntouchedImport(row)
    local settings  = SafeJsonDecode(row.settings)
    local ok, locs  = pcall(json.decode, row.locations or "{}")
    local locations = (ok and type(locs) == "table") and locs or {}

    -- All four location slots must be missing/empty tables
    if not IsNotTable(locations.boss)     then return false end
    if not IsNotTable(locations.stash)    then return false end
    if not IsNotTable(locations.wardrobe) then return false end
    if not IsNotTable(locations.garage)   then return false end

    -- Settings must still match the auto-import defaults
    if not IsNotTable(settings.outfits)        then return false end
    if not IsNotTable(settings.storeItems)     then return false end
    if not IsNotTable(settings.storeCategories) then return false end
    if settings.logo ~= nil and settings.logo ~= ""        then return false end
    if settings.lockLogo                                    then return false end
    if settings.color ~= nil and settings.color ~= "#3b82f6" then return false end
    if settings.deliveryStash ~= nil and settings.deliveryStash ~= "" then return false end

    return true
end

-- ─── Import logic ─────────────────────────────────────────────────────────────

-- Imports all framework jobs (or a single job if jobName is provided) into the DB.
-- Returns the number of rows actually inserted.
function BossMenu.ImportFrameworkJobs(source, jobName)
    if not (Framework and Framework.GetAllJobs) then
        ImportNotify(source, "^1[ERROR]^0 BossMenu: the active framework bridge cannot list jobs.", "error")
        return 0
    end

    if not DB.ready then
        ImportNotify(source, "^1[ERROR]^0 BossMenu: the database is not ready yet - try again in a moment.", "error")
        return 0
    end

    if importRunning then
        ImportNotify(source, "^3[WARNING]^0 BossMenu: an import is already running.", "error")
        return 0
    end

    importRunning = true

    local allJobs = Framework:GetAllJobs()
    if type(allJobs) ~= "table" or not next(allJobs) then
        importRunning = false
        ImportNotify(source, "^3[WARNING]^0 BossMenu: no jobs found in the framework.", "error")
        return 0
    end

    -- Single-job mode validation
    if jobName then
        if not allJobs[jobName] then
            importRunning = false
            ImportNotify(source, ("^3[WARNING]^0 BossMenu: your framework has no job named %s."):format(jobName), "error")
            return 0
        end
        if IsBlacklisted(jobName) then
            importRunning = false
            ImportNotify(source, ("^3[WARNING]^0 BossMenu: %s is in Creator.ImportBlacklist and was skipped."):format(jobName), "error")
            return 0
        end
    end

    local existingJobs  = FetchExistingMenuJobs()
    local insertBatch   = {}   -- { query, values } entries for MySQL.transaction
    local importedNames = {}   -- job names successfully queued for insert
    local skippedNames  = {}   -- job names skipped (no grades, name too long, etc.)
    local alreadyHad    = 0    -- jobs that already had a boss menu

    for name, jobData in pairs(allJobs) do
        local shouldProcess = (jobName == nil or jobName == name)
        if not shouldProcess then goto nextJob end
        if IsBlacklisted(name) then goto nextJob end

        if existingJobs[name] then
            alreadyHad = alreadyHad + 1
            goto nextJob
        end

        if #name > 50 then
            skippedNames[#skippedNames + 1] = name .. " (name longer than 50 characters)"
            goto nextJob
        end

        -- Resolve grades from the job data or fall back to framework
        local grades = jobData.grades
        if type(grades) ~= "table" then
            if Framework.GetJobGrades then
                grades = Framework:GetJobGrades(name)
            end
        end

        if type(grades) ~= "table" or #grades == 0 then
            skippedNames[#skippedNames + 1] = name
            goto nextJob
        end

        -- Sort grades ascending
        table.sort(grades, function(a, b)
            return (tonumber(a.grade) or 0) < (tonumber(b.grade) or 0)
        end)

        local settings = {
            societyName          = "society_" .. name,
            color                = "#3b82f6",
            grades               = grades,
            bossMenuGrades       = GetExtraBossGrades(grades),
            outfits              = {},
            storeItems           = {},
            storeCategories      = {},
            storeDeliveryMinutes = 120,
            deliveryStash        = "",
            imported             = true,
        }

        local label = TruncateString(jobData.label or name, 50)

        local emptyLocations = { boss = {}, stash = {}, wardrobe = {}, garage = {} }

        insertBatch[#insertBatch + 1] = {
            query  = "INSERT INTO bablo_bossmenus (job_name, label, locations, settings) VALUES (?, ?, ?, ?)",
            values = { name, label, json.encode(emptyLocations), json.encode(settings) },
        }
        importedNames[#importedNames + 1] = name

        ::nextJob::
    end

    -- Execute inserts
    local insertedCount = 0
    if #insertBatch > 0 then
        local ok = pcall(function()
            return MySQL.transaction.await(insertBatch)
        end)

        if ok then
            insertedCount = #insertBatch
        else
            -- Bulk transaction failed — retry one by one
            ImportNotify(source, "^3[WARNING]^0 BossMenu: bulk import failed (see the oxmysql error above) - retrying one job at a time.", "error")
            for i, entry in ipairs(insertBatch) do
                local rowOk, rowErr = pcall(function()
                    MySQL.insert.await(entry.query, entry.values)
                end)
                if rowOk then
                    insertedCount = insertedCount + 1
                else
                    ImportNotify(source, ("^1[ERROR]^0 BossMenu: could not import %s - %s"):format(importedNames[i], tostring(rowErr)), "error")
                end
            end
        end
    end

    importRunning = false

    -- Report skipped jobs
    if #skippedNames > 0 then
        table.sort(skippedNames)
        ImportNotify(source, ("^3[WARNING]^0 BossMenu: %s job(s) have no grades in the framework and were skipped: %s")
            :format(#skippedNames, table.concat(skippedNames, ", ")), "error")
    end

    ImportNotify(source, ("^2[INFO]^0 BossMenu: imported %s job(s), %s already had a boss menu."):format(insertedCount, alreadyHad))

    if insertedCount > 0 then
        table.sort(importedNames)
        print("^2[INFO]^0 BossMenu: imported " .. table.concat(importedNames, ", "))

        BossMenu.LoadMenus(function(success)
            if not success then return end
            CreateThread(function()
                BossMenu.RegisterJobs()
                BossMenu.SyncAll()
                local creatorCmd = Creator.Command or "bosscreator"
                ImportNotify(source, ("^2[INFO]^0 BossMenu: now place a boss menu location for each job with /%s."):format(creatorCmd))
            end)
        end)
    end

    return insertedCount
end

-- ─── /bossmenuimport command ──────────────────────────────────────────────────

local importCommand = Creator.ImportCommand or "bossmenuimport"

RegisterCommand(importCommand, function(source, args)
    if source ~= 0 then
        if not (Framework and Framework.HasCreatorPermission and Framework:HasCreatorPermission(source)) then
            Notify:Show(source, Tr("notify.no_permission_use", "You do not have permission to use this."), "error")
            return
        end
    end

    local jobName = (args and args[1] ~= "" and args[1]) or nil
    BossMenu.ImportFrameworkJobs(source, jobName)
end, false)

-- ─── /bossmenuimportundo command ─────────────────────────────────────────────

local undoCommand = Creator.ImportUndoCommand or "bossmenuimportundo"

RegisterCommand(undoCommand, function(source, args)
    local undoCmd = Creator.ImportUndoCommand or "bossmenuimportundo"

    if not Settings.Debug then
        if source == 0 then
            print("^3[WARNING]^0 BossMenu: this command only works with Settings.Debug = true.")
        end
        return
    end

    if source ~= 0 then
        if not (Framework and Framework.HasCreatorPermission and Framework:HasCreatorPermission(source)) then
            Notify:Show(source, Tr("notify.no_permission_use", "You do not have permission to use this."), "error")
            return
        end
    end

    if not DB.ready then
        ImportNotify(source, "^1[ERROR]^0 BossMenu: the database is not ready yet.", "error")
        return
    end

    -- Parse flags from args: "legacy" and/or "confirm"
    local flags = {}
    for _, arg in ipairs(args or {}) do
        flags[tostring(arg):lower()] = true
    end
    local includeLegacy = flags.legacy  == true
    local confirmed     = flags.confirm == true

    -- Load all existing rows and split into imported vs untouched-legacy
    local rows = MySQL.query.await("SELECT id, job_name, settings, locations FROM bablo_bossmenus") or {}

    local importedRows = {}  -- rows with imported = true in settings
    local legacyRows   = {}  -- rows that look untouched but have no import marker

    for _, row in ipairs(rows) do
        local settings = SafeJsonDecode(row.settings)
        if settings.imported == true then
            importedRows[#importedRows + 1] = row
        elseif IsUntouchedImport(row) then
            legacyRows[#legacyRows + 1] = row
        end
    end

    -- Helper: extract sorted job_name list from a row array
    local function JobNameList(rowList)
        local names = {}
        for _, row in ipairs(rowList) do names[#names + 1] = row.job_name end
        table.sort(names)
        return names
    end

    -- Build the set of rows to act on
    local targetRows = {}
    for _, row in ipairs(importedRows) do targetRows[#targetRows + 1] = row end
    if includeLegacy then
        for _, row in ipairs(legacyRows) do targetRows[#targetRows + 1] = row end
    end

    if #targetRows == 0 then
        ImportNotify(source, "^2[INFO]^0 BossMenu: no imported boss menus found - nothing to remove.")

        if #legacyRows > 0 and not includeLegacy then
            ImportNotify(source,
                ("^3[WARNING]^0 BossMenu: %s untouched menu(s) without an import marker exist (%s). Run ^5%s legacy^0 to include them.")
                :format(#legacyRows, table.concat(JobNameList(legacyRows), ", "), undoCmd),
                "error")
        end
        return
    end

    -- Dry-run: show what would happen, then exit
    if not confirmed then
        if #importedRows > 0 then
            ImportNotify(source,
                ("^3[WARNING]^0 BossMenu: %s imported menu(s) would be removed: %s")
                :format(#importedRows, table.concat(JobNameList(importedRows), ", ")),
                "error")
        end

        if includeLegacy and #legacyRows > 0 then
            ImportNotify(source,
                ("^3[WARNING]^0 BossMenu: %s untouched legacy menu(s) would be removed: %s")
                :format(#legacyRows, table.concat(JobNameList(legacyRows), ", ")),
                "error")
        elseif not includeLegacy and #legacyRows > 0 then
            ImportNotify(source,
                ("^3[WARNING]^0 BossMenu: %s untouched menu(s) without an import marker are NOT included (%s). Add ^5legacy^0 to include them.")
                :format(#legacyRows, table.concat(JobNameList(legacyRows), ", ")),
                "error")
        end

        local legacyFlag = includeLegacy and " legacy" or ""
        ImportNotify(source,
            ("^3[WARNING]^0 BossMenu: run ^5%s%s confirm^0 to delete. Menus configured by hand in the creator are never touched.")
            :format(undoCmd, legacyFlag),
            "error")
        return
    end

    -- Confirmed: build DELETE IN (?,?,…) and run it
    local ids        = {}
    local placeholders = {}
    for _, row in ipairs(targetRows) do
        ids[#ids + 1]           = row.id
        placeholders[#placeholders + 1] = "?"
    end

    local ok, err = pcall(function()
        MySQL.query.await(
            "DELETE FROM bablo_bossmenus WHERE id IN (" .. table.concat(placeholders, ",") .. ")",
            ids
        )
    end)

    if not ok then
        ImportNotify(source, ("^1[ERROR]^0 BossMenu: could not remove boss menus - %s"):format(tostring(err)), "error")
        return
    end

    local removedNames = JobNameList(targetRows)
    ImportNotify(source, ("^2[INFO]^0 BossMenu: removed %s boss menu(s): %s"):format(#removedNames, table.concat(removedNames, ", ")))

    BossMenu.LoadMenus(function(success)
        if not success then return end
        for _, name in ipairs(removedNames) do
            TriggerClientEvent("bablo-bossmenu:client:removeBossMenu", -1, name)
        end
    end)
end, false)