Orders = {}

-- Tracks how many delivery attempts have been made per order ID
local deliveryAttempts = {}

-- ─── Internal helpers ─────────────────────────────────────────────────────────

-- Returns the cached BossMenu entry for a job name, or nil
function GetMenuByJob(jobName)
    for _, menu in ipairs(BossMenu.Cache) do
        if menu.name == jobName then return menu end
    end
    return nil
end

-- ─── Orders API ───────────────────────────────────────────────────────────────

-- Returns the stash location entry for a menu.
-- Prefers the entry matching stashId; falls back to the first stash in the list.
function Orders.GetStashLocation(menu, stashId)
    local stashes = menu.locations and menu.locations.stash
    if type(stashes) ~= "table" or #stashes == 0 then return nil end

    if stashId and stashId ~= "" then
        for _, stash in ipairs(stashes) do
            if stash.id == stashId then return stash end
        end
    end
    return stashes[1]
end

-- Returns the inventory stash identifier string for a job + stash location
function Orders.StashId(jobName, stashLocation)
    return ("bossmenu_%s_%s"):format(jobName, stashLocation.id)
end

-- Returns the inventory stash metadata table for a menu + stash location
function Orders.StashData(menu, stashLocation)
    return {
        label     = (menu.label or menu.name) .. " - " .. (stashLocation.name or "Stash"),
        maxweight = 2000000,
        slots     = 100,
    }
end

-- Inserts a new pending order into the DB
function Orders.Create(jobName, stashId, items, deliveryMinutes)
    MySQL.insert([[
        INSERT INTO bablo_bossmenu_orders (job_name, stash_id, items, deliver_at)
        VALUES (?, ?, ?, DATE_ADD(NOW(), INTERVAL ? MINUTE))
    ]], { jobName, stashId, json.encode(items), deliveryMinutes })
end

-- ─── Notify helpers ───────────────────────────────────────────────────────────

-- Sends a success notification to every online player working jobName
function NotifyJobMembers(jobName, message)
    if not (Framework and Framework.GetPlayerJob) then return end

    for _, rawSource in ipairs(GetPlayers()) do
        local source = tonumber(rawSource)
        if source then
            local job = Framework:GetPlayerJob(source)
            if job and job.name == jobName then
                Notify:Show(source, message, "success")
            end
        end
    end
end

-- ─── Net events ───────────────────────────────────────────────────────────────

RegisterNetEvent("bablo-bossmenu:server:openStash", function(jobName, stashId)
    local source = source

    if type(jobName) ~= "string" then return end

    if not (Inventory and Inventory.openStash) then
        Notify:Show(source, Tr("notify.no_inventory", "No supported inventory system is running."), "error")
        return
    end

    local playerJob = Framework and Framework.GetPlayerJob and Framework:GetPlayerJob(source)
    if not playerJob or playerJob.name ~= jobName then
        Notify:Show(source, Tr("notify.not_your_job", "You do not work here."), "error")
        return
    end

    local menu = GetMenuByJob(jobName)
    if not menu then return end

    local stashLocation = Orders.GetStashLocation(menu, stashId)
    if not stashLocation then
        Notify:Show(source, Tr("notify.no_stash", "This job has no stash placed."), "error")
        return
    end

    -- Parse coords — may be stored as a "x, y, z" string or as a table
    local coords = stashLocation.coords
    if type(coords) == "string" then
        local x, y, z = coords:match("([%-%d%.]+),%s*([%-%d%.]+),%s*([%-%d%.]+)")
        coords = x and { x = tonumber(x), y = tonumber(y), z = tonumber(z) } or nil
    end

    -- Distance check: player must be within 8 units of the stash
    if type(coords) == "table" and coords.x then
        local ped       = GetPlayerPed(source)
        local playerPos = ped and GetEntityCoords(ped)
        if playerPos then
            local dist = #(playerPos - vec3(coords.x, coords.y, coords.z))
            if dist > 8.0 then return end
        end
    end

    Inventory:openStash(
        source,
        Orders.StashId(jobName, stashLocation),
        Orders.StashData(menu, stashLocation)
    )
end)

-- ─── Order delivery loop ──────────────────────────────────────────────────────

CreateThread(function()
    local intervalMinutes = tonumber(Settings.OrderCheckMinutes) or 10
    intervalMinutes = math.floor(math.max(0.1, math.min(60, intervalMinutes)))
    local intervalMs = intervalMinutes * 60000

    print(("^2[INFO]^0 BossMenu: checking for due store orders every %s minute(s)."):format(intervalMinutes))

    while true do
        Wait(intervalMs)

        if not (Inventory and Inventory.addToStash) then goto continue end

        local dueOrders = MySQL.query.await(
            "SELECT id, job_name, stash_id, items FROM bablo_bossmenu_orders WHERE delivered = 0 AND deliver_at <= NOW()"
        )
        if not dueOrders then goto continue end

        for _, order in ipairs(dueOrders) do
            local ok, items = pcall(json.decode, order.items)
            if not (ok and type(items) == "table") then goto nextOrder end

            local menu      = GetMenuByJob(order.job_name)
            local stashData = menu and {
                label     = (menu.label or order.job_name) .. " Stash",
                maxweight = 2000000,
                slots     = 100,
            } or nil

            -- Try to add each item; collect any that fail
            local failedItems = {}
            for _, item in ipairs(items) do
                local itemName = item.name
                local quantity = tonumber(item.quantity)
                if itemName and quantity then
                    local result = Inventory:addToStash(order.stash_id, itemName, quantity, stashData)
                    if result == false then
                        failedItems[#failedItems + 1] = ("%sx %s"):format(quantity, itemName)
                    end
                end
            end

            if #failedItems == 0 then
                -- All items delivered successfully
                deliveryAttempts[order.id] = nil
                MySQL.update("UPDATE bablo_bossmenu_orders SET delivered = 1 WHERE id = ?", { order.id })
                NotifyJobMembers(order.job_name, Tr("notify.order_delivered", "A store order has been delivered to the job stash."))
            else
                -- Partial or full failure — track attempts
                deliveryAttempts[order.id] = (deliveryAttempts[order.id] or 0) + 1
                local attempts = deliveryAttempts[order.id]

                print(("^1[ERROR]^0 BossMenu: order %s could not be delivered to %s (attempt %s) - %s")
                    :format(order.id, order.stash_id, attempts, table.concat(failedItems, ", ")))

                if attempts >= 5 then
                    -- Give up; mark as failed (delivered = 2) for manual review/refund
                    MySQL.update("UPDATE bablo_bossmenu_orders SET delivered = 2 WHERE id = ?", { order.id })
                    NotifyJobMembers(order.job_name, Tr("notify.order_failed", "A store order could not be delivered - contact an admin."))
                    print(("^1[ERROR]^0 BossMenu: giving up on order %s. It stays in bablo_bossmenu_orders with delivered = 2 so it can be refunded or retried by hand.")
                        :format(order.id))
                end
            end

            ::nextOrder::
        end

        ::continue::
    end
end)