Paycheck = {}

local societyWarningShown = false

-- ─── Salary lookup ────────────────────────────────────────────────────────────

-- Returns the salary for a grade directly from the framework
function GetFrameworkSalary(jobName, gradeNumber)
    if not (Framework and Framework.GetJobGrades) then return 0 end

    local grades = Framework:GetJobGrades(jobName)
    for _, gradeEntry in ipairs(grades or {}) do
        if tonumber(gradeEntry.grade) == tonumber(gradeNumber) then
            return math.floor(tonumber(gradeEntry.salary) or 0)
        end
    end
    return 0
end

-- Returns salary and whether the boss menu cache was the source (hasCachedMenu).
-- Prefers the salary set in the boss menu's grade config over the framework's value.
function ResolveSalary(jobName, gradeNumber)
    local menu = BossMenu.GetCached(jobName)
    local hasCachedMenu = menu ~= nil

    if hasCachedMenu and type(menu.grades) == "table" then
        for _, gradeEntry in ipairs(menu.grades) do
            if tonumber(gradeEntry.grade) == tonumber(gradeNumber) then
                local salary = math.floor(tonumber(gradeEntry.salary) or 0)
                if salary > 0 then
                    return salary, hasCachedMenu
                end
                break
            end
        end
    end

    return GetFrameworkSalary(jobName, gradeNumber), hasCachedMenu
end

-- ─── Paycheck logic ───────────────────────────────────────────────────────────

-- Issues a paycheck to a single player if they qualify
function IssuePaycheck(source)
    -- Resolve current job
    local playerJob = Framework and Framework.GetPlayerJob and Framework:GetPlayerJob(source)
    if not playerJob or not playerJob.name or playerJob.name == "unemployed" then return end

    -- Respect off-duty check unless offDutyPay is enabled
    if not Settings.SalarySystem.offDutyPay then
        if Framework.IsOnDuty and not Framework:IsOnDuty(source) then return end
    end

    local salary, hasCachedMenu = ResolveSalary(playerJob.name, playerJob.grade)
    if salary <= 0 then return end

    -- Society-funded paychecks: deduct from the job's account first
    if Settings.SalarySystem.societyFunded and hasCachedMenu then
        if not (Society and Society.GetBalance and Society.RemoveMoney) then
            if not societyWarningShown then
                societyWarningShown = true
                print("^3[WARNING]^0 BossMenu: Settings.SalarySystem.societyFunded is on but no supported society resource is running - paychecks are not being funded by job accounts.")
            end
            return
        end

        local balance = tonumber(Society:GetBalance(playerJob.name)) or 0
        if salary > balance then
            Notify:Show(source, Tr("notify.paycheck_unaffordable", "Your employer could not afford your paycheck."), "error")
            return
        end

        if Society:RemoveMoney(playerJob.name, salary) == false then
            Notify:Show(source, Tr("notify.paycheck_unaffordable", "Your employer could not afford your paycheck."), "error")
            return
        end
    end

    -- Pay the player
    if not (Framework and Framework.AddPlayerMoney) then return end

    local success = Framework:AddPlayerMoney(source, salary, "bossmenu-paycheck")
    if success then
        local msg = Tr("notify.paycheck_received", "Paycheck received: $%s"):format(salary)
        Notify:Show(source, msg, "success")
    end
end

-- ─── Paycheck loop ────────────────────────────────────────────────────────────

CreateThread(function()
    if not (Settings.SalarySystem and Settings.SalarySystem.enabled) then return end

    local intervalMinutes = math.max(1, math.floor(tonumber(Settings.SalarySystem.intervalMinutes) or 10))
    print(("^2[INFO]^0 BossMenu: custom salary system active (every %s min)."):format(intervalMinutes))

    while true do
        Wait(intervalMinutes * 60000)

        if not Framework then goto continue end

        for _, rawSource in ipairs(GetPlayers()) do
            local source = tonumber(rawSource)
            if source then
                local ok, err = pcall(IssuePaycheck, source)
                if not ok then
                    print(("^1[ERROR]^0 BossMenu paycheck: %s"):format(err))
                end
            end
        end

        ::continue::
    end
end)
