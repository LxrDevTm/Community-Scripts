
Creator = {}

Creator.Command = "bosscreator"

Creator.UsePermissions = true -- locket command on group
Creator.Permissions = {
    "admin",
    "superadmin",
}

-- Bulk import command. Creates a boss menu for every job that already exists in
-- your framework, using each job's real label, grades and salaries - handy on a
-- server that already has a lot of jobs configured.
--
--   /bossmenuimport          imports every job that has no boss menu yet
--   /bossmenuimport police   imports just that one job
--
-- Can also be run from the server console. Jobs that already have a boss menu
-- are never touched, so running it again only picks up what is new. After
-- importing, place a boss menu location for each job in the creator.
Creator.ImportCommand = "bossmenuimport"

-- Jobs the importer always skips.
Creator.ImportBlacklist = {
    "unemployed",
}

-- Removes every boss menu that was created by the import command and has
-- not been touched in the creator since. Handy to reset and re-import.
-- Only works while Settings.Debug is true. Run it once to see what would
-- be removed, then again with "confirm" to actually delete:
--
--   /bossmenuimportundo                  imported menus (dry run)
--   /bossmenuimportundo confirm          delete them
--   /bossmenuimportundo legacy           also include untouched menus that
--                                        pre-date the import marker (dry run)
--   /bossmenuimportundo legacy confirm   delete those too
Creator.ImportUndoCommand = "bossmenuimportundo"
