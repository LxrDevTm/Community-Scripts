
Settings = {}
Settings.Debug = true

-- Which appearance/clothing resource to bridge to.
-- 'auto' picks the first one that is running, in this priority order:
--   illenium-appearance > fivem-appearance > bl_appearance > crm-appearance >
--   rcore_clothing > codem-appearance > tgiann-clothing > qb-clothing >
--   esx_skin > skinchanger
-- Or force one by name, e.g. 'illenium-appearance' or 'qb-clothing'
Settings.Appearance = 'auto'

-- Which inventory resource to bridge to (stashes, store items, deliveries).
-- 'auto' picks the first one that is running, in this priority order:
--   tgiann-inventory > qb-inventory > qs-inventory > ps-inventory >
--   ox_inventory > origen_inventory > core_inventory > codem-inventory
-- Or force one by name, e.g. 'qb-inventory'
Settings.Inventory = 'auto'

-- Which resource holds the society/job money (deposits, withdrawals, salaries).
-- 'auto' picks the first one that is running, in this priority order:
--   bablo-banking > qb-management > esx_addonaccount
-- Or force one by name, e.g. 'qb-management'
Settings.Society = 'auto'

-- Take over salary payouts from the framework, so bosses can set custom
-- per-grade salaries in the boss menu and creator.
--
-- enabled = true:
--   This resource pays every online employee on its own timer. A grade uses
--   the custom salary set for it in the boss menu / creator; grades with no
--   custom salary fall back to the job's default framework payment, and jobs
--   without a boss menu are paid their normal framework salary.
--   IMPORTANT: turn the framework's own paycheck OFF so nobody is paid twice
--     qb-core: comment out the PaycheckInterval() call in qb-core/server/player.lua
--     esx: disable the salary payout in the es_extended config
--
-- enabled = false:
--   Nothing here pays out and the "Set Salary" action is hidden in the boss
--   menu - the framework handles salaries exactly as it did before. (Grade
--   salaries set in the creator are still written into the job data, so the
--   framework's own paycheck keeps using them.)
Settings.SalarySystem = {
    enabled = true,        -- master switch for the custom salary payout system
    intervalMinutes = 10,  -- how often salaries are paid out
    societyFunded = false, -- true = paychecks come out of the job's society money (skipped when it cannot afford)
    offDutyPay = false     -- true = also pay employees who are off duty (QBCore/Qbox duty system)
}

-- How often the server checks for store orders that are due to be delivered.
-- Orders are stored with a delivery time, so this is only how often that list
-- is looked at - an order can therefore land up to this long after the delivery
-- time set for it (a 2 minute item on a 10 minute check arrives in 2-12 min).
-- Lower it if you want deliveries to feel punctual, raise it to do fewer queries.
Settings.OrderCheckMinutes = 10

Settings.SalaryLimit = 25000 -- Highest salary a grade can be given from the boss menu / creator

Settings.RevenueHistoryDays = 30 -- How long to keep revenue data (in days)
Settings.AttendanceHistoryDays = 14 -- How many days to keep attendance history data
Settings.TransactionHistoryDays = 30 -- How many days to keep transactions history data
