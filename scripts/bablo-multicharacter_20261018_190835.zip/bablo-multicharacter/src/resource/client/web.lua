-- Shared NUI response builder used by all callbacks in this file.
local function nuiResponse(success, data, message)
    return { success = success, data = data, message = message }
end

-- Tracks whether a character-creation request is currently in flight.
-- Guards against duplicate CREATE_CHARACTER calls from a double-click.
local createInProgress = false

local function clearCreateInProgress()
    createInProgress = false
end

-- UI_BOOTED: fired by the NUI page once its JS bundle has initialised.
RegisterNUICallback("UI_BOOTED", function(data, cb)
    Main.uiBooted = true
    Trace(("[Main] NUI booted at %d"):format(GetGameTimer()))
    cb(nuiResponse(true, {}, "OK"))
end)

-- PANEL_SHOWN: fired when the character-detail side-panel has finished rendering.
RegisterNUICallback("PANEL_SHOWN", function(data, cb)
    Trace(("[Main] character detail panel rendered at %d"):format(GetGameTimer()))
    cb(nuiResponse(true, {}, "OK"))
end)

-- NUI_JAM: fired by the JS watchdog when the NUI thread was blocked.
-- Logged server-side for diagnostics; no game-state change required.
RegisterNUICallback("NUI_JAM", function(data, cb)
    local duration    = (data and data.duration)    or 0
    local attribution = (data and data.attribution) or ""
    local suffix      = (attribution ~= "") and (" by " .. attribution) or ""
    Trace(("[Main] NUI thread was BLOCKED for %dms%s"):format(duration, suffix))
    cb(nuiResponse(true, {}, "OK"))
end)

-- CLOSE_UI: player dismissed the multichar screen (e.g. pressed Escape).
RegisterNUICallback("CLOSE_UI", function(data, cb)
    Main:Destroy()
    cb(nuiResponse(true, {}, "OK"))
end)

-- UNSELECT_CHARACTER: player clicked away from a selected character card.
RegisterNUICallback("UNSELECT_CHARACTER", function(data, cb)
    Main:unSelectCharacter()
    cb(nuiResponse(true, {}, "OK"))
end)

-- GET_SPAWN_POSITIONS: NUI requests the list of available spawn locations for the spawn menu.
RegisterNUICallback("GET_SPAWN_POSITIONS", function(data, cb)
    cb(nuiResponse(true, Main:exportSpawnPositions(), "OK"))
end)

-- SELECT_CHARACTER: player pressed "Play" on a character card.
-- Resolves the correct spawn strategy (home interior / custom event / world point)
-- then calls Framework.LoadCharacter before spawning.
RegisterNUICallback("SELECT_CHARACTER", function(data, cb)
    local spawnData  = data and data.spawn
    local spawnCoords = spawnData and spawnData.coords
    local houseEntry  = spawnData and spawnData.house
    local charId      = data and data.id

    -- Custom spawn is active when the config enables it AND the spawn menu is disabled.
    local useCustomSpawn = Config.CustomSpawn
        and Config.CustomSpawn.enabled
        and (Config.EnableSpawnMenu == false)

    local function doSpawn()
        if houseEntry and houseEntry.name then
            Main:spawnAtHome(houseEntry)
        elseif useCustomSpawn then
            Main:spawnCustom(charId)
        else
            Main:spawnAtPoint(spawnCoords)
        end
    end

    if charId then
        Framework:LoadCharacter(charId, function(success)
            if success then
                doSpawn()
            else
                Trace(("[NUI] LoadCharacter failed for id=%s"):format(tostring(charId)))
            end
        end)
    end

    cb(nuiResponse(true, {}, "OK"))
end)

-- CREATE_CHARACTER: player submitted the character-creation form.
-- Guarded by createInProgress to prevent duplicate submissions.
RegisterNUICallback("CREATE_CHARACTER", function(data, cb)
    if createInProgress then
        cb(nuiResponse(false, {}, "in progress"))
        return
    end

    -- Check that at least one free (non-locked, empty) slot exists.
    local hasFreeSlot = false
    for _, char in ipairs(Main.characters or {}) do
        if not char.identifier and not char._locked then
            hasFreeSlot = true
            break
        end
    end

    if not hasFreeSlot then
        Trace("[NUI] CreateCharacter blocked — no free (non-locked) slot available")
        cb(nuiResponse(false, {}, "no_free_slot"))
        return
    end

    createInProgress = true

    if data then
        Framework:CreateCharacter(data, function(success, charData)
            if success then
                Main:submitCreate(data, charData)
            else
                Trace("[NUI] CreateCharacter failed")
                Main:cancelCreate()
                createInProgress = false
            end
        end)
    else
        Main:cancelCreate()
        createInProgress = false
    end

    cb(nuiResponse(true, {}, "OK"))
end)

-- CANCEL_CREATE_CHARACTER: player backed out of the creation form.
RegisterNUICallback("CANCEL_CREATE_CHARACTER", function(data, cb)
    Main:cancelCreate()
    cb(nuiResponse(true, {}, "OK"))
end)

-- SWITCH_CHARACTER: player chose a different character while already logged in.
RegisterNUICallback("SWITCH_CHARACTER", function(data, cb)
    if data and data.id then
        Main:switchToCharacter(data.id)
    end
    cb(nuiResponse(true, {}, "OK"))
end)

-- DELETE_CHARACTER: player confirmed character deletion.
RegisterNUICallback("DELETE_CHARACTER", function(data, cb)
    if Config.AllowCharacterDeletion == false then
        cb(nuiResponse(false, {}, "deletion_disabled"))
        return
    end

    local charId = data and data.id
    if charId then
        Framework:DeleteCharacter(charId, function(success)
            if success then
                Main:refreshCast(charId)
            else
                Trace(("[NUI] DeleteCharacter failed — id=%s"):format(tostring(charId)))
            end
        end)
    end

    cb(nuiResponse(true, {}, "OK"))
end)

-- SELECT_SPAWN: player picked a spawn point from the spawn-selection menu.
RegisterNUICallback("SELECT_SPAWN", function(data, cb)
    local coords = data and data.coords
    Main:spawnAtPoint(coords)
    cb(nuiResponse(true, {}, "OK"))
end)

-- Clear createInProgress when the UI is torn down (resource stop or explicit close).
AddEventHandler("onResourceStop", function(resourceName)
    if resourceName == GetCurrentResourceName() then
        clearCreateInProgress()
    end
end)

AddEventHandler(eventName .. "client:closeUI",           clearCreateInProgress)
AddEventHandler(eventName .. "client:multicharDestroyed", clearCreateInProgress)
