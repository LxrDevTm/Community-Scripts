local currentOriginCoords = nil
local currentOriginSpotKey = nil
local currentDestinationSpotKey = nil
local currentDestinationCoords = nil
local destinationFlightReady = false
local currentStationPropEntity = nil
local createdStationBlips = {}

local stationTransitionCamera = nil
local propPreviewCamera = nil
local menuSoundId = nil
local preventExitActive = false

function IsFacingEachOther(firstHeading, secondHeading)
  local headingDifference = math.abs(((firstHeading - secondHeading + 180) % 360) - 180)
  return headingDifference <= 30
end


function GetLocaleText(localeKey, fallbackText)
  local locales = Config.Locales
  if type(locales) == "table" then
    local value = locales[localeKey]
    if type(value) == "string" and value ~= "" then
      return value
    end
  end

  return fallbackText
end

function CreateFlightStations()
  for _, landingSpot in pairs(Config.LandingSpots) do
    lib.zones.box({
      coords = vec3(landingSpot.propCoords.x, landingSpot.propCoords.y, landingSpot.propCoords.z),
      size = vec3(50.0, 50.0, 50.0),
      rotation = landingSpot.propCoords.w,
      debug = false,
      onEnter = function()
        local propModel = 774781230
        RequestModel(propModel)
        while not HasModelLoaded(propModel) do
          Wait(10)
        end

        local propEntity = CreateObject(
          propModel,
          landingSpot.propCoords.x,
          landingSpot.propCoords.y,
          landingSpot.propCoords.z,
          false,
          false,
          false
        )

        SetEntityHeading(propEntity, landingSpot.propCoords.w)
        FreezeEntityPosition(propEntity, true)

        landingSpot.spawnedProp = propEntity
        currentStationPropEntity = propEntity

        exports.ox_target:addLocalEntity(propEntity, {
          {
            icon = "fas fa-plane",
            label = GetLocaleText("target_pick_destination", "Pick Traveling Destination"),
            onSelect = function()
              ChooseTravelingSpot(landingSpot.name, propEntity)
            end,
            canInteract = function()
              local playerPed = PlayerPedId()
              if not DoesEntityExist(propEntity) then
                return false
              end
              return IsFacingEachOther(GetEntityHeading(playerPed), GetEntityHeading(propEntity))
            end,
            distance = 2.0
          }
        })
      end,
      onExit = function()
        if landingSpot.spawnedProp and DoesEntityExist(landingSpot.spawnedProp) then
          exports.ox_target:removeLocalEntity(landingSpot.spawnedProp)
          DeleteEntity(landingSpot.spawnedProp)
          landingSpot.spawnedProp = nil
        end
      end
    })

    if landingSpot.blip then
      local spotCoords = landingSpot.coords
      local blip = AddBlipForCoord(spotCoords.x, spotCoords.y, spotCoords.z)

      SetBlipSprite(blip, Config.Blip.sprite)
      SetBlipDisplay(blip, 4)
      SetBlipScale(blip, Config.Blip.scale)
      SetBlipColour(blip, Config.Blip.color)
      SetBlipAsShortRange(blip, true)

      BeginTextCommandSetBlipName("STRING")
      AddTextComponentString(Config.Blip.name)
      EndTextCommandSetBlipName(blip)

      createdStationBlips[#createdStationBlips + 1] = blip
    end
  end
end

function BuildLandingSpotsWithPrices(fromSpotKey)
  local spotsWithPrices = {}

  if not Config.LandingSpots[fromSpotKey] then
    for spotKey, landingSpot in pairs(Config.LandingSpots) do
      local spotCopy = {}
      for key, value in pairs(landingSpot) do
        spotCopy[key] = value
      end

      spotCopy.price = 1
      if not Config.EnablePayment then
        spotCopy.price = "FREE"
      end

      spotsWithPrices[spotKey] = spotCopy
    end

    return spotsWithPrices
  end

  for spotKey, landingSpot in pairs(Config.LandingSpots) do
    local spotCopy = {}
    for key, value in pairs(landingSpot) do
      spotCopy[key] = value
    end

    local price = 0
    if Config.AutomaticPriceGenerator then
      local fromCoords = Config.LandingSpots[fromSpotKey].coords
      local toCoords = Config.LandingSpots[spotKey].coords
      local fromVector = vector3(fromCoords.x, fromCoords.y, fromCoords.z)
      local toVector = vector3(toCoords.x, toCoords.y, toCoords.z)
      local distance = #(fromVector - toVector)

      price = math.ceil(distance * Config.PricePerMile)
    else
      if Config.Prices[fromSpotKey] and Config.Prices[fromSpotKey][spotKey] ~= nil then
        price = Config.Prices[fromSpotKey][spotKey]
      else
        price = 1
      end
    end

    spotCopy.price = price
    if not Config.EnablePayment then
      spotCopy.price = "FREE"
    end

    spotsWithPrices[spotKey] = spotCopy
  end

  return spotsWithPrices
end

function CreateStationCam(toSpotKey, fromSpotKey)
  local playerPed = PlayerPedId()

  if stationTransitionCamera then
    DestroyCam(stationTransitionCamera, false)
    stationTransitionCamera = nil
  end

  local originalPlayerCoords = GetEntityCoords(playerPed)
  local originalPlayerHeading = GetEntityHeading(playerPed)
  local fromSpot = Config.LandingSpots[fromSpotKey]
  local toSpot = Config.LandingSpots[toSpotKey]

  stationTransitionCamera = CreateCam("DEFAULT_SCRIPTED_CAMERA", true)
  SetCamCoord(
    stationTransitionCamera,
    fromSpot.camera.coords.x,
    fromSpot.camera.coords.y,
    fromSpot.camera.coords.z
  )

  SetCamRot(stationTransitionCamera, -20.0, 0.0, fromSpot.camera.heading, 2)
  SetCamActive(stationTransitionCamera, true)
  RenderScriptCams(true, true, 1500, true, true)

  TransitionToStation(toSpotKey, toSpot)

  Citizen.SetTimeout(5500, function()
    if stationTransitionCamera then
      TransitionToStation(fromSpotKey, fromSpot)
      FreezeEntityPosition(playerPed, false)
      SetEntityVisible(playerPed, true, 0)
      SetEntityCoords(playerPed, originalPlayerCoords.x, originalPlayerCoords.y, originalPlayerCoords.z)
      SetEntityHeading(playerPed, originalPlayerHeading)
      SetEntityCollision(playerPed, true, true)

      RenderScriptCams(false, true, 1500, true, true)
      DestroyCam(stationTransitionCamera, false)
      stationTransitionCamera = nil

      Wait(2000)
      ChooseTravelingSpot(fromSpotKey, currentStationPropEntity)
    end
  end)
end

function InterpolateAngle(fromHeading, toHeading, progress)
  local delta = (toHeading - fromHeading) % 360
  if delta > 180 then
    delta = delta - 360
  end

  return (fromHeading + (delta * progress)) % 360
end

function CalculateHeadingFromPointToPoint(fromCoords, toCoords)
  local deltaX = toCoords.x - fromCoords.x
  local deltaY = toCoords.y - fromCoords.y
  local heading = math.deg(math.atan2(deltaX, deltaY)) % 360
  return heading - 180
end

function TransitionToStation(toSpotKey, fromSpotData)
  local playerPed = PlayerPedId()

  if not stationTransitionCamera then
    return
  end

  local destinationCamera = Config.LandingSpots[toSpotKey].camera
  local currentCamCoords = GetCamCoord(stationTransitionCamera)
  local pitch = -20.0
  local highAltitudeOffset = 900.0

  for progress = 0, 1, 0.01 do
    local interpolatedZ = ((1 - progress) * currentCamCoords.z) + (progress * (currentCamCoords.z + highAltitudeOffset))

    SetCamCoord(stationTransitionCamera, currentCamCoords.x, currentCamCoords.y, interpolatedZ)

    local currentHeading = GetCamRot(stationTransitionCamera, 2).z
    SetCamRot(stationTransitionCamera, pitch, 0.0, currentHeading, 2)

    Citizen.Wait(20)
  end

  local highAltitudePoint = vector3(currentCamCoords.x, currentCamCoords.y, currentCamCoords.z + highAltitudeOffset)
  local travelHeading = CalculateHeadingFromPointToPoint(highAltitudePoint, destinationCamera.coords)

  local currentAltitude = highAltitudePoint.z
  local startX = highAltitudePoint.x
  local startY = highAltitudePoint.y
  local destinationX = destinationCamera.coords.x
  local destinationY = destinationCamera.coords.y

  for progress = 0, 1, 0.01 do
    local interpolatedX = ((1 - progress) * startX) + (progress * destinationX)
    local interpolatedY = ((1 - progress) * startY) + (progress * destinationY)

    SetCamCoord(stationTransitionCamera, interpolatedX, interpolatedY, currentAltitude)
    SetCamRot(stationTransitionCamera, pitch, 0.0, travelHeading, 2)

    Citizen.Wait(20)
  end

  SetEntityVisible(playerPed, false, 0)
  SetEntityCoords(
    playerPed,
    fromSpotData.camera.coords.x,
    fromSpotData.camera.coords.y,
    fromSpotData.camera.coords.z
  )
  SetEntityHeading(playerPed, fromSpotData.camera.heading)
  FreezeEntityPosition(playerPed, true)
  SetEntityCollision(playerPed, false, false)

  local finalCameraPoint = vector3(destinationCamera.coords.x, destinationCamera.coords.y, destinationCamera.coords.z + 2.0)
  local startHeading = travelHeading
  local endHeading = destinationCamera.heading

  for progress = 0, 1, 0.01 do
    local interpolatedZ = ((1 - progress) * currentAltitude) + (progress * finalCameraPoint.z)
    local interpolatedHeading = InterpolateAngle(startHeading, endHeading, progress)

    SetCamCoord(stationTransitionCamera, finalCameraPoint.x, finalCameraPoint.y, interpolatedZ)
    SetCamRot(stationTransitionCamera, pitch, 0.0, interpolatedHeading, 2)

    Citizen.Wait(20)
  end

  SetCamCoord(stationTransitionCamera, finalCameraPoint.x, finalCameraPoint.y, finalCameraPoint.z)
  SetCamRot(stationTransitionCamera, pitch, 0.0, endHeading, 2)
end

function CreateCustomCameraOnProp(propEntity, fieldOfView)
  local propCoords = GetEntityCoords(propEntity)
  local forwardVector = GetEntityForwardVector(propEntity)
  local cameraCoords = propCoords - (forwardVector * 0.7)
  local propHeading = GetEntityHeading(propEntity) + 180.0

  local camera = CreateCam("DEFAULT_SCRIPTED_CAMERA", true)
  SetCamCoord(camera, cameraCoords.x, cameraCoords.y, cameraCoords.z + 1.3)
  SetCamRot(camera, 0.0, 0.0, propHeading + 180.0, 2)
  SetCamActive(camera, true)
  SetCamFov(camera, fieldOfView)
  RenderScriptCams(true, false, 0, true, false)

  propPreviewCamera = camera
end

function DeleteCustomCamera()
  if propPreviewCamera then
    RenderScriptCams(false, false, 0, true, true)
    DestroyCam(propPreviewCamera, false)
    propPreviewCamera = nil
  end
end

function PayAnimation()
  local playerPed = PlayerPedId()

  local firstAnimDict = "weapons@pistol@"
  local firstAnimName = "aim_2_holster"
  RequestAnimDict(firstAnimDict)
  while not HasAnimDictLoaded(firstAnimDict) do
    Wait(10)
  end

  TaskPlayAnim(playerPed, firstAnimDict, firstAnimName, 3.0, -1, -1, 49, 0, false, false, false)
  Wait(1000)

  local cashPropModel = GetHashKey("prop_anim_cash_pile_01")
  RequestModel(cashPropModel)
  while not HasModelLoaded(cashPropModel) do
    Wait(10)
  end

  local playerCoords = GetEntityCoords(playerPed)
  local cashProp = CreateObject(cashPropModel, playerCoords.x, playerCoords.y, playerCoords.z + 0.2, true, true, true)

  AttachEntityToEntity(
    cashProp,
    playerPed,
    GetPedBoneIndex(playerPed, 57005),
    0.12,
    0.02,
    -0.02,
    90.0,
    180.0,
    0.0,
    true,
    true,
    false,
    true,
    1,
    true
  )

  local secondAnimDict = "anim@heists@keycard@"
  local secondAnimName = "exit"
  RequestAnimDict(secondAnimDict)
  while not HasAnimDictLoaded(secondAnimDict) do
    Wait(10)
  end

  TaskPlayAnim(playerPed, secondAnimDict, secondAnimName, 3.0, -1, -1, 49, 0, false, false, false)
  Wait(1000)

  DeleteEntity(cashProp)
  ClearPedTasks(playerPed)
end

CreateFlightStations()

function ChooseTravelingSpot(fromSpotKey, propEntity)
  if menuSoundId then
    StopSound(menuSoundId)
    menuSoundId = nil
  end

  if propEntity and DoesEntityExist(propEntity) then
    CreateCustomCameraOnProp(propEntity, 40.0)
  else
    DeleteCustomCamera()
  end

  local spotsWithPrices = BuildLandingSpotsWithPrices(fromSpotKey)

  SetNuiFocus(true, true)
  SendNUIMessage({
    action = "openUI",
    start = fromSpotKey,
    spots = spotsWithPrices
  })

  while not RequestScriptAudioBank("audiodirectory/custom_sounds", false) do
    Wait(0)
  end

  menuSoundId = GetSoundId()
  PlaySoundFrontend(menuSoundId, "nteamdron", "special_soundset", true)
  ReleaseSoundId(menuSoundId)
  menuSoundId = nil

  Wait(2000)
  ReleaseNamedScriptAudioBank("audiodirectory/custom_sounds")
end

function IsEntityNearCoords(entity, x, y, z, radius)
  if not DoesEntityExist(entity) then
    return false
  end

  if not radius then
    radius = 1.0
  end

  return IsEntityAtCoord(entity, x, y, z, radius, radius, radius, false, false, 0)
end

RegisterNetEvent("nteam_dron:client:starttransport")
AddEventHandler("nteam_dron:client:starttransport", function()
  PayAnimation()

  local playerPed = PlayerPedId()

  TaskGoStraightToCoord(
    playerPed,
    currentOriginCoords.x - 2.0,
    currentOriginCoords.y - 1.0,
    currentOriginCoords.z,
    1.0,
    -1,
    currentOriginCoords.w or 0.0,
    0.0
  )

  Citizen.CreateThread(function()
    local reachedTakeoffPoint = false

    while not reachedTakeoffPoint do
      Citizen.Wait(500)

      local playerCoords = GetEntityCoords(playerPed)
      local distanceToTakeoff = #(playerCoords - vector3(currentOriginCoords.x, currentOriginCoords.y, currentOriginCoords.z))
      if distanceToTakeoff < 5.5 then
        reachedTakeoffPoint = true
        FreezeEntityPosition(playerPed, true)
        ClearPedTasks(playerPed)
        spawnDrone()
      end
    end
  end)
end)

function PreventExitThread()
  CreateThread(function()
    PlayerPedId()

    while preventExitActive do
      Wait(0)
      DisableControlAction(0, 75, true)
      DisableControlAction(27, 75, true)
    end
  end)
end

function spawnDrone()
  destinationFlightReady = false

  local rerouteTriggered = false
  local playerPed = PlayerPedId()

  local droneModel = 1656007438
  RequestModel(droneModel)
  while not HasModelLoaded(droneModel) do
    Wait(0)
  end

  local spawnCoords = currentOriginCoords
  local droneVehicle = CreateVehicle(
    droneModel,
    spawnCoords.x,
    spawnCoords.y,
    spawnCoords.z + 10.0,
    spawnCoords.w,
    true,
    false
  )

  local configuredFuel = Config.DroneFuelAmount
  if Config.Fuel and Config.Fuel.Amount ~= nil then
    configuredFuel = Config.Fuel.Amount
  end

  local droneFuelAmount = tonumber(configuredFuel) or 100.0
  if droneFuelAmount < 0 then
    droneFuelAmount = 0
  end

  SetFuel(droneVehicle, droneFuelAmount)
  SetVehicleDoorsLocked(droneVehicle, 1)
  SetVehicleDoorsLockedForAllPlayers(droneVehicle, false)
  SetEntityAsMissionEntity(droneVehicle, true, true)
  SetVehicleEngineOn(droneVehicle, true, true, false)

  local pilotModel = -413447396
  RequestModel(pilotModel)
  while not HasModelLoaded(pilotModel) do
    Wait(0)
  end

  local pilotPed = CreatePedInsideVehicle(droneVehicle, 1, pilotModel, -1, true, false)

  SetBlockingOfNonTemporaryEvents(pilotPed, true)
  SetPedFleeAttributes(pilotPed, 0, 0)
  SetPedCanBeDraggedOut(pilotPed, false)
  SetPedKeepTask(pilotPed, true)

  preventExitActive = true
  PreventExitThread()

  local descendFinished = false
  local ascendFinished = false

  CreateThread(function()
    while not descendFinished do
      if not DoesEntityExist(droneVehicle) then
        break
      end

      if GetEntityCoords(droneVehicle).z <= currentOriginCoords.z + 0.7 then
        descendFinished = true

        SetVehicleUndriveable(droneVehicle, true)
        SetEntityVelocity(droneVehicle, 0.0, 0.0, 0.0)
        SetEntityCoords(droneVehicle, spawnCoords.x, spawnCoords.y, spawnCoords.z, false, false, false, true)
        FreezeEntityPosition(droneVehicle, true)
        SetVehicleEngineOn(droneVehicle, false, true, true)

        Wait(15000)

        FreezeEntityPosition(playerPed, false)
        TaskEnterVehicle(playerPed, droneVehicle, 6500, 0, 1.0, 1, 0)

        local enterAttempts = 0
        while not IsPedInAnyVehicle(playerPed, false) and enterAttempts < 50 do
          Wait(100)
          enterAttempts = enterAttempts + 1
        end

        if not IsPedInAnyVehicle(playerPed, false) then
          TaskWarpPedIntoVehicle(playerPed, droneVehicle, 0)
        end

        FreezeEntityPosition(playerPed, true)
        FreezeEntityPosition(droneVehicle, false)
        SetVehicleEngineOn(droneVehicle, true, true, true)
        SetVehicleUndriveable(droneVehicle, false)

        break
      end

      DisableControlAction(0, 75, true)
      SetEntityVelocity(droneVehicle, 0.0, 0.0, -1.5)
      SetEntityHeading(droneVehicle, GetEntityHeading(droneVehicle))
      Citizen.Wait(0)
    end

    Wait(2000)

    while not ascendFinished do
      if GetEntityCoords(droneVehicle).z >= currentOriginCoords.z + 20.0 then
        ascendFinished = true
        TriggerServerEvent("nteam_dron:server:UpdateSpotStatus", currentOriginSpotKey)
        destinationFlightReady = true
        break
      end

      DisableControlAction(0, 75, true)
      SetEntityHeading(droneVehicle, GetEntityHeading(droneVehicle))
      SetEntityVelocity(droneVehicle, 0.0, 0.0, 1.5)
      Citizen.Wait(0)
    end
  end)

  CreateThread(function()
    while not destinationFlightReady do
      Wait(100)
    end

    local movingToDestination = true
    local driveSpeed = Config.DefaultDroneSpeed

    if Config.Speeds[currentOriginSpotKey] and Config.Speeds[currentOriginSpotKey][currentDestinationSpotKey] then
      driveSpeed = Config.Speeds[currentOriginSpotKey][currentDestinationSpotKey]
    end

    TaskVehicleDriveToCoord(
      pilotPed,
      droneVehicle,
      currentDestinationCoords.x,
      currentDestinationCoords.y,
      currentDestinationCoords.z + 20.0,
      driveSpeed,
      0,
      GetEntityModel(droneVehicle),
      16777216,
      5.0
    )

    local waitDuration = 100
    local travelFinished = false

    while not travelFinished do
      if movingToDestination then
        if IsEntityNearCoords(droneVehicle, currentDestinationCoords.x, currentDestinationCoords.y, currentDestinationCoords.z, 1.0) then
          ClearPedTasks(pilotPed)
          TriggerServerEvent("nteam_dron:server:UpdateSpotStatus", currentDestinationSpotKey)
          movingToDestination = false
          SetEntityHeading(droneVehicle, GetEntityHeading(droneVehicle))
        end

        if IsEntityNearCoords(droneVehicle, currentDestinationCoords.x, currentDestinationCoords.y, currentDestinationCoords.z, 200.0) then
          if not rerouteTriggered then
            rerouteTriggered = true
            ClearPedTasks(pilotPed)
            Wait(100)

            TaskVehicleDriveToCoord(
              pilotPed,
              droneVehicle,
              currentDestinationCoords.x,
              currentDestinationCoords.y,
              currentDestinationCoords.z + 20.0,
              10.0,
              0,
              GetEntityModel(droneVehicle),
              16777216,
              5.0
            )
          end
        end
      end

      if not movingToDestination then
        waitDuration = 0

        local droneCoords = GetEntityCoords(droneVehicle)
        if droneCoords.z <= currentDestinationCoords.z + 0.7 then
          local completedSpotKey = currentDestinationSpotKey

          SetEntityVelocity(droneVehicle, 0.0, 0.0, 0.0)
          SetVehicleEngineOn(droneVehicle, false, true, true)
          FreezeEntityPosition(droneVehicle, true)
          SetVehicleUndriveable(droneVehicle, true)

          Wait(18000)

          FreezeEntityPosition(playerPed, false)
          TaskLeaveVehicle(playerPed, droneVehicle, 0)
          preventExitActive = false

          Wait(1000)

          local destinationData = Config.LandingSpots[currentDestinationSpotKey]
          local walkOffCoords = destinationData and destinationData.walkoffcoords
          if walkOffCoords then
            TaskGoStraightToCoord(
              playerPed,
              walkOffCoords.x,
              walkOffCoords.y,
              walkOffCoords.z,
              1.0,
              12000,
              walkOffCoords.w or 0.0,
              0.5
            )
          end
          Wait(15000)

          FreezeEntityPosition(droneVehicle, false)
          SetVehicleEngineOn(droneVehicle, true, true, true)
          SetVehicleUndriveable(droneVehicle, false)

          for doorIndex = 0, 5, 1 do
            SetVehicleDoorShut(droneVehicle, doorIndex, false)
          end

          Wait(15000)

          DeleteEntity(droneVehicle)
          DeleteEntity(pilotPed)

          travelFinished = true
          TriggerServerEvent("nteam_dron:server:UpdateSpotStatus", completedSpotKey)
          destinationFlightReady = false
          break
        end

        SetEntityHeading(droneVehicle, GetEntityHeading(droneVehicle))
        SetEntityVelocity(droneVehicle, 0.0, 0.0, -1.5)
      end

      Wait(waitDuration)
    end
  end)
end

RegisterNUICallback("closeMenu", function(_, callback)
  SetNuiFocus(false, false)
  callback("ok")
  DeleteCustomCamera()
  if menuSoundId then
    StopSound(menuSoundId)
    menuSoundId = nil
  end
end)

RegisterNUICallback("select", function(data, callback)
  SetNuiFocus(false, false)
  DeleteCustomCamera()

  local toSpotKey = data.to
  local selectedSpot = Config.LandingSpots[toSpotKey]
  if selectedSpot then
    currentOriginCoords = Config.LandingSpots[data.from].coords
    currentOriginSpotKey = data.from
    currentDestinationCoords = selectedSpot.coords
    currentDestinationSpotKey = toSpotKey

    if Config.EnablePayment then
      TriggerServerEvent("nteam_dron:server:tryPayment", currentOriginSpotKey, toSpotKey, true)
    else
      TriggerServerEvent("nteam_dron:server:tryPayment", currentOriginSpotKey, toSpotKey, false)
    end
  end

  callback("ok")
end)

RegisterNUICallback("preview", function(data, callback)
  DeleteCustomCamera()
  SetNuiFocus(false, false)
  CreateStationCam(data.to, data.from)
  callback("ok")
end)

AddEventHandler("onResourceStop", function(resourceName)
  if GetCurrentResourceName() ~= resourceName then
    return
  end

  local playerPed = PlayerPedId()
  FreezeEntityPosition(playerPed, false)

  if menuSoundId then
    StopSound(menuSoundId)
    menuSoundId = nil
  end

  for _, blip in ipairs(createdStationBlips) do
    if DoesBlipExist(blip) then
      RemoveBlip(blip)
    end
  end
end)


