function IsFuelResourceStarted(resourceName)
	if type(resourceName) ~= "string" or resourceName == "" then
		return false
	end

	return GetResourceState(resourceName) == "started"
end

function GetFuelConfig()
	local fuelConfig = Config.Fuel or {}

	local amount = tonumber(fuelConfig.Amount)
	if not amount then
		amount = tonumber(Config.DroneFuelAmount) or 100.0
	end
	if amount < 0 then
		amount = 0
	end

	return {
		enabled = fuelConfig.Enabled ~= false,
		amount = amount,
		provider = tostring(fuelConfig.Provider or "auto"):lower(),
		resource = tostring(fuelConfig.Resource or "ox_fuel"),
		exportName = tostring(fuelConfig.ExportName or "SetFuel"),
		eventName = fuelConfig.EventName,
		stateBagFallback = fuelConfig.StateBagFallback ~= false,
		nativeFallback = fuelConfig.NativeFallback ~= false
	}
end

function ApplyFuelByDynamicExport(resourceName, exportName, vehicle, fuelAmount)
	if not IsFuelResourceStarted(resourceName) then
		return false
	end

	local exportTable = exports[resourceName]
	if not exportTable then
		return false
	end

	local exportFunction = exportTable[exportName]
	if type(exportFunction) ~= "function" then
		return false
	end

	local success = pcall(function()
		exportFunction(vehicle, fuelAmount)
	end)
	if success then
		return true
	end

	success = pcall(function()
		exportFunction(exportTable, vehicle, fuelAmount)
	end)
	return success
end

function ApplyFuelByStateBag(vehicle, fuelAmount)
	local success = pcall(function()
		Entity(vehicle).state.fuel = fuelAmount
	end)
	return success
end

function ApplyFuelByEvent(eventName, vehicle, fuelAmount)
	if type(eventName) ~= "string" or eventName == "" then
		return false
	end

	TriggerEvent(eventName, vehicle, fuelAmount)
	return true
end

function ApplyFuelByProvider(providerName, resourceName, exportName, eventName, vehicle, fuelAmount)
	if providerName == "custom" then
		if ApplyFuelByEvent(eventName, vehicle, fuelAmount) then
			return true
		end
		return ApplyFuelByDynamicExport(resourceName, exportName, vehicle, fuelAmount)
	end

	if providerName == "ox_fuel" then
		if resourceName ~= "" and IsFuelResourceStarted(resourceName) then
			return ApplyFuelByStateBag(vehicle, fuelAmount)
		end
		if IsFuelResourceStarted("ox_fuel") then
			return ApplyFuelByStateBag(vehicle, fuelAmount)
		end
		return false
	end

	if providerName == "legacyfuel" or providerName == "legacy_fuel" then
		if ApplyFuelByDynamicExport(resourceName, "SetFuel", vehicle, fuelAmount) then
			return true
		end
		return ApplyFuelByDynamicExport("LegacyFuel", "SetFuel", vehicle, fuelAmount)
	end

	if providerName == "ps-fuel" or providerName == "ps_fuel" then
		if ApplyFuelByDynamicExport(resourceName, "SetFuel", vehicle, fuelAmount) then
			return true
		end
		return ApplyFuelByDynamicExport("ps-fuel", "SetFuel", vehicle, fuelAmount)
	end

	if providerName == "cdn-fuel" or providerName == "cdn_fuel" then
		if ApplyFuelByDynamicExport(resourceName, "SetFuel", vehicle, fuelAmount) then
			return true
		end
		return ApplyFuelByDynamicExport("cdn-fuel", "SetFuel", vehicle, fuelAmount)
	end

	if providerName == "auto" then
		if resourceName ~= "" and IsFuelResourceStarted(resourceName) then
			if resourceName == "ox_fuel" and ApplyFuelByStateBag(vehicle, fuelAmount) then
				return true
			end

			if ApplyFuelByDynamicExport(resourceName, exportName, vehicle, fuelAmount) then
				return true
			end
		end

		if IsFuelResourceStarted("ox_fuel") and ApplyFuelByStateBag(vehicle, fuelAmount) then
			return true
		end
		if ApplyFuelByDynamicExport("LegacyFuel", "SetFuel", vehicle, fuelAmount) then
			return true
		end
		if ApplyFuelByDynamicExport("ps-fuel", "SetFuel", vehicle, fuelAmount) then
			return true
		end
		if ApplyFuelByDynamicExport("cdn-fuel", "SetFuel", vehicle, fuelAmount) then
			return true
		end
	end

	return false
end

function SetFuel(vehicle, fuel)
	if not vehicle or vehicle == 0 or not DoesEntityExist(vehicle) then
		return
	end

	local fuelConfig = GetFuelConfig()
	if not fuelConfig.enabled then
		return
	end

	local fuelAmount = tonumber(fuel)
	if not fuelAmount then
		fuelAmount = fuelConfig.amount
	end
	if fuelAmount < 0 then
		fuelAmount = 0
	end

	local wasApplied = ApplyFuelByProvider(
		fuelConfig.provider,
		fuelConfig.resource,
		fuelConfig.exportName,
		fuelConfig.eventName,
		vehicle,
		fuelAmount
	)

	if not wasApplied and fuelConfig.stateBagFallback then
		ApplyFuelByStateBag(vehicle, fuelAmount)
	end

	if fuelConfig.nativeFallback then
		SetVehicleFuelLevel(vehicle, math.min(fuelAmount, 100.0))
	end
end
