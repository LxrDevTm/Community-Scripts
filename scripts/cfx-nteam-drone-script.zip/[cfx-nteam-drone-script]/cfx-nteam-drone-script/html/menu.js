// Funkcija za otvaranje i upravljanje UI
function ChooseTravelingSpot(start, landingSpots) {
  const ui = document.getElementById('travelUI');
  const optionsList = document.getElementById('optionsList');
  const previewBox = document.getElementById('previewBox');
  const previewPlaceholder = document.getElementById('previewPlaceholder');
  const selectBtn = document.getElementById('selectBtn');
  const previewBtn = document.getElementById('previewBtn');
  const selectedName = document.getElementById('selectedName');
  const startLabel = document.getElementById('startLabel');

  // Prikaz UI
  ui.style.display = "grid";
  startLabel.textContent = `Start: ${start}`;

  optionsList.innerHTML = '';
  previewBox.innerHTML = '';
  previewBox.appendChild(previewPlaceholder.cloneNode(true));

  let state = { selected: null };

  // Pretvaranje Lua objekta u JS niz
  const spotsArray = Object.values(landingSpots);

  spotsArray.forEach(sp => {
    if (sp.name === start) return;

    const el = document.createElement('div');
    el.className = 'option';
    el.innerHTML = `
      <div class="icon">✈️</div>
      <div class="meta">
        <div class="title">${sp.name.toUpperCase()}</div>
        <div class="subtitle">${'$' + sp.price}</div>
      </div>
    `;

    // Hover za preview
    el.addEventListener('mouseenter', () => showPreview(sp));

    // Kada se skine hover
    // el.addEventListener('mouseleave', () => {
    //   // Ako ova opcija NIJE selektovana, vrati na placeholder
    //   if (state.selected !== sp) {
    //     previewBox.innerHTML = '';
    //     previewBox.appendChild(previewPlaceholder.cloneNode(true));
    //   }
    // });

    // Klik za selekciju
    el.addEventListener('click', () => {
      document.querySelectorAll('.option').forEach(o => o.classList.remove('selected'));
      el.classList.add('selected');
      state.selected = sp;
      selectedName.textContent = sp.name;
      selectBtn.disabled = false;
      previewBtn.disabled = false;
      showPreview(sp);
    });

    optionsList.appendChild(el);
  });

  // Funkcija za prikaz preview slike
  function showPreview(opt) {
    previewBox.innerHTML = '';
    const img = document.createElement('img');
    img.src = `nui://cfx-nteam-drone-script/html/images/${opt.image}`;
    img.alt = opt.name;
    img.style.width = '100%';
    img.style.height = '100%';
    img.style.objectFit = 'cover';
    previewBox.appendChild(img);
  }

  // Funkcija za zatvaranje UI
  function closeUI() {
    ui.style.display = "none";

    // Reset dugmadi i selekcije
    selectBtn.disabled = true;
    previewBtn.disabled = true;
    selectedName.textContent = 'No Destination Selected';
    previewBox.innerHTML = '';
    previewBox.appendChild(previewPlaceholder.cloneNode(true));

    // Pošalji callback clientu da zatvori fokus
    sendToClient('closeMenu');
  }

  // Dugmad
  selectBtn.onclick = () => {
    if (!state.selected) return;
    sendToClient('select', { from: start, to: state.selected.name });
    closeUI();
  };

  previewBtn.onclick = () => {
    if (!state.selected) return;
    sendToClient('preview', { from: start, to: state.selected.name });
    closeUI();
  };

  // ESC za zatvaranje
  document.addEventListener('keydown', (event) => {
    if (event.key === "Escape" && ui.style.display !== "none") {
      closeUI();
    }
  });
}

// Helper za callback clientu (FiveM NUI standard)
function sendToClient(type, data = {}) {
  fetch(`https://${GetParentResourceName()}/${type}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data)
  });
}

// Sluša otvaranje UI od clienta
window.addEventListener('message', (event) => {
  const data = event.data;
  if (data.action === 'openUI') {
    ChooseTravelingSpot(data.start, data.spots);
  }
});
