DroneFrameworkObject = nil
DroneFrameworkName = string.upper(Config.FrameWork or "")

if DroneFrameworkName ~= "ESX" and DroneFrameworkName ~= "QB" and DroneFrameworkName ~= "QBCORE" and DroneFrameworkName ~= "QBOX" and DroneFrameworkName ~= "QBX" then
  if GetResourceState("qbx_core") == "started" then
    DroneFrameworkName = "QBOX"
  elseif GetResourceState("qb-core") == "started" then
    DroneFrameworkName = "QBCORE"
  elseif GetResourceState("es_extended") == "started" then
    DroneFrameworkName = "ESX"
  end
end

function LoadFrameworkObject()
  if DroneFrameworkObject then
    return
  end

  if DroneFrameworkName == "ESX" then
    if GetResourceState("es_extended") == "started" then
      DroneFrameworkObject = exports["es_extended"]:getSharedObject()
    end

    if not DroneFrameworkObject then
      TriggerEvent("esx:getSharedObject", function(object)
        DroneFrameworkObject = object
      end)
    end
    return
  end

  if DroneFrameworkName == "QB" or DroneFrameworkName == "QBCORE" then
    if GetResourceState("qb-core") == "started" then
      DroneFrameworkObject = exports["qb-core"]:GetCoreObject()
    end
    return
  end

  if DroneFrameworkName == "QBOX" or DroneFrameworkName == "QBX" then
    if GetResourceState("qbx_core") == "started" then
      DroneFrameworkObject = exports["qbx_core"]
    end
    return
  end
end

LoadFrameworkObject()

function GetFrameworkPlayer(playerSource)
  if not DroneFrameworkObject then
    LoadFrameworkObject()
  end

  if DroneFrameworkName == "ESX" and DroneFrameworkObject then
    return DroneFrameworkObject.GetPlayerFromId(playerSource)
  end

  if (DroneFrameworkName == "QB" or DroneFrameworkName == "QBCORE") and DroneFrameworkObject then
    return DroneFrameworkObject.Functions.GetPlayer(playerSource)
  end

  if (DroneFrameworkName == "QBOX" or DroneFrameworkName == "QBX") and DroneFrameworkObject then
    return DroneFrameworkObject:GetPlayer(playerSource)
  end

  return nil
end

function IsNotifyResourceStarted(resourceName)
  if type(resourceName) ~= "string" or resourceName == "" then
    return false
  end

  return GetResourceState(resourceName) == "started"
end

function GetNotifyConfig()
  local notifyConfig = Config.Notify or {}
  local typeMap = notifyConfig.TypeMap or {}
  local duration = tonumber(notifyConfig.Duration) or 5000
  if duration < 1000 then
    duration = 1000
  end

  return {
    enabled = notifyConfig.Enabled ~= false,
    system = tostring(notifyConfig.System or "auto"):lower(),
    resource = tostring(notifyConfig.Resource or "ox_lib"),
    resourceEvent = notifyConfig.ResourceEvent,
    duration = duration,
    title = notifyConfig.Title or "Drone Service",
    customEvent = notifyConfig.CustomEvent,
    typeMap = {
      inform = typeMap.inform or "inform",
      success = typeMap.success or "success",
      error = typeMap.error or "error",
      warning = typeMap.warning or "warning"
    }
  }
end

function MapNotifyType(configTypeMap, notifyType)
  local sourceType = tostring(notifyType or "inform"):lower()
  return configTypeMap[sourceType] or configTypeMap.inform or "inform"
end

function SendChatNotify(playerSource, title, message)
  TriggerClientEvent("chat:addMessage", playerSource, {
    color = { 255, 255, 255 },
    args = { title, message }
  })
end

function SendOxLibNotify(playerSource, title, message, mappedType, duration)
  if not IsNotifyResourceStarted("ox_lib") then
    return false
  end

  TriggerClientEvent("ox_lib:notify", playerSource, {
    title = title,
    description = message,
    type = mappedType,
    duration = duration
  })
  return true
end

function SendFrameworkNotify(playerSource, message, mappedType)
  if DroneFrameworkName == "ESX" then
    TriggerClientEvent("esx:showNotification", playerSource, message)
    return true
  end

  if DroneFrameworkName == "QB" or DroneFrameworkName == "QBCORE" or DroneFrameworkName == "QBOX" or DroneFrameworkName == "QBX" then
    local qbType = mappedType
    if mappedType == "inform" then
      qbType = "primary"
    end
    TriggerClientEvent("QBCore:Notify", playerSource, message, qbType)
    return true
  end

  return false
end

function SendConfiguredResourceNotify(playerSource, notifyConfig, message, mappedType)
  if type(notifyConfig.resourceEvent) == "string" and notifyConfig.resourceEvent ~= "" then
    TriggerClientEvent(notifyConfig.resourceEvent, playerSource, {
      title = notifyConfig.title,
      description = message,
      type = mappedType,
      duration = notifyConfig.duration
    })
    return true
  end

  local resourceName = string.lower(notifyConfig.resource or "")

  if resourceName == "ox_lib" then
    return SendOxLibNotify(playerSource, notifyConfig.title, message, mappedType, notifyConfig.duration)
  end

  if resourceName == "okoknotify" or resourceName == "okok_notify" then
    if IsNotifyResourceStarted("okokNotify") or IsNotifyResourceStarted("okok_notify") then
      local okokType = mappedType
      if mappedType == "inform" then
        okokType = "info"
      end
      TriggerClientEvent("okokNotify:Alert", playerSource, notifyConfig.title, message, notifyConfig.duration, okokType)
      return true
    end
    return false
  end

  if resourceName == "mythic_notify" then
    if IsNotifyResourceStarted("mythic_notify") then
      TriggerClientEvent("mythic_notify:client:SendAlert", playerSource, {
        type = mappedType,
        text = message,
        length = notifyConfig.duration
      })
      return true
    end
    return false
  end

  if resourceName == "wasabi_notify" then
    if IsNotifyResourceStarted("wasabi_notify") then
      TriggerClientEvent("wasabi_notify:notify", playerSource, notifyConfig.title, message, notifyConfig.duration, mappedType)
      return true
    end
    return false
  end

  if resourceName == "framework" or resourceName == "qb-core" or resourceName == "qbx_core" or resourceName == "es_extended" then
    return SendFrameworkNotify(playerSource, message, mappedType)
  end

  return false
end

function NotifyPlayer(playerSource, message, notifyType)
  local safeMessage = tostring(message or "Notification")
  local notifyConfig = GetNotifyConfig()
  if not notifyConfig.enabled then
    return
  end

  local mappedType = MapNotifyType(notifyConfig.typeMap, notifyType)

  if notifyConfig.system == "custom" then
    if type(notifyConfig.customEvent) == "string" and notifyConfig.customEvent ~= "" then
      TriggerClientEvent(notifyConfig.customEvent, playerSource, {
        title = notifyConfig.title,
        description = safeMessage,
        type = mappedType,
        duration = notifyConfig.duration
      })
      return
    end

    SendChatNotify(playerSource, notifyConfig.title, safeMessage)
    return
  end

  if notifyConfig.system == "chat" then
    SendChatNotify(playerSource, notifyConfig.title, safeMessage)
    return
  end

  if notifyConfig.system == "resource" then
    if SendConfiguredResourceNotify(playerSource, notifyConfig, safeMessage, mappedType) then
      return
    end
  end

  if notifyConfig.system == "ox_lib" then
    if SendOxLibNotify(playerSource, notifyConfig.title, safeMessage, mappedType, notifyConfig.duration) then
      return
    end
  end

  if notifyConfig.system == "framework" then
    if SendFrameworkNotify(playerSource, safeMessage, mappedType) then
      return
    end
  end

  if notifyConfig.system == "auto" then
    if SendConfiguredResourceNotify(playerSource, notifyConfig, safeMessage, mappedType) then
      return
    end

    if SendOxLibNotify(playerSource, notifyConfig.title, safeMessage, mappedType, notifyConfig.duration) then
      return
    end

    if SendFrameworkNotify(playerSource, safeMessage, mappedType) then
      return
    end
  end

  SendChatNotify(playerSource, notifyConfig.title, safeMessage)
  print(("[nteam_dron] notify %s: %s"):format(playerSource, safeMessage))
end

function RemovePlayerMoney(playerSource, amount)
  local moneyToRemove = tonumber(amount) or 0
  if moneyToRemove <= 0 then
    return true
  end

  local player = GetFrameworkPlayer(playerSource)
  if not player then
    return false
  end

  if DroneFrameworkName == "ESX" then
    local currentMoney = 0

    if player.getAccount then
      local account = player.getAccount("money")
      if account and account.money then
        currentMoney = account.money
      end
    elseif player.getMoney then
      currentMoney = player.getMoney()
    end

    if currentMoney < moneyToRemove then
      return false
    end

    if player.removeAccountMoney then
      player.removeAccountMoney("money", moneyToRemove)
      return true
    end

    if player.removeMoney then
      player.removeMoney(moneyToRemove)
      return true
    end

    return false
  end

  if DroneFrameworkName == "QB" or DroneFrameworkName == "QBCORE" then
    local currentMoney = 0
    if player.Functions and player.Functions.GetMoney then
      currentMoney = player.Functions.GetMoney("cash") or 0
    end

    if currentMoney < moneyToRemove then
      return false
    end

    if player.Functions and player.Functions.RemoveMoney then
      player.Functions.RemoveMoney("cash", moneyToRemove, "nteam-drone")
      return true
    end

    return false
  end

  if DroneFrameworkName == "QBOX" or DroneFrameworkName == "QBX" then
    local currentMoney = 0
    if player.Functions and player.Functions.GetMoney then
      currentMoney = player.Functions.GetMoney("cash") or 0
    end

    if currentMoney < moneyToRemove then
      return false
    end

    if player.Functions and player.Functions.RemoveMoney then
      player.Functions.RemoveMoney("cash", moneyToRemove, "nteam-drone")
      return true
    end

    return false
  end

  return false
end

