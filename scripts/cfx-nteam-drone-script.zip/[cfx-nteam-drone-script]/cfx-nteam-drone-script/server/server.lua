ActiveFlights = {}
ActiveFlightTimeoutSeconds = tonumber(Config.ActiveFlightTimeoutSeconds) or 600
if ActiveFlightTimeoutSeconds <= 0 then
  ActiveFlightTimeoutSeconds = 600
end

function GetLocaleText(localeKey, fallbackText)
  local locales = Config.Locales
  if type(locales) == "table" then
    local value = locales[localeKey]
    if type(value) == "string" and value ~= "" then
      return value
    end
  end

  return fallbackText
end

function GetLandingSpot(spotKey)
  if type(spotKey) ~= "string" then
    return nil
  end

  local landingSpots = Config.LandingSpots or {}
  return landingSpots[spotKey]
end

function IsSpotAvailable(spotKey)
  local landingSpot = GetLandingSpot(spotKey)
  if not landingSpot then
    return false
  end

  return landingSpot.status ~= false
end

function SetSpotStatus(spotKey, status)
  local landingSpot = GetLandingSpot(spotKey)
  if not landingSpot then
    return false
  end

  if status == true or status == false then
    landingSpot.status = status
  else
    landingSpot.status = not (landingSpot.status ~= false)
  end

  return true
end

function IsFlightStateExpired(flightState)
  if not flightState or not flightState.startedAt then
    return true
  end

  return (os.time() - flightState.startedAt) > ActiveFlightTimeoutSeconds
end

function GetPlayerFlightState(playerSource)
  local flightState = ActiveFlights[playerSource]
  if not flightState then
    return nil
  end

  if IsFlightStateExpired(flightState) then
    ActiveFlights[playerSource] = nil
    return nil
  end

  return flightState
end

function SetPlayerFlightState(playerSource, fromSpotKey, toSpotKey)
  ActiveFlights[playerSource] = {
    fromSpotKey = fromSpotKey,
    toSpotKey = toSpotKey,
    startedAt = os.time()
  }
end

function ClearPlayerFlightState(playerSource)
  ActiveFlights[playerSource] = nil
end

function IsSpotPartOfPlayerFlight(playerSource, spotKey)
  local flightState = GetPlayerFlightState(playerSource)
  if not flightState then
    return false
  end

  return flightState.fromSpotKey == spotKey or flightState.toSpotKey == spotKey
end

function GetRoutePrice(fromSpotKey, toSpotKey)
  local price = 0

  if Config.AutomaticPriceGenerator then
    local fromCoords = Config.LandingSpots[fromSpotKey].coords
    local toCoords = Config.LandingSpots[toSpotKey].coords
    local fromVector = vector3(fromCoords.x, fromCoords.y, fromCoords.z)
    local toVector = vector3(toCoords.x, toCoords.y, toCoords.z)
    local distance = #(fromVector - toVector)

    price = math.ceil(distance * Config.PricePerMile)
  else
    if Config.Prices[fromSpotKey] and Config.Prices[fromSpotKey][toSpotKey] ~= nil then
      price = Config.Prices[fromSpotKey][toSpotKey]
    else
      price = 1
    end
  end

  price = tonumber(price) or 0
  if price < 0 then
    price = 0
  end

  return price
end

RegisterNetEvent("nteam_dron:server:UpdateSpotStatus")
AddEventHandler("nteam_dron:server:UpdateSpotStatus", function(spotKey, forceStatus)
  local playerSource = source
  if playerSource and playerSource > 0 then
    if not IsSpotPartOfPlayerFlight(playerSource, spotKey) then
      return
    end
  end

  local wasUpdated = SetSpotStatus(spotKey, forceStatus)
  if not wasUpdated then
    return
  end

  if playerSource and playerSource > 0 then
    local flightState = GetPlayerFlightState(playerSource)
    if flightState and flightState.toSpotKey == spotKey then
      local destinationSpot = GetLandingSpot(spotKey)
      if destinationSpot and destinationSpot.status ~= false then
        ClearPlayerFlightState(playerSource)
      end
    end
  end
end)

RegisterNetEvent("nteam_dron:server:tryPayment")
AddEventHandler("nteam_dron:server:tryPayment", function(fromSpotKey, toSpotKey)
  local playerSource = source

  if type(fromSpotKey) ~= "string" or type(toSpotKey) ~= "string" then
    NotifyPlayer(playerSource, GetLocaleText("invalid_request", "Invalid flight request."), "error")
    return
  end

  if fromSpotKey == toSpotKey then
    NotifyPlayer(playerSource, GetLocaleText("same_destination", "You are already at this station."), "error")
    return
  end

  if GetPlayerFlightState(playerSource) then
    NotifyPlayer(playerSource, GetLocaleText("already_in_flight", "You already have an active drone flight."), "error")
    return
  end

  local fromSpot = GetLandingSpot(fromSpotKey)
  local toSpot = GetLandingSpot(toSpotKey)

  if not fromSpot or not toSpot then
    NotifyPlayer(playerSource, GetLocaleText("invalid_destination", "Selected station does not exist."), "error")
    return
  end

  if not IsSpotAvailable(fromSpotKey) or not IsSpotAvailable(toSpotKey) then
    NotifyPlayer(playerSource, GetLocaleText("spot_used", "This station is currently unavailable."), "error")
    return
  end

  local mustCharge = Config.EnablePayment
  if mustCharge then
    local routePrice = GetRoutePrice(fromSpotKey, toSpotKey)
    if routePrice > 0 then
      local paid = RemovePlayerMoney(playerSource, routePrice)
      if not paid then
        NotifyPlayer(playerSource, GetLocaleText("no_money", "You do not have enough money."), "error")
        return
      end
    end
  end

  SetSpotStatus(fromSpotKey, false)
  SetPlayerFlightState(playerSource, fromSpotKey, toSpotKey)
  TriggerClientEvent("nteam_dron:client:starttransport", playerSource)
end)

AddEventHandler("playerDropped", function()
  local playerSource = source
  local flightState = ActiveFlights[playerSource]
  if flightState then
    SetSpotStatus(flightState.fromSpotKey, true)
    SetSpotStatus(flightState.toSpotKey, true)
  end
  ClearPlayerFlightState(playerSource)
end)



