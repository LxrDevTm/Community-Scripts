Config = {}

Config.FrameWork = 'QB' -- Code is aditionaly done for ESX and QB, but you can put any framework you are using and add your own code inside server/framework.lua

Config.EnablePayment = true -- If you want to disable payment set this to false
Config.AutomaticPriceGenerator = true -- if you set this to true price will be calculated by distance how much player have to travel from one destination to another if you set this to false on each destination you have to change price
Config.PricePerMile = 1.0 -- if you are using automatic payment ( set this to any number you want, this automatic system is working checking Distance * PricePerMile )

Config.DefaultDroneSpeed = 100.00
Config.DroneFuelAmount = 150.0 -- starting drone fuel
Config.ActiveFlightTimeoutSeconds = 600 -- server-side active-flight safety timeout

Config.Fuel = {
	Enabled = true,
	Amount = 150.0, -- preferred fuel amount (falls back to Config.DroneFuelAmount if nil)
	Provider = "cdn-fuel", -- auto, ox_fuel, legacyfuel, ps-fuel, cdn-fuel, custom
	Resource = "ox_fuel", -- preferred resource for auto/custom providers
	ExportName = "SetFuel", -- used for custom provider export calls
	EventName = nil, -- optional client event for custom provider
	StateBagFallback = true, -- fallback to Entity(vehicle).state.fuel
	NativeFallback = true -- fallback to SetVehicleFuelLevel
}

Config.Notify = {
	Enabled = true, -- set false to disable notifications from this resource
	System = "resource", -- auto, ox_lib, framework, resource, chat, custom
	Resource = "okokNotify", -- resource mode supports: ox_lib, okokNotify, mythic_notify, wasabi_notify
	ResourceEvent = nil, -- optional direct client event for System=resource
	Duration = 5000,
	Title = "Drone Service",
	CustomEvent = nil, -- client event name when System is custom
	TypeMap = {
		inform = "inform",
		success = "success",
		error = "error",
		warning = "warning"
	}
}

Config.ImagesRoot = "nui://cfx-nteam-drone-script/html/images/"

Config.LandingSpots = {
	-- propCoords must be in straight line from coords for landing/flying
	['beach'] = {
		coords = vector4(-1550.5115, -1075.3739, 11.5971, 140.9738),
		name = 'beach',
		status = true,
		propCoords = vector4(-1558.5465, -1067.0444, 8.4869, 142.1855 - 180.0), -- prop coords must be directly in from of stairs
		-- walkoffcoords = vector4(-1544.2556, -1075.7444, 11.5973, 270.1879),
		camera = {coords = vector3(-1557.5962, -1130.3798, 45.7529), heading = 354.6852, name = 'beach'},
		image = 'beach.jpg',
		blip = true, -- If you want to disable blips set this to false
	},
	['highway'] = {
		coords = vector4(-495.3520, -1347.9109, 32.9640, 5.5448),
		name = 'highway',
		status = true,
		propCoords = vector4(-483.7668, -1348.6528, 29.8537, 357.0739 - 180.0),
		-- walkoffcoords = vector4(-499.7803, -1352.1198, 32.9640, 133.0271),
		camera = {coords = vector3(-510.9091, -1304.6688, 47.9677), heading = 201.6076, name = 'highway'},
		image = 'highway.jpg',
		blip = true, -- If you want to disable blips set this to false
	},
	['police'] = {
		coords = vector4(449.3913, -981.3456, 43.6917, 91.2151),
		name = 'police',
		status = true,
		propCoords = vector4(449.3173, -972.5751, 42.6917, 179.3626 - 180.0),
		-- walkoffcoords = vector4(454.7753, -986.2593, 43.6916, 232.4119),
		camera = {coords = vector3(424.0651, -996.4862, 64.0469), heading = 299.9153, name = 'police'},
		image = 'police.jpg',
		blip = true, -- If you want to disable blips set this to false
	},
	['ambulance'] = {
		coords = vector4(351.6245, -587.7859, 74.1656, 233.9938),
		name = 'ambulance',
		status = true,
		propCoords = vector4(340.5121, -581.2504, 73.1656, 250.8548 - 180.0),
		-- walkoffcoords = vector4(358.8053, -587.3202, 74.1656, 277.7320),
		camera = {coords = vector3(375.3659, -633.1843, 128.5697), heading = 29.5875, name = 'ambulance'},
		image = 'ambulance.jpg',
		blip = true, -- If you want to disable blips set this to false
	},
	['airport'] = {
		coords = vector4(-898.7160, -2738.7490, 19.2219, 57.1489),
		name = 'airport',
		status = true,
		propCoords = vector4(-892.5784, -2729.5496, 16.1116, 62.3966 - 180.0),
		-- walkoffcoords = vector4(-897.2491, -2735.9065, 19.2212, 151.2669),
		camera = {coords = vector3(-852.6988, -2696.6235, 56.0924), heading = 131.6306, name = 'airport'},
		image = 'airport.jpg',
		blip = true, -- If you want to disable blips set this to false
	},
	['docks'] = {
		coords = vector4(817.3634, -2924.5454, 11.3375, 165.4979),
		name = 'docks',
		status = true,
		propCoords = vector4(815.6656, -2936.6018, 8.2165, 273.8560 - 180.0),
		-- walkoffcoords = vector4(816.6475, -2928.7676, 11.3324, 1.9480),
		camera = {coords = vector3(754.0939, -2873.6160, 40.3376), heading = 230.1997, name = 'docks'},
		image = 'docks.jpg',
		blip = true, -- If you want to disable blips set this to false
	},
	['casino'] = {
		coords = vector4(994.9900, 215.9809, 87.0254, 158.9716),
		name = 'casino',
		status = true,
		propCoords = vector4(986.8843, 207.6132, 83.9152, 232.2887 - 180.0),
		-- walkoffcoords = vector4(999.2341, 212.4479, 87.0230, 237.6653),
		camera = {coords = vector3(1016.1503, 265.4483, 110.9917), heading = 159.2113, name = 'casino'},
		image = 'casino.jpg',
		blip = true, -- If you want to disable blips set this to false
	},
	['radiotower'] = {
		coords = vector4(821.3611, 1302.9667, 367.8492, 173.9908),
		name = 'radiotower',
		status = true,
		propCoords = vector4(809.9521, 1305.0160, 364.7727, 183.4545 - 180.0),
		-- walkoffcoords = vector4(818.4532, 1304.1862, 367.8698, 266.8111),
		camera = {coords = vector3(866.6048, 1355.2776, 424.3341), heading = 137.5003, name = 'radiotower'},
		image = 'radiotower.jpg',
		blip = true, -- If you want to disable blips set this to false
	},
	['observatorium'] = {
		coords = vector4(-473.0136, 1169.8029, 330.6337, 348.9242),
		name = 'observatorium',
		status = true,
		propCoords = vector4(-461.7780, 1166.9315, 327.5240, 350.6718 - 180.0),
		-- walkoffcoords = vector4(-469.8547, 1168.6768, 330.6337, 71.5930),
		camera = {coords = vector3(-501.9257, 1212.9504, 354.3196), heading = 213.3737, name = 'observatorium'},
		image = 'observatorium.jpg',
		blip = true, -- If you want to disable blips set this to false
	},
	['industrialzone'] = {
		coords = vector4(1203.7139, -2104.8123, 49.9814, 10.6080),
		name = 'industrialzone',
		status = true,
		propCoords = vector4(1215.2972, -2103.1553, 46.8718, 21.7392 - 180.0),
		-- walkoffcoords = vector4(1207.0597, -2104.9783, 49.9820, 103.2354),
		camera = {coords = vector3(1223.7212, -2044.0746, 83.9230), heading = 163.3772, name = 'industrialzone'},
		image = 'industrialzone.jpg',
		blip = true, -- If you want to disable blips set this to false
	},
	['helidock'] = {
		coords = vector4(-745.4754, -1468.7589, 5.0005, 234.2676),
		name = 'helidock',
		status = true,
		propCoords = vector4(-745.4680, -1480.6530, 4.0005, 327.7493 - 180.0),
		-- walkoffcoords = vector4(-749.9058, -1474.5607, 5.0005, 339.7073),
		camera = {coords = vector3(-706.0593, -1457.8722, 29.1650), heading = 106.2908, name = 'helidock'},
		image = 'helidock.jpg',
		blip = true, -- If you want to disable blips set this to false
	},
	['mazebank'] = {
		coords = vector4(-75.2064, -818.9163, 326.1751, 65.3041),
		name = 'mazebank',
		status = true,
		propCoords = vector4(-68.0105, -813.3168, 325.0840, 127.1143 - 180.0),
		-- walkoffcoords = vector4(-71.1260, -813.9545, 326.1751, 138.2509),
		camera = {coords = vector3(-54.1524, -853.8508, 342.0950), heading = 28.3172, name = 'mazebank'},
		image = 'mazebank.jpg',
		blip = true, -- If you want to disable blips set this to false
	},
	['cementary'] = {
		coords = vector4(-1780.2076, -96.4202, 91.3677, 212.7789),
		name = 'cementary',
		status = true,
		propCoords = vector4(-1791.4779, -98.1794, 88.2574, 198.5002 - 180.0),
		-- walkoffcoords = vector4(-1783.3568, -96.3564, 91.3677, 289.4605),
		camera = {coords = vector3(-1817.5292, -53.8644, 118.1012), heading = 217.5169, name = 'cementary'},
		image = 'cementary.jpg',
		blip = true, -- If you want to disable blips set this to false
	},
	['fib'] = {
		coords = vector4(2510.9170, -341.8971, 118.1863, 215.2367),
		name = 'fib',
		status = true,
		propCoords = vector4(2505.5544, -348.2706, 117.0253, 0.1476 - 180.0),
		-- walkoffcoords = vector4(2507.5549, -345.2794, 118.0254, 332.8224),
		camera = {coords = vector3(2558.7341, -369.9431, 152.0328), heading = 59.1754, name = 'fib'},
		image = 'fib.jpg',
		blip = true, -- If you want to disable blips set this to false
	},
	['prison'] = {
		coords = vector4(1941.2589, 2644.0376, 51.8385, 187.7018),
		name = 'prison',
		status = true,
		propCoords = vector4(1930.0244, 2645.1753, 48.7282, 181.0456 - 180.0),
		-- walkoffcoords = vector4(1938.4674, 2644.4104, 51.8385, 264.0851),
		camera = {coords = vector3(1990.6721, 2665.9402, 75.9312), heading = 112.5500, name = 'prison'},
		image = 'prison.jpg',
		blip = true, -- If you want to disable blips set this to false
	},
	['sandy1'] = {
		coords = vector4(529.3227, 2726.2488, 47.2687, 270.6906),
		name = 'sandy1',
		status = true,
		propCoords = vector4(529.5766, 2714.6765, 44.1584, 281.1259 - 180.0),
		-- walkoffcoords = vector4(529.1020, 2723.2634, 47.2687, 358.9577),
		camera = {coords = vector3(491.1952, 2759.5083, 68.9397), heading = 229.0439, name = 'sandy1'},
		image = 'sandy1.jpg',
		blip = true, -- If you want to disable blips set this to false
	},
	['sandy2'] = {
		coords = vector4(1409.5145, 3722.8889, 38.9954, 282.0714),
		name = 'sandy2',
		status = true,
		propCoords = vector4(1411.7542, 3711.6719, 35.8852, 288.9319 - 180.0),
		-- walkoffcoords = vector4(1409.6273, 3719.7192, 38.9954, 13.3425),
		camera = {coords = vector3(1477.0409, 3704.8789, 62.2053), heading = 75.5805, name = 'sandy2'},
		image = 'sandy2.jpg',
		blip = true, -- If you want to disable blips set this to false
	},
	['militarybase'] = {
		coords = vector4(-1877.2839, 2805.3093, 32.8065, 325.3008),
		name = 'militarybase',
		status = true,
		propCoords = vector4(-1889.7356, 2802.9570, 31.8065, 331.0639 - 180.0),
		-- walkoffcoords = vector4(-1884.0480, 2808.8447, 32.8065, 255.5365),
		camera = {coords = vector3(-1850.8367, 2774.1187, 52.8418), heading = 35.4044, name = 'militarybase'},
		image = 'militarybase.jpg',
		blip = true, -- If you want to disable blips set this to false
	},
	['leftside'] = {
		coords = vector4(-3180.5710, 971.8026, 20.4108, 266.2189),
		name = 'leftside',
		status = true,
		propCoords = vector4(-3181.8521, 960.1177, 17.3005, 269.1454 - 180.0),
		-- walkoffcoords = vector4(-3181.0588, 968.5135, 20.4108, 349.7881),
		camera = {coords = vector3(-3115.1099, 941.0656, 54.1460), heading = 65.4701, name = 'leftside'},
		image = 'leftside.jpg',
		blip = true, -- If you want to disable blips set this to false
	},
	['paleto'] = {
		coords = vector4(-454.0475, 6110.5879, 36.4040, 239.2557),
		name = 'paleto',
		status = true,
		propCoords = vector4(-461.3097, 6101.4580, 33.2937, 242.1125 - 180.0),
		-- walkoffcoords = vector4(-456.5062, 6108.3354, 36.4040, 326.0906),
		camera = {coords = vector3(-509.3365, 6105.9346, 71.1228), heading = 274.7047, name = 'paleto'},
		image = 'paleto.jpg',
		blip = true, -- If you want to disable blips set this to false
	},
	['mountchiliad'] = {
		coords = vector4(511.1120, 5522.4951, 783.3984, 78.7345),
		name = 'mountchiliad',
		status = true,
		propCoords = vector4(515.0648, 5533.6318, 780.2892, 74.0131 - 180.0),
		-- walkoffcoords = vector4(512.6268, 5525.5503, 783.3984, 158.6416),
		camera = {coords = vector3(462.4655, 5587.3247, 834.9826), heading = 213.1944, name = 'mountchiliad'},
		image = 'mountchiliad.jpg',
		blip = true, -- If you want to disable blips set this to false
	},
	['grapeseed'] = {
		coords = vector4(1768.7770, 4682.8838, 48.6577, 89.7138),
		name = 'grapeseed',
		status = true,
		propCoords = vector4(1769.7448, 4694.9014, 45.5476, 93.6911 - 180.0),
		-- walkoffcoords = vector4(1769.4015, 4686.4590, 48.6579, 176.9857),
		camera = {coords = vector3(1805.5398, 4642.3389, 77.6518), heading = 39.6199, name = 'grapeseed'},
		image = 'grapeseed.jpg',
		blip = true, -- If you want to disable blips set this to false
	},
}

--==========================================
--				PRICING
--==========================================

-- DON'T EDIT ANYTHING EXCEPT PRICES ( WE ARE USING THIS IF AutomaticPriceGenerator IS FALSE )

Config.Prices = {
	['beach'] = {
		['highway']=1,['police']=1,['ambulance']=1,['airport']=1,['docks']=1,['casino']=1,
		['radiotower']=1,['observatorium']=1,['industrialzone']=1,['helidock']=1,['mazebank']=1,
		['cementary']=1,['fib']=1,['prison']=1,['sandy1']=1,['sandy2']=1,['militarybase']=1,
		['leftside']=1,['paleto']=1,['mountchiliad']=1,['grapeseed']=1,
	},
	['highway'] = {
		['beach']=1,['police']=1,['ambulance']=1,['airport']=1,['docks']=1,['casino']=1,
		['radiotower']=1,['observatorium']=1,['industrialzone']=1,['helidock']=1,['mazebank']=1,
		['cementary']=1,['fib']=1,['prison']=1,['sandy1']=1,['sandy2']=1,['militarybase']=1,
		['leftside']=1,['paleto']=1,['mountchiliad']=1,['grapeseed']=1,
	},
	['police'] = {
		['beach']=1,['highway']=1,['ambulance']=1,['airport']=1,['docks']=1,['casino']=1,
		['radiotower']=1,['observatorium']=1,['industrialzone']=1,['helidock']=1,['mazebank']=1,
		['cementary']=1,['fib']=1,['prison']=1,['sandy1']=1,['sandy2']=1,['militarybase']=1,
		['leftside']=1,['paleto']=1,['mountchiliad']=1,['grapeseed']=1,
	},
	['ambulance'] = {
		['beach']=1,['highway']=1,['police']=1,['airport']=1,['docks']=1,['casino']=1,
		['radiotower']=1,['observatorium']=1,['industrialzone']=1,['helidock']=1,['mazebank']=1,
		['cementary']=1,['fib']=1,['prison']=1,['sandy1']=1,['sandy2']=1,['militarybase']=1,
		['leftside']=1,['paleto']=1,['mountchiliad']=1,['grapeseed']=1,
	},
	['airport'] = {
		['beach']=1,['highway']=1,['police']=1,['ambulance']=1,['docks']=1,['casino']=1,
		['radiotower']=1,['observatorium']=1,['industrialzone']=1,['helidock']=1,['mazebank']=1,
		['cementary']=1,['fib']=1,['prison']=1,['sandy1']=1,['sandy2']=1,['militarybase']=1,
		['leftside']=1,['paleto']=1,['mountchiliad']=1,['grapeseed']=1,
	},
	['docks'] = {
		['beach']=1,['highway']=1,['police']=1,['ambulance']=1,['airport']=1,['casino']=1,
		['radiotower']=1,['observatorium']=1,['industrialzone']=1,['helidock']=1,['mazebank']=1,
		['cementary']=1,['fib']=1,['prison']=1,['sandy1']=1,['sandy2']=1,['militarybase']=1,
		['leftside']=1,['paleto']=1,['mountchiliad']=1,['grapeseed']=1,
	},
	['casino'] = {
		['beach']=1,['highway']=1,['police']=1,['ambulance']=1,['airport']=1,['docks']=1,
		['radiotower']=1,['observatorium']=1,['industrialzone']=1,['helidock']=1,['mazebank']=1,
		['cementary']=1,['fib']=1,['prison']=1,['sandy1']=1,['sandy2']=1,['militarybase']=1,
		['leftside']=1,['paleto']=1,['mountchiliad']=1,['grapeseed']=1,
	},
	['radiotower'] = {
		['beach']=1,['highway']=1,['police']=1,['ambulance']=1,['airport']=1,['docks']=1,
		['casino']=1,['observatorium']=1,['industrialzone']=1,['helidock']=1,['mazebank']=1,
		['cementary']=1,['fib']=1,['prison']=1,['sandy1']=1,['sandy2']=1,['militarybase']=1,
		['leftside']=1,['paleto']=1,['mountchiliad']=1,['grapeseed']=1,
	},
	['observatorium'] = {
		['beach']=1,['highway']=1,['police']=1,['ambulance']=1,['airport']=1,['docks']=1,
		['casino']=1,['radiotower']=1,['industrialzone']=1,['helidock']=1,['mazebank']=1,
		['cementary']=1,['fib']=1,['prison']=1,['sandy1']=1,['sandy2']=1,['militarybase']=1,
		['leftside']=1,['paleto']=1,['mountchiliad']=1,['grapeseed']=1,
	},
	['industrialzone'] = {
		['beach']=1,['highway']=1,['police']=1,['ambulance']=1,['airport']=1,['docks']=1,
		['casino']=1,['radiotower']=1,['observatorium']=1,['helidock']=1,['mazebank']=1,
		['cementary']=1,['fib']=1,['prison']=1,['sandy1']=1,['sandy2']=1,['militarybase']=1,
		['leftside']=1,['paleto']=1,['mountchiliad']=1,['grapeseed']=1,
	},
	['helidock'] = {
		['beach']=1,['highway']=1,['police']=1,['ambulance']=1,['airport']=1,['docks']=1,
		['casino']=1,['radiotower']=1,['observatorium']=1,['industrialzone']=1,['mazebank']=1,
		['cementary']=1,['fib']=1,['prison']=1,['sandy1']=1,['sandy2']=1,['militarybase']=1,
		['leftside']=1,['paleto']=1,['mountchiliad']=1,['grapeseed']=1,
	},
	['mazebank'] = {
		['beach']=1,['highway']=1,['police']=1,['ambulance']=1,['airport']=1,['docks']=1,
		['casino']=1,['radiotower']=1,['observatorium']=1,['industrialzone']=1,['helidock']=1,
		['cementary']=1,['fib']=1,['prison']=1,['sandy1']=1,['sandy2']=1,['militarybase']=1,
		['leftside']=1,['paleto']=1,['mountchiliad']=1,['grapeseed']=1,
	},
	['cementary'] = {
		['beach']=1,['highway']=1,['police']=1,['ambulance']=1,['airport']=1,['docks']=1,
		['casino']=1,['radiotower']=1,['observatorium']=1,['industrialzone']=1,['helidock']=1,
		['mazebank']=1,['fib']=1,['prison']=1,['sandy1']=1,['sandy2']=1,['militarybase']=1,
		['leftside']=1,['paleto']=1,['mountchiliad']=1,['grapeseed']=1,
	},
	['fib'] = {
		['beach']=1,['highway']=1,['police']=1,['ambulance']=1,['airport']=1,['docks']=1,
		['casino']=1,['radiotower']=1,['observatorium']=1,['industrialzone']=1,['helidock']=1,
		['mazebank']=1,['cementary']=1,['prison']=1,['sandy1']=1,['sandy2']=1,['militarybase']=1,
		['leftside']=1,['paleto']=1,['mountchiliad']=1,['grapeseed']=1,
	},
	['prison'] = {
		['beach']=1,['highway']=1,['police']=1,['ambulance']=1,['airport']=1,['docks']=1,
		['casino']=1,['radiotower']=1,['observatorium']=1,['industrialzone']=1,['helidock']=1,
		['mazebank']=1,['cementary']=1,['fib']=1,['sandy1']=1,['sandy2']=1,['militarybase']=1,
		['leftside']=1,['paleto']=1,['mountchiliad']=1,['grapeseed']=1,
	},
	['sandy1'] = {
		['beach']=1,['highway']=1,['police']=1,['ambulance']=1,['airport']=1,['docks']=1,
		['casino']=1,['radiotower']=1,['observatorium']=1,['industrialzone']=1,['helidock']=1,
		['mazebank']=1,['cementary']=1,['fib']=1,['prison']=1,['sandy2']=1,['militarybase']=1,
		['leftside']=1,['paleto']=1,['mountchiliad']=1,['grapeseed']=1,
	},
	['sandy2'] = {
		['beach']=1,['highway']=1,['police']=1,['ambulance']=1,['airport']=1,['docks']=1,
		['casino']=1,['radiotower']=1,['observatorium']=1,['industrialzone']=1,['helidock']=1,
		['mazebank']=1,['cementary']=1,['fib']=1,['prison']=1,['sandy1']=1,['militarybase']=1,
		['leftside']=1,['paleto']=1,['mountchiliad']=1,['grapeseed']=1,
	},
	['militarybase'] = {
		['beach']=1,['highway']=1,['police']=1,['ambulance']=1,['airport']=1,['docks']=1,
		['casino']=1,['radiotower']=1,['observatorium']=1,['industrialzone']=1,['helidock']=1,
		['mazebank']=1,['cementary']=1,['fib']=1,['prison']=1,['sandy1']=1,['sandy2']=1,
		['leftside']=1,['paleto']=1,['mountchiliad']=1,['grapeseed']=1,
	},
	['leftside'] = {
		['beach']=1,['highway']=1,['police']=1,['ambulance']=1,['airport']=1,['docks']=1,
		['casino']=1,['radiotower']=1,['observatorium']=1,['industrialzone']=1,['helidock']=1,
		['mazebank']=1,['cementary']=1,['fib']=1,['prison']=1,['sandy1']=1,['sandy2']=1,
		['militarybase']=1,['paleto']=1,['mountchiliad']=1,['grapeseed']=1,
	},
	['paleto'] = {
		['beach']=1,['highway']=1,['police']=1,['ambulance']=1,['airport']=1,['docks']=1,
		['casino']=1,['radiotower']=1,['observatorium']=1,['industrialzone']=1,['helidock']=1,
		['mazebank']=1,['cementary']=1,['fib']=1,['prison']=1,['sandy1']=1,['sandy2']=1,
		['militarybase']=1,['leftside']=1,['mountchiliad']=1,['grapeseed']=1,
	},
	['mountchiliad'] = {
		['beach']=1,['highway']=1,['police']=1,['ambulance']=1,['airport']=1,['docks']=1,
		['casino']=1,['radiotower']=1,['observatorium']=1,['industrialzone']=1,['helidock']=1,
		['mazebank']=1,['cementary']=1,['fib']=1,['prison']=1,['sandy1']=1,['sandy2']=1,
		['militarybase']=1,['leftside']=1,['paleto']=1,['grapeseed']=1,
	},
	['grapeseed'] = {
		['beach']=1,['highway']=1,['police']=1,['ambulance']=1,['airport']=1,['docks']=1,
		['casino']=1,['radiotower']=1,['observatorium']=1,['industrialzone']=1,['helidock']=1,
		['mazebank']=1,['cementary']=1,['fib']=1,['prison']=1,['sandy1']=1,['sandy2']=1,
		['militarybase']=1,['leftside']=1,['paleto']=1,['mountchiliad']=1,
	},
}

-- HERE YOU CAN CONFIGURE SPEED BETWEEN 2 LOCATIONS IF YOU DONT WANT TO USE DEFAULT ONE

--==========================================
--				SPEEDS
--==========================================

Config.Speeds = {
	['beach'] = {
		['highway']=Config.DefaultDroneSpeed,['police']=Config.DefaultDroneSpeed,['ambulance']=Config.DefaultDroneSpeed,
		['airport']=Config.DefaultDroneSpeed,['docks']=Config.DefaultDroneSpeed,['casino']=Config.DefaultDroneSpeed,
		['radiotower']=Config.DefaultDroneSpeed,['observatorium']=Config.DefaultDroneSpeed,['industrialzone']=Config.DefaultDroneSpeed,
		['helidock']=Config.DefaultDroneSpeed,['mazebank']=Config.DefaultDroneSpeed,['cementary']=Config.DefaultDroneSpeed,
		['fib']=Config.DefaultDroneSpeed,['prison']=Config.DefaultDroneSpeed,['sandy1']=Config.DefaultDroneSpeed,
		['sandy2']=Config.DefaultDroneSpeed,['militarybase']=Config.DefaultDroneSpeed,['leftside']=Config.DefaultDroneSpeed,
		['paleto']=Config.DefaultDroneSpeed,['mountchiliad']=Config.DefaultDroneSpeed,['grapeseed']=Config.DefaultDroneSpeed,
	},
	['highway'] = {
		['beach']=Config.DefaultDroneSpeed,['police']=Config.DefaultDroneSpeed,['ambulance']=Config.DefaultDroneSpeed,
		['airport']=Config.DefaultDroneSpeed,['docks']=Config.DefaultDroneSpeed,['casino']=Config.DefaultDroneSpeed,
		['radiotower']=Config.DefaultDroneSpeed,['observatorium']=Config.DefaultDroneSpeed,['industrialzone']=Config.DefaultDroneSpeed,
		['helidock']=Config.DefaultDroneSpeed,['mazebank']=Config.DefaultDroneSpeed,['cementary']=Config.DefaultDroneSpeed,
		['fib']=Config.DefaultDroneSpeed,['prison']=Config.DefaultDroneSpeed,['sandy1']=Config.DefaultDroneSpeed,
		['sandy2']=Config.DefaultDroneSpeed,['militarybase']=Config.DefaultDroneSpeed,['leftside']=Config.DefaultDroneSpeed,
		['paleto']=Config.DefaultDroneSpeed,['mountchiliad']=Config.DefaultDroneSpeed,['grapeseed']=Config.DefaultDroneSpeed,
	},
	['police'] = {
		['beach']=Config.DefaultDroneSpeed,['highway']=Config.DefaultDroneSpeed,['ambulance']=Config.DefaultDroneSpeed,
		['airport']=Config.DefaultDroneSpeed,['docks']=Config.DefaultDroneSpeed,['casino']=Config.DefaultDroneSpeed,
		['radiotower']=Config.DefaultDroneSpeed,['observatorium']=Config.DefaultDroneSpeed,['industrialzone']=Config.DefaultDroneSpeed,
		['helidock']=Config.DefaultDroneSpeed,['mazebank']=Config.DefaultDroneSpeed,['cementary']=Config.DefaultDroneSpeed,
		['fib']=Config.DefaultDroneSpeed,['prison']=Config.DefaultDroneSpeed,['sandy1']=Config.DefaultDroneSpeed,
		['sandy2']=Config.DefaultDroneSpeed,['militarybase']=Config.DefaultDroneSpeed,['leftside']=Config.DefaultDroneSpeed,
		['paleto']=Config.DefaultDroneSpeed,['mountchiliad']=Config.DefaultDroneSpeed,['grapeseed']=Config.DefaultDroneSpeed,
	},
	['ambulance'] = {
		['beach']=Config.DefaultDroneSpeed,['highway']=Config.DefaultDroneSpeed,['police']=Config.DefaultDroneSpeed,
		['airport']=Config.DefaultDroneSpeed,['docks']=Config.DefaultDroneSpeed,['casino']=Config.DefaultDroneSpeed,
		['radiotower']=Config.DefaultDroneSpeed,['observatorium']=Config.DefaultDroneSpeed,['industrialzone']=Config.DefaultDroneSpeed,
		['helidock']=Config.DefaultDroneSpeed,['mazebank']=Config.DefaultDroneSpeed,['cementary']=Config.DefaultDroneSpeed,
		['fib']=Config.DefaultDroneSpeed,['prison']=Config.DefaultDroneSpeed,['sandy1']=Config.DefaultDroneSpeed,
		['sandy2']=Config.DefaultDroneSpeed,['militarybase']=Config.DefaultDroneSpeed,['leftside']=Config.DefaultDroneSpeed,
		['paleto']=Config.DefaultDroneSpeed,['mountchiliad']=Config.DefaultDroneSpeed,['grapeseed']=Config.DefaultDroneSpeed,
	},
	['airport'] = {
		['beach']=Config.DefaultDroneSpeed,['highway']=Config.DefaultDroneSpeed,['police']=Config.DefaultDroneSpeed,
		['ambulance']=Config.DefaultDroneSpeed,['docks']=Config.DefaultDroneSpeed,['casino']=Config.DefaultDroneSpeed,
		['radiotower']=Config.DefaultDroneSpeed,['observatorium']=Config.DefaultDroneSpeed,['industrialzone']=Config.DefaultDroneSpeed,
		['helidock']=Config.DefaultDroneSpeed,['mazebank']=Config.DefaultDroneSpeed,['cementary']=Config.DefaultDroneSpeed,
		['fib']=Config.DefaultDroneSpeed,['prison']=Config.DefaultDroneSpeed,['sandy1']=Config.DefaultDroneSpeed,
		['sandy2']=Config.DefaultDroneSpeed,['militarybase']=Config.DefaultDroneSpeed,['leftside']=Config.DefaultDroneSpeed,
		['paleto']=Config.DefaultDroneSpeed,['mountchiliad']=Config.DefaultDroneSpeed,['grapeseed']=Config.DefaultDroneSpeed,
	},
	['docks'] = {
		['beach']=Config.DefaultDroneSpeed,['highway']=Config.DefaultDroneSpeed,['police']=Config.DefaultDroneSpeed,
		['ambulance']=Config.DefaultDroneSpeed,['airport']=Config.DefaultDroneSpeed,['casino']=Config.DefaultDroneSpeed,
		['radiotower']=Config.DefaultDroneSpeed,['observatorium']=Config.DefaultDroneSpeed,['industrialzone']=Config.DefaultDroneSpeed,
		['helidock']=Config.DefaultDroneSpeed,['mazebank']=Config.DefaultDroneSpeed,['cementary']=Config.DefaultDroneSpeed,
		['fib']=Config.DefaultDroneSpeed,['prison']=Config.DefaultDroneSpeed,['sandy1']=Config.DefaultDroneSpeed,
		['sandy2']=Config.DefaultDroneSpeed,['militarybase']=Config.DefaultDroneSpeed,['leftside']=Config.DefaultDroneSpeed,
		['paleto']=Config.DefaultDroneSpeed,['mountchiliad']=Config.DefaultDroneSpeed,['grapeseed']=Config.DefaultDroneSpeed,
	},
	['casino'] = {
		['beach']=Config.DefaultDroneSpeed,['highway']=Config.DefaultDroneSpeed,['police']=Config.DefaultDroneSpeed,
		['ambulance']=Config.DefaultDroneSpeed,['airport']=Config.DefaultDroneSpeed,['docks']=Config.DefaultDroneSpeed,
		['radiotower']=Config.DefaultDroneSpeed,['observatorium']=Config.DefaultDroneSpeed,['industrialzone']=Config.DefaultDroneSpeed,
		['helidock']=Config.DefaultDroneSpeed,['mazebank']=Config.DefaultDroneSpeed,['cementary']=Config.DefaultDroneSpeed,
		['fib']=Config.DefaultDroneSpeed,['prison']=Config.DefaultDroneSpeed,['sandy1']=Config.DefaultDroneSpeed,
		['sandy2']=Config.DefaultDroneSpeed,['militarybase']=Config.DefaultDroneSpeed,['leftside']=Config.DefaultDroneSpeed,
		['paleto']=Config.DefaultDroneSpeed,['mountchiliad']=Config.DefaultDroneSpeed,['grapeseed']=Config.DefaultDroneSpeed,
	},
	['radiotower'] = {
		['beach']=Config.DefaultDroneSpeed,['highway']=Config.DefaultDroneSpeed,['police']=Config.DefaultDroneSpeed,
		['ambulance']=Config.DefaultDroneSpeed,['airport']=Config.DefaultDroneSpeed,['docks']=Config.DefaultDroneSpeed,
		['casino']=Config.DefaultDroneSpeed,['observatorium']=Config.DefaultDroneSpeed,['industrialzone']=Config.DefaultDroneSpeed,
		['helidock']=Config.DefaultDroneSpeed,['mazebank']=Config.DefaultDroneSpeed,['cementary']=Config.DefaultDroneSpeed,
		['fib']=Config.DefaultDroneSpeed,['prison']=Config.DefaultDroneSpeed,['sandy1']=Config.DefaultDroneSpeed,
		['sandy2']=Config.DefaultDroneSpeed,['militarybase']=Config.DefaultDroneSpeed,['leftside']=Config.DefaultDroneSpeed,
		['paleto']=Config.DefaultDroneSpeed,['mountchiliad']=Config.DefaultDroneSpeed,['grapeseed']=Config.DefaultDroneSpeed,
	},
	['observatorium'] = {
		['beach']=Config.DefaultDroneSpeed,['highway']=Config.DefaultDroneSpeed,['police']=Config.DefaultDroneSpeed,
		['ambulance']=Config.DefaultDroneSpeed,['airport']=Config.DefaultDroneSpeed,['docks']=Config.DefaultDroneSpeed,
		['casino']=Config.DefaultDroneSpeed,['radiotower']=Config.DefaultDroneSpeed,['industrialzone']=Config.DefaultDroneSpeed,
		['helidock']=Config.DefaultDroneSpeed,['mazebank']=Config.DefaultDroneSpeed,['cementary']=Config.DefaultDroneSpeed,
		['fib']=Config.DefaultDroneSpeed,['prison']=Config.DefaultDroneSpeed,['sandy1']=Config.DefaultDroneSpeed,
		['sandy2']=Config.DefaultDroneSpeed,['militarybase']=Config.DefaultDroneSpeed,['leftside']=Config.DefaultDroneSpeed,
		['paleto']=Config.DefaultDroneSpeed,['mountchiliad']=Config.DefaultDroneSpeed,['grapeseed']=Config.DefaultDroneSpeed,
	},
	['industrialzone'] = {
		['beach']=Config.DefaultDroneSpeed,['highway']=Config.DefaultDroneSpeed,['police']=Config.DefaultDroneSpeed,
		['ambulance']=Config.DefaultDroneSpeed,['airport']=Config.DefaultDroneSpeed,['docks']=Config.DefaultDroneSpeed,
		['casino']=Config.DefaultDroneSpeed,['radiotower']=Config.DefaultDroneSpeed,['observatorium']=Config.DefaultDroneSpeed,
		['helidock']=Config.DefaultDroneSpeed,['mazebank']=Config.DefaultDroneSpeed,['cementary']=Config.DefaultDroneSpeed,
		['fib']=Config.DefaultDroneSpeed,['prison']=Config.DefaultDroneSpeed,['sandy1']=Config.DefaultDroneSpeed,
		['sandy2']=Config.DefaultDroneSpeed,['militarybase']=Config.DefaultDroneSpeed,['leftside']=Config.DefaultDroneSpeed,
		['paleto']=Config.DefaultDroneSpeed,['mountchiliad']=Config.DefaultDroneSpeed,['grapeseed']=Config.DefaultDroneSpeed,
	},
	['helidock'] = {
		['beach']=Config.DefaultDroneSpeed,['highway']=Config.DefaultDroneSpeed,['police']=Config.DefaultDroneSpeed,
		['ambulance']=Config.DefaultDroneSpeed,['airport']=Config.DefaultDroneSpeed,['docks']=Config.DefaultDroneSpeed,
		['casino']=Config.DefaultDroneSpeed,['radiotower']=Config.DefaultDroneSpeed,['observatorium']=Config.DefaultDroneSpeed,
		['industrialzone']=Config.DefaultDroneSpeed,['mazebank']=Config.DefaultDroneSpeed,['cementary']=Config.DefaultDroneSpeed,
		['fib']=Config.DefaultDroneSpeed,['prison']=Config.DefaultDroneSpeed,['sandy1']=Config.DefaultDroneSpeed,
		['sandy2']=Config.DefaultDroneSpeed,['militarybase']=Config.DefaultDroneSpeed,['leftside']=Config.DefaultDroneSpeed,
		['paleto']=Config.DefaultDroneSpeed,['mountchiliad']=Config.DefaultDroneSpeed,['grapeseed']=Config.DefaultDroneSpeed,
	},
	['mazebank'] = {
		['beach']=Config.DefaultDroneSpeed,['highway']=Config.DefaultDroneSpeed,['police']=Config.DefaultDroneSpeed,
		['ambulance']=Config.DefaultDroneSpeed,['airport']=Config.DefaultDroneSpeed,['docks']=Config.DefaultDroneSpeed,
		['casino']=Config.DefaultDroneSpeed,['radiotower']=Config.DefaultDroneSpeed,['observatorium']=Config.DefaultDroneSpeed,
		['industrialzone']=Config.DefaultDroneSpeed,['helidock']=Config.DefaultDroneSpeed,['cementary']=Config.DefaultDroneSpeed,
		['fib']=Config.DefaultDroneSpeed,['prison']=Config.DefaultDroneSpeed,['sandy1']=Config.DefaultDroneSpeed,
		['sandy2']=Config.DefaultDroneSpeed,['militarybase']=Config.DefaultDroneSpeed,['leftside']=Config.DefaultDroneSpeed,
		['paleto']=Config.DefaultDroneSpeed,['mountchiliad']=Config.DefaultDroneSpeed,['grapeseed']=Config.DefaultDroneSpeed,
	},
	['cementary'] = {
		['beach']=Config.DefaultDroneSpeed,['highway']=Config.DefaultDroneSpeed,['police']=Config.DefaultDroneSpeed,
		['ambulance']=Config.DefaultDroneSpeed,['airport']=Config.DefaultDroneSpeed,['docks']=Config.DefaultDroneSpeed,
		['casino']=Config.DefaultDroneSpeed,['radiotower']=Config.DefaultDroneSpeed,['observatorium']=Config.DefaultDroneSpeed,
		['industrialzone']=Config.DefaultDroneSpeed,['helidock']=Config.DefaultDroneSpeed,['mazebank']=Config.DefaultDroneSpeed,
		['fib']=Config.DefaultDroneSpeed,['prison']=Config.DefaultDroneSpeed,['sandy1']=Config.DefaultDroneSpeed,
		['sandy2']=Config.DefaultDroneSpeed,['militarybase']=Config.DefaultDroneSpeed,['leftside']=Config.DefaultDroneSpeed,
		['paleto']=Config.DefaultDroneSpeed,['mountchiliad']=Config.DefaultDroneSpeed,['grapeseed']=Config.DefaultDroneSpeed,
	},
	['fib'] = {
		['beach']=Config.DefaultDroneSpeed,['highway']=Config.DefaultDroneSpeed,['police']=Config.DefaultDroneSpeed,
		['ambulance']=Config.DefaultDroneSpeed,['airport']=Config.DefaultDroneSpeed,['docks']=Config.DefaultDroneSpeed,
		['casino']=Config.DefaultDroneSpeed,['radiotower']=Config.DefaultDroneSpeed,['observatorium']=Config.DefaultDroneSpeed,
		['industrialzone']=Config.DefaultDroneSpeed,['helidock']=Config.DefaultDroneSpeed,['mazebank']=Config.DefaultDroneSpeed,
		['cementary']=Config.DefaultDroneSpeed,['prison']=Config.DefaultDroneSpeed,['sandy1']=Config.DefaultDroneSpeed,
		['sandy2']=Config.DefaultDroneSpeed,['militarybase']=Config.DefaultDroneSpeed,['leftside']=Config.DefaultDroneSpeed,
		['paleto']=Config.DefaultDroneSpeed,['mountchiliad']=Config.DefaultDroneSpeed,['grapeseed']=Config.DefaultDroneSpeed,
	},
	['prison'] = {
		['beach']=Config.DefaultDroneSpeed,['highway']=Config.DefaultDroneSpeed,['police']=Config.DefaultDroneSpeed,
		['ambulance']=Config.DefaultDroneSpeed,['airport']=Config.DefaultDroneSpeed,['docks']=Config.DefaultDroneSpeed,
		['casino']=Config.DefaultDroneSpeed,['radiotower']=Config.DefaultDroneSpeed,['observatorium']=Config.DefaultDroneSpeed,
		['industrialzone']=Config.DefaultDroneSpeed,['helidock']=Config.DefaultDroneSpeed,['mazebank']=Config.DefaultDroneSpeed,
		['cementary']=Config.DefaultDroneSpeed,['fib']=Config.DefaultDroneSpeed,['sandy1']=Config.DefaultDroneSpeed,
		['sandy2']=Config.DefaultDroneSpeed,['militarybase']=Config.DefaultDroneSpeed,['leftside']=Config.DefaultDroneSpeed,
		['paleto']=Config.DefaultDroneSpeed,['mountchiliad']=Config.DefaultDroneSpeed,['grapeseed']=Config.DefaultDroneSpeed,
	},
	['sandy1'] = {
		['beach']=Config.DefaultDroneSpeed,['highway']=Config.DefaultDroneSpeed,['police']=Config.DefaultDroneSpeed,
		['ambulance']=Config.DefaultDroneSpeed,['airport']=Config.DefaultDroneSpeed,['docks']=Config.DefaultDroneSpeed,
		['casino']=Config.DefaultDroneSpeed,['radiotower']=Config.DefaultDroneSpeed,['observatorium']=Config.DefaultDroneSpeed,
		['industrialzone']=Config.DefaultDroneSpeed,['helidock']=Config.DefaultDroneSpeed,['mazebank']=Config.DefaultDroneSpeed,
		['cementary']=Config.DefaultDroneSpeed,['fib']=Config.DefaultDroneSpeed,['prison']=Config.DefaultDroneSpeed,
		['sandy2']=Config.DefaultDroneSpeed,['militarybase']=Config.DefaultDroneSpeed,['leftside']=Config.DefaultDroneSpeed,
		['paleto']=Config.DefaultDroneSpeed,['mountchiliad']=Config.DefaultDroneSpeed,['grapeseed']=Config.DefaultDroneSpeed,
	},
	['sandy2'] = {
		['beach']=Config.DefaultDroneSpeed,['highway']=Config.DefaultDroneSpeed,['police']=Config.DefaultDroneSpeed,
		['ambulance']=Config.DefaultDroneSpeed,['airport']=Config.DefaultDroneSpeed,['docks']=Config.DefaultDroneSpeed,
		['casino']=Config.DefaultDroneSpeed,['radiotower']=Config.DefaultDroneSpeed,['observatorium']=Config.DefaultDroneSpeed,
		['industrialzone']=Config.DefaultDroneSpeed,['helidock']=Config.DefaultDroneSpeed,['mazebank']=Config.DefaultDroneSpeed,
		['cementary']=Config.DefaultDroneSpeed,['fib']=Config.DefaultDroneSpeed,['prison']=Config.DefaultDroneSpeed,
		['sandy1']=Config.DefaultDroneSpeed,['militarybase']=Config.DefaultDroneSpeed,['leftside']=Config.DefaultDroneSpeed,
		['paleto']=Config.DefaultDroneSpeed,['mountchiliad']=Config.DefaultDroneSpeed,['grapeseed']=Config.DefaultDroneSpeed,
	},
	['militarybase'] = {
		['beach']=Config.DefaultDroneSpeed,['highway']=Config.DefaultDroneSpeed,['police']=Config.DefaultDroneSpeed,
		['ambulance']=Config.DefaultDroneSpeed,['airport']=Config.DefaultDroneSpeed,['docks']=Config.DefaultDroneSpeed,
		['casino']=Config.DefaultDroneSpeed,['radiotower']=Config.DefaultDroneSpeed,['observatorium']=Config.DefaultDroneSpeed,
		['industrialzone']=Config.DefaultDroneSpeed,['helidock']=Config.DefaultDroneSpeed,['mazebank']=Config.DefaultDroneSpeed,
		['cementary']=Config.DefaultDroneSpeed,['fib']=Config.DefaultDroneSpeed,['prison']=Config.DefaultDroneSpeed,
		['sandy1']=Config.DefaultDroneSpeed,['sandy2']=Config.DefaultDroneSpeed,['leftside']=Config.DefaultDroneSpeed,
		['paleto']=Config.DefaultDroneSpeed,['mountchiliad']=Config.DefaultDroneSpeed,['grapeseed']=Config.DefaultDroneSpeed,
	},
	['leftside'] = {
		['beach']=Config.DefaultDroneSpeed,['highway']=Config.DefaultDroneSpeed,['police']=Config.DefaultDroneSpeed,
		['ambulance']=Config.DefaultDroneSpeed,['airport']=Config.DefaultDroneSpeed,['docks']=Config.DefaultDroneSpeed,
		['casino']=Config.DefaultDroneSpeed,['radiotower']=Config.DefaultDroneSpeed,['observatorium']=Config.DefaultDroneSpeed,
		['industrialzone']=Config.DefaultDroneSpeed,['helidock']=Config.DefaultDroneSpeed,['mazebank']=Config.DefaultDroneSpeed,
		['cementary']=Config.DefaultDroneSpeed,['fib']=Config.DefaultDroneSpeed,['prison']=Config.DefaultDroneSpeed,
		['sandy1']=Config.DefaultDroneSpeed,['sandy2']=Config.DefaultDroneSpeed,['militarybase']=Config.DefaultDroneSpeed,
		['paleto']=Config.DefaultDroneSpeed,['mountchiliad']=Config.DefaultDroneSpeed,['grapeseed']=Config.DefaultDroneSpeed,
	},
	['paleto'] = {
		['beach']=Config.DefaultDroneSpeed,['highway']=Config.DefaultDroneSpeed,['police']=Config.DefaultDroneSpeed,
		['ambulance']=Config.DefaultDroneSpeed,['airport']=Config.DefaultDroneSpeed,['docks']=Config.DefaultDroneSpeed,
		['casino']=Config.DefaultDroneSpeed,['radiotower']=Config.DefaultDroneSpeed,['observatorium']=Config.DefaultDroneSpeed,
		['industrialzone']=Config.DefaultDroneSpeed,['helidock']=Config.DefaultDroneSpeed,['mazebank']=Config.DefaultDroneSpeed,
		['cementary']=Config.DefaultDroneSpeed,['fib']=Config.DefaultDroneSpeed,['prison']=Config.DefaultDroneSpeed,
		['sandy1']=Config.DefaultDroneSpeed,['sandy2']=Config.DefaultDroneSpeed,['militarybase']=Config.DefaultDroneSpeed,
		['leftside']=Config.DefaultDroneSpeed,['mountchiliad']=Config.DefaultDroneSpeed,['grapeseed']=Config.DefaultDroneSpeed,
	},
	['mountchiliad'] = {
		['beach']=Config.DefaultDroneSpeed,['highway']=Config.DefaultDroneSpeed,['police']=Config.DefaultDroneSpeed,
		['ambulance']=Config.DefaultDroneSpeed,['airport']=Config.DefaultDroneSpeed,['docks']=Config.DefaultDroneSpeed,
		['casino']=Config.DefaultDroneSpeed,['radiotower']=Config.DefaultDroneSpeed,['observatorium']=Config.DefaultDroneSpeed,
		['industrialzone']=Config.DefaultDroneSpeed,['helidock']=Config.DefaultDroneSpeed,['mazebank']=Config.DefaultDroneSpeed,
		['cementary']=Config.DefaultDroneSpeed,['fib']=Config.DefaultDroneSpeed,['prison']=Config.DefaultDroneSpeed,
		['sandy1']=Config.DefaultDroneSpeed,['sandy2']=Config.DefaultDroneSpeed,['militarybase']=Config.DefaultDroneSpeed,
		['leftside']=Config.DefaultDroneSpeed,['paleto']=Config.DefaultDroneSpeed,['grapeseed']=Config.DefaultDroneSpeed,
	},
	['grapeseed'] = {
		['beach']=Config.DefaultDroneSpeed,['highway']=Config.DefaultDroneSpeed,['police']=Config.DefaultDroneSpeed,
		['ambulance']=Config.DefaultDroneSpeed,['airport']=Config.DefaultDroneSpeed,['docks']=Config.DefaultDroneSpeed,
		['casino']=Config.DefaultDroneSpeed,['radiotower']=Config.DefaultDroneSpeed,['observatorium']=Config.DefaultDroneSpeed,
		['industrialzone']=Config.DefaultDroneSpeed,['helidock']=Config.DefaultDroneSpeed,['mazebank']=Config.DefaultDroneSpeed,
		['cementary']=Config.DefaultDroneSpeed,['fib']=Config.DefaultDroneSpeed,['prison']=Config.DefaultDroneSpeed,
		['sandy1']=Config.DefaultDroneSpeed,['sandy2']=Config.DefaultDroneSpeed,['militarybase']=Config.DefaultDroneSpeed,
		['leftside']=Config.DefaultDroneSpeed,['paleto']=Config.DefaultDroneSpeed,['mountchiliad']=Config.DefaultDroneSpeed,
	},
}

Config.Locales = {
	['target_pick_destination'] = 'Pick Traveling Destination',
	['no_money'] = 'You don\'t have enough money!',
	['spot_used'] = 'This spot is not accessable for flight wait for another flight to land!',
	['invalid_request'] = 'Invalid flight request.',
	['invalid_destination'] = 'Selected station does not exist.',
	['same_destination'] = 'You are already at this station.',
	['already_in_flight'] = 'You already have an active drone flight.',
}

Config.Blip = {
	['name'] = 'Drone Station',
	['scale'] = 0.7,
	['sprite'] = 612,
	['color'] = 24,
}

