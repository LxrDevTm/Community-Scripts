fx_version 'cerulean'
game 'gta5'

files {
    'stream/drone model/nteamdrone.yft',
    'stream/drone model/nteamdrone.ytd',
    'handling.meta',
    'vehicles.meta',
    'carcols.meta',
    'carvariations.meta'
}

data_file 'HANDLING_FILE' 'handling.meta'
data_file 'VEHICLE_METADATA_FILE' 'vehicles.meta'
data_file 'CARCOLS_FILE' 'carcols.meta'
data_file 'VEHICLE_VARIATION_FILE' 'carvariations.meta'

dependency '/assetpacks'