

-- sdfsdfgsd created by FURKAN
Config.DoorList['sdgdsfgds-sdfsdfgsd'] = {
    doorType = 'double',
    positionData = {
        position = vector3(446.522888, -989.100769, 30.888378),
        rotation = vector3(0.000000, -0.000000, 0.000000),
        heading = 0.000000,
        handle = 1029890
    },
    allAuthorized = true,
    authorizedCitizenIDs = { ['123'] = true },
    locked = false,
    svgDistance = 5,
    cantUnlock = false,
    doors = {
        {objName = 185711165, objYaw = 179.99998474121, objCoords = vector3(443.407776, -989.445435, 30.839302)},
        {objName = 185711165, objYaw = 0.0, objCoords = vector3(446.007935, -989.445435, 30.839302)}
    },
    doorRate = 1.0,
    interactDistance = 3,
    passCode = '1234',
    owner = 'ZRU81065',
}