let inputStates = {
    ['1']: false,
    ['2']: false,
    ['3']: false,
    ['4']: false,
};
doorTypeOpen = false;
currentNetId = 0;
currentDoorType = null
clientDoorType = null;

window.addEventListener("message", function (e) {
    e = e.data
    console.log(JSON.stringify(e));
    switch (e.action) {
        case "openCreateDoorMenu":
          return openCreateDoorMenu(e);
        case "textUI":
            return textUI(e);
        case " audio":
            return audio(e);
        case "openPassCodeMenu":
            return openPassCodeMenu(e);
        case "opendui":
            return opendui(e);
        default:
        return;
    }
});

function opendui(e) {
    console.log(JSON.stringify(e));
    $("body, .tv-dui-page").show();
    $(".starter").fadeIn(500);
  }

function openPassCodeMenu(e) { 
    currentPassCode = e.passcode;
    $('.passcode , body').css('display', 'flex');
    $('.frkn-box').css('display', 'none');
}

function audio(e) {
    var volume = (e.audio['volume'] / 10) * e.sfx
        if (e.distance !== 0) volume /= e.distance;
        if (volume > 1.0) volume = 1.0;
        const sound = new Audio('sounds/' + e.audio['file']);
        sound.volume = volume;
        sound.play();
}   

function textUI(e) {
    $('.doors-list-box , .passcode , .frkn-box').css('display', 'none');
    if (e.show) {
        $('body').css('display', 'flex');
        $("#textUI ").show().css({bottom: "-10%", position:'absolute', display:'flex'}).animate({bottom: "4%"}, 800, function() {});
    }else{
        $('body').css('display', 'none');
        $("#textUI ").show().css({bottom: "4%", position:'absolute', display:'flex'}).animate({bottom: "-10%"}, 800, function() {});
    }
}
  
function openCreateDoorMenu(e) {
    if (e.netId) {
        currentNetId = e.netId;
    }

    clientDoorType = e.type;
    console.log("TYPE " , e.type);
    if (e.type=="double") {
        $('.dbl').css('display', 'flex');
        $('.single').css('display', 'none');
    }else{
        $('.dbl').css('display', 'none');
        $('.single').css('display', 'flex');
    }

    $('.hash1').val(e.hash1)
    $('.hash2').val(e.hash2)

    $('body , .frkn-box').css('display', 'flex');
    $('.doors-list-box , .passcode').css('display', 'none');
}


function clFunc(name1, name2, name3) {
  if (name1 === "changeInputState") {
        if (inputStates[name2]) {
            inputStates[name2] = false;
            document.getElementById("CDDT2DDIDiv" + name2).style.background = "rgba(255, 255, 255, 0.06)";
            document.getElementById("CDDT2DDIDiv" + name2).style.justifyContent = "flex-start";
            document.getElementById("CDDT2DDIDiv" + name2).innerHTML = `<div id="CDDT2DDIDivInsideRed"></div>`;
        } else {
            inputStates[name2] = true;
            document.getElementById("CDDT2DDIDiv" + name2).style.background = "rgba(122, 255, 175, 0.24)";
            document.getElementById("CDDT2DDIDiv" + name2).style.justifyContent = "flex-end";
            document.getElementById("CDDT2DDIDiv" + name2).innerHTML = `<div id="CDDT2DDIDivInsideGreen"></div>`;
        }
    }
}

var pincode = 0;
var code = []
$(document).on('click', '.number', function (e) {
    code.push($(this).text());
    if (pincode < 4) {
        pincode++;
        $('.'+pincode).css('background', '#459BFF');
    }else{
        pincode = 0;
        $('.1, .2, .3, .4').css('background', 'radial-gradient(110.83% 110.83% at 50% 50%, rgba(255, 255, 255, 0.21) 0%, rgba(255, 255, 255, 0.00) 100%)');
    }

})

$(document).on('click', '.enter', function (e) {
    console.log("code", code.join('') , "currentPassCode", currentPassCode);
    if (Number(code.join('')) === Number(currentPassCode)) {
        $('.1, .2, .3, .4').css('background', 'green');
        $('.passcode').fadeOut(500);
        $('.pincode').val(code.join(''));
        $.post(`https://frkn-doorlock/callback`, JSON.stringify({ 
            action: "openDoor",
        }), function (x) {})
        $('.1, .2, .3, .4').css('background', 'radial-gradient(110.83% 110.83% at 50% 50%, rgba(255, 255, 255, 0.21) 0%, rgba(255, 255, 255, 0.00) 100%)');

    }else{
        $('.1, .2, .3, .4').css('background', 'red');
        setTimeout(() => {
            $('.1, .2, .3, .4').css('background', 'radial-gradient(110.83% 110.83% at 50% 50%, rgba(255, 255, 255, 0.21) 0%, rgba(255, 255, 255, 0.00) 100%)');
        },1000)
    }
    pincode = 0;
    code = [];
})


$(document).on('click', '.close-border', function (e) {
    $.post(`https://frkn-doorlock/callback`, JSON.stringify({ 
        action: "nuiFocus",
    }), function (x) {})
    $('.doors-list-box , .passcode , .frkn-box , body').css('display', 'none');
})

$(document).on('keyup', function (e) {
    if (e.key === "Escape" || e.keyCode === 27) {
        $.post(`https://frkn-doorlock/callback`, JSON.stringify({ 
            action: "nuiFocus",
        }), function (x) {})
        $('.doors-list-box , .passcode , .frkn-box , body').css('display', 'none');
    }
});


$(document).on('click', '.submit', function (e) {
    $.post(`https://frkn-doorlock/callback`, JSON.stringify({ 
        action: "createDoor",
        data: {
                configfile: $('.configfile').val(),
                job: $('.jobvalue').val(),
                gang: $('.gangvalue').val(),
                cid: 123,
                item: $('.itemvalue').val(),
                locked: inputStates["1"],
                pickable: inputStates["2"],
                cantunlock: inputStates["3"],
                fixText: inputStates["4"],
                svgDistance: Number($('.svgvalue').val()),
                interactDistance: Number($('.interactdistance').val()),
                dooridentifier: $('.doorname').val(),
                netId: Number(currentNetId),
                doortype: currentDoorType,
                passCode: $('.pincode').val(),
        }
    }), function (x) {
        $('.doors-list-box , .passcode , .frkn-box , body').css('display', 'none');
    })
})

$(document).on('click', '.doortype', function (e) {
    doorTypeOpen = !doorTypeOpen;

    if (doorTypeOpen) {   
        if (clientDoorType=="double") {
            $('.dbl').css('display', 'flex');
            $('.single').css('display', 'none');
        }else{
            $('.dbl').css('display', 'none');
            $('.single').css('display', 'flex');
        }
    }else{
            $('.dbl').css('display', 'none');
            $('.single').css('display', 'none');
        
    }

})

$(document).on('click', '.dooropen', function (e) {
    html = $(this).text();
    $('.doortype span').html(html) 
    currentDoorType = $(this).data('type');
    $('.dooropen').css('display', 'none');
})