let inputStates = {
    ['1']: false,
    ['2']: false,
    ['3']: false,
    ['4']: false,
    ['5']: false,
    ['6']: false,
};
doorTypeOpen = false;
currentNetId = 0;
currentDoorType = null
clientDoorType = null;
control = false;

window.addEventListener("message", function (e) {
    e = e.data
    switch (e.action) {
        case "openCreateDoorMenu":
          return openCreateDoorMenu(e);
        case "textUI":
            return textUI(e);
        case "audio":
            return audio(e);
        case "openPassCodeMenu":
            return openPassCodeMenu(e);
        case "opendui":
            return openDui(e);
        case "closedui":
            return closeDui(e);
        case "convert":
            return Convert(e.pMugShotTxd, e.removeImageBackGround, e.id);
        case "doorsList":
            return doorsList(e);
        default:
        return;
    }
});


function substring(str, start, end) {
    return str.substring(start, end);
}

function doorsList(e) {  
    i = 0;
    $('.doors-list-box').html('');
    playerData = e.playerInfo || {}; 
    var playerName = playerData.name || "Unknown";
    
    $('.user-name').html(playerName);
    $('.user-permission').html("User Id :: " + (playerData.source || "Unknown"));
    $('.user-box img').attr("src", playerData.discord || ""); 
    
    // console.log(JSON.stringify(e.data[0]['doors']))
    $.each(e.data, function (index, value) {
        console.log(JSON.stringify(value))
        i++;
        value.passCode = value.passCode == null ? "----" : value.passCode;
        value.locked = value.locked == true ? "Locked" : "Unlocked";
        value.interactDistance = value.interactDistance == null ? "----" : value.interactDistance;

        $('.doors-list-box').append(`
        <div class="doors-list-item">
        <div class="top-bg">
            <div class="id">#${i}</div>
            <div class="name">${value.key}</div>
            <div class="delete">
                <svg  xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none">
                    <path d="M12.6667 2.66667H10.3334L9.66671 2H6.33337L5.66671 2.66667H3.33337V4H12.6667M4.00004 12.6667C4.00004 13.0203 4.14052 13.3594 4.39056 13.6095C4.64061 13.8595 4.97975 14 5.33337 14H10.6667C11.0203 14 11.3595 13.8595 11.6095 13.6095C11.8596 13.3594 12 13.0203 12 12.6667V4.66667H4.00004V12.6667Z" fill="#FF5B5B"/>
                </svg>
            </div>
          
        </div>
        <svg class="coords-icon" xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 15 15" fill="none">
            <mask id="mask0_8_60" style="mask-type:luminance" maskUnits="userSpaceOnUse" x="0" y="1" width="15" height="14">
              <path d="M7.5 3.75L11.875 6.25V11.25L7.5 13.75L3.125 11.25V6.25L7.5 3.75Z" fill="white" stroke="white" stroke-width="1.25" stroke-linejoin="round"/>
              <path d="M7.5 1.875V3.75" stroke="white" stroke-width="1.25" stroke-linecap="round" stroke-linejoin="round"/>
              <path d="M3.125 6.25L7.5 8.75L11.875 6.25" stroke="black" stroke-width="1.25" stroke-linecap="round" stroke-linejoin="round"/>
              <path d="M11.875 11.25L13.75 12.1875M1.25 12.1875L3.125 11.25" stroke="white" stroke-width="1.25" stroke-linecap="round" stroke-linejoin="round"/>
              <path d="M7.5 8.75V13.75" stroke="black" stroke-width="1.25" stroke-linecap="round" stroke-linejoin="round"/>
              <path d="M9.6875 5L11.875 6.25V8.75M5.3125 5L3.125 6.25V8.75M5.3125 12.5L7.5 13.75L9.6875 12.5" stroke="white" stroke-width="1.25" stroke-linejoin="round"/>
            </mask>
            <g mask="url(#mask0_8_60)">
              <path d="M0 0H15V15H0V0Z" fill="white"/>
            </g>
          </svg>
          <div class="coords-text">Coords</div>
          <div class="coords-x-box"><span style="color: rgba(174, 216, 255, 1);">X: </span> ${substring(JSON.stringify(value.doors[0].objCoords['x']),0,10)}</div>
          <div style="left: 25.5%;" class="coords-x-box"><span style="color: rgba(174, 216, 255, 1);">Y: </span>  ${substring(JSON.stringify(value.doors[0].objCoords['y']),0, 10)}</div>
          <div style="left: 48%;" class="coords-x-box"><span style="color: rgba(174, 216, 255, 1);">Z: </span>  ${substring(JSON.stringify(value.doors[0].objCoords['z']),0, 10)}</div>
          <div style="left: 71%;" class="coords-x-box"><span style="color: rgba(174, 216, 255, 1);">H: </span>   ${substring(JSON.stringify(value.doors[0]['objYaw'],0, 5))}</div>
          
          <svg class="job-icon" xmlns="http://www.w3.org/2000/svg" width="15" height="17" viewBox="0 0 15 17" fill="none">
            <path fill-rule="evenodd" clip-rule="evenodd" d="M4.53126 4.42886V5.35017L3.47251 5.43971C3.10878 5.4701 2.76537 5.62621 2.49718 5.88309C2.22899 6.13997 2.05152 6.48278 1.99314 6.85671C1.96751 7.0241 1.94314 7.19149 1.92189 7.35953C1.91683 7.40016 1.92433 7.44141 1.94331 7.47733C1.9623 7.51324 1.99178 7.54197 2.02751 7.55937L2.07564 7.58273C5.46876 9.25017 9.53189 9.25017 12.9244 7.58273L12.9725 7.55937C13.0081 7.54187 13.0375 7.5131 13.0563 7.47719C13.0752 7.44129 13.0826 7.40009 13.0775 7.35953C13.0563 7.19158 13.0328 7.02395 13.0069 6.85671C12.9485 6.48278 12.771 6.13997 12.5028 5.88309C12.2347 5.62621 11.8912 5.4701 11.5275 5.43971L10.4688 5.35082V4.42951C10.4688 4.15756 10.3749 3.89463 10.204 3.68852C10.0331 3.48241 9.79657 3.34683 9.53751 3.30642L8.77501 3.18769C7.92974 3.05605 7.07028 3.05605 6.22501 3.18769L5.46251 3.30642C5.20356 3.34681 4.96715 3.4823 4.79627 3.68827C4.62538 3.89424 4.53135 4.15703 4.53126 4.42886ZM8.63564 4.14987C7.88276 4.03265 7.11726 4.03265 6.36439 4.14987L5.60189 4.26861C5.56489 4.27435 5.53111 4.29369 5.50668 4.32309C5.48225 4.3525 5.4688 4.39003 5.46876 4.42886V5.28205C6.82182 5.20158 8.1782 5.20158 9.53126 5.28205V4.42886C9.53122 4.39003 9.51777 4.3525 9.49334 4.32309C9.46891 4.29369 9.43513 4.27435 9.39814 4.26861L8.63564 4.14987Z" fill="white"/>
            <path d="M13.1988 8.71685C13.1975 8.69587 13.1914 8.67552 13.1809 8.65755C13.1704 8.63957 13.1559 8.62451 13.1385 8.61366C13.1212 8.60281 13.1016 8.5965 13.0814 8.59526C13.0612 8.59402 13.041 8.59789 13.0225 8.60655C9.54064 10.2072 5.45938 10.2072 1.97751 8.60655C1.95906 8.59789 1.93886 8.59402 1.91866 8.59526C1.89845 8.5965 1.87883 8.60281 1.86149 8.61366C1.84415 8.62451 1.82961 8.63957 1.81912 8.65755C1.80863 8.67552 1.8025 8.69587 1.80126 8.71685C1.73739 9.95898 1.80171 11.2046 1.99313 12.4326C2.05139 12.8066 2.22881 13.1496 2.49701 13.4066C2.76521 13.6636 3.10869 13.8198 3.47251 13.8502L4.64251 13.9475C6.54438 14.1072 8.45501 14.1072 10.3575 13.9475L11.5275 13.8502C11.8913 13.8198 12.2348 13.6636 12.503 13.4066C12.7712 13.1496 12.9486 12.8066 13.0069 12.4326C13.1981 11.2031 13.2631 9.95737 13.1988 8.7175" fill="white"/>
          </svg>

            <div class="job-text">Distance</div>

            <div class="job-box">${value.interactDistance}</div>

            <svg class="grade-icon" xmlns="http://www.w3.org/2000/svg" width="15" height="16" viewBox="0 0 15 16" fill="none">
                <path d="M3.64062 13.7202L4.65625 9.16235L1.25 6.09672L5.75 5.69122L7.5 1.39285L9.25 5.69122L13.75 6.09672L10.3438 9.16235L11.3594 13.7202L7.5 11.3034L3.64062 13.7202Z" fill="white"/>
            </svg>

            <div class="grade-text">Locked</div>

            <div class="grade-box"><span>${value.locked}</span></div>

            <div class="pin-text">Pin Code</div>

            <div class="pin-box"><span>${value.passCode}</span></div>


    </div>`);
    
    })
    $('.doors-list-box , body , .frkn-box').css('display', 'flex');
    $('.face-scanner , .passcode , .add-door').css('display', 'none');
}

let whileLoop = false;
function openDui(e) {
    if (whileLoop == false) {
        $("body , .face-scanner").show();
        $('.frkn-box').hide();
        console.log("e.image", e.image)

        $('.charbg').attr('src', e.image);
        whileLoop = true;
        control = e.faceController
        scanner();
    }
}

function closeDui(e) {  
    $('.scanner-progress').css('width', 0 + '%');
    $('.scan-line').css({
        borderTop: '0.2vh solid #3D8AFF',
        background: 'linear-gradient(180deg, rgba(61, 138, 255, 0.31) 0%, rgba(61, 138, 255, 0.00) 100%)',
        left: '-10%', 
    });
    $('.scanner-text').text('scanning in progress').css(
        {
            color: 'rgba(255, 255, 255, 0.33)',
            fontWeight: 'bold',
        }
    );
    $('.scan1').css('display', 'flex');
    $('.scan2 , .scan3').css('display', 'none');
    $('.scanner-progress-bg').css({
        background: 'rgba(255, 255, 255, 0.09)',
        boxShadow: 'none',
    });
    whileLoop = false;
    $('.face-scanner,body').fadeOut(500);
}

var divValue = $('.scanner-progress').width();
function scanner() { 
    var intervalId = setInterval(() => {
        divValue += 1;
        $('.scanner-progress').css('width', divValue + '%');
        if (divValue >= 100) {
            clearInterval(intervalId);
            divValue = 0;
            $('.scanner-progress').css('width', 0 + '%');
            if (!control) {      
                setTimeout(() => {
                    $('.scan-line').css({
                        borderTop: '2px solid #FF4141',
                        background: 'linear-gradient(180deg, rgba(255, 65, 65, 0.31) 0%, rgba(255, 65, 65, 0.00) 100%)',
                        left: '-10%', 
                    });
                    control = false; 
                    $('.scanner-text').text('Incorrect entry').css({
                        color: '#000',
                        fontWeight: 'bold',
                    });
                    
                    $('.scan1 , .scan3').css('display', 'none');
                    $('.scan2').css('display', 'flex');
                    $('.scanner-progress-bg').css({
                        background: '#FF4141',
                        boxShadow: '0px 0px 47.5px 0px rgba(255, 65, 65, 0.47)',
                    });

                    $.post(`https://frkn-doorlock/callback`, JSON.stringify({
                        action: "openDoor",
                    }), function (x) {});
                }, 1000); 
            } else {
                setTimeout(() => {
                    $('.scan-line').css({
                        borderTop: '2px solid #3DFF8B',
                        background: 'linear-gradient(180deg, rgba(61, 255, 139, 0.31) 0%, rgba(61, 255, 139, 0.00) 100%)',
                        left: '-10%', 
                    });
                    control = false; 
                    $('.scanner-text').text('Door Unlocked').css({
                        color: '#000',
                        fontWeight: 'bold',
                    });
                    $('.scan1 ,.scan2').css('display', 'none');
                    $('.scan3').css('display', 'flex');
                    $('.scanner-progress-bg').css({
                        background: '#3DFF8B',
                        boxShadow: '0px 0px 47.5px 0px rgba(61, 255, 139, 0.47)',
                    });

                    $.post(`https://frkn-doorlock/callback`, JSON.stringify({
                        action: "openDoor",
                    }), function (x) {});
                }, 1000);             
            }
        }
    }, 100);
}






function openPassCodeMenu(e) { 
    currentPassCode = e.passcode;
    $('.passcode , body').css('display', 'flex');
    $('.frkn-box , .face-scanner').css('display', 'none');
}

function audio(e) {
    var volume = (e.audio['volume'] / 10) * e.sfx
        if (e.distance !== 0) volume /= e.distance;
        if (volume > 1.0) volume = 1.0;
        const sound = new Audio('sounds/' + e.audio['file']);
        sound.volume = volume;
        sound.play();
}   

function textUI(e) {
    $('.doors-list-box , .passcode , .frkn-box , .face-scanner').css('display', 'none');
    if (e.show) {
        $('body').css('display', 'flex');
        $("#textUI ").show().css({bottom: "-10%", position:'absolute', display:'flex'}).animate({bottom: "4%"}, 800, function() {});
    }else{
        $('body').css('display', 'none');
        $("#textUI ").show().css({bottom: "4%", position:'absolute', display:'flex'}).animate({bottom: "-10%"}, 800, function() {});
    }
}
  
function openCreateDoorMenu(e) {
    if (e.netId) {
        currentNetId = e.netId;
    }
    clientDoorType = e.type;
    playerData = e.playerInfo || {};

    var playerName = playerData.name || "Unknown";
    
    $('.user-name').html(playerName);
    $('.user-permission').html("User Id :: " + (playerData.source || "Unknown"));
    $('.user-box img').attr("src", playerData.discord || "");

    if (e.type=="double") {
        $('.dbl').css('display', 'flex');
        $('.single').css('display', 'none');
    }else{
        $('.dbl').css('display', 'none');
        $('.single').css('display', 'flex');
    }

    $('.hash1').val(e.hash1)
    $('.hash2').val(e.hash2)

    $('body , .frkn-box , .add-door').css('display', 'flex');
    $('.doors-list-box , .passcode , .face-scanner').css('display', 'none');
}


function clFunc(name1, name2, name3) {
  if (name1 === "changeInputState") {
        if (inputStates[name2]) {
            inputStates[name2] = false;
            document.getElementById("CDDT2DDIDiv" + name2).style.background = "rgba(255, 255, 255, 0.06)";
            document.getElementById("CDDT2DDIDiv" + name2).style.justifyContent = "flex-start";
            document.getElementById("CDDT2DDIDiv" + name2).innerHTML = `<div id="CDDT2DDIDivInsideRed"></div>`;
        } else {
            inputStates[name2] = true;
            document.getElementById("CDDT2DDIDiv" + name2).style.background = "rgba(122, 255, 175, 0.24)";
            document.getElementById("CDDT2DDIDiv" + name2).style.justifyContent = "flex-end";
            document.getElementById("CDDT2DDIDiv" + name2).innerHTML = `<div id="CDDT2DDIDivInsideGreen"></div>`;
        }
    }else if (name1 === "scanner") {
        if (inputStates[name3]) {
            inputStates[name3] = false;
            document.getElementById("CDDT2DDIDiv" + name3).style.background = "rgba(255, 255, 255, 0.06)";
            document.getElementById("CDDT2DDIDiv" + name3).style.justifyContent = "flex-start";
            document.getElementById("CDDT2DDIDiv" + name3).innerHTML = `<div id="CDDT2DDIDivInsideRed"></div>`;
        } else {
            inputStates[name3] = true;
            document.getElementById("CDDT2DDIDiv" + name3).style.background = "rgba(122, 255, 175, 0.24)";
            document.getElementById("CDDT2DDIDiv" + name3).style.justifyContent = "flex-end";
            document.getElementById("CDDT2DDIDiv" + name3).innerHTML = `<div id="CDDT2DDIDivInsideGreen"></div>`;
            $('.doors-list-box , .passcode , .frkn-box , body').css('display', 'none');
            $.post(`https://frkn-doorlock/callback`, JSON.stringify({
                action: "faceScanner",
                data: {
                    scanner: false,
                }
            }), function (x) {})
        }
        
    }
}

var pincode = 0;
var code = []
$(document).on('click', '.number', function (e) {
    code.push($(this).text());
    if (pincode < 4) {
        pincode++;
        $('.'+pincode).css('background', '#459BFF');
    }else{
        pincode = 0;
        $('.1, .2, .3, .4').css('background', 'radial-gradient(110.83% 110.83% at 50% 50%, rgba(255, 255, 255, 0.21) 0%, rgba(255, 255, 255, 0.00) 100%)');
    }

})

$(document).on('click', '.enter', function (e) {
    if (Number(code.join('')) === Number(currentPassCode)) {
        $('.1, .2, .3, .4').css('background', 'green');
        $('.passcode').fadeOut(500);
        $('.pincode').val(code.join(''));
        $.post(`https://frkn-doorlock/callback`, JSON.stringify({ 
            action: "openDoor",
        }), function (x) {})
        $('.1, .2, .3, .4').css('background', 'radial-gradient(110.83% 110.83% at 50% 50%, rgba(255, 255, 255, 0.21) 0%, rgba(255, 255, 255, 0.00) 100%)');

    }else{
        $('.1, .2, .3, .4').css('background', 'red');
        setTimeout(() => {
            $('.1, .2, .3, .4').css('background', 'radial-gradient(110.83% 110.83% at 50% 50%, rgba(255, 255, 255, 0.21) 0%, rgba(255, 255, 255, 0.00) 100%)');
        },1000)
    }
    pincode = 0;
    code = [];
})

// $(document).on('click', '.door-box', function (e) {
//     $('.doors-list-box').css('display', 'flex');
//     $('.add-door').css('display', 'none');
//     $('.add-door-button-top').css({left:'73%'});
//     $('.door-box').css({left:'6%'});
// })

// $(document).on('click', '.add-door-button-top', function (e) {
//     $('.doors-list-box').css('display', 'none');
//     $('.add-door').css('display', 'flex');
//     $('.add-door-button-top').css({left:'6%'})
//     $('.door-box').css({left:'83%'})
// })


$(document).on('click', '.close-border', function (e) {
    $.post(`https://frkn-doorlock/callback`, JSON.stringify({ 
        action: "nuiFocus",
    }), function (x) {})
    $('.doors-list-box , .passcode , .frkn-box , body').css('display', 'none');
})

$(document).on('keyup', function (e) {
    if (e.key === "Escape" || e.keyCode === 27) {
        $.post(`https://frkn-doorlock/callback`, JSON.stringify({ 
            action: "nuiFocus",
        }), function (x) {})
        $('.doors-list-box , .passcode , .frkn-box , body').css('display', 'none');
    }
});


$(document).on('click', '.submit', function (e) {
    $.post(`https://frkn-doorlock/callback`, JSON.stringify({ 
        action: "createDoor",
        data: {
                configfile: $('.configfile').val(),
                job: $('.jobvalue').val(),
                gang: $('.gangvalue').val(),
                cid: 123,
                item: $('.itemvalue').val(),
                locked: inputStates["1"],
                pickable: inputStates["2"],
                cantunlock: inputStates["3"],
                fixText: inputStates["4"],
                svgDistance: Number($('.svgvalue').val()),
                interactDistance: Number($('.interactdistance').val()),
                dooridentifier: $('.doorname').val(),
                netId: Number(currentNetId),
                doortype: currentDoorType,
                passCode: $('.pincode').val(),
                positionData: {
                    position: {
                        x: 0,
                        y: 0,
                        z: 0,
                    },
                    rotation: {
                        x: 0,
                        y: 0,
                        z: 0,
                    },
                    handle: 0,
                    heading: 0,
                }
        }
    }), function (x) {
        $('.doors-list-box , .passcode , .frkn-box , body').css('display', 'none');
    })
})

$(document).on('click', '.doortype', function (e) {
    doorTypeOpen = !doorTypeOpen;

    if (doorTypeOpen) {   
        if (clientDoorType=="double") {
            $('.dbl').css('display', 'flex');
            $('.single').css('display', 'none');
        }else{
            $('.dbl').css('display', 'none');
            $('.single').css('display', 'flex');
        }
    }else{
            $('.dbl').css('display', 'none');
            $('.single').css('display', 'none');
        
    }

})

$(document).on('click', '.dooropen', function (e) {
    html = $(this).text();
    $('.doortype span').html(html) 
    currentDoorType = $(this).data('type');
    $('.dooropen').css('display', 'none');
})


async function getBase64Image(src, removeImageBackGround, callback, outputFormat) {
	const img = new Image();
	img.crossOrigin = 'Anonymous';
	img.addEventListener("load", () => loadFunc(), false);
	async function loadFunc() {
		const canvas = document.createElement('canvas');
		const ctx = canvas.getContext('2d');
		var convertingCanvas = canvas;
		if (removeImageBackGround) {
			var selectedSize = 320
			canvas.height = selectedSize;
			canvas.width = selectedSize;
			ctx.drawImage(img, 0, 0, selectedSize, selectedSize);
			await removeBackGround(canvas);
			const canvas2 = document.createElement('canvas');
			const ctx2 = canvas2.getContext('2d');
			canvas2.height = 64;
			canvas2.width = 64;
			ctx2.drawImage(canvas, 0, 0, selectedSize, selectedSize, 0, 0, img.naturalHeight, img.naturalHeight);
			convertingCanvas = canvas2;
		} else {
			canvas.height = img.naturalHeight;
			canvas.width = img.naturalWidth;
			ctx.drawImage(img, 0, 0);
		}
		var dataURL = convertingCanvas.toDataURL(outputFormat);
		canvas.remove();
		convertingCanvas.remove();
		img.remove();
		callback(dataURL);
	};
	img.src = src;
	if (img.complete || img.complete === undefined) {
		img.src = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACEAAAAkCAIAAACIS8SLAAAAKklEQVRIie3NMQEAAAgDILV/55nBww8K0Enq2XwHDofD4XA4HA6Hw+E4Wwq6A0U+bfCEAAAAAElFTkSuQmCC";
		img.src = src;
	}
}
  

async function Convert(pMugShotTxd, removeImageBackGround, id) {
	var tempUrl = `https://nui-img/${pMugShotTxd}/${pMugShotTxd}?t=${String(Math.round(new Date().getTime() / 1000))}`;
	getBase64Image(tempUrl, removeImageBackGround, function(dataUrl) {
		var xhr = new XMLHttpRequest();
		xhr.open("POST", `https://frkn-doorlock/Answer`, true);
		xhr.setRequestHeader('Content-Type', 'application/json');
		xhr.send(JSON.stringify({Answer: dataUrl, Id: id,}));
        $('.charbg').attr('src', dataUrl);
	})
}
 

async function removeBackGround(sentCanvas) {
	const canvas = sentCanvas;
	const ctx = canvas.getContext('2d');
	// Loading the model
	const net = await bodyPix.load({
		architecture: 'MobileNetV1',
		outputStride: 16,
		multiplier: 0.75,
		quantBytes: 2
	});
	// Segmentation
	const { data:map } = await net.segmentPerson(canvas, {
	  	internalResolution: 'medium',
	});
	// Extracting image data
	const { data:imgData } = ctx.getImageData(0, 0, canvas.width, canvas.height);
	// Creating new image data
	const newImg = ctx.createImageData(canvas.width, canvas.height);
	const newImgData = newImg.data;
	for (var i=0; i<map.length; i++) {
	  	//The data array stores four values for each pixel
		const [r, g, b, a] = [imgData[i*4], imgData[i*4+1], imgData[i*4+2], imgData[i*4+3]];
		[
		newImgData[i*4],
		newImgData[i*4+1],
		newImgData[i*4+2],
		newImgData[i*4+3]
		] = !map[i] ? [255, 255, 255, 0] : [r, g, b, a];
	}
	// Draw the new image back to canvas
	ctx.putImageData(newImg, 0, 0);
}