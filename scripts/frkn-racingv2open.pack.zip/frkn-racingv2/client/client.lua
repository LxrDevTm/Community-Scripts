cacheData = {}
identifier = nil

raceDescription = nil
raceName = nil
raceType = nil
raceMinLaps = nil
checkpointControl = nil
blips = {}
checkpoints = {}
checkpointCreationProps = {}
radius = 4.0
checkpointTime = 0
groupedCheckpointTimes = {}
racePlayers = {}
lastPlayerCoords = nil
racePositions = {}
trackType = nil
lastCheckpointPos = nil
bestLapTime = nil
lastLapTime = nil
startCoords = nil 
racecheckpoints = nil
spawnedRaceVehicle = nil
totalLaps = 1
currentCheckpoint = 1
currentLap = 1
currentRaceId = nil
blip = nil
createdObjects = {}
raceTimeLimit = 5
currentGroupIndex = 1
forceFPP = "No"
collision = false
showPosition = "No"
raceStarted = false
raceStartTime = 0
lapStartTime = 0
raceThreadActive = true
countdownActive = false
racerBlips =  {}

storedHandling, driftMode = {}, {}
kmh, mph = 3.6, 2.23693629
speed, speedLimit = kmh, 1000.0

driftScore = 0
totalDriftScore = 0
isDrifting = false
highestDriftScore = 0
driftCooldown = 0
driftTimeout = 1000 
manualMode = true  

playerPed = nil
tabletObject = nil
checkpointObjects = {} 
heightOffset = 0.0
forceFPPRunning = false

racerspeds = {}
preRacePosition = nil
tablet = false
raceStartBlip = nil
raceStartMarkerCoords = nil
raceStartMarkerThread = false

Drift = {
    currentGear = 1,
    maxGear = 6,
    currentRPM = 0.3,
    maxRPM = 0.95,
    throttleAccel = 0.015,
    cooldown = 0.008,
    vehicle = nil,
    gearRatios = {
        1.0, 0.8, 0.6, 0.5, 0.4, 0.3
    },
    gearSpeedLimits = {},

    CalculateSpeedLimits = function(self, veh)
        local handlingMaxSpeed = GetVehicleHandlingFloat(veh, 'CHandlingData', 'fInitialDriveMaxFlatVel')
        local step = handlingMaxSpeed / self.maxGear
        self.gearSpeedLimits = {}
        for i = 1, self.maxGear do
            self.gearSpeedLimits[i] = step * i * 1.98 
        end
    end
}




local targetCoords = nil
local isLineActive = false
local arrows = {}


local gearboxSystemEnabled = false
local commandManualMode = false
local gearboxThread = nil

Command = {
    currentGear = 1,
    maxGear = 6,
    currentRPM = 0.3,
    maxRPM = 0.95,
    throttleAccel = 0.015,
    cooldown = 0.008,
    vehicle = nil,
    gearRatios = {
        1.0, 0.85, 0.7, 0.6, 0.525, 0.45
    },
    gearSpeedLimits = {}
}


FlagProp = "tr_prop_tr_flag_01a"

propIndex = 1

colorHexToBlipId = {
    ["#cccccc"] = 0,  
    ["#a03b3b"] = 1,  
    ["#4b4b4b"] = 2,  
    ["#2f7d32"] = 25, 
    ["#2671ec"] = 3,  
    ["#4fa9f3"] = 4,  
    ["#473122"] = 5,  
    ["#734532"] = 6,  
    ["#4a3848"] = 7,  
    ["#a55639"] = 8,  
    ["#e2d142"] = 9,  
    ["#ffff99"] = 10, 
    ["#4dbb6e"] = 11, 
}


RegisterNetEvent('frkn-racing:setClient', function(data)
    cacheData = data
end)

AddEventHandler('QBCore:Client:OnPlayerLoaded', function()
    racesDataLoaded()
end)


RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function()
    racesDataLoaded()
end)

RegisterNetEvent('QBCore:Client:OnPlayerUnload', function()
    TriggerServerEvent('frkn-racing:removeSource')
end)

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(1000)
        if NetworkIsPlayerActive(PlayerId()) then
            racesDataLoaded()
            break
        end
    end
end)

function racesDataLoaded()
    identifier = GetPlayerIdentifier()

    if identifier == nil then
       TriggerServerEvent('frkn-racing:requestIdentifier')
    end

    TriggerServerEvent('frkn-racing:addSource')
    TriggerServerEvent('frkn-racing:dataPostClient')

    Citizen.SetTimeout(3000, function()
        TriggerCallback('frkn-racing:checkSavedPosition', function(savedPos)
            if savedPos then
                local ped = PlayerPedId()
                DoScreenFadeOut(500)
                Wait(600)
                SetEntityCoords(ped, savedPos.x, savedPos.y, savedPos.z, false, false, false, false)
                SetEntityHeading(ped, savedPos.h)
                Wait(500)
                DoScreenFadeIn(1000)
            end
        end)
    end)
end

RegisterNetEvent('frkn-racing:setIdentifier')
AddEventHandler('frkn-racing:setIdentifier', function(id)
    identifier = id
end)

RegisterNetEvent('frkn-racing:update')
AddEventHandler('frkn-racing:update',function(data)
    cacheData = data
end)

RegisterCommand("gotolastcp", function()
    if not raceStarted then
        Notify(Lang:t('general.race_not_active'))
        return
    end

    if not racecheckpoints or not currentCheckpoint or currentCheckpoint <= 1 then
        Notify(Lang:t('general.no_checkpoint_teleport'))
        return
    end

    local lastCheckpointIndex = currentCheckpoint - 1
    local cp = racecheckpoints[lastCheckpointIndex]
    if cp and cp.pos then
        local ped = PlayerPedId()
        local veh = GetVehiclePedIsIn(ped, false)
        local entity = veh ~= 0 and veh or ped 

        SetEntityCoords(entity, cp.pos.x, cp.pos.y, cp.pos.z + 1.0, false, false, false, true)
        SetEntityHeading(entity, cp.pos.w or 0.0)
        Notify(Lang:t('general.teleported_checkpoint'))
    else
        Notify(Lang:t('general.teleport_failed'))
    end
end)


RegisterCommand('openttab',function()
    if FRKN.UseTabletApp then
        return
    end
    alias = cacheData['alias'][identifier] or nil

    if not alias then
        TriggerServerEvent('frkn-racing:requestAlias')
        Wait(1000)
        alias = cacheData['alias'][identifier]
    end

    SendNUIMessage({
        action = 'open',
        data = cacheData,
        alias = cacheData['alias'][identifier],
        allAlias = cacheData['alias'],
        identifier = identifier,
    })
    SetNuiFocus(true, true)
end)


RegisterCommand("gearbox", function()
    local ped = PlayerPedId()
    local veh = GetVehiclePedIsIn(ped, false)

    if veh == 0 then
        Notify(Lang:t('general.must_be_in_vehicle'))
        return
    end

    gearboxSystemEnabled = not gearboxSystemEnabled
    if gearboxSystemEnabled then
        Notify(Lang:t('general.gearbox_enabled'))
    else
        Notify(Lang:t('general.gearbox_disabled'))
    end

    if not gearboxSystemEnabled and gearboxThread then
        Citizen.Wait(0)
        if DoesEntityExist(gearboxThread) then
            Citizen.Wait(0)
            Citizen.KillThread(gearboxThread)
            gearboxThread = nil
        end
        SendNUIMessage({ action = "closeGearbox" })
    end

    if gearboxSystemEnabled then
        gearboxThread = Citizen.CreateThread(function()
            while gearboxSystemEnabled do
                Citizen.Wait(0)

                ped = PlayerPedId()
                veh = GetVehiclePedIsIn(ped, false)

                if veh ~= 0 then
                    if Command.vehicle ~= veh then
                        Command.vehicle = veh
                        Command:CalculateSpeedLimits(veh)
                    end

                    if FRKN.ManuelSystem then 
                        if IsControlJustPressed(0, 137) then 
                            commandManualMode = not commandManualMode
                            if commandManualMode then
                                Notify(Lang:t('general.gearbox_manual'))
                            else
                                Notify(Lang:t('general.gearbox_automatic'))
                            end
                        end
                    end

          

                    if commandManualMode then
                        if IsControlJustPressed(0, 21) then Command:Upshift() end
                        if IsControlJustPressed(0, 36) then Command:DownShift() end

                        local throttle = GetControlNormal(0, 71)
                        if throttle > 0.1 then
                            Command.currentRPM = math.min(Command.currentRPM + (Command.throttleAccel * throttle), Command.maxRPM)
                        else
                            Command.currentRPM = math.max(Command.currentRPM - Command.cooldown, 0.15)
                        end

                        local gear_ratio = Command:GetGearInertia(Command.currentGear)
                        SetVehicleCurrentRpm(veh, Command.currentRPM)
                        SetVehicleHandlingFloat(veh, "CHandlingData", "fDriveInertia", gear_ratio + 0.02)

                        local currentSpeed = GetEntitySpeed(veh) * 3.6
                        local speedLimit = Command.gearSpeedLimits[Command.currentGear]
                        if currentSpeed > speedLimit then
                            local excessSpeed = currentSpeed - speedLimit
                            local brakeFactor = math.min(excessSpeed * 0.05, 0.30)
                            local velocity = GetEntityVelocity(veh)
                            SetEntityVelocity(veh, velocity.x * (1.0 - brakeFactor), velocity.y * (1.0 - brakeFactor), velocity.z)
                        end
                    else
                        Command.currentGear = GetVehicleCurrentGear(veh)
                    end

                    SendNUIMessage({
                        action = "updateGearbox",
                        currentGear = Command.currentGear,
                    })
                end
            end
        end)
    end
end)

RegisterCommand('openTablet', function()
    if FRKN.UseTabletApp then
        return
    end
    TriggerEvent('frkn-racing:openTablet')
end)

RegisterNetEvent('frkn-racing:openTablet')
AddEventHandler('frkn-racing:openTablet', function(data)
 

    local alias = cacheData['alias'] and cacheData['alias'][identifier]

    if not alias then

        TriggerCallback('frkn-racing:requestAlias', function(result)
            cacheData = result or {}
                openTabletUI()
        end, identifier)

        return
    end

    openTabletUI()
end)

local function getDefaultTabletAlias()
    return {
        alias = 'NAME NOT SET',
        data = {
            avatar = '',
            xp = 0,
            level = 0,
            rating = 0,
            matches = 0,
            moneyearned = 0,
            requiredXP = 0,
            races_won = 0,
            checkpointcolor = '#28FFFD',
            gpscolor = '#28FFFD'
        }
    }
end

local function buildTabletUiPayload()
    local aliases = cacheData and cacheData['alias'] or {}
    local alias = aliases and aliases[identifier] or nil

    return {
        action = 'open',
        data = cacheData or {},
        alias = alias or getDefaultTabletAlias(),
        allAlias = aliases or {},
        identifier = identifier or '',
        crew = FRKN.CrewSystem,
        menuItems = FRKN.MenuItems or {},
        formulaTrackId = FRKN.FormulaTrackId or 20,
        categoryTracks = FRKN.CategoryTracks or {},
        devMode = FRKN.DevMode or false,
    }
end

function openTabletUI()
    local ped = PlayerPedId()

    SendNUIMessage(buildTabletUiPayload())
    SetNuiFocus(true, true)
    if IsPedInAnyVehicle(ped, false) then
        return
    end
    
    if tablet then
        tablet = false
        return
    end
    

    tablet = true

    Citizen.CreateThread(function()
        local tabletDict = "amb@code_human_in_bus_passenger_idles@female@tablet@base"
        local tabletAnim = "base"
        local tabletProp = `prop_cs_tablet`
        local tabletBone = 60309
        local tabletOffset = vector3(0.03, 0.002, 0.0)
        local tabletRot = vector3(10.0, 160.0, 0.0)

        RequestAnimDict(tabletDict)
        while not HasAnimDictLoaded(tabletDict) do
            Wait(150)
        end

        RequestModel(tabletProp)
        while not HasModelLoaded(tabletProp) do
            Wait(150)
        end

        SetCurrentPedWeapon(ped, `weapon_unarmed`, true)

        tabletObj = CreateObject(tabletProp, 0.0, 0.0, 0.0, true, true, false)

        AttachEntityToEntity(
            tabletObj,
            ped,
            GetPedBoneIndex(ped, tabletBone),
            tabletOffset.x, tabletOffset.y, tabletOffset.z,
            tabletRot.x, tabletRot.y, tabletRot.z,
            true, false, false, false, 2, true
        )

        SetModelAsNoLongerNeeded(tabletProp)

        while tablet do
            Wait(100)

            if not IsEntityPlayingAnim(ped, tabletDict, tabletAnim, 3) then
                TaskPlayAnim(ped, tabletDict, tabletAnim, 3.0, 3.0, -1, 49, 0, false, false, false)
            end
        end

        ClearPedSecondaryTask(ped)
        Wait(400)

        DetachEntity(tabletObj, true, false)
        DeleteEntity(tabletObj)
    end)
end


function cleanupTablet()
    local ped = PlayerPedId()

    tablet = false

    ClearPedSecondaryTask(ped)
    ClearPedTasksImmediately(ped)

    if tabletObject and DoesEntityExist(tabletObject) then
        DetachEntity(tabletObject, true, true)
        DeleteEntity(tabletObject)
        tabletObject = nil
    end

    SetNuiFocus(false, false)
end



RegisterNetEvent('frkn-racing:joined')
AddEventHandler('frkn-racing:joined', function(race)
    TriggerCallback('frkn-racing:getTrackCheckpoints', function(checkpoints)
        racecheckpoints = checkpoints or {}
        checkpointsPerGroup = math.ceil(#racecheckpoints / 4)
        for i = 1, 4 do
            table.insert(groupedCheckpointTimes, {groupIndex = i, totalTime = 0})
        end
        totalLaps = race.laps
        currentCheckpoint = 1
        blips = {}
        raceStarted = false
        currentRaceId = race.entry_id
        Notify(Lang:t('general.notify_join'))
    end, tonumber(race.track_id))
end)

local formulaGridPositions = {
    {x = 2276.9075, y = 7838.9365, z = 423.0959, h = 146.8606}, 
    {x = 2271.4453, y = 7842.4282, z = 423.0954, h = 147.7312}, 
    {x = 2281.1743, y = 7845.9634, z = 423.0957, h = 150.5693}, 
}

local function GenerateFormulaGrid(maxPlayers)
    if #formulaGridPositions >= maxPlayers then
        return formulaGridPositions
    end
    
    local grid = {}
    for i = 1, #formulaGridPositions do
        grid[i] = formulaGridPositions[i]
    end
    
    local rightOffset = {
        x = formulaGridPositions[2].x - formulaGridPositions[1].x,
        y = formulaGridPositions[2].y - formulaGridPositions[1].y,
        z = formulaGridPositions[2].z - formulaGridPositions[1].z,
        h = formulaGridPositions[2].h - formulaGridPositions[1].h
    }
    
    local rowOffset = {
        x = formulaGridPositions[3].x - formulaGridPositions[1].x,
        y = formulaGridPositions[3].y - formulaGridPositions[1].y,
        z = formulaGridPositions[3].z - formulaGridPositions[1].z,
        h = formulaGridPositions[3].h - formulaGridPositions[1].h
    }
    
    local currentRow = 1
    for i = #formulaGridPositions + 1, maxPlayers do
        local isLeftSide = (i % 2 == 1) 
        local baseRow = math.floor((i - 1) / 2)
        
        if isLeftSide then
            grid[i] = {
                x = formulaGridPositions[1].x + (rowOffset.x * baseRow),
                y = formulaGridPositions[1].y + (rowOffset.y * baseRow),
                z = formulaGridPositions[1].z + (rowOffset.z * baseRow),
                h = formulaGridPositions[1].h + (rowOffset.h * baseRow)
            }
        else
            grid[i] = {
                x = formulaGridPositions[2].x + (rowOffset.x * (baseRow - 1)),
                y = formulaGridPositions[2].y + (rowOffset.y * (baseRow - 1)),
                z = formulaGridPositions[2].z + (rowOffset.z * (baseRow - 1)),
                h = formulaGridPositions[2].h + (rowOffset.h * (baseRow - 1))
            }
        end
    end
    
    return grid
end


local function GenerateTrackGrid(startPos, playerCount, trackRaceType)
    local grid = {}
    local heading = startPos.h or 0.0
    local headingRad = math.rad(heading)
    
    local forwardX = -math.sin(headingRad)
    local forwardY = math.cos(headingRad)
    local rightX = math.cos(headingRad)
    local rightY = math.sin(headingRad)
    
    local rowSpacing = 8.0   
    local colSpacing = 4.0   
    
    local rType = trackRaceType and trackRaceType:lower() or ""
    if rType == "plane" then
        rowSpacing = 25.0
        colSpacing = 30.0
    elseif rType == "jetski" then
        rowSpacing = 12.0
        colSpacing = 8.0
    end
    
    for i = 1, playerCount do
        local row = math.floor((i - 1) / 2)  
        local isRight = (i % 2 == 0)         
        
        local backX = startPos.x - (forwardX * rowSpacing * row)
        local backY = startPos.y - (forwardY * rowSpacing * row)
        
        local offsetMultiplier = isRight and 1 or -1
        local finalX = backX + (rightX * colSpacing * offsetMultiplier * 0.5)
        local finalY = backY + (rightY * colSpacing * offsetMultiplier * 0.5)
        
        grid[i] = {
            x = finalX,
            y = finalY,
            z = startPos.z,
            h = heading
        }
    end
    
    return grid
end

RegisterCommand('exitrace', function()
    if not raceStarted or not currentRaceId then return end

    TriggerCallback('frkn-racing:leave', function(call)
        if call.type == "success" then
            TriggerEvent('frkn-racing:finished', 'none')
        end
    end, currentRaceId, nil, "self")
end)

local function HexToRGB(hex)
    hex = (hex or "#FFFFFF"):gsub("#", "")
    return tonumber("0x"..hex:sub(1,2)) or 255,
           tonumber("0x"..hex:sub(3,4)) or 255,
           tonumber("0x"..hex:sub(5,6)) or 255
end

local raceInfoPanel = {
    active = false,
    eventName = "",
    vehicleClass = "Open",
    trackName = "",
    countdown = 0,
    countdownActive = false,
}

function FormatRaceTime(seconds)
    if not seconds or seconds <= 0 then return "00:00" end
    local mins = math.floor(seconds / 60)
    local secs = seconds % 60
    return string.format("%02d:%02d", mins, secs)
end

local function GetRaceDataById(raceId)
    if not raceId then
        return nil, nil
    end

    for _, entry in pairs(cacheData or {}) do
        if tonumber(entry.id) == tonumber(raceId) then
            if type(entry.races) == "string" then
                entry.races = json.decode(entry.races)
            end

            local raceData = entry.races and (entry.races[1] or entry.races['1']) or entry
            if raceData then
                return entry, raceData
            end
        end
    end

    return nil, nil
end

local function ResolveRaceAliasName(player)
    if type(player) ~= "table" then
        return "Unknown"
    end

    if type(player.alias) == "table" and player.alias.alias and player.alias.alias ~= "" then
        return player.alias.alias
    end

    if type(player.alias) == "string" and player.alias ~= "" then
        return player.alias
    end

    if type(player.aliasData) == "table" and player.aliasData.alias and player.aliasData.alias ~= "" then
        return player.aliasData.alias
    end

    if player.identifier and cacheData['alias'] and cacheData['alias'][player.identifier] then
        local aliasEntry = cacheData['alias'][player.identifier]
        if aliasEntry and aliasEntry.alias and aliasEntry.alias ~= "" then
            return aliasEntry.alias
        end
    end

    return "Unknown"
end

local function FormatRaceBoardTime(seconds)
    local value = tonumber(seconds)
    if not value or value <= 0 then
        return "--:--.--"
    end

    local mins = math.floor(value / 60)
    local secs = math.floor(value % 60)
    local hundredths = math.floor(((value - math.floor(value)) * 100) + 0.5)

    if hundredths >= 100 then
        hundredths = hundredths - 100
        secs = secs + 1
        if secs >= 60 then
            secs = secs - 60
            mins = mins + 1
        end
    end

    return string.format("%02d:%02d.%02d", mins, secs, hundredths)
end

local function FormatMoneyText(amount)
    local formatted = tostring(math.floor((tonumber(amount) or 0) + 0.5))
    local changed = 1

    while changed > 0 do
        formatted, changed = formatted:gsub("^(%-?%d+)(%d%d%d)", "%1,%2")
    end

    return "$" .. formatted
end

local function BuildFinishRewardMap(raceData, racerCount)
    local rewards = {}

    if raceData and raceData.isAutoRace and FRKN.AutoRaceSystem and FRKN.AutoRaceSystem.prizes then
        for rawPosition, prize in pairs(FRKN.AutoRaceSystem.prizes) do
            local position = tonumber(rawPosition)
            if position then
                if prize.type == "money" and prize.amount then
                    rewards[position] = FormatMoneyText(prize.amount)
                elseif prize.type == "item" and prize.item then
                    rewards[position] = string.format("%sx %s", prize.amount or 1, prize.item)
                end
            end
        end
    elseif raceData and tonumber(raceData.buyIn or 0) > 0 and tonumber(racerCount or 0) > 0 then
        rewards[1] = FormatMoneyText((tonumber(raceData.buyIn) or 0) * tonumber(racerCount or 0))
    end

    return rewards
end

local function BuildRaceFinishPayload(totalRaceTime, finishPosition)
    local _, raceData = GetRaceDataById(currentRaceId)
    local myServerId = GetPlayerServerId(PlayerId())
    local myAliasEntry = cacheData['alias'] and cacheData['alias'][identifier] or {}
    local myAliasName = (myAliasEntry and myAliasEntry.alias) or GetPlayerName(PlayerId()) or "You"
    local standings = {}
    local racers = racePositions or {}
    local totalRacers = #racers
    local rewardMap = BuildFinishRewardMap(raceData, totalRacers)
    local foundPlayerRow = false

    for index, racer in ipairs(racers) do
        local rowPosition = tonumber(racer.position) or index
        local isLocalPlayer = racer.identifier == identifier or tonumber(racer.source or -1) == tonumber(myServerId)
        local timeText = racer.finishTime and FormatRaceBoardTime(racer.finishTime)
            or (racer.timeDifference and tostring(racer.timeDifference) or "--:--.--")

        if isLocalPlayer then
            foundPlayerRow = true
            timeText = FormatRaceBoardTime(totalRaceTime)
        end

        standings[#standings + 1] = {
            position = rowPosition,
            name = ResolveRaceAliasName(racer),
            timeText = timeText,
            rewardText = rewardMap[rowPosition],
            isPlayer = isLocalPlayer,
            status = isLocalPlayer and "SEN" or nil
        }
    end

    if totalRacers == 0 then
        totalRacers = raceData and #(raceData.players or {}) or 0
    end

    if (not finishPosition or finishPosition <= 0) and foundPlayerRow then
        for _, row in ipairs(standings) do
            if row.isPlayer then
                finishPosition = row.position
                break
            end
        end
    end

    if (not finishPosition or finishPosition <= 0) and totalRacers == 1 then
        finishPosition = 1
    end

    if not foundPlayerRow then
        standings[#standings + 1] = {
            position = finishPosition or 0,
            name = myAliasName,
            timeText = FormatRaceBoardTime(totalRaceTime),
            rewardText = rewardMap[finishPosition or 1],
            isPlayer = true,
            status = "SEN"
        }
    end

    table.sort(standings, function(a, b)
        return (tonumber(a.position) or 999) < (tonumber(b.position) or 999)
    end)

    return {
        action = "raceFinishResult",
        raceName = raceData and raceData.eventName or raceName or "RACE FINISH",
        playerName = myAliasName,
        position = finishPosition or 0,
        totalTime = totalRaceTime,
        bestLap = bestLapTime,
        checkpointsPassed = (racecheckpoints and #racecheckpoints or 0) * (tonumber(totalLaps) or 1),
        totalCheckpoints = (racecheckpoints and #racecheckpoints or 0) * (tonumber(totalLaps) or 1),
        lapsCompleted = totalLaps,
        totalLaps = totalLaps,
        totalRacers = totalRacers,
        standings = standings,
        buyIn = raceData and raceData.buyIn or 0,
        prizeType = raceData and raceData.prizeType or nil
    }
end




RegisterNetEvent('frkn-racing:started')
AddEventHandler('frkn-racing:started', function(id, racerIds)
    currentRaceId = id
    racerspeds = racerIds
    local countdownTime = 5000
    local raceDataFound = false
    local trackIdToFetchFallback = nil
    SetNuiFocus(false, false)
    
    tablet = false
    if tabletObject and DoesEntityExist(tabletObject) then
        DetachEntity(tabletObject, true, true)
        DeleteEntity(tabletObject)
        tabletObject = nil
    end
    StopAnimTask(PlayerPedId(), "amb@code_human_in_bus_passenger_idles@female@tablet@base", "base", 1.0)
    
    raceType = nil
    racecheckpoints = nil

    if raceStartBlip and DoesBlipExist(raceStartBlip) then
        RemoveBlip(raceStartBlip)
        raceStartBlip = nil
    end
    raceStartMarkerCoords = nil

    local retryCount = 0
    while not raceDataFound and retryCount < 15 do
        for k, v in pairs(cacheData) do
            if v.races ~= nil then 
                local controlData = v.races[1] or v.races['1']
                if controlData and tonumber(v.id) == tonumber(id) then 
                    countdownTime = (tonumber(controlData.countdownStart) or 5) * 1000
                    totalLaps = tonumber(controlData.laps)
                    raceTimeLimit = tonumber(controlData.raceTime)
                    forceFPP = controlData.forceFPP
                    racePlayers = controlData.players or {}
                    showPosition = controlData.showPosition
                    collision = controlData.collision
                    raceDataFound = true
                    raceType = controlData.type
                    checkpointControl = controlData.enableAlerts
                    trackIdToFetchFallback = tonumber(v.track_id) or tonumber(controlData.track_id)

                    if controlData.checkpoints and #controlData.checkpoints > 0 then
                        racecheckpoints = controlData.checkpoints
                    end

                    break 
                end
            end
        end
        if not raceDataFound then
            Wait(200)
            retryCount = retryCount + 1
        end
    end

    if trackIdToFetchFallback and (not racecheckpoints or #racecheckpoints == 0) then
        local fetched = false
        TriggerCallback('frkn-racing:getTrackCheckpoints', function(fetchedCheckpoints)
            if fetchedCheckpoints and #fetchedCheckpoints > 0 then
                racecheckpoints = fetchedCheckpoints
            end
            fetched = true
        end, trackIdToFetchFallback)
        
        local timeout = 0
        while not fetched and timeout < 50 do
            Wait(100)
            timeout = timeout + 1
        end
    end

    local ped = PlayerPedId()
    local veh = GetVehiclePedIsIn(ped, false)

    if veh ~= 0 then
        local coords = GetEntityCoords(veh)
        local heading = GetEntityHeading(veh)

        preRacePosition = {
            x = coords.x,
            y = coords.y,
            z = coords.z,
            h = heading
        }
    else
        local coords = GetEntityCoords(ped)
        local heading = GetEntityHeading(ped)

        preRacePosition = {
            x = coords.x,
            y = coords.y,
            z = coords.z,
            h = heading
        }
    end

    if raceDataFound then
        if raceType and (raceType:lower() == "formula" or raceType:lower() == "plane" or raceType:lower() == "jetski") then
            TriggerServerEvent('frkn-racing:savePreRacePosition', preRacePosition)
        end
        if raceType and (raceType:lower() == "formula" or raceType:lower() == "plane" or raceType:lower() == "jetski") then
            local myServerId = GetPlayerServerId(PlayerId())
            local myGridPosition = nil
            
            for index, raceSource in ipairs(racerIds) do
                if tonumber(raceSource) == tonumber(myServerId) then
                    myGridPosition = index
                    break
                end
            end
            
            if myGridPosition then
                local gridPositions
                local totalPlayers = #racerIds
                if raceType:lower() == "formula" then
                    gridPositions = GenerateFormulaGrid(totalPlayers)
                else
                    local checkpoints = nil
                    for k, v in pairs(cacheData) do
                        if v.races ~= nil then
                            local cd = v.races[1] or v.races['1']
                            if cd and tonumber(v.id) == tonumber(currentRaceId) then
                                checkpoints = cd.checkpoints
                                break
                            end
                        end
                    end
                    
                    if (not checkpoints or #checkpoints == 0) and racecheckpoints and #racecheckpoints > 0 then
                        checkpoints = racecheckpoints
                    end
                    
                    if checkpoints and checkpoints[1] and checkpoints[1].pos then
                        local cp1 = checkpoints[1].pos
                        local heading = 0.0
                        
                        if checkpoints[2] and checkpoints[2].pos then
                            local cp2 = checkpoints[2].pos
                            local dx = cp2.x - cp1.x
                            local dy = cp2.y - cp1.y
                            heading = -math.deg(math.atan(dx, dy))
                            if heading < 0 then heading = heading + 360.0 end
                        end
                        
                        local startPos = {
                            x = cp1.x,
                            y = cp1.y,
                            z = cp1.z,
                            h = heading
                        }
                        gridPositions = GenerateTrackGrid(startPos, totalPlayers, raceType)
                    else
                    end
                end
                local spawnPos = gridPositions and gridPositions[myGridPosition]
                
                if spawnPos then
                    local playerPed = PlayerPedId()
                    local playerVehicle = GetVehiclePedIsIn(playerPed, false)
                    
                    DoScreenFadeOut(200)
                    while not IsScreenFadedOut() do
                        Wait(0)
                    end
                    
                    if playerVehicle ~= 0 then
                        TaskLeaveVehicle(playerPed, playerVehicle, 16)
                        Wait(500)
                        DeleteVehicle(playerVehicle)
                    end
                    
                    SetEntityCoords(playerPed, spawnPos.x, spawnPos.y, spawnPos.z, false, false, false, false)
                    SetEntityHeading(playerPed, spawnPos.h)
                    Wait(100)
                    
                    local spawnModel
                    if raceType:lower() == "formula" then
                        spawnModel = FRKN.FormulaVehicle or "openwheel1"
                    elseif raceType:lower() == "plane" then
                        spawnModel = FRKN.AirplaneVehicle or "velum"
                    else
                        spawnModel = FRKN.JetSkiVehicle or "seashark"
                    end
                    local modelHash = GetHashKey(spawnModel)
                    RequestModel(modelHash)
                    while not HasModelLoaded(modelHash) do
                        Wait(10)
                    end
                    
                    local spawnZ = spawnPos.z
                    local spawnX = spawnPos.x
                    local spawnY = spawnPos.y

                    local headingRad = math.rad(spawnPos.h)
                    spawnX = spawnX + math.sin(headingRad) * 25.0
                    spawnY = spawnY - math.cos(headingRad) * 25.0

                    if raceType:lower() == "formula" then
                        local foundGround, gZ = GetGroundZFor_3dCoord(spawnX, spawnY, spawnPos.z + 5.0, false)
                        if foundGround then
                            spawnZ = gZ + 0.5
                        end
                    elseif raceType:lower() == "plane" then
                        local foundGround, gZ = GetGroundZFor_3dCoord(spawnX, spawnY, spawnPos.z + 10.0, false)
                        if foundGround then
                            spawnZ = gZ + 0.5
                        end
                    end

                    local spawnedVehicle = CreateVehicle(modelHash, spawnX, spawnY, spawnZ, spawnPos.h, true, false)
                    spawnedRaceVehicle = spawnedVehicle
                    SetModelAsNoLongerNeeded(modelHash)
                    SetEntityHeading(spawnedVehicle, spawnPos.h)
                    FreezeEntityPosition(spawnedVehicle, true)
                    
                    NetworkRequestControlOfEntity(spawnedVehicle)
                    local timeout = 0
                    while not NetworkHasControlOfEntity(spawnedVehicle) and timeout < 20 do
                        Wait(100)
                        timeout = timeout + 1
                    end

                    local plate = GetVehicleNumberPlateText(spawnedVehicle)
                    if plate then
                        TriggerEvent('frkn-racingv2:giveKeys', plate)
                    end

                    if FRKN.SetFuel then
                        FRKN.SetFuel(spawnedVehicle, 100.0)
                    else
                        SetVehicleFuelLevel(spawnedVehicle, 100.0)
                        DecorSetFloat(spawnedVehicle, "_FUEL_LEVEL", 100.0)
                    end
                    
                    Wait(200)
                    SetPedIntoVehicle(playerPed, spawnedVehicle, -1)
                    
                    local retries = 0
                    while not IsPedInVehicle(playerPed, spawnedVehicle, false) and retries < 10 do
                        Wait(100)
                        SetPedIntoVehicle(playerPed, spawnedVehicle, -1)
                        retries = retries + 1
                    end
                    
                    Wait(500)
                    DoScreenFadeIn(1000)
                    while not IsScreenFadedIn() do
                        Wait(0)
                    end
                end
            end
        else
            local playerVehicle = GetVehiclePedIsIn(PlayerPedId(), false)
            if playerVehicle ~= 0 then 
                FreezeEntityPosition(playerVehicle, true)
            end
        end


        local countdownSeconds = math.max(math.floor(countdownTime / 1000), 3)

        SendNUIMessage({
            action = "startRace",
            time = countdownTime,
        })
        
        Wait(countdownSeconds * 1000 + 50)
        
        local playerVehicle = GetVehiclePedIsIn(PlayerPedId(), false)
        if playerVehicle ~= 0 then 
            FreezeEntityPosition(playerVehicle, false)
        end

        lastPlayerCoords = GetEntityCoords(PlayerPedId())

        raceStarted = true
        currentLap = 1
        currentCheckpoint = 1
        raceStartTime = GetGameTimer()
        lapStartTime = GetGameTimer()
        raceThreadActive = true
        Citizen.CreateThread(function()
            StartRace()
        end)
        FRKN.HudOpen()


        CreateThread(function()
            while raceStarted  do
                Wait(0)
                if isLineActive then
                    DrawAllArrows()
                else
                    Wait(500)
                end
            end
        end)

        CreateThread(function()
            while raceThreadActive do
                Citizen.Wait(0)
                local skipStartMarker = raceType and (raceType:lower() == "formula" or raceType:lower() == "jetski")
                if not skipStartMarker and racecheckpoints and #racecheckpoints > 0 and currentLap == 1 and currentCheckpoint <= 1 then
                    local startPos = racecheckpoints[1].pos
                    if startPos then
                        DrawMarker(
                            4,
                            startPos.x, startPos.y, startPos.z + 1.0,
                            0.0, 0.0, 0.0,
                            0.0, 0.0, 0.0,
                            7.0, 7.0, 7.0,
                            0, 255, 0, 200,
                            false, true, 2, false, nil, nil, false
                        )
                    end
                end
                if FRKN.EndOfRaceMarker and lastCheckpointPos and racecheckpoints then
                    local isLastLap = (currentLap >= totalLaps)
                    local nearEnd = (currentCheckpoint >= #racecheckpoints - 1)
                    if isLastLap and nearEnd then
                        DrawMarker(
                            4,
                            lastCheckpointPos.x, lastCheckpointPos.y, lastCheckpointPos.z + 1.0,
                            0.0, 0.0, 0.0,
                            0.0, 0.0, 0.0,
                            7.0, 7.0, 7.0,
                            255, 0, 0, 200,
                            false, true, 2, false, nil, nil, false
                        )
                    end
                end
            end
        end)

        Citizen.CreateThread(function()
            local lastNUIUpdate = GetGameTimer()
            local lastServerUpdate = GetGameTimer()

            lastPlayerCoords = GetEntityCoords(PlayerPedId())
        
            while raceStarted do
                Citizen.Wait(0)
                local ped = PlayerPedId()
                local veh = GetVehiclePedIsIn(ped, false)
                local playerCoords = GetEntityCoords(ped)

                if IsEntityDead(ped) then
                    raceStarted = false
                    SendNUIMessage({ action = "close" })
                    resetVehicleHandling(veh)
                    TriggerServerEvent('frkn-racing:disqualify', currentRaceId)
                    break
                end

                if not racecheckpoints then break end
                if currentCheckpoint == 1 and racecheckpoints[1] and not isLineActive then
                    if FRKN.RaceLineSettings.enabled then
                        if not FRKN.RaceLineSettings.formulaOnly or (raceType and raceType:lower() == "formula") then
                            local first = racecheckpoints[1]
                            targetCoords = GetGroundPoint(vector3(first.pos.x, first.pos.y, first.pos.z))
                            isLineActive = true
                            CalculateArrows()
                        end
                    end
                end

                if collision then
                    SetCollisions(racerspeds, true)
                end

                if not racecheckpoints then break end
                local cpData = racecheckpoints[currentCheckpoint]
                if cpData then
                    local checkpointCoords = vector3(cpData.pos.x, cpData.pos.y, cpData.pos.z)
                    if checkpointControl and racecheckpoints and #racecheckpoints > 0 then
                        local markerStart = currentCheckpoint
                        local markerEnd = math.min(currentCheckpoint + 2, #racecheckpoints)
                        for i = markerStart, markerEnd do
                            local cp = racecheckpoints[i]
                            if cp then
                                local coords = vector3(cp.pos.x, cp.pos.y, cp.pos.z)
                                local distance = #(playerCoords - coords)

                                local playerColorHex = "#FF3B30"
                                for _, p in pairs(racePlayers) do
                                    if tonumber(p.source) == GetPlayerServerId(PlayerId()) or p.identifier == identifier then
                                        if p.alias and p.alias.data and p.alias.data.checkpointcolor then
                                            playerColorHex = p.alias.data.checkpointcolor
                                        elseif p.aliasData and p.aliasData.data and p.aliasData.data.checkpointcolor then
                                            playerColorHex = p.aliasData.data.checkpointcolor
                                        end
                                        break
                                    end
                                end

                                local r, g, b = HexToRGB(playerColorHex)
                                local isNext = (i == currentCheckpoint)
                                DrawCheckpointMarkerWithDistance(coords, distance, isNext, r, g, b)
                            end
                        end
                    end

                    if raceType and veh ~= 0 then
                        local lowerType = raceType:lower()
                        local plate = getVehiclePlate(veh)

                        if not storedHandling[plate] then
                            storeVehicleHandling(veh)
                        end

                        if Drift.vehicle ~= veh then
                            Drift.vehicle = veh
                            Drift:CalculateSpeedLimits(veh)
                        end
                        if lowerType == "drift" then
                            local model = GetDisplayNameFromVehicleModel(GetEntityModel(veh)):lower()
                            local isBlacklisted = false
                            for _, blacklisted in ipairs(FRKN.DriftBlacklist) do
                                if model == blacklisted:lower() then
                                    isBlacklisted = true
                                    break
                                end
                            end

                            if not isBlacklisted then
                                driftMode[plate] = true
                                applyDriftHandling(veh)
                                SetVehicleEnginePowerMultiplier(veh, 20.0)
                                SetVehicleEngineTorqueMultiplier(veh, 3.0)
                            end

                            local speed = GetEntitySpeed(veh) * 3.6
                            local velocity = GetEntityVelocity(veh)
                            local velVector = vector3(velocity.x, velocity.y, 0.0)
                            local forwardVector = vector3(GetEntityForwardVector(veh).x, GetEntityForwardVector(veh).y, 0.0)

                            local dot = Dot(velVector.xy, forwardVector.xy)
                            local mag1 = #(velVector.xy)
                            local mag2 = #(forwardVector.xy)
                            local angle = math.deg(math.acos(dot / (mag1 * mag2 + 1e-6)))

                            local now = GetGameTimer()
                            local isReversing = (forwardVector.x * velocity.x + forwardVector.y * velocity.y) < 0

                            if angle > 15.0 and speed > 30.0 and not isReversing then
                                if not isDrifting then isDrifting = true end
                                driftCooldown = now
                                driftScore = driftScore + math.floor(angle * 0.6)
                            else
                                if isDrifting and (now - driftCooldown) > driftTimeout then
                                    isDrifting = false
                                    totalDriftScore = totalDriftScore + driftScore

                                    if driftScore > highestDriftScore then
                                        highestDriftScore = driftScore
                                    end

                                    driftScore = 0

                                    TriggerServerEvent('frkn-racing:updatePlayerPosition', {
                                        raceId = currentRaceId,
                                        lap = currentLap,
                                        checkpoint = currentCheckpoint,
                                        checkpointTime = checkpointTime,
                                        totalCheckpoints = #racecheckpoints,
                                        bestLapTime = bestLapTime,
                                        carName = currentCarName(),
                                        carTransmission = getRandomTransmission(),
                                        carType = getCarType(veh),
                                        carTurbo = determineCarCustomization(getCarPowerByType(getCarType(veh))),
                                        carPlate = getVehiclePlate(veh),
                                        totalDriftScore = totalDriftScore,
                                        raceType = raceType,
                                        hasDrifted = true,
                                    })
                                end
                            end

                        elseif FRKN.handlingPresets[lowerType] then
                            driftMode[plate] = false
                            SetVehicleEngineTorqueMultiplier(veh, 1.0)
                            SetVehicleEnginePowerMultiplier(veh, 1.0)
                            for k, v in pairs(FRKN.handlingPresets[lowerType]) do
                                SetVehicleHandlingFloat(veh, "CHandlingData", k, tonumber(v) or 0.0)
                            end
                        end
                    end

                    if veh ~= 0 and not driftMode[getVehiclePlate(veh)] then
                        SetVehicleReduceGrip(veh, false)
                        SetVehicleEngineTorqueMultiplier(veh, 1.0)
                    end

                    if showPosition then
                        for _, playerData in ipairs(racePlayers) do
                            local serverId = playerData.source
                            local playerId = GetPlayerFromServerId(serverId)

                            if playerId == -1 and racerBlips[serverId] then
                                RemoveBlip(racerBlips[serverId])
                                racerBlips[serverId] = nil
                            end

                            if playerId ~= -1 and playerId ~= PlayerId() then
                                local otherPed = GetPlayerPed(playerId)
                                local otherCoords = GetEntityCoords(otherPed)

                                local gpsHex = playerData.alias and playerData.alias.data and playerData.alias.data.gpscolor
                                if not gpsHex and playerData.aliasData and playerData.aliasData.data then
                                    gpsHex = playerData.aliasData.data.gpscolor
                                end

                                gpsHex = gpsHex or "#cccccc"

                                local colorId = colorHexToBlipId[string.lower(gpsHex)] or 5

                                if not racerBlips[serverId] then
                                    local blip = AddBlipForEntity(otherPed)
                                    SetBlipSprite(blip, 1)
                                    SetBlipScale(blip, 0.85)
                                    SetBlipColour(blip, colorId)
                                    ShowHeadingIndicatorOnBlip(blip, true)

                                    BeginTextCommandSetBlipName("STRING")
                                    AddTextComponentString("#" .. (playerData.alias and playerData.alias.alias or playerData.alias or '?'))
                                    EndTextCommandSetBlipName(blip)

                                    racerBlips[serverId] = blip
                                else
                                    SetBlipCoords(racerBlips[serverId], otherCoords)
                                end
                            end
                        end
                    end

                    local cpVec = vector3(cpData.pos.x, cpData.pos.y, cpData.pos.z)
                    local distToCP = GetDistanceBetweenCoords(playerCoords, cpVec, true)

                    local hitCheckpoint = false
                    if distToCP < 15.0 and not lapJustFinished then
                        hitCheckpoint = true
                    elseif lastPlayerCoords and not lapJustFinished then
                        local segLen = #(playerCoords - lastPlayerCoords)
                        if segLen > 5.0 then
                            local dir = (playerCoords - lastPlayerCoords) / segLen
                            local toCP = cpVec - lastPlayerCoords
                            local proj = toCP.x * dir.x + toCP.y * dir.y + toCP.z * dir.z
                            if proj > 0 and proj < segLen then
                                local closest = lastPlayerCoords + dir * proj
                                local perpDist = #(closest - cpVec)
                                if perpDist < 15.0 then
                                    hitCheckpoint = true
                                end
                            end
                        end
                    end
                    lastPlayerCoords = playerCoords

                    if hitCheckpoint then
                        checkpointTime = (GetGameTimer() - raceStartTime) / 1000
                        if groupedCheckpointTimes[currentGroupIndex] then
                            groupedCheckpointTimes[currentGroupIndex].totalTime = checkpointTime
                        end

                        if currentCheckpoint % checkpointsPerGroup == 0 or currentCheckpoint == #racecheckpoints then
                            currentGroupIndex = currentGroupIndex + 1
                        end

                        RemoveBlip(blips[currentCheckpoint])

                        if FRKN.Sound.EnableCheckpointSound then
                            PlaySound(-1, FRKN.Sound.CheckpointSound, FRKN.Sound.CheckpointSoundSet, 0, 0, 1)
                        end

                        currentCheckpoint = currentCheckpoint + 1

                        if currentCheckpoint > 1 then
                            local prevBlip = blips[currentCheckpoint - 1]
                            if prevBlip then
                                RemoveBlip(prevBlip)
                                blips[currentCheckpoint - 1] = nil
                            end

                            local prevObjects = checkpointObjects[currentCheckpoint - 1]
                            if prevObjects then
                                if DoesEntityExist(prevObjects.left) then DeleteEntity(prevObjects.left) end
                                if DoesEntityExist(prevObjects.right) then DeleteEntity(prevObjects.right) end
                                checkpointObjects[currentCheckpoint - 1] = nil
                            end
                        end

                        if FRKN.RaceLineSettings.enabled then
                            if not FRKN.RaceLineSettings.formulaOnly or (raceType and raceType:lower() == "formula") then
                                local nextCP = racecheckpoints[currentCheckpoint]
                                if nextCP then
                                    targetCoords = GetGroundPoint(vector3(nextCP.pos.x, nextCP.pos.y, nextCP.pos.z))
                                    isLineActive = true
                                    CalculateArrows()
                                end
                            end
                        end

                        if currentCheckpoint > #racecheckpoints then
                            lapJustFinished = true

                            local currentLapTime = (GetGameTimer() - lapStartTime) / 1000
                            if not bestLapTime or currentLapTime < bestLapTime then
                                bestLapTime = currentLapTime
                            end

                            lastLapTime = currentLapTime
                            currentLap = currentLap + 1
                            lapStartTime = GetGameTimer()

                            if currentLap > totalLaps then
                                isLineActive = false
                                targetCoords = nil
                                arrows = {}

                                TriggerServerEvent('frkn-racing:updatePlayerPosition', {
                                    raceId = currentRaceId,
                                    lap = currentLap,
                                    checkpoint = currentCheckpoint,
                                    checkpointTime = checkpointTime,
                                    totalCheckpoints = #racecheckpoints,
                                    bestLapTime = bestLapTime,
                                    carName = currentCarName(),
                                    carTransmission = getRandomTransmission(),
                                    carType = getCarType(veh),
                                    carPlate = getVehiclePlate(veh),
                                    carTurbo = determineCarCustomization(getCarPowerByType(getCarType(veh))),
                                    totalDriftScore = totalDriftScore,
                                    raceType = raceType,
                                    hasDrifted = true,
                                    completed = true
                                })

                                local myServerId = GetPlayerServerId(PlayerId())
                                local finishPosition = 0
                                for idx, racer in ipairs(racePositions) do
                                    if racer.source == myServerId then
                                        finishPosition = idx
                                        break
                                    end
                                end

                                local totalRaceTime = (GetGameTimer() - raceStartTime) / 1000

                                SendNUIMessage(BuildRaceFinishPayload(totalRaceTime, finishPosition))
                                SendNUIMessage({ action = "close" })
                                raceStarted = false

                                resetVehicleHandling(veh)

                                TriggerServerEvent('frkn-racing:finish', currentRaceId, racePositions, false)

                            else
                                currentCheckpoint = 1
                                currentGroupIndex = 1
                                SetAllCheckpoints()

                                if FRKN.RaceLineSettings.enabled then
                                    if not FRKN.RaceLineSettings.formulaOnly or (raceType and raceType:lower() == "formula") then
                                        local firstCP = racecheckpoints[1]
                                        targetCoords = GetGroundPoint(vector3(firstCP.pos.x, firstCP.pos.y, firstCP.pos.z))
                                        isLineActive = true
                                        CalculateArrows()
                                    end
                                end
                            end
                        else
                            local nextCheckpoint = racecheckpoints[currentCheckpoint]
                            SetNewWaypoint(nextCheckpoint.pos.x, nextCheckpoint.pos.y)
                        end
                    end

                    if GetDistanceBetweenCoords(playerCoords, vector3(cpData.pos.x, cpData.pos.y, cpData.pos.z), true) > 15.0 then
                        lapJustFinished = false
                    end

                    local lapElapsed = math.floor((GetGameTimer() - lapStartTime) / 1000)
                    local remain = 0

                    if raceStartTime and raceTimeLimit then
                        local elapsed = math.floor((GetGameTimer() - raceStartTime) / 1000)
                        remain = raceTimeLimit - elapsed
                        if remain < 0 then remain = 0 end
                    end

                    local lapTimeRemaining = raceLimit and ((raceLimit / totalLaps) - lapElapsed) or 0

                    local myServerId = GetPlayerServerId(PlayerId())
                    local myPosition = 0

                    for index, racer in ipairs(racePositions) do
                        if racer.source == myServerId then
                            myPosition = index
                            break
                        end
                    end

                    if raceStarted and GetGameTimer() - lastNUIUpdate >= 1000 then
                        SendNUIMessage({
                            action = "updateRaceData",
                            time = remain,
                            lapTime = lapElapsed,
                            lapTimeRemaining = lapTimeRemaining,
                            lap = currentLap,
                            totalLaps = totalLaps,
                            currentCheckpoint = currentCheckpoint,
                            totalCheckpoints = #racecheckpoints,
                            bestLapTime = bestLapTime,
                            lastLapTime = lastLapTime,
                            checkpointTime = checkpointTime,
                            groupedCheckpointTimes = groupedCheckpointTimes,
                            racePositions = racePositions,
                            myAlias = cacheData['alias'][identifier],
                            driftScore = driftScore,
                            totalDriftScore = totalDriftScore,
                            isDrifting = isDrifting,
                            highestDriftScore = highestDriftScore,
                            currentGear = Drift.currentGear, 
                            raceType = raceType,
                            myPosition = myPosition,
                            totalRacers = #racePositions
                        })
                        lastNUIUpdate = GetGameTimer()
                    end

                    if GetGameTimer() - lastServerUpdate >= 1000 and racecheckpoints then
                        local cpPos = racecheckpoints[currentCheckpoint] and racecheckpoints[currentCheckpoint].pos
                        local distToNext = cpPos and GetDistanceBetweenCoords(playerCoords, vector3(cpPos.x, cpPos.y, cpPos.z), true) or 9999.0

                        TriggerServerEvent('frkn-racing:updatePlayerPosition', {
                            raceId = currentRaceId,
                            lap = currentLap,
                            checkpoint = currentCheckpoint,
                            checkpointTime = checkpointTime,
                            totalCheckpoints = racecheckpoints and #racecheckpoints or 0,
                            bestLapTime = bestLapTime,
                            distanceToNext = distToNext,
                            carName = currentCarName(),
                            carTransmission = getRandomTransmission(),
                            carType = getCarType(veh),
                            carPlate = getVehiclePlate(veh),
                            carTurbo = determineCarCustomization(getCarPowerByType(getCarType(veh))),
                            totalDriftScore = totalDriftScore,
                            raceType = raceType,
                            hasDrifted = true
                        })
                        lastServerUpdate = GetGameTimer()
                    end
                end
            end
        end)

        if FRKN.DisqualifySystem.enabled then
            Citizen.CreateThread(function()
                local disqualifyTimer = FRKN.DisqualifySystem.time
                while raceStarted do
                    Citizen.Wait(1000)
                    local playerPed = PlayerPedId()
                    if not IsPedInAnyVehicle(playerPed, false) then
                        if not countdownActive then
                            countdownActive = true
                            Notify(Lang:t('general.notify_incar'))
                        end
                        disqualifyTimer = disqualifyTimer - 1
                        if disqualifyTimer <= 0 then
                            TriggerServerEvent('frkn-racing:disqualify', currentRaceId)
                            local upperType = raceType and string.upper(raceType) or ""
                            resetVehicleHandling(GetVehiclePedIsIn(PlayerPedId(), false))
                            ResetRaceState()
                            Notify(Lang:t('general.notify_disqualified'))
                            
                            if (upperType == "FORMULA" or upperType == "PLANE" or upperType == "JETSKI") and preRacePosition then
                                DoScreenFadeOut(200)
                                while not IsScreenFadedOut() do Wait(0) end
                                local ped = PlayerPedId()
                                local veh = GetVehiclePedIsIn(ped, false)
                                if veh ~= 0 then
                                    TaskLeaveVehicle(ped, veh, 16)
                                    Wait(500)
                                    DeleteVehicle(veh)
                                    spawnedRaceVehicle = nil
                                end
                                SetEntityCoords(ped, preRacePosition.x, preRacePosition.y, preRacePosition.z, false, false, false, true)
                                SetEntityHeading(ped, preRacePosition.h)
                                Wait(300)
                                DoScreenFadeIn(1000)
                                while not IsScreenFadedIn() do Wait(0) end
                            end
                            TriggerServerEvent('frkn-racing:clearPreRacePosition')
                            preRacePosition = nil
                        end
                    else
                        countdownActive = false
                        disqualifyTimer = FRKN.DisqualifySystem.time
                    end
                end
            end)
        end
        
        if forceFPP then
            forceFPPRunning = true

            Citizen.CreateThread(function()
                SetFollowVehicleCamViewMode(4)
            
                while raceStarted and forceFPPRunning do
                    Citizen.Wait(0)
                    DisableControlAction(0, 0, true)
                end
            end)
        end
    end
end)

RegisterNetEvent('frkn-racing:positionsUpdated')
AddEventHandler('frkn-racing:positionsUpdated', function(raceId, players)
    racePositions = players
end)

RegisterNUICallback('placeBet', function(data, cb)
    TriggerCallback('frkn-racing:placeBet', function(call)
        cb(call)
    end, data.raceId, data.playerId, data.betAmount)
end)

RegisterNUICallback('withdrawBets', function(data, cb)
    TriggerCallback('frkn-racing:withdrawBets', function(call)
        cb(call)
    end,data.betIds)
end)

RegisterNUICallback('getBets', function(data, cb)
    cb(cacheData['bets'] or {})
end)

RegisterNUICallback('getAlias', function(data, cb)
    cb(cacheData['alias'] or {})
end)
RegisterNUICallback('startRace', function(data, cb)
    local raceId = tonumber(data.id)

    local currentRaceType = nil
    for _, v in pairs(cacheData) do
        if v.races then
            for _, r in pairs(v.races) do
                if r and tonumber(r.id) == raceId and r.type then
                    currentRaceType = r.type:lower()
                    break
                end
            end
        end
        if currentRaceType then break end
    end

    if currentRaceType and (currentRaceType == "car" or currentRaceType == "motorcycle" or currentRaceType == "bike" or currentRaceType == "drift") then
        local ped = PlayerPedId()
        local veh = GetVehiclePedIsIn(ped, false)
        if veh == 0 then
            cb({ type = "error", header = Lang:t('general.header_error'), message = Lang:t('general.must_be_in_car') })
            return
        end
        local vehClass = GetVehicleClass(veh)
        if currentRaceType == "motorcycle" or currentRaceType == "bike" then
            if vehClass ~= 8 then
                cb({ type = "error", header = Lang:t('general.header_error'), message = Lang:t('general.must_be_on_motorcycle') })
                return
            end
        else
            if vehClass == 8 or vehClass == 14 or vehClass == 15 or vehClass == 16 then
                cb({ type = "error", header = Lang:t('general.header_error'), message = Lang:t('general.must_be_in_car') })
                return
            end
        end
    end

    TriggerCallback('frkn-racing:start', function(call)
        cb(call)

        if call.type == "success" then
            SetNuiFocus(false, false)

            tablet = false

            if tabletObject and DoesEntityExist(tabletObject) then
                DeleteEntity(tabletObject)
                tabletObject = nil
            end
        end
    end, data.id)
end)


local raceStart, raceLimit

RegisterNetEvent('frkn-racing:timeSync')
AddEventHandler('frkn-racing:timeSync', function(raceId, startTime, timeLimit)
    raceStart = startTime
    raceLimit = timeLimit
end)

function CleanupRaceVisuals()
    isLineActive = false
    targetCoords = nil
    arrows = {}

    for _, objs in pairs(checkpointObjects) do
        if objs.left and DoesEntityExist(objs.left) then DeleteEntity(objs.left) end
        if objs.right and DoesEntityExist(objs.right) then DeleteEntity(objs.right) end
    end
    checkpointObjects = {}

    for i, blip in pairs(blips) do
        if DoesBlipExist(blip) then RemoveBlip(blip) end
    end
    blips = {}

    for serverId, blip in pairs(racerBlips) do
        if DoesBlipExist(blip) then RemoveBlip(blip) end
    end
    racerBlips = {}

    driftScore = 0
    totalDriftScore = 0
    isDrifting = false
    raceInfoPanel.active = false
end

function ResetRaceState()
    CleanupRaceVisuals()
    ClearAllBlips()
    clearCreationBlips()
    cleanupCreation()

    raceStarted = false
    currentRaceId = nil
    racecheckpoints = nil
    totalLaps = 1
    currentLap = 1
    currentCheckpoint = 1
    currentGroupIndex = 1
    racePositions = {}
    racerspeds = {}
    racePlayers = {}
    groupedCheckpointTimes = {}
    checkpointTime = 0
    lastCheckpointPos = nil
    lastPlayerCoords = nil
    bestLapTime = nil
    lastLapTime = nil
    raceStartTime = 0
    lapStartTime = 0
    raceTimeLimit = nil
    raceStart = nil
    raceLimit = nil

    showPosition = false
    collision = false
    forceFPP = "No"
    forceFPPRunning = false
    checkpointControl = nil
    countdownActive = false

    if raceStartBlip and DoesBlipExist(raceStartBlip) then
        RemoveBlip(raceStartBlip)
    end
    raceStartBlip = nil
    raceStartMarkerCoords = nil

    if autoRaceBlip and DoesBlipExist(autoRaceBlip) then
        SetBlipRoute(autoRaceBlip, false)
        RemoveBlip(autoRaceBlip)
    end
    autoRaceBlip = nil

    for _, object in ipairs(createdObjects) do
        if DoesEntityExist(object) then
            DeleteObject(object)
        end
    end
    createdObjects = {}

    SendNUIMessage({ action = "close" })
    SendNUIMessage({ action = "hideAutoRacePanel" })

    FRKN.HudClose()
end

RegisterNUICallback('getPlayerGarage', function(data, cb)
    TriggerCallback('frkn-racing:getPlayerGarage', function(vehicles)
        if vehicles and vehicles.vehicles then
            for _, v in ipairs(vehicles.vehicles) do
                local model = v.model
                if model then
                    local modelNum = tonumber(model)
                    if modelNum then
                        local displayName = GetDisplayNameFromVehicleModel(modelNum)
                        if displayName and displayName ~= "" and displayName ~= "CARNOTFOUND" then
                            v.model = string.lower(displayName)
                        else
                            v.model = tostring(modelNum)
                        end
                    end
                end
            end
        end
        cb(vehicles)
    end)
end)

RegisterNUICallback('selectGarageCar', function(data, cb)
    TriggerCallback('frkn-racing:selectGarageCar', function(call)
        cb(call)
    end, data.plate)
end)

RegisterNUICallback('joinRace', function(data, cb)
    data.id = tonumber(data.id)

    local rType = ""
    for _, race in pairs(cacheData or {}) do
        if type(race) ~= "table" or not race.id then goto continue_joinType end
        if tonumber(race.id) == data.id then
            local races = race.races
            if type(races) == "string" then races = json.decode(races) end
            for _, r in pairs(races or {}) do
                if type(r) == "table" and r.type then
                    rType = string.upper(r.type)
                end
            end
            break
        end
        ::continue_joinType::
    end

    if rType ~= "FORMULA" and rType ~= "PLANE" and rType ~= "JETSKI" then
        local ped = PlayerPedId()
        local veh = GetVehiclePedIsIn(ped, false)
        if veh == 0 then
            cb({
                type = "error",
                header = Lang:t('general.header_error'),
                message = Lang:t('general.must_be_in_vehicle_create')
            })
            return
        end
        local vehClass = GetVehicleClass(veh)
        if rType == "MOTORCYCLE" or rType == "BIKE" then
            if vehClass ~= 8 then
                cb({
                    type = "error",
                    header = Lang:t('general.header_error'),
                    message = Lang:t('general.must_be_on_motorcycle')
                })
                return
            end
        else
            if vehClass == 8 or vehClass == 14 or vehClass == 15 or vehClass == 16 then
                cb({
                    type = "error",
                    header = Lang:t('general.header_error'),
                    message = Lang:t('general.must_be_in_car')
                })
                return
            end
        end
    end
    TriggerCallback('frkn-racing:join', function(call)
        if call.type == "success" then
            local trackIdToFetch = nil
            for _, race in pairs(cacheData or {}) do
                if type(race) ~= "table" or not race.id then goto continue_joinTrack end
                if tonumber(race.id) == data.id then
                    trackIdToFetch = race.track_id
                    break
                end
                ::continue_joinTrack::
            end
            
            if trackIdToFetch then
                TriggerCallback('frkn-racing:getTrackCheckpoints', function(fetchedCheckpoints)
                    racecheckpoints = fetchedCheckpoints or {}
                    if fetchedCheckpoints and fetchedCheckpoints[1] and fetchedCheckpoints[1].pos then
                        local startCP = fetchedCheckpoints[1]
                                if raceStartBlip and DoesBlipExist(raceStartBlip) then
                                    RemoveBlip(raceStartBlip)
                                end
                                raceStartBlip = AddBlipForCoord(startCP.pos.x, startCP.pos.y, startCP.pos.z)
                                SetBlipSprite(raceStartBlip, 315)
                                SetBlipDisplay(raceStartBlip, 4)
                                SetBlipScale(raceStartBlip, 1.2)
                                SetBlipColour(raceStartBlip, 47)
                                SetBlipAsShortRange(raceStartBlip, false)
                                SetBlipRoute(raceStartBlip, true)
                                SetBlipRouteColour(raceStartBlip, 47)
                                BeginTextCommandSetBlipName("STRING")
                                AddTextComponentString("YARIS BASLANGIC")
                                EndTextCommandSetBlipName(raceStartBlip)

                                local markerPos = vector3(startCP.pos.x, startCP.pos.y, startCP.pos.z)
                                raceStartMarkerCoords = markerPos
                                local skipMarker = raceType and (raceType:lower() == "formula" or raceType:lower() == "jetski")
                                if not skipMarker and not raceStartMarkerThread then
                                    raceStartMarkerThread = true
                                    CreateThread(function()
                                        while raceStartMarkerCoords do
                                            Wait(0)
                                            local mc = raceStartMarkerCoords
                                            if not mc then break end
                                            DrawMarker(4, mc.x, mc.y, mc.z + 1.0, 0, 0, 0, 0, 0, 0, 7.0, 7.0, 7.0, 0, 255, 0, 200, false, true, 2, false, nil, nil, false)

                                            local playerCoords = GetEntityCoords(PlayerPedId())
                                            local distToMarker = #(playerCoords - mc)

                                            if distToMarker < 100.0 then
                                                local textZ = mc.z + 2.5
                                                SetTextScale(0.45, 0.45)
                                                SetTextFont(4)
                                                SetTextProportional(true)
                                                SetTextColour(40, 200, 255, 220)
                                                SetTextDropShadow(0, 0, 0, 0, 255)
                                                SetTextEdge(2, 0, 0, 0, 200)
                                                SetTextOutline()
                                                SetTextCentre(true)
                                                SetDrawOrigin(mc.x, mc.y, textZ, 0)
                                                BeginTextCommandDisplayText("STRING")
                                                AddTextComponentSubstringPlayerName(Lang:t('general.race_start_marker_text'))
                                                EndTextCommandDisplayText(0.0, 0.0)
                                                ClearDrawOrigin()
                                            end
                                        end
                                        raceStartMarkerThread = false
                                    end)
                            end
                        end
                    end, tonumber(trackIdToFetch))
            end
        end
        cb(call)
    end, data.id, data.password)
end)

RegisterNetEvent('frkn-racing:client:refreshLobby')
AddEventHandler('frkn-racing:client:refreshLobby', function(raceId)
    SendNUIMessage({
        action = "refreshLobby",
        id = tonumber(raceId)
    })
end)

RegisterNUICallback('leaveRace', function(data, cb)
    data.id = tonumber(data.id)
    local savedRaceType = raceType and string.upper(raceType) or ""
    local savedPreRacePosition = preRacePosition
    TriggerCallback('frkn-racing:leave', function(call)
        cb(call)
    end, data.id,data.identifier,data.type)
    SetNuiFocus(false, false)
    tablet = false
    ResetRaceState()

    if (savedRaceType == "FORMULA" or savedRaceType == "PLANE" or savedRaceType == "JETSKI") and savedPreRacePosition then
        DoScreenFadeOut(200)
        while not IsScreenFadedOut() do Wait(0) end
        local ped = PlayerPedId()
        local veh = GetVehiclePedIsIn(ped, false)
        if veh ~= 0 then
            TaskLeaveVehicle(ped, veh, 16)
            Wait(500)
            DeleteVehicle(veh)
            spawnedRaceVehicle = nil
        end
        SetEntityCoords(ped, savedPreRacePosition.x, savedPreRacePosition.y, savedPreRacePosition.z, false, false, false, true)
        SetEntityHeading(ped, savedPreRacePosition.h)
        Wait(300)
        DoScreenFadeIn(1000)
        while not IsScreenFadedIn() do Wait(0) end
    end
    TriggerServerEvent('frkn-racing:clearPreRacePosition')
    preRacePosition = nil
end)

RegisterNUICallback('endRace', function(data, cb)
    local savedRaceType = raceType and string.upper(raceType) or ""
    for k, race in pairs(cacheData) do
        if type(race) == "table" and race.id and tonumber(race.id) == tonumber(data.id) then
            cacheData[k] = nil
            break
        end
    end
    TriggerCallback('frkn-racing:delete', function(call)
        cb(call)
        SetNuiFocus(false, false)
        tablet = false
        local savedPreRacePosition = preRacePosition
        resetVehicleHandling(GetVehiclePedIsIn(PlayerPedId(), false))
        ResetRaceState()

        if (savedRaceType == "FORMULA" or savedRaceType == "PLANE" or savedRaceType == "JETSKI") and savedPreRacePosition then
            DoScreenFadeOut(200)
            while not IsScreenFadedOut() do Wait(0) end
            local ped = PlayerPedId()
            local veh = GetVehiclePedIsIn(ped, false)
            if veh ~= 0 then
                TaskLeaveVehicle(ped, veh, 16)
                Wait(500)
                DeleteVehicle(veh)
                spawnedRaceVehicle = nil
            end
            SetEntityCoords(ped, savedPreRacePosition.x, savedPreRacePosition.y, savedPreRacePosition.z, false, false, false, true)
            SetEntityHeading(ped, savedPreRacePosition.h)
            Wait(300)
            DoScreenFadeIn(1000)
            while not IsScreenFadedIn() do Wait(0) end
        end
        TriggerServerEvent('frkn-racing:clearPreRacePosition')
        preRacePosition = nil
    end, data.id)
end)


RegisterNUICallback('deleteRace', function(data, cb)
    for k, race in pairs(cacheData) do
        if type(race) == "table" and race.id and tonumber(race.id) == tonumber(data.id) then
            cacheData[k] = nil
            break
        end
    end
    TriggerCallback('frkn-racing:delete', function(call)
        cb(call)
        ResetRaceState()
    end, data.id)
end)


RegisterNUICallback('racepreview', function(data)
    ClearAllBlips()
    local trackIdToFetch = nil
    for _, race in pairs(cacheData) do
        if type(race) ~= "table" or not race.id then goto continue_preview end
        if tonumber(race.id) == tonumber(data.id) then
            trackIdToFetch = race.track_id
            break
        end
        ::continue_preview::
    end

    if trackIdToFetch then
        TriggerCallback('frkn-racing:getTrackCheckpoints', function(fetchedCheckpoints)
            if not fetchedCheckpoints then return end
            racecheckpoints = fetchedCheckpoints
            checkpointsPerGroup = math.ceil(#racecheckpoints / 4)
            for i = 1, 4 do
                table.insert(groupedCheckpointTimes, {groupIndex = i, totalTime = 0})
            end

            for i, checkpoint in ipairs(racecheckpoints) do
                local blip = AddBlipForCoord(checkpoint.pos.x, checkpoint.pos.y, checkpoint.pos.z)
                SetBlipSprite(blip, 1)
                SetBlipDisplay(blip, 4)
                SetBlipScale(blip, 1.0)
                SetBlipColour(blip, 3)
                SetBlipAsShortRange(blip, true)
                SetBlipFlashes(blip, true)
                BeginTextCommandSetBlipName("STRING")
                AddTextComponentString(tostring(i))
                EndTextCommandSetBlipName(blip)
                table.insert(blips, blip)
            end

            Wait(5000)
            ClearAllBlips()
        end, tonumber(trackIdToFetch))
    end
end)

RegisterNUICallback('setTrackGPS', function(data, cb)
    local trackId = tonumber(data.trackId)
    if not trackId then
        cb({ header = "Error", message = "Failed to set GPS. Please try again.", type = "error" })
        return
    end

    TriggerCallback('frkn-racing:getTrackCheckpoints', function(checkpoints)
        if checkpoints and checkpoints[1] and checkpoints[1].pos then
            local coords = checkpoints[1].pos
            SetNewWaypoint(coords.x, coords.y)

            local previewBlips = {}
            for i, cp in ipairs(checkpoints) do
                local blip = AddBlipForCoord(cp.pos.x, cp.pos.y, cp.pos.z)
                SetBlipSprite(blip, 1)
                SetBlipDisplay(blip, 4)
                SetBlipScale(blip, 0.8)
                SetBlipColour(blip, 3)
                SetBlipAsShortRange(blip, true)
                SetBlipFlashes(blip, true)
                BeginTextCommandSetBlipName("STRING")
                AddTextComponentString(tostring(i))
                EndTextCommandSetBlipName(blip)
                previewBlips[#previewBlips + 1] = blip
            end

            CreateThread(function()
                Wait(10000)
                for _, blip in ipairs(previewBlips) do
                    if DoesBlipExist(blip) then
                        RemoveBlip(blip)
                    end
                end
            end)

            cb({ header = "GPS Set", message = "GPS has been set to the first checkpoint of the track.", type = "success" })
        else
            cb({ header = "Error", message = "Failed to set GPS. Please try again.", type = "error" })
        end
    end, trackId)
end)

RegisterNUICallback('setTracksPreview', function(data, cb)
    ClearAllBlips()

    local trackId = tonumber(data.trackId)
    local trackCheckpoints = nil

    TriggerCallback('frkn-racing:getTrackCheckpoints', function(checkpoints)
        trackCheckpoints = checkpoints
        if not trackCheckpoints or #trackCheckpoints == 0 then
            cb({
                header = "Error",
                message = "No checkpoints found for this track.",
                type = "error",
            })
            return
        end

        for i, checkpoint in ipairs(trackCheckpoints) do
        local blip = AddBlipForCoord(checkpoint.pos.x, checkpoint.pos.y, checkpoint.pos.z)
        SetBlipSprite(blip, 1)
        SetBlipDisplay(blip, 4)
        SetBlipScale(blip, 1.0)
        SetBlipColour(blip, 3)
        SetBlipAsShortRange(blip, false)
        SetBlipFlashes(blip, true)

        BeginTextCommandSetBlipName("STRING")
        AddTextComponentString("Checkpoint " .. tostring(i))
        EndTextCommandSetBlipName(blip)

        table.insert(blips, blip)

        if i == 1 then
            SetNewWaypoint(checkpoint.pos.x, checkpoint.pos.y)
        end
    end

    CreateThread(function()
        Wait(30000)
        ClearAllBlips()
    end)

    cb({
            header = "Track Preview",
            message = "Track preview has been set.",
            type = "success",
        })
    end, trackId)
end)


RegisterNUICallback('setGPS', function(data, cb)
    local id = tonumber(data.id)
    local trackIdForGPS = nil

    for _, race in pairs(cacheData or {}) do
        if type(race) ~= "table" or not race.id then goto continue_gps end
        if tonumber(race.id) == id then
            trackIdForGPS = race.track_id
            break
        end
    ::continue_gps::
    end

    if trackIdForGPS then
        TriggerCallback('frkn-racing:getTrackCheckpoints', function(checkpoints)
            if checkpoints and checkpoints[1] and checkpoints[1].pos then
                local firstPos = checkpoints[1].pos
                SetNewWaypoint(firstPos.x, firstPos.y)
                if cb then cb({ok=true}) end
            else
                if cb then cb({ok=false}) end
            end
        end, tonumber(trackIdForGPS))
    else
        if cb then cb({ok=false}) end
    end
end)

RegisterNUICallback('createRace', function(data, cb)
    data.id = tonumber(data.id)
    local myTrack = filterTrackCache(data.trackId) 

    if not myTrack or not myTrack.track_data then
        cb({
            type = "error",
            header = Lang:t('general.track_error_header'),
            message = Lang:t('general.track_error_message')
        })
        return 
    end

    local rType = data.type and string.upper(data.type) or ""
    if rType ~= "FORMULA" and rType ~= "PLANE" and rType ~= "JETSKI" then
        local ped = PlayerPedId()
        local veh = GetVehiclePedIsIn(ped, false)
        if veh == 0 then
            cb({
                type = "error",
                header = Lang:t('general.header_error'),
                message = Lang:t('general.must_be_in_vehicle_create')
            })
            return
        end
        local vehClass = GetVehicleClass(veh)
        if rType == "MOTORCYCLE" or rType == "BIKE" then
            if vehClass ~= 8 then
                cb({
                    type = "error",
                    header = Lang:t('general.header_error'),
                    message = Lang:t('general.must_be_on_motorcycle')
                })
                return
            end
        else
            if vehClass == 8 or vehClass == 14 or vehClass == 15 or vehClass == 16 then
                cb({
                    type = "error",
                    header = Lang:t('general.header_error'),
                    message = Lang:t('general.must_be_in_car')
                })
                return
            end
        end
    end

    TriggerCallback('frkn-racing:getTrackCheckpoints', function(fetchedCheckpoints)
    local raceData = {
        id = data.id,
        trackId = data.trackId,
        eventName = data.eventName,
        vehicleClass = data.vehicleClass,
        prizeType = data.prizeType,
        buyIn = tonumber(data.participationFee),
        laps = tonumber(data.laps),
        countdownStart = tonumber(data.countdown),
        raceTime = tonumber(data.raceTime) * 60,
        password = data.password,
        maxPlayers = tonumber(data.maxParticipants),
        reverseControls = data.reverseControls,
        showPosition = data.showPosition,
        collision = data.collisions,
        forceFPP = data.forceFPP,
        enableAlerts = data.enableAlerts,
        type = data.type,
        checkpoints = fetchedCheckpoints,       
        distance = myTrack.track_data.distance,  
    }

    TriggerCallback('frkn-racing:create', function(call)
        cb(call)

        if call.type == "success" and fetchedCheckpoints and #fetchedCheckpoints > 0 then
            local startCP = fetchedCheckpoints[1]
            if startCP and startCP.pos then
                if raceStartBlip and DoesBlipExist(raceStartBlip) then
                    RemoveBlip(raceStartBlip)
                end
                raceStartBlip = AddBlipForCoord(startCP.pos.x, startCP.pos.y, startCP.pos.z)
                SetBlipSprite(raceStartBlip, 315)
                SetBlipDisplay(raceStartBlip, 4)
                SetBlipScale(raceStartBlip, 1.2)
                SetBlipColour(raceStartBlip, 47)
                SetBlipAsShortRange(raceStartBlip, false)
                SetBlipRoute(raceStartBlip, true)
                SetBlipRouteColour(raceStartBlip, 47)
                BeginTextCommandSetBlipName("STRING")
                AddTextComponentString("YARIS BASLANGIC")
                EndTextCommandSetBlipName(raceStartBlip)

                local markerPos = vector3(startCP.pos.x, startCP.pos.y, startCP.pos.z)
                raceStartMarkerCoords = markerPos
                local skipMarker = raceType and (raceType:lower() == "formula" or raceType:lower() == "jetski")
                if not skipMarker and not raceStartMarkerThread then
                    raceStartMarkerThread = true
                    CreateThread(function()
                        while raceStartMarkerCoords do
                            Wait(0)
                            local mc = raceStartMarkerCoords
                            if not mc then break end
                            DrawMarker(4, mc.x, mc.y, mc.z + 1.0, 0, 0, 0, 0, 0, 0, 7.0, 7.0, 7.0, 0, 255, 0, 200, false, true, 2, false, nil, nil, false)
                            local playerCoords = GetEntityCoords(PlayerPedId())
                            local distToMarker = #(playerCoords - mc)
                            if distToMarker < 100.0 then
                                local textZ = mc.z + 2.5
                                SetTextScale(0.45, 0.45)
                                SetTextFont(4)
                                SetTextProportional(true)
                                SetTextColour(40, 200, 255, 220)
                                SetTextDropShadow(0, 0, 0, 0, 255)
                                SetTextEdge(2, 0, 0, 0, 200)
                                SetTextOutline()
                                SetTextCentre(true)
                                SetDrawOrigin(mc.x, mc.y, textZ, 0)
                                BeginTextCommandDisplayText("STRING")
                                AddTextComponentSubstringPlayerName(Lang:t('general.race_start_marker_text'))
                                EndTextCommandDisplayText(0.0, 0.0)
                                ClearDrawOrigin()
                            end
                        end
                        raceStartMarkerThread = false
                    end)
                end
            end
        end
    end, raceData)
        
        removeCheckpoint()
        clearCreationBlips()
    end, data.trackId)
end)


RegisterNUICallback('getRaces', function(data, cb)
    local racesData = {}
    for k, v in pairs(cacheData) do
        if type(v.races) == "table" and next(v.races) ~= nil then
            for _, race in pairs(v.races) do
                table.insert(racesData, race)
            end
        end
    end

    local racesList = {}

    for _, raceData in pairs(racesData) do 
        local players = raceData.players or {}
        local buyIn = raceData.buyIn or 0
        local prize = #players * buyIn

        for _, player in ipairs(players) do
            local aliasInfo = cacheData.alias and cacheData.alias[player.identifier]
            if aliasInfo then
                player.alias = aliasInfo.alias
                player.ratingData = aliasInfo.ratingData
                player.extraData = aliasInfo.data
            end
        end

        table.insert(racesList, {
            id = raceData.id,
            eventName = raceData.eventName,
            type = raceData.type,
            buyIn = raceData.buyIn,
            laps = raceData.laps,
            maxPlayers = raceData.maxPlayers,
            vehicleClass = raceData.vehicleClass,
            forceFPP = raceData.forceFPP,
            creator = raceData.creator,
            identifier = raceData.identifier,
            password = raceData.password,
            countdownStart = raceData.countdownStart,
            raceTime = raceData.raceTime,
            distance = raceData.distance,
            completed = raceData.completed,
            reverse = raceData.reverse,
            collision = raceData.collision,
            showPosition = raceData.showPosition,
            createTime = raceData.createTime,
            players = players,
            raceResult = raceData.raceResult,
            checkpoints = raceData.checkpoints,
            creatorName = raceData.creatorName,
            prize = prize,
            isAutoRace = raceData.isAutoRace or false,
            duration = raceData.duration,
            startTime = raceData.startTime
        })
    end

    cb(racesList)
end)


RegisterNUICallback('getRacesByTrackId', function(data, cb)
    local trackId = tonumber(data.trackId)
    local racesData = {}

    for _, v in pairs(cacheData) do
        if tonumber(v.id) == trackId and type(v.races) == "table" and next(v.races) ~= nil then
            for _, race in pairs(v.races) do
                table.insert(racesData, race)
            end
        end
    end

    local racesList = {}

    for _, raceData in pairs(racesData) do 
        local players = raceData.players or {}
        local buyIn = raceData.buyIn or 0
        local prize = #players * buyIn

        table.insert(racesList, {
            id = raceData.id,
            eventName = raceData.eventName,
            type = raceData.type,
            buyIn = raceData.buyIn,
            laps = raceData.laps,
            maxPlayers = raceData.maxPlayers,
            vehicleClass = raceData.vehicleClass,
            forceFPP = raceData.forceFPP,
            creator = raceData.creator,
            identifier = raceData.identifier,
            password = raceData.password,
            countdownStart = raceData.countdownStart,
            raceTime = raceData.raceTime,
            distance = raceData.distance,
            completed = raceData.completed,
            reverse = raceData.reverse,
            collision = raceData.collision,
            showPosition = raceData.showPosition,
            createTime = raceData.createTime,
            players = raceData.players,
            raceResult = raceData.raceResult,
            checkpoints = raceData.checkpoints,
            creatorName = raceData.creatorName,
            prize = prize
        })
    end

    cb(racesList)
end)


RegisterNUICallback('getTracks', function(data, cb)
    local tracks = cacheData['tracks']
    local trackList = {}
    for i, v in ipairs(tracks) do
        local trackData = v.track_data or {}
        table.insert(trackList, {
            checkpoints = v.checkpoints,
            name = trackData.name,
            type = trackData.type,
            laps = trackData.laps,
            description = trackData.description,
            creator = trackData.creator,
            time = trackData.createTime,
            name = trackData.eventName,
            identifier = v.identifier,
            id = v.id
        })
    end
    cb(trackList)
end)

RegisterNUICallback('deleteTrack', function(data, cb)
    local trackId = tonumber(data.id)
    if not trackId then
        cb({ type = "error", header = "Error", message = "Invalid track ID" })
        return
    end
    TriggerCallback('frkn-racing:deleteTrack', function(response)
        if response and response.type == "success" then
            for i, track in ipairs(cacheData['tracks'] or {}) do
                if tonumber(track.id) == trackId then
                    table.remove(cacheData['tracks'], i)
                    break
                end
            end
        end
        cb(response)
    end, trackId)
end)

RegisterNUICallback('claimReward', function(data, cb)
    TriggerCallback('frkn-racing:claimReward', function(response)

        response.inventoryPath = FRKN.InventoryImagePath  
        if response.type == "error" then
            cb(response)
            return
        end
        if response.reward and response.reward.type == "car" then
            local carModel = response.reward.carModel

            local plate = SpawnRewardVehicle(carModel)

            TriggerServerEvent("frkn-racing:reward:addVehicleToDB", {
                model = carModel,
                plate = plate
            }) 
        end

        cb(response)

    end, data.id)
end)




function SpawnRewardVehicle(modelName)
    local model = joaat(modelName)

    RequestModel(model)
    while not HasModelLoaded(model) do Wait(0) end

    local ped = PlayerPedId()
    local coords = GetEntityCoords(ped)
    local heading = GetEntityHeading(ped)

    local plate = ("RW".. math.random(10000,99999))

    local veh = CreateVehicle(model, coords.x, coords.y, coords.z, heading, true, false)

    SetVehicleNumberPlateText(veh, plate)
    SetEntityAsMissionEntity(veh, true, true)
    SetVehicleOnGroundProperly(veh)
    TaskWarpPedIntoVehicle(ped, veh, -1)

    SetModelAsNoLongerNeeded(model)

    return plate
end

RegisterNetEvent('frkn-racing:notifyPlayerByCid')
AddEventHandler('frkn-racing:notifyPlayerByCid', function(notification)
    Notify(notification.message, notification.type, notification.header)
end)

RegisterNetEvent('frkn-racing:altNotify')
AddEventHandler('frkn-racing:altNotify', function(notification)
    SendNUIMessage({
        action = "showNotification",
        message = notification.message,
        type = notification.type,
        header = notification.header,
        duration = notification.duration or nil
    })
end)

RegisterNUICallback('getCrews', function(data, cb)
    TriggerCallback('frkn-racingv2:getCrews', function(result)
        cb(result)
    end, {})
end)

RegisterNUICallback('requestCrewJoin', function(data, cb)
    local crewId = tonumber(data.crew_id)
    local player = PlayerPedId()

    TriggerCallback('frkn-racingv2:requestCrewJoin', function(result)
        cb(result)
    end, { crew_id = crewId })
end)

RegisterNUICallback('denyCrewRequest', function(data, cb)
    TriggerServerEvent('frkn-racingv2:denyCrewRequest', data)
    cb({})
end)

RegisterNUICallback('acceptCrewRequest', function(data, cb)
    local cid = data.cid

    TriggerCallback('frkn-racingv2:acceptCrewRequest', function(result)
        cb(result)
    end, { cid = cid })
end)

RegisterNetEvent('frkn-racing:crewChatUpdate')
AddEventHandler('frkn-racing:crewChatUpdate', function(crewId, messages)
    SendNUIMessage({
        action = "crewChatUpdate",
        messages = messages
    })
end)

RegisterNUICallback('sendCrewMessage', function(data, cb)
    local message = data.message

    TriggerCallback('frkn-racing:sendCrewMessage', function(response)
        cb(response)
    end, message)
end)

RegisterNUICallback('sendBetsMessage', function(data, cb)
    local message = data.message

    TriggerCallback('frkn-racing:sendBetsMessage', function(response)
        cb(response)
    end, message)
end)

RegisterNUICallback('getChatMessages', function(data, cb)
    cb(cacheData['chat'] or {})
end)

RegisterNetEvent('frkn-racing:chatUpdate', function(newMsg)
    SendNUIMessage({
        action = "chatUpdate",
        messages = newMsg
    })
end)

RegisterNUICallback('deleteCrew', function(data, cb)
    local crewId = data.id

    TriggerCallback('frkn-racingv2:deleteCrew', function(response)
        cb(response)
    end, crewId)
end)

RegisterNUICallback('kickMember', function(data, cb)
    local crewId = data.crewId
    local memberId = data.memberId

    TriggerCallback('frkn-racing:kickMember', function(response)
        cb(response)
    end, crewId, memberId)
end)

RegisterNUICallback('changeName', function(data, cb)
    local name = data.name
    cacheData['alias'][identifier] = name
    TriggerServerEvent('frkn-racing:changeName', name)
end)

RegisterNUICallback('changeAvatar',function(data,cb)
    local avatar = data.avatar
    TriggerServerEvent('frkn-racing:changeAvatar', avatar)
end)

RegisterNUICallback('changeColor',function(data,cb)
    TriggerServerEvent('frkn-racing:changeColor', data)
end)

RegisterNUICallback('closeTablet', function(data, cb)
    SetNuiFocus(false, false)
    tablet = false

    local ped = PlayerPedId()

    if tabletObject then
        DeleteEntity(tabletObject)
        tabletObject = nil
    end

    if creating then
        cancelRaceCreation()
        if trackType == "PLANE" then
            resetPlayerFromPlaneMode()
        end
    end

    if cb then cb() end
end)

RegisterNUICallback('createTrack', function(data, cb)
    local playerPed = PlayerPedId()
    local vehicle = GetVehiclePedIsIn(playerPed, false)

    trackType = data.selectedMode
    SetNuiFocus(false, false)
    if data.selectedMode == "PLANE" then
        cb({
            success = true,
            message = "Track creation started.",
            header = "Success",
            type = "success"
        })

        creating = true
        local noclipSpeed = 2.0
        startCoords = GetEntityCoords(playerPed)

        SetEntityInvincible(playerPed, true)
        SetEntityVisible(playerPed, true, false)
        SetEntityCollision(playerPed, false, false)
        FreezeEntityPosition(playerPed, false)

        CreateThread(function()
            while creating do
                local pos = GetEntityCoords(playerPed)
                local camRot = GetGameplayCamRot(2)
                local camHeading = math.rad(camRot.z)
                local camPitch = math.rad(camRot.x)

                local direction = vector3(
                    -math.sin(camHeading) * math.cos(camPitch),
                     math.cos(camHeading) * math.cos(camPitch),
                     math.sin(camPitch)
                )

                if IsControlPressed(0, 32) then
                    pos = pos + direction * noclipSpeed
                end
                if IsControlPressed(0, 33) then
                    pos = pos - direction * noclipSpeed
                end

                SetEntityCoordsNoOffset(playerPed, pos.x, pos.y, pos.z, true, true, true)
                Wait(0)
            end
        end)

        startRaceCreation({
            name = data.name,
            selectedMode = trackType,
            laps = data.laps,
            description = data.description
        })

        return
    end

    if not IsPedInAnyVehicle(playerPed, false) then
        SetNuiFocus(true, true)
        cb({
            success = false,
            message = "You must be inside a vehicle to create a track.",
            header = "Vehicle Required",
            type = "error"
        })
        return
    end

    cb({
        success = true,
        message = "Track creation started.",
        header = "Success",
        type = "success"
    })

    TriggerEvent('frkn-racing:cmd:racecreate', data)
end)

RegisterNUICallback('createCrew', function(data, cb)
    TriggerCallback('frkn-racing:createCrew', function(result)
        cb(result)
    end, data.crew_name, data.crew_description)
end)

RegisterNUICallback('deleteTrack',function(data,cb)
    TriggerCallback('frkn-racing:deleteTrack', function(call)
        cb(call)
    end, data.id)
end)

RegisterNUICallback('finishTrack', function(data, cb)
    raceName = data.trackName
    raceDescription = data.trackDesc
    TriggerEvent('frkn-racing:cmd:racecreatedone')
    if trackType == "PLANE" then
        resetPlayerFromPlaneMode()
    end
    Notify(Lang:t('general.track_saved_select'))
end)

RegisterNetEvent('frkn-racing:trackCreated')
AddEventHandler('frkn-racing:trackCreated', function(trackId)
    SendNUIMessage({
        action = "autoSelectTrack",
        trackId = trackId
    })
end)

RegisterNUICallback('cancelTrack', function(data, cb)
    TriggerEvent('frkn-racing:cmd:racecreatecancel')

    SetNuiFocus(false, false)

    tablet = false

    if tabletObject then
        DeleteEntity(tabletObject)
        tabletObject = nil
    end

    if trackType == "PLANE" then
        resetPlayerFromPlaneMode()
    end

    if cb then cb() end
end)

RegisterNUICallback('getVehicleClass', function(data, cb)
    local ped = PlayerPedId()
    local veh = GetVehiclePedIsIn(ped, false)
    if veh == 0 then
        cb({ class = "NONE", inVehicle = false, vehicleType = "none" })
        return
    end
    local classId = GetVehicleClass(veh)
    local classMap = {
        [0] = "D", -- Compacts
        [1] = "D", -- Sedans
        [2] = "C", -- SUVs
        [3] = "C", -- Coupes
        [4] = "B", -- Muscle
        [5] = "A", -- Sports Classics
        [6] = "A", -- Sports
        [7] = "S", -- Super
        [8] = "D", -- Motorcycles
        [9] = "C", -- Off-road
        [10] = "D", -- Industrial
        [11] = "D", -- Utility
        [12] = "D", -- Vans
        [13] = "D", -- Cycles
        [14] = "D", -- Boats
        [15] = "D", -- Helicopters
        [16] = "D", -- Planes
        [17] = "D", -- Service
        [18] = "D", -- Emergency
        [19] = "D", -- Military
        [20] = "D", -- Commercial
        [21] = "D", -- Trains
        [22] = "X", -- Open Wheel (Formula)
    }

    local typeMap = {
        [8] = "motorcycle",
        [13] = "motorcycle", -- Cycles
        [14] = "jetski",     -- Boats
        [15] = "airplane",   -- Helicopters
        [16] = "airplane",   -- Planes
        [22] = "formula",    -- Open Wheel
    }
    local classLetter = classMap[classId] or "D"
    local vehicleType = typeMap[classId] or "car"
    cb({ class = classLetter, inVehicle = true, vehicleType = vehicleType })
end)

RegisterNetEvent("frkn-racing:cmd:racecreate")
AddEventHandler("frkn-racing:cmd:racecreate", function(options)
    if GetVehiclePedIsIn(PlayerPedId(), false) ~= 0 then
        startRaceCreation(options)
    end
end)

RegisterNetEvent("frkn-racing:cmd:racecreatedone")
AddEventHandler("frkn-racing:cmd:racecreatedone", function()
    finishRaceCreation()
end)

RegisterNetEvent("frkn-racing:cmd:racecreatecancel")
AddEventHandler("frkn-racing:cmd:racecreatecancel", function()
    cancelRaceCreation()
end)

AddEventHandler("onResourceStop", function(resource)
    if resource ~= GetCurrentResourceName() then
        return
    end
    
    if tabletObject then
        DeleteEntity(tabletObject)
        tabletObject = nil
    end

    if spawnedRaceVehicle and DoesEntityExist(spawnedRaceVehicle) then
        local ped = PlayerPedId()
        if IsPedInVehicle(ped, spawnedRaceVehicle, false) then
            TaskLeaveVehicle(ped, spawnedRaceVehicle, 16)
        end
        SetEntityAsMissionEntity(spawnedRaceVehicle, true, true)
        DeleteVehicle(spawnedRaceVehicle)
        DeleteEntity(spawnedRaceVehicle)
        spawnedRaceVehicle = nil
    end

    if preRacePosition then
        local ped = PlayerPedId()
        SetEntityCoords(ped, preRacePosition.x, preRacePosition.y, preRacePosition.z, false, false, false, false)
        SetEntityHeading(ped, preRacePosition.h)
        TriggerServerEvent('frkn-racing:clearPreRacePosition')
        preRacePosition = nil
    end

    cleanupCreation()
    cleanupTablet()
    CleanupRaceVisuals()

    raceStarted = false
    raceThreadActive = false
    currentRaceId = nil
    raceType = nil
    countdownActive = false
    racecheckpoints = nil
    raceStartMarkerCoords = nil
    if raceStartBlip and DoesBlipExist(raceStartBlip) then
        RemoveBlip(raceStartBlip)
        raceStartBlip = nil
    end
end)

RegisterNetEvent('frkn-racing:notify')
AddEventHandler('frkn-racing:notify', function(msg)
    Notify(msg)
end)

RegisterNetEvent('frkn-racing:finished')
AddEventHandler('frkn-racing:finished', function(success)

    EnableControlAction(0, 0, true)
    SetFollowVehicleCamViewMode(0)
    SetNuiFocus(false, false)
    tablet = false

    local savedRaceType = raceType and string.upper(raceType) or ""
    local savedPreRacePosition = preRacePosition
    resetVehicleHandling(GetVehiclePedIsIn(PlayerPedId(), false))
    ResetRaceState()

    if success then
        Notify(Lang:t('general.notify_raceover'))
    elseif success == 'none' then
    else
        Notify(Lang:t('general.notify_raceovertime'))
    end

    if (savedRaceType == "FORMULA" or savedRaceType == "PLANE" or savedRaceType == "JETSKI") and savedPreRacePosition then
        DoScreenFadeOut(200)
        while not IsScreenFadedOut() do Wait(0) end
        local ped = PlayerPedId()
        local veh = GetVehiclePedIsIn(ped, false)
        if veh ~= 0 then
            TaskLeaveVehicle(ped, veh, 16)
            Wait(500)
            DeleteVehicle(veh)
            spawnedRaceVehicle = nil
        end
        SetEntityCoords(ped, savedPreRacePosition.x, savedPreRacePosition.y, savedPreRacePosition.z, false, false, false, true)
        SetEntityHeading(ped, savedPreRacePosition.h)
        Wait(300)
        DoScreenFadeIn(1000)
        while not IsScreenFadedIn() do Wait(0) end
    end
    TriggerServerEvent('frkn-racing:clearPreRacePosition')
    preRacePosition = nil

end)

RegisterNetEvent('frkn-racing:disqualified')
AddEventHandler('frkn-racing:disqualified', function(msg)
    local savedRaceType = raceType and string.upper(raceType) or ""
    local savedPreRacePosition = preRacePosition
    resetVehicleHandling(GetVehiclePedIsIn(PlayerPedId(), false))
    cleanupObjects()
    ResetRaceState()
    SetNuiFocus(false, false)
    tablet = false
    
    if (savedRaceType == "FORMULA" or savedRaceType == "PLANE" or savedRaceType == "JETSKI") and savedPreRacePosition then
        DoScreenFadeOut(200)
        while not IsScreenFadedOut() do Wait(0) end
        local ped = PlayerPedId()
        local veh = GetVehiclePedIsIn(ped, false)
        if veh ~= 0 then
            TaskLeaveVehicle(ped, veh, 16)
            Wait(500)
            DeleteVehicle(veh)
            spawnedRaceVehicle = nil
        end
        SetEntityCoords(ped, savedPreRacePosition.x, savedPreRacePosition.y, savedPreRacePosition.z, false, false, false, true)
        SetEntityHeading(ped, savedPreRacePosition.h)
        Wait(300)
        DoScreenFadeIn(1000)
        while not IsScreenFadedIn() do Wait(0) end
    end
    TriggerServerEvent('frkn-racing:clearPreRacePosition')
    preRacePosition = nil
    
    Notify(msg)
end)

RegisterNetEvent('frkn-racing:setStartGPS')
AddEventHandler('frkn-racing:setStartGPS', function(coords)
    if raceStartBlip and DoesBlipExist(raceStartBlip) then
        RemoveBlip(raceStartBlip)
    end
    raceStartBlip = AddBlipForCoord(coords.x, coords.y, coords.z)
    SetBlipSprite(raceStartBlip, 315)
    SetBlipColour(raceStartBlip, 1)
    SetBlipScale(raceStartBlip, 1.2)
    SetBlipRoute(raceStartBlip, true)
    SetBlipRouteColour(raceStartBlip, 1)
    BeginTextCommandSetBlipName("STRING")
    AddTextComponentString("Race Start")
    EndTextCommandSetBlipName(raceStartBlip)
    SetTimeout(30000, function()
        if raceStartBlip and DoesBlipExist(raceStartBlip) then
            RemoveBlip(raceStartBlip)
            raceStartBlip = nil
        end
    end)
end)


function StartRace()
    SetAllCheckpoints()
end

RegisterNUICallback('tabletAppBootstrap', function(_, cb)
    if not FRKN.UseTabletApp then
        cb({ disabled = true })
        return
    end

    local aliases = cacheData and cacheData['alias'] or {}
    if aliases and aliases[identifier] then
        cb(buildTabletUiPayload())
        return
    end

    TriggerCallback('frkn-racing:requestAlias', function(result)
        if type(result) == 'table' then
            cacheData = result
        end
        cb(buildTabletUiPayload())
    end, identifier)
end)

exports('IsTabletAppEnabled', function()
    return FRKN.UseTabletApp == true
end)

function SetAllCheckpoints()
    ClearAllBlips()

    if not racecheckpoints or #racecheckpoints == 0 then
        return 
    end

    groupedCheckpointTimes = {}
    checkpointsPerGroup = math.ceil(#racecheckpoints / 4)

    for i = 1, 4 do
        table.insert(groupedCheckpointTimes, {
            groupIndex = i,
            totalTime = 0
        })
    end

    local colorHex = "#cccccc"
    for _, race in pairs(cacheData or {}) do
        if type(race) ~= "table" or not race.id then goto continue_color end
        if tonumber(race.id) == tonumber(currentRaceId) then
            local races = race.races
            if type(races) == "string" then races = json.decode(races) end
            for _, r in pairs(races or {}) do
                if type(r) == "table" and r.players then
                    local playerData = r.players or {}
                    for _, p in pairs(playerData) do
                        if tonumber(p.source) == GetPlayerServerId(PlayerId()) or p.identifier == identifier then
                            if p.alias and p.alias.data and p.alias.data.checkpointcolor then
                                colorHex = p.alias.data.checkpointcolor
                            elseif p.aliasData and p.aliasData.data and p.aliasData.data.checkpointcolor then
                                colorHex = p.aliasData.data.checkpointcolor
                            end
                            break
                        end
                    end
                end
            end
            break
        end
        ::continue_color::
    end

    local blipColorId = colorHexToBlipId[string.lower(colorHex)] or 3

    for i, checkpoint in ipairs(racecheckpoints) do
        local blip = AddBlipForCoord(
                        checkpoint.pos.x,
                        checkpoint.pos.y,
                        checkpoint.pos.z
                    )

                    SetBlipSprite(blip, 1)
                    SetBlipDisplay(blip, 4)
                    SetBlipScale(blip, 0.85)
                    SetBlipColour(blip, blipColorId)
                    SetBlipAsShortRange(blip, true)
                    SetBlipFlashes(blip, true)
                    ShowNumberOnBlip(blip, i)

                    table.insert(blips, blip)

                    if raceType ~= "PLANE" and checkpoint.prop then
                    local cpobject = checkpoint.prop
                    RequestModelAndLoad(cpobject)

                    local leftPos = vector3(
                        checkpoint.leftObjPos.x,
                        checkpoint.leftObjPos.y,
                        checkpoint.leftObjPos.z
                    )

                    local rightPos = vector3(
                        checkpoint.rightObjPos.x,
                        checkpoint.rightObjPos.y,
                        checkpoint.rightObjPos.z
                    )

                    local leftZ = leftPos.z
                    local rightZ = rightPos.z

                    if raceType == "JETSKI" then
                        local waterZLeft = getWaterZ(leftPos.x, leftPos.y)
                        local waterZRight = getWaterZ(rightPos.x, rightPos.y)

                        if waterZLeft then leftZ = waterZLeft end
                        if waterZRight then rightZ = waterZRight end
                    end

                    local leftObject = CreateObjectNoOffset(
                        cpobject,
                        leftPos.x,
                        leftPos.y,
                        leftZ,
                        false, false, false
                    )

                    local rightObject = CreateObjectNoOffset(
                        cpobject,
                        rightPos.x,
                        rightPos.y,
                        rightZ,
                        false, false, false
                    )

                    if raceType ~= "JETSKI" then
                        PlaceObjectOnGroundProperly(leftObject)
                        PlaceObjectOnGroundProperly(rightObject)
                    end

                    SetEntityCollision(leftObject, false, false)
                    SetEntityCollision(rightObject, false, false)

                    SetModelAsNoLongerNeeded(cpobject)

                    table.insert(createdObjects, leftObject)
                    table.insert(createdObjects, rightObject)

                    checkpointObjects[i] = {
                        left = leftObject,
                        right = rightObject
                    }
                    end 
                end

                if #racecheckpoints > 0 then
                    local first = racecheckpoints[1]
                    SetNewWaypoint(first.pos.x, first.pos.y)
                    lastCheckpointPos = racecheckpoints[#racecheckpoints].pos
                end
end

function ClearAllBlips()
    for i, blip in ipairs(blips) do
        RemoveBlip(blip)
    end
    for _, obj in ipairs(createdObjects) do
        if DoesEntityExist(obj) then
            DeleteObject(obj)
        end
    end
    blips = {}
    createdObjects = {}
    checkpointObjects = {}

    raceThreadActive = false  
end

function changeHeight(dir)
    local step = 0.25

    if dir == "up" then
        heightOffset = heightOffset + step
    elseif dir == "down" then
        heightOffset = heightOffset - step
    end
end

function getWaterZ(x, y)
    local found, waterZ = GetWaterHeight(x, y)
    if found then
        return waterZ
    end
    return nil
end

function startRaceCreation(options)
    options = options or {}
    raceName = options.name or "Unnamed"
    raceType = options.selectedMode or "Lap"
    raceMinLaps = options.laps or 1
    raceDescription = options.description or "No description provided."
    creating = true

    spawnObjects(true)
    CreateThread(function()
        while creating do
            if IsControlPressed(0, 172) then
                changeRadius("up")
            end
            if IsControlPressed(0, 173) then
                changeRadius("down")
            end
            if IsControlPressed(0, 174) then
                if raceType == "JETSKI" then
                    changeHeight("down")
                else
                    if GetEntitySpeed(GetVehiclePedIsIn(PlayerPedId(), false)) <= 0 then
                        changeRotation("left")
                    end
                end
            end

            if IsControlPressed(0, 175) then
                if raceType == "JETSKI" then
                    changeHeight("up")
                else
                    if GetEntitySpeed(GetVehiclePedIsIn(PlayerPedId(), false)) <= 0 then
                        changeRotation("right")
                    end
                end
            end

            if not IsControlPressed(0, 21) and IsControlJustPressed(0, 51) then
                addCheckpoint()
            end
            if IsControlPressed(0, 21) and IsControlJustPressed(0, 51) then
                removeCheckpoint()
            end

            if IsControlJustPressed(0, 137) then
                propIndex = (propIndex % #FRKN.propList) + 1
                FlagProp = FRKN.propList[propIndex]
                spawnObjects(true, FlagProp)
            
                SendNUIMessage({
                    action = "setActiveProp",
                    index = propIndex,
                    prop = FlagProp
                })
            end

            if IsControlJustPressed(0, 191) then
                if #checkpoints == 0 then
                    Notify(Lang:t('general.no_checkpoints_added'))
                else
                    cleanupObjects()
                    openTabletUI()
                    Citizen.SetTimeout(500, function()
                        SendNUIMessage({ action = "autoSaveTrack" })
                    end)
                end
            end

            if IsControlJustPressed(0, 200) then
                SendNUIMessage({
                    action = "closeTrackPage"
                })
                SetNuiFocus(false, false)
                tablet = false
                cancelRaceCreation()
                if trackType == "PLANE" then
                    resetPlayerFromPlaneMode()
                end
                Notify(Lang:t('general.track_cancelled'))
            end

            Wait(0)
        end
    end)

    CreateThread(function()
        local ped = PlayerPedId()
        while creating do
            local pos = GetEntityCoords(ped)
            local rot = GetEntityHeading(PlayerPedId())

            DrawMarker(
                26,
                pos.x,
                pos.y,
                pos.z + 1.0 + heightOffset,
                0.0, 0.0, 0.0,
                0.0, 0.0, rot,
                radius * 2,
                radius * 2,
                5.0,
                255, 128, 0, 25,
                false, false, 2,
                nil, nil, false
            )

            if raceType ~= "PLANE" then
                updateObjects()
            end

            Wait(0)
        end
    end)
end

function updateObjects()
    if object1 == nil or object2 == nil then
        return
    end

    local plyPed = PlayerPedId()
    local coords = GetEntityCoords(plyPed)
    local heading = GetEntityHeading(plyPed)
    local objPos1, objPos2 = getCheckpointObjectPositions(coords, radius, heading)

    if raceType == "JETSKI" then
        local waterZ1 = getWaterZ(objPos1.x, objPos1.y)
        local waterZ2 = getWaterZ(objPos2.x, objPos2.y)

        if waterZ1 then
            SetEntityCoordsNoOffset(
                object1,
                objPos1.x,
                objPos1.y,
                waterZ1 + heightOffset,
                true, true, true
            )
        end

        if waterZ2 then
            SetEntityCoordsNoOffset(
                object2,
                objPos2.x,
                objPos2.y,
                waterZ2 + heightOffset,
                true, true, true
            )
        end
    else
        local zOffset = heightOffset or 0.0

        SetEntityCoordsNoOffset(object1, objPos1.x, objPos1.y, objPos1.z + zOffset, true, true, true)
        SetEntityCoordsNoOffset(object2, objPos2.x, objPos2.y, objPos2.z + zOffset, true, true, true)

        PlaceObjectOnGroundProperly(object1)
        PlaceObjectOnGroundProperly(object2)
    end

    SetEntityHeading(object1, heading)
    SetEntityHeading(object2, heading + 180.0)
end

function spawnObjects(start , prop)
    if object1 ~= nil then
        cleanupObjects() 
    end

    local cpobject = prop or FlagProp
    RequestModelAndLoad(cpobject)

    local plyPed = PlayerPedId()
    local coords = GetEntityCoords(plyPed)
    local heading = GetEntityHeading(plyPed)
    local objPos1, objPos2 = getCheckpointObjectPositions(coords, radius, heading)

    object1 = CreateObjectNoOffset(cpobject, objPos1, false, false, false)
    object2 = CreateObjectNoOffset(cpobject, objPos2, false, false, false)

    if raceType ~= "JETSKI" then
        PlaceObjectOnGroundProperly(object1)
        PlaceObjectOnGroundProperly(object2)
    end

    SetEntityCollision(object1, false, false)
    SetEntityCollision(object2, false, false)

    SetModelAsNoLongerNeeded(cpobject)
end

function Drift:GetGearInertia(gear)
    return self.gearRatios[gear] or 0.2
end

function Drift:Upshift()
    if self.currentGear < self.maxGear then
        self.currentGear = self.currentGear + 1
        self.currentRPM = self.currentRPM * 0.5
    else
        Notify(Lang:t('general.max_gear_reached'))
    end
end

function Drift:DownShift()
    if self.currentGear > 1 then
        self.currentGear = self.currentGear - 1
        self.currentRPM = math.min(self.currentRPM / 0.7, self.maxRPM)
    else
        Notify(Lang:t('general.min_gear_reached'))
    end
end

function Command:GetGearInertia(gear)
    return self.gearRatios[gear] or 0.2
end

function Command:Upshift()
    if self.currentGear < self.maxGear then
        self.currentGear = self.currentGear + 1
        self.currentRPM = self.currentRPM * 0.5
    else
        Notify(Lang:t('general.max_gear_reached'))
    end
end

function Command:DownShift()
    if self.currentGear > 1 then
        self.currentGear = self.currentGear - 1
        self.currentRPM = math.min(self.currentRPM / 0.7, self.maxRPM)
    else
        Notify(Lang:t('general.min_gear_reached'))
    end
end

function Command:CalculateSpeedLimits(veh)
    local handlingMaxSpeed = GetVehicleHandlingFloat(veh, 'CHandlingData', 'fInitialDriveMaxFlatVel')
    local step = handlingMaxSpeed / self.maxGear
    self.gearSpeedLimits = {}
    for i = 1, self.maxGear do
        self.gearSpeedLimits[i] = step * i * 1.98 
    end
end

function resetPlayerFromPlaneMode()
    local ped = PlayerPedId()
    creating = false

    if startCoords then
        SetEntityCoords(ped, startCoords.x, startCoords.y, startCoords.z, false, false, false, false)
    end

    SetEntityInvincible(ped, false)
    SetEntityVisible(ped, true, false)
    SetEntityCollision(ped, true, true)
    FreezeEntityPosition(ped, false)
    ResetEntityAlpha(ped)
end


function Dot(v1, v2)
    return v1.x * v2.x + v1.y * v2.y
end

function resetHandling(vehicle)
    local plate = getVehiclePlate(vehicle)
    local handling = storedHandling[plate]
    if handling then
        for k, v in pairs(handling) do
            SetVehicleHandlingFloat(vehicle, "CHandlingData", k, v)
        end
    end
end

function applyDriftHandling(vehicle)
    storeVehicleHandling(vehicle)

    SetVehicleHandlingFloat(vehicle, "CHandlingData", "fBrakeForce", 2.0)
    SetVehicleHandlingFloat(vehicle, "CHandlingData", "fBrakeBiasFront", 1.0)
    SetVehicleHandlingFloat(vehicle, "CHandlingData", "fHandBrakeForce", 6.7)

    SetVehicleHandlingFloat(vehicle, "CHandlingData", "fSteeringLock", 75.0)
    SetVehicleHandlingFloat(vehicle, "CHandlingData", "fTractionCurveMax", 1.2)
    SetVehicleHandlingFloat(vehicle, "CHandlingData", "fTractionCurveMin", 1.4)
    SetVehicleHandlingFloat(vehicle, "CHandlingData", "fLowSpeedTractionLossMult", 0.6)
    SetVehicleHandlingFloat(vehicle, "CHandlingData", "fInitialDriveForce", 0.32)
    SetVehicleHandlingFloat(vehicle, "CHandlingData", "fDriveInertia", 1.2)
    
    SetVehicleHandlingFloat(vehicle, "CHandlingData", "fTractionCurveLateral", 25.5)
    SetVehicleHandlingFloat(vehicle, "CHandlingData", "fLowSpeedTractionLossMult", 0.15)
    SetVehicleHandlingFloat(vehicle, "CHandlingData", "fTractionBiasFront", 0.45)
    SetVehicleHandlingFloat(vehicle, "CHandlingData", "fTractionLossMult", 1.0)

    SetVehicleHandlingFloat(vehicle, "CHandlingData", "fSuspensionForce", 2.9)
    SetVehicleHandlingFloat(vehicle, "CHandlingData", "fSuspensionCompDamp", 1.7)
    SetVehicleHandlingFloat(vehicle, "CHandlingData", "fSuspensionReboundDamp", 2.4)
    SetVehicleHandlingFloat(vehicle, "CHandlingData", "fSuspensionUpperLimit", 0.1)
    SetVehicleHandlingFloat(vehicle, "CHandlingData", "fSuspensionLowerLimit", -0.16)
    SetVehicleHandlingFloat(vehicle, "CHandlingData", "fSuspensionBiasFront", 0.45)

    SetVehicleHandlingFloat(vehicle, "CHandlingData", "fRollCentreHeightFront", 0.33)
    SetVehicleHandlingFloat(vehicle, "CHandlingData", "fRollCentreHeightRear", 0.33)

    SetVehicleHandlingFloat(vehicle, "CHandlingData", "fCollisionDamageMult", 0.7)
    SetVehicleHandlingFloat(vehicle, "CHandlingData", "fWeaponDamageMult", 1.0)
    SetVehicleHandlingFloat(vehicle, "CHandlingData", "fDeformationDamageMult", 0.7)
    SetVehicleHandlingFloat(vehicle, "CHandlingData", "fEngineDamageMult", 1.5)
    SetVehicleHandlingFloat(vehicle, "CHandlingData", "fPetrolTankVolume", 65.0)
    SetVehicleHandlingFloat(vehicle, "CHandlingData", "fOilVolume", 5.0)

end


function storeVehicleHandling(vehicle)
    local plate = getVehiclePlate(vehicle)
    if not storedHandling[plate] then
         storedHandling[plate] = {
            fInitialDriveForce = GetVehicleHandlingFloat(vehicle, "CHandlingData", "fInitialDriveForce"),
            fDriveInertia = GetVehicleHandlingFloat(vehicle, "CHandlingData", "fDriveInertia"),
            fBrakeForce = GetVehicleHandlingFloat(vehicle, "CHandlingData", "fBrakeForce"),
            fBrakeBiasFront = GetVehicleHandlingFloat(vehicle, "CHandlingData", "fBrakeBiasFront"),
            fHandBrakeForce = GetVehicleHandlingFloat(vehicle, "CHandlingData", "fHandBrakeForce"),

            fSteeringLock = GetVehicleHandlingFloat(vehicle, "CHandlingData", "fSteeringLock"),
            fTractionCurveMax = GetVehicleHandlingFloat(vehicle, "CHandlingData", "fTractionCurveMax"),
            fTractionCurveMin = GetVehicleHandlingFloat(vehicle, "CHandlingData", "fTractionCurveMin"),
            fTractionCurveLateral = GetVehicleHandlingFloat(vehicle, "CHandlingData", "fTractionCurveLateral"),
            fLowSpeedTractionLossMult = GetVehicleHandlingFloat(vehicle, "CHandlingData", "fLowSpeedTractionLossMult"),
            fTractionBiasFront = GetVehicleHandlingFloat(vehicle, "CHandlingData", "fTractionBiasFront"),
            fTractionLossMult = GetVehicleHandlingFloat(vehicle, "CHandlingData", "fTractionLossMult"),

            fSuspensionForce = GetVehicleHandlingFloat(vehicle, "CHandlingData", "fSuspensionForce"),
            fSuspensionCompDamp = GetVehicleHandlingFloat(vehicle, "CHandlingData", "fSuspensionCompDamp"),
            fSuspensionReboundDamp = GetVehicleHandlingFloat(vehicle, "CHandlingData", "fSuspensionReboundDamp"),
            fSuspensionUpperLimit = GetVehicleHandlingFloat(vehicle, "CHandlingData", "fSuspensionUpperLimit"),
            fSuspensionLowerLimit = GetVehicleHandlingFloat(vehicle, "CHandlingData", "fSuspensionLowerLimit"),
            fSuspensionBiasFront = GetVehicleHandlingFloat(vehicle, "CHandlingData", "fSuspensionBiasFront"),

            fRollCentreHeightFront = GetVehicleHandlingFloat(vehicle, "CHandlingData", "fRollCentreHeightFront"),
            fRollCentreHeightRear = GetVehicleHandlingFloat(vehicle, "CHandlingData", "fRollCentreHeightRear"),

            fCollisionDamageMult = GetVehicleHandlingFloat(vehicle, "CHandlingData", "fCollisionDamageMult"),
            fWeaponDamageMult = GetVehicleHandlingFloat(vehicle, "CHandlingData", "fWeaponDamageMult"),
            fDeformationDamageMult = GetVehicleHandlingFloat(vehicle, "CHandlingData", "fDeformationDamageMult"),
            fEngineDamageMult = GetVehicleHandlingFloat(vehicle, "CHandlingData", "fEngineDamageMult"),
            fPetrolTankVolume = GetVehicleHandlingFloat(vehicle, "CHandlingData", "fPetrolTankVolume"),
            fOilVolume = GetVehicleHandlingFloat(vehicle, "CHandlingData", "fOilVolume")
        }
    end
end

function resetVehicleHandling(vehicle)
    local plate = getVehiclePlate(vehicle)
    if storedHandling[plate] then
        for k, v in pairs(storedHandling[plate]) do
            SetVehicleHandlingFloat(vehicle, "CHandlingData", k, v)
        end
        driftMode[plate] = false
        storedHandling[plate] = nil
    end

    SetVehicleEnginePowerMultiplier(vehicle, 1.0)
    SetVehicleEngineTorqueMultiplier(vehicle, 1.0)
end


function changeRadius(dir)
    if dir == "up" then
        radius = radius + 0.1
    elseif dir == "down" then
        radius = math.max(radius - 0.1, 1.0)
    end
end

function changeRotation(dir)
    local veh = GetVehiclePedIsIn(PlayerPedId(), false)
    local head = GetEntityHeading(veh)
    if dir == "left" then
        SetEntityHeading(veh, head + 1.0)
    elseif dir == "right" then
        SetEntityHeading(veh, head - 1.0)
    end
end


function addCheckpoint()
    local pos = GetEntityCoords(PlayerPedId())
    local heading = GetEntityHeading(PlayerPedId())
    local leftObjPos, rightObjPos = getCheckpointObjectPositions(pos, radius, heading)
    local currentProp = FRKN.propList[propIndex]

    checkpoints[#checkpoints + 1] = {
        pos = {
            x = tonumber(string.format("%.3f", pos.x)),
            y = tonumber(string.format("%.3f", pos.y)),
            z = tonumber(string.format("%.3f", pos.z)),
        },
        hdg = tonumber(string.format("%.3f", heading)),
        rad = tonumber(string.format("%.3f", radius)),
        prop = currentProp,
        leftObjPos = {
            x = tonumber(string.format("%.3f", leftObjPos.x)),
            y = tonumber(string.format("%.3f", leftObjPos.y)),
            z = tonumber(string.format("%.3f", leftObjPos.z)),
        },
        rightObjPos = {
            x = tonumber(string.format("%.3f", rightObjPos.x)),
            y = tonumber(string.format("%.3f", rightObjPos.y)),
            z = tonumber(string.format("%.3f", rightObjPos.z)),
        }
    }

    PlaySound(-1, "3_2_1", "HUD_MINI_GAME_SOUNDSET", 0, 0, 1)

    if #checkpoints == 1 then
        spawnObjects(false)
    end

    RequestModelAndLoad(currentProp)
    local leftProp = CreateObjectNoOffset(currentProp, leftObjPos, false, false, false)
    PlaceObjectOnGroundProperly(leftProp)
    SetEntityHeading(leftProp, heading)
    SetEntityCollision(leftProp, false, false)
    SetEntityAsMissionEntity(leftProp, true, true)
    FreezeEntityPosition(leftProp, true)

    local rightProp = CreateObjectNoOffset(currentProp, rightObjPos, false, false, false)
    PlaceObjectOnGroundProperly(rightProp)
    SetEntityHeading(rightProp, heading + 180.0)
    SetEntityCollision(rightProp, false, false)
    SetEntityAsMissionEntity(rightProp, true, true)
    FreezeEntityPosition(rightProp, true)

    checkpointCreationProps[#checkpoints] = { left = leftProp, right = rightProp }

    local blip = AddBlipForCoord(pos)
    ShowNumberOnBlip(blip, #checkpoints)
    SetBlipDisplay(blip, 8)
    SetBlipScale(blip, 1.0)
    SetBlipAsShortRange(blip, true)
    blips[#blips + 1] = blip

    SendNUIMessage({
    action = "addCheckpoint",
    index = #checkpoints,
    x = pos.x,
    y = pos.y
    })

end


function removeCheckpoint()
    if #checkpoints == 0 then
        return
    end

    local removedIndex = #checkpoints
    checkpoints[removedIndex] = nil

    PlaySound(-1, "CHECKPOINT_NORMAL", "HUD_MINI_GAME_SOUNDSET", 0, 0, 1)

    local propPair = checkpointCreationProps[removedIndex]
    if propPair then
        if propPair.left and DoesEntityExist(propPair.left) then
            DeleteEntity(propPair.left)
        end
        if propPair.right and DoesEntityExist(propPair.right) then
            DeleteEntity(propPair.right)
        end
        checkpointCreationProps[removedIndex] = nil
    end

    if #checkpoints < 1 then
        spawnObjects(true)
    end

    RemoveBlip(blips[removedIndex])
    blips[removedIndex] = nil

    SendNUIMessage({
        action = "removeCheckpoint",
        index = removedIndex
    })

end

function clearCreationBlips()
    for i = 1, #blips do
        RemoveBlip(blips[i])
    end
    blips = {}
end



function RequestModelAndLoad(hash)
    RequestModel(hash)
    while not HasModelLoaded(hash) do
        Wait(0)
    end
end

function getCheckpointObjectPositions(origin, radius, heading)
    if heading == nil then heading = 0.0 end
    local leftObjPos = vector3(origin.x - radius, origin.y, origin.z)
    local rightObjPos = vector3(origin.x + radius, origin.y, origin.z)
    return rotate(origin, leftObjPos, heading), rotate(origin, rightObjPos, heading)
end

function rotate(origin, point, theta)
    if theta == 0.0 then return point end
    local p = point - origin
    local pX, pY = p.x, p.y
    theta = math.rad(theta)
    local cosTheta = math.cos(theta)
    local sinTheta = math.sin(theta)
    local x = pX * cosTheta - pY * sinTheta
    local y = pX * sinTheta + pY * cosTheta
    return vector3(x, y, 0.0) + origin
end

function DrawText3Ds(x, y, z, text)
    local onScreen, _x, _y = World3dToScreen2d(x, y, z)
    SetTextScale(0.35, 0.35)
    SetTextFont(4)
    SetTextProportional(1)
    SetTextColour(255, 255, 255, 215)
    SetTextEntry("STRING")
    SetTextCentre(true)
    AddTextComponentString(text)
    DrawText(_x, _y)
    local factor = (string.len(text)) / 340
    DrawRect(_x, _y + 0.0125, 0.015 + factor, 0.03, 41, 11, 41, 68)
end



function finishRaceCreation()
    if not creating then
        return
    end

    TriggerServerEvent("frkn-racing:recieveCreateData", raceName, raceType, raceMinLaps, checkpoints , raceDescription)
    cleanupCreation()
end

RegisterNetEvent("frkn-racing:client:getCarType", function(model, callbackUUID)
    local ped = PlayerPedId()
    local hash = GetHashKey(tostring(model))

    if not IsModelAVehicle(hash) then
        TriggerServerEvent("frkn-racing:returnCarType", callbackUUID, "non")
        return
    end

    RequestModel(hash)
    local timeout = 50
    while not HasModelLoaded(hash) and timeout > 0 do
        Wait(100)
        timeout = timeout - 1
    end

    if not HasModelLoaded(hash) then
        TriggerServerEvent("frkn-racing:returnCarType", callbackUUID, "non")
        return
    end

    local coords = GetEntityCoords(ped)

    local veh = CreateVehicle(hash, coords.x, coords.y, coords.z, 0.0, false, false)

    SetEntityVisible(veh, false, false)
    SetEntityCollision(veh, false, false)
    SetVehicleEngineOn(veh, false, true, false)
    FreezeEntityPosition(veh, true)

    local maxSpeed = GetVehicleHandlingFloat(veh, "CHandlingData", "fInitialDriveMaxFlatVel")

    local carType
    if maxSpeed >= 150.0 then
        carType = "x"
    elseif maxSpeed >= 120.0 then
        carType = "s"
    elseif maxSpeed >= 90.0 then
        carType = "a"
    elseif maxSpeed >= 60.0 then
        carType = "b"
    elseif maxSpeed >= 30.0 then
        carType = "c"
    else
        carType = "d"
    end

    TriggerServerEvent("frkn-racing:returnCarType", callbackUUID, carType)

    DeleteVehicle(veh)
end)


function getCarType(playerVehicle)
    local maxSpeed = GetVehicleHandlingFloat(playerVehicle, "CHandlingData", "fInitialDriveMaxFlatVel")
    local carType
    if maxSpeed >= 150.0 then
        carType = "x"
    elseif maxSpeed >= 120.0 then
        carType = "s"
    elseif maxSpeed >= 90.0 then
        carType = "a"
    elseif maxSpeed >= 60.0 then
        carType = "b"
    elseif maxSpeed >= 30.0 then
        carType = "c"
    else
        carType = "d"
    end

    return carType
end



function cancelRaceCreation()
    if not creating then
        return
    end

    cleanupCreation()
end

function cleanupObjects()
    if object1 then DeleteObject(object1) end
    if object2 then DeleteObject(object2) end
    object1, object2 = nil, nil
end

function cleanupCreation()
    creating = false
    radius = 4.0
    raceName = nil
    raceType = nil
    checkpoints = {}
    raceDescription = nil
    cleanupObjects()
    clearCreationBlips()

    for i, propPair in pairs(checkpointCreationProps) do
        if propPair.left and DoesEntityExist(propPair.left) then
            DeleteEntity(propPair.left)
        end
        if propPair.right and DoesEntityExist(propPair.right) then
            DeleteEntity(propPair.right)
        end
    end
    checkpointCreationProps = {}

    SendNUIMessage({ action = "clearCheckpoints" })
end


function filterTrackCache(id)
    local track = nil
    for k, v in pairs(cacheData['tracks']) do
        if tonumber(v.id) == tonumber(id) then
            track = v
        end
    end
    return track
end

function SetCollisions(_, bool)
    local userCar = GetVehiclePedIsIn(PlayerPedId(), false)
    if not userCar or userCar == 0 then return end

    for k,v in pairs(racerspeds) do
        local i = GetPlayerFromServerId(v)
        if i ~= -1 and i ~= PlayerId() then
            local ped = GetPlayerPed(i)
            if ped and DoesEntityExist(ped) then
                local veh = GetVehiclePedIsIn(ped, false)
                if veh and veh ~= 0 and DoesEntityExist(veh) and veh ~= userCar then
                    SetEntityNoCollisionEntity(userCar, veh, true)
                    SetEntityNoCollisionEntity(veh, userCar, true)
                end
            end
        end
    end
end


function currentCarName()
    local vehicle = GetVehiclePedIsIn(PlayerPedId(), false)
    local hash = GetEntityModel(vehicle)
    local name = GetDisplayNameFromVehicleModel(hash)
    return name
end

function getRandomTransmission()
    local transmissionTypes = {"Sequential", "Automatic"}
    local selectedTransmission = transmissionTypes[math.random(#transmissionTypes)]
    return selectedTransmission
end

function getCarPowerByType(carType)
    local minPower, maxPower

    if carType == "x" then
        minPower, maxPower = 1000, 1500
    elseif carType == "s" then
        minPower, maxPower = 700, 1000
    elseif carType == "a" then
        minPower, maxPower = 500, 700
    elseif carType == "b" then
        minPower, maxPower = 300, 500
    elseif carType == "c" then
        minPower, maxPower = 200, 300
    elseif carType == "d" then
        minPower, maxPower = 100, 200
    else
        minPower, maxPower = 100, 100
    end

    local carPower = math.random(minPower, maxPower)
    return carPower
end


function determineCarCustomization(carPower)
    if carPower > 130 then
        return "Custom"
    else
        return "Stock"
    end
end

function DrawCheckpointMarkerWithDistance(coords, distance, isNext, r, g, b) 
 
    if distance > 500.0 then return end 
 
    if isNext then 
        r, g, b = 255, 255, 255 
    end 
 
    if raceType == "PLANE" then
        local ringSize = 15.0
        local alpha = 180
        
        if isNext then
            alpha = 220
        else
            alpha = 120
            ringSize = 12.0
        end
        
        local ringRotX = 0.0
        local ringRotY = 90.0 
        local ringRotZ = 0.0
        
        if racecheckpoints and currentCheckpoint then
            local nextIdx = currentCheckpoint + 1
            if nextIdx <= #racecheckpoints then
                local nextCp = racecheckpoints[nextIdx]
                if nextCp then
                    local dx = nextCp.pos.x - coords.x
                    local dy = nextCp.pos.y - coords.y
                    ringRotZ = math.deg(math.atan(dx, dy))
                end
            end
        end
        
        local thickness = 0.3
        DrawMarker(
            1,  
            coords.x,
            coords.y,
            coords.z,
            0.0, 0.0, 0.0,
            ringRotX, ringRotY, ringRotZ,
            ringSize, ringSize, thickness,
            r, g, b, alpha,
            false,
            false,
            2,
            nil,
            nil,
            false
        )
        
        local innerSize = ringSize * 0.85
        DrawMarker(
            1,
            coords.x,
            coords.y,
            coords.z,
            0.0, 0.0, 0.0,
            ringRotX, ringRotY, ringRotZ,
            innerSize, innerSize, thickness + 0.1,
            0, 0, 0, 0,  
            false,
            false,
            2,
            nil,
            nil,
            false
        )
        
        DrawMarker(
            1,
            coords.x,
            coords.y,
            coords.z,
            0.0, 0.0, 0.0,
            ringRotX, ringRotY, ringRotZ,
            ringSize * 1.02, ringSize * 1.02, thickness * 0.5,
            r, g, b, math.floor(alpha * 0.4),
            false,
            false,
            2,
            nil,
            nil,
            false
        )
        
        local ratio = math.min(distance / 100.0, 1.0)
        local maxFontScale = 0.45
        local minFontScale = 0.30
        local fontRatio = 1.0 - ratio
        local dynamicScale = minFontScale + (maxFontScale - minFontScale) * fontRatio
        
        local textZ = coords.z + (ringSize * 0.5) + 2.0
        local distanceText = string.format("%dM", math.floor(distance))
        local checkpointText = "CHECKPOINT"
        local textCoords = vector3(coords.x, coords.y, textZ)
        
        DrawStyledText3DWithGradient(
            textCoords,
            distanceText,
            checkpointText,
            r, g, b,
            dynamicScale,
            4,
            true
        )
        return
    end
 
    local maxHeight = 30.0 
    local minHeight = 1.0 
    local ratio = math.min(distance / 100.0, 1.0) 
    local adjustedHeight = minHeight + (maxHeight - minHeight) * ratio 
 
    local maxFontScale = 0.35
    local minFontScale = 0.25
    local fontRatio = 1.0 - ratio 
    local dynamicScale = minFontScale + (maxFontScale - minFontScale) * fontRatio 
 
    local lineBottomZ
    
    if raceType == "JETSKI" then
        lineBottomZ = coords.z
    else
        local found, groundZ = GetGroundZFor_3dCoord(coords.x, coords.y, coords.z + 50.0, false) 
        if not found then 
            groundZ = coords.z 
        end 
        lineBottomZ = groundZ
    end
    
    local lineTopZ = lineBottomZ + adjustedHeight

    local thickness = 0.03
    for i = -2, 2 do 
        local offset = i * thickness 
        DrawLine( 
            coords.x + offset, 
            coords.y, 
            lineBottomZ, 
            coords.x + offset, 
            coords.y, 
            lineTopZ, 
            100, 150, 220, 200 
        ) 
    end 
 
    local minMarkerSize = 0.6 
    local maxMarkerSize = 1.8 
    local markerScale = minMarkerSize + (maxMarkerSize - minMarkerSize) * ratio 
 
    DrawMarker( 
        2, 
        coords.x, 
        coords.y, 
        lineTopZ + 0.25, 
        0.0, 0.0, 0.0, 
        0.0, 0.0, 0.0, 
        markerScale, 
        markerScale, 
        markerScale, 
        r, g, b, 220, 
        false, 
        false, 
        2, 
        nil, 
        nil, 
        false 
    ) 
 
    local minOffset = 1.5
    local maxOffset = 4.5
    local offsetRatio = math.min(distance / 100.0, 1.0) 
    local textOffsetAboveLine = minOffset + (maxOffset - minOffset) * offsetRatio 
 
    local textZ = lineTopZ + textOffsetAboveLine 
    
    local distanceText = string.format("%dM", math.floor(distance))
    
    local checkpointText = "CHECKPOINT"
    
    local textCoords = vector3(coords.x, coords.y, textZ) 
 
    DrawStyledText3DWithGradient( 
        textCoords, 
        distanceText,
        checkpointText,
        r, g, b, 
        dynamicScale, 
        4, 
        true 
    ) 
end 
 
function DrawStyledText3DWithGradient(coords, distanceText, checkpointText, r, g, b, scale, font, shadow) 
    local onScreen, _x, _y = World3dToScreen2d(coords.x, coords.y, coords.z) 
    if onScreen then 
        local bgWidth = 0.065
        local bgHeight = 0.045
        
        local gradientSteps = 15
        local stepHeight = bgHeight / gradientSteps
        
        for i = 0, gradientSteps - 1 do
            local progress = i / (gradientSteps - 1)
            
            local alpha = 255 - (progress * 175)
            
            local yPos = (_y - 0.020) - (bgHeight / 2) + (i * stepHeight) + (stepHeight / 2)
            
            DrawRect(_x, yPos, bgWidth, stepHeight + 0.001, 90, 150, 230, alpha)
        end
        
        local borderHeight = 0.0025
        DrawRect(_x, _y + 0.003, bgWidth, borderHeight, 100, 100, 100, 255)
        
        SetTextScale(scale * 2.2, scale * 2.2)  
        SetTextFont(0)  
        SetTextProportional(1)
        SetTextCentre(1)
        SetTextColour(255, 255, 255, 255)
        SetTextDropshadow(4, 0, 0, 0, 255)
        SetTextEdge(2, 0, 0, 0, 255)
        SetTextEntry("STRING")
        AddTextComponentString(distanceText)
        DrawText(_x, _y - 0.045)
        
        SetTextScale(scale * 0.85, scale * 0.85)  
        SetTextFont(0)
        SetTextProportional(0)  
        SetTextCentre(1)
        SetTextColour(180, 180, 180, 230)  
        SetTextEntry("STRING")
        AddTextComponentString(checkpointText)
        DrawText(_x, _y + 0.008)  
    end 
end


function DrawStyledText3D(coords, text, r, g, b, scale, font, shadow)
    local onScreen, _x, _y = World3dToScreen2d(coords.x, coords.y, coords.z)
    if onScreen then
        SetTextScale(scale, scale)
        SetTextFont(font)
        SetTextProportional(1)
        SetTextCentre(1)
        SetTextColour(r, g, b, 255)
        if shadow then SetTextDropShadow(2, 2, 2, 2, 255) end
        SetTextEntry("STRING")
        AddTextComponentString(text)
        DrawText(_x, _y)
    end
end





DisplayRadar(false)

function GetDistanceColor(dist)
    local green = {0, 255, 0}
    local yellow = {255, 255, 0}
    local orange = {255, 128, 0}
    local red = {255, 0, 0}
    
    if dist >= 70.0 then
        return green[1], green[2], green[3]
    elseif dist >= 50.0 then
        local t = (70.0 - dist) / 20.0
        return math.floor(green[1] + (yellow[1] - green[1]) * t),
               math.floor(green[2] + (yellow[2] - green[2]) * t),
               math.floor(green[3] + (yellow[3] - green[3]) * t)
    elseif dist >= 30.0 then
        local t = (50.0 - dist) / 20.0
        
        if t < 0.5 then
            local t2 = t * 2
            return math.floor(yellow[1] + (orange[1] - yellow[1]) * t2),
                   math.floor(yellow[2] + (orange[2] - yellow[2]) * t2),
                   math.floor(yellow[3] + (orange[3] - yellow[3]) * t2)
        else
            local t2 = (t - 0.5) * 2
            return math.floor(orange[1] + (red[1] - orange[1]) * t2),
                   math.floor(orange[2] + (red[2] - orange[2]) * t2),
                   math.floor(orange[3] + (red[3] - orange[3]) * t2)
        end
    else
        return red[1], red[2], red[3]
    end
end

function GetGroundPoint(pos)
    local success, groundZ = GetGroundZFor_3dCoord(pos.x, pos.y, pos.z + 999.0, false)
    if success then
        return vector3(pos.x, pos.y, groundZ + 0.03)
    end
    return pos
end

function CatmullRomSpline(p0, p1, p2, p3, t)
    local t2 = t * t
    local t3 = t2 * t
    
    local v0 = (p2 - p0) * 0.5
    local v1 = (p3 - p1) * 0.5
    
    return (2 * p1 - 2 * p2 + v0 + v1) * t3 +
           (-3 * p1 + 3 * p2 - 2 * v0 - v1) * t2 +
           v0 * t + p1
end

function LerpVector(a, b, t)
    return vector3(
        a.x + (b.x - a.x) * t,
        a.y + (b.y - a.y) * t,
        a.z + (b.z - a.z) * t
    )
end

function CalculateArrows()
    if not targetCoords or not racecheckpoints then return end
    
    arrows = {}

    local ped = PlayerPedId()
    local vehicle = GetVehiclePedIsIn(ped, false)
    if vehicle == 0 then return end
    
    local startPos = GetEntityCoords(vehicle)
    
    local currentCPIndex = currentCheckpoint or 1
    
    local distToTarget = #(startPos - targetCoords)
    if distToTarget < 15.0 and currentCPIndex >= #racecheckpoints then
        CalculateStraightArrows(startPos, targetCoords)
        return
    end
    
    local pathPoints = {}
    table.insert(pathPoints, startPos)
    
    local nextCheckpoints = {}
    for i = currentCPIndex, math.min(currentCPIndex + 2, #racecheckpoints) do
        local cp = racecheckpoints[i]
        if cp then
            table.insert(nextCheckpoints, vector3(cp.pos.x, cp.pos.y, cp.pos.z))
        end
    end
    
    if #nextCheckpoints < 2 then
        CalculateStraightArrows(startPos, targetCoords)
        return
    end
    
    local p0 = startPos
    local p1 = nextCheckpoints[1]
    local p2 = nextCheckpoints[2] or nextCheckpoints[1]
    local p3 = nextCheckpoints[3] or p2
    
    local segmentDist = #(p1 - p0)
    local segmentSteps = math.max(math.floor(segmentDist / FRKN.RaceLineSettings.arrowDistance), 1)
    
    for i = 1, segmentSteps do
        local t = i / segmentSteps
        local point = CatmullRomSpline(p0, p0, p1, p2, t)
        table.insert(pathPoints, point)
    end
    
    if #nextCheckpoints >= 2 then
        segmentDist = #(p2 - p1)
        segmentSteps = math.max(math.floor(segmentDist / FRKN.RaceLineSettings.arrowDistance), 1)
        
        for i = 1, segmentSteps do
            local t = i / segmentSteps
            local point = CatmullRomSpline(p0, p1, p2, p3, t)
            table.insert(pathPoints, point)
        end
    end
    
    for i = 2, #pathPoints do
        local current = GetGroundPoint(pathPoints[i])
        local previous = GetGroundPoint(pathPoints[i-1])
        
        local dx = current.x - previous.x
        local dy = current.y - previous.y
        local heading = math.atan2(dy, dx)
        
        arrows[#arrows + 1] = {
            pos = current,
            heading = heading,
        }
    end
end

function CalculateStraightArrows(startPos, endPos)
    arrows = {}
    
    local dx = endPos.x - startPos.x
    local dy = endPos.y - startPos.y
    local dz = endPos.z - startPos.z

    local distance = math.sqrt(dx*dx + dy*dy + dz*dz)
    local numArrows = math.max(math.floor(distance / FRKN.RaceLineSettings.arrowDistance), 1)

    local stepX = dx / numArrows
    local stepY = dy / numArrows
    local stepZ = dz / numArrows

    local heading = math.atan2(stepY, stepX)

    for i = 1, numArrows do
        local px = startPos.x + stepX * i
        local py = startPos.y + stepY * i
        local pz = startPos.z + stepZ * i

        local point = GetGroundPoint(vector3(px, py, pz))

        arrows[#arrows + 1] = {
            pos = point,
            heading = heading,
        }
    end
end

function DrawTriangle(pos, heading, size, r, g, b, a)
    local half = size * 0.5

    local A = vector3(pos.x + math.cos(heading) * size, pos.y + math.sin(heading) * size, pos.z)
    local B = vector3(pos.x + math.cos(heading + 2.4) * half, pos.y + math.sin(heading + 2.4) * half, pos.z)
    local C = vector3(pos.x + math.cos(heading - 2.4) * half, pos.y + math.sin(heading - 2.4) * half, pos.z)

    DrawPoly(A, B, C, r, g, b, a)
end

function DrawAllArrows()
    if not isLineActive then return end
    if #arrows == 0 then return end
    
    local ped = PlayerPedId()
    local veh = GetVehiclePedIsIn(ped, false)
    if veh == 0 then return end
    
    local vehiclePos = GetEntityCoords(veh)
    local distToTarget = #(vehiclePos - targetCoords)

    local r, g, b = GetDistanceColor(distToTarget)
    local alpha = 210

    for i = 1, #arrows do
        local a = arrows[i]
        DrawTriangle(a.pos, a.heading, 2.2, r, g, b, alpha)
    end
end


RegisterCommand('setraceline', function()
    local ped = PlayerPedId()
    local vehicle = GetVehiclePedIsIn(ped, false)

    if vehicle == 0 then
        return
    end
    
    local waypoint = GetFirstBlipInfoId(8)
    if not DoesBlipExist(waypoint) then
        return
    end
    
    local coords = GetBlipInfoIdCoord(waypoint)
    targetCoords = GetGroundPoint(coords)
    
    isLineActive = true
    CalculateArrows()
end)

RegisterCommand('stopraceline', function()
    isLineActive = false
    targetCoords = nil
    arrows = {}
end)

RegisterCommand('+toggleraceline', function()
    if isLineActive then
        ExecuteCommand('stopraceline')
    else
        ExecuteCommand('setraceline')
    end
end)

RegisterKeyMapping('+toggleraceline', 'Toggle Race Line', 'keyboard', 'F6')




local function teleportPlayer(coords)
    local ped = PlayerPedId()
    local entity = IsPedInAnyVehicle(ped, false) and GetVehiclePedIsIn(ped, false) or ped

    DoScreenFadeOut(300)
    while not IsScreenFadedOut() do Wait(0) end

    SetEntityCoords(entity, coords.x, coords.y, coords.z, false, false, false, true)
    SetEntityHeading(entity, coords.w)

    Wait(300)
    DoScreenFadeIn(300)
end

local function buildCityTargetOptions()
    local options = {}

    for _, data in pairs(FRKN.RacingNPC.cityCoords) do
        options[#options + 1] = {
            icon = FRKN.RacingNPC.target.icon,
            label = data.text,
            onSelect = function()
                teleportPlayer(data.coords)
            end,
            action = function()
                teleportPlayer(data.coords)
            end
        }
    end

    return options
end

racingNPC = nil
Citizen.CreateThread(function()
    if not FRKN.RacingNPC.enabled then return end

    local modelHash = GetHashKey(FRKN.RacingNPC.model)
    RequestModel(modelHash)
    while not HasModelLoaded(modelHash) do
        Wait(100)
    end

    racingNPC = CreatePed(
        4,
        modelHash,
        FRKN.RacingNPC.coords.x,
        FRKN.RacingNPC.coords.y,
        FRKN.RacingNPC.coords.z - 1.0,
        FRKN.RacingNPC.coords.w,
        false,
        true
    )

    SetEntityInvincible(racingNPC, true)
    SetBlockingOfNonTemporaryEvents(racingNPC, true)
    FreezeEntityPosition(racingNPC, true)
    SetPedCanRagdoll(racingNPC, false)
    SetPedCanBeTargetted(racingNPC, false)

    if FRKN.RacingNPC.scenario then
        TaskStartScenarioInPlace(racingNPC, FRKN.RacingNPC.scenario, 0, true)
    end

    if FRKN.RacingNPC.blip.enabled then
        local blip = AddBlipForCoord(
            FRKN.RacingNPC.coords.x,
            FRKN.RacingNPC.coords.y,
            FRKN.RacingNPC.coords.z
        )
        SetBlipSprite(blip, FRKN.RacingNPC.blip.sprite)
        SetBlipColour(blip, FRKN.RacingNPC.blip.color)
        SetBlipScale(blip, FRKN.RacingNPC.blip.scale)
        SetBlipAsShortRange(blip, true)

        BeginTextCommandSetBlipName("STRING")
        AddTextComponentString(FRKN.RacingNPC.blip.label)
        EndTextCommandSetBlipName(blip)
    end
end)

Citizen.CreateThread(function()
    Wait(2000)
    if not FRKN.RacingNPC.enabled or not racingNPC then return end

    if FRKN.Interaction.Target == 'qb-target' then
        exports['qb-target']:AddTargetEntity(racingNPC, {
            options = buildCityTargetOptions(),
            distance = FRKN.RacingNPC.target.distance
        })

    elseif FRKN.Interaction.Target == 'ox_target' then
        exports['ox_target']:addLocalEntity(
            racingNPC,
            buildCityTargetOptions()
        )
    end
end)

local autoRaceBlip = nil

AddEventHandler('onResourceStop', function(resourceName)
    if resourceName ~= GetCurrentResourceName() then return end

    if DoesEntityExist(racingNPC) then
        DeleteEntity(racingNPC)
    end

    if autoRaceBlip and DoesBlipExist(autoRaceBlip) then
        RemoveBlip(autoRaceBlip)
        autoRaceBlip = nil
    end
end)


RegisterNetEvent('frkn-racing:autoRaceAnnounce')
AddEventHandler('frkn-racing:autoRaceAnnounce', function(data)
    local trackName = data.trackName or "Bilinmeyen Pist"
    local minsLeft = data.minutesLeft or 10
    local buyIn = data.buyIn or 0
    local laps = data.laps or 2
    local prizes = data.prizes or {}

    local prizeLines = ""
    if prizes[1] and prizes[1].amount then
        prizeLines = prizeLines .. "\n1st: $" .. prizes[1].amount
    end
    if prizes[2] and prizes[2].amount then
        prizeLines = prizeLines .. "  2nd: $" .. prizes[2].amount
    end
    if prizes[3] and prizes[3].amount then
        prizeLines = prizeLines .. "  3rd: $" .. prizes[3].amount
    end

    local buyInText = ""
    if buyIn > 0 then
        buyInText = Lang:t('general.auto_race_buyin') .. ": $" .. buyIn
    else
        buyInText = Lang:t('general.auto_race_free')
    end

    local startTime = data.startTime or ""
    local msg = startTime
        .. " | " .. trackName
        .. "\n" .. laps .. " " .. Lang:t('general.auto_race_laps') .. " | " .. buyInText
        .. prizeLines
        .. "\n\n" .. minsLeft .. " " .. Lang:t('general.auto_race_minutes_left')

    TriggerEvent('frkn-racing:altNotify', {
        type = "success",
        header = Lang:t('general.auto_race_announce_header'),
        message = msg,
        duration = 5000
    })

    if data.raceId then
        local raceTrackId = nil
        for _, race in ipairs(clientData or {}) do
            if tonumber(race.id) == tonumber(data.raceId) then
                raceTrackId = race.track_id
                break
            end
        end

        if raceTrackId then
            TriggerCallback('frkn-racing:getTrackCheckpoints', function(checkpoints)
            local raceCheckpoints = nil
            if checkpoints and checkpoints[1] and checkpoints[1].pos then
                raceCheckpoints = checkpoints[1].pos
            end

            if raceCheckpoints then
            if autoRaceBlip and DoesBlipExist(autoRaceBlip) then
                RemoveBlip(autoRaceBlip)
            end

            autoRaceBlip = AddBlipForCoord(raceCheckpoints.x, raceCheckpoints.y, raceCheckpoints.z)
            SetBlipSprite(autoRaceBlip, 315)
            SetBlipDisplay(autoRaceBlip, 4)
            SetBlipScale(autoRaceBlip, 1.2)
            SetBlipColour(autoRaceBlip, 69)
            SetBlipAsShortRange(autoRaceBlip, false)
            BeginTextCommandSetBlipName("STRING")
            AddTextComponentString("[AUTO] " .. trackName)
            EndTextCommandSetBlipName(autoRaceBlip)

            CreateThread(function()
                Wait((data.joinTimeSeconds or 120) * 1000 + 30000)
                if autoRaceBlip and DoesBlipExist(autoRaceBlip) then
                    RemoveBlip(autoRaceBlip)
                    autoRaceBlip = nil
                end
            end)
        end
        end, tonumber(raceTrackId))
        end
    end
end)

RegisterCommand('autorace', function()
    if FRKN.UseTabletApp then
        return
    end
    TriggerServerEvent('frkn-racing:autoRaceJoin')
end, false)

local autoRaceBlip = nil

RegisterCommand('leaverace', function()
    TriggerServerEvent('frkn-racing:leaveAllRaces')
    local savedRaceType = raceType and string.upper(raceType) or ""
    local veh = GetVehiclePedIsIn(PlayerPedId(), false)
    if veh ~= 0 and resetVehicleHandling then
        resetVehicleHandling(veh)
    end
    cleanupObjects()
    ResetRaceState()
    SetNuiFocus(false, false)
    tablet = false

    if (savedRaceType == "FORMULA" or savedRaceType == "PLANE" or savedRaceType == "JETSKI") and preRacePosition then
        DoScreenFadeOut(200)
        while not IsScreenFadedOut() do Wait(0) end
        local ped = PlayerPedId()
        local veh2 = GetVehiclePedIsIn(ped, false)
        if veh2 ~= 0 then
            TaskLeaveVehicle(ped, veh2, 16)
            Wait(500)
            DeleteVehicle(veh2)
            spawnedRaceVehicle = nil
        end
        SetEntityCoords(ped, preRacePosition.x, preRacePosition.y, preRacePosition.z, false, false, false, true)
        SetEntityHeading(ped, preRacePosition.h)
        Wait(300)
        DoScreenFadeIn(1000)
        while not IsScreenFadedIn() do Wait(0) end
    end
    TriggerServerEvent('frkn-racing:clearPreRacePosition')
    preRacePosition = nil
end, false)

RegisterCommand('racetoggle', function()
    if FRKN.UseTabletApp then
        return
    end
    SendNUIMessage({ action = "toggleAutoRacePanel" })
end, false)

local autoRaceMarkerCoords = nil
local autoRaceMarkerThread = false

RegisterNetEvent('frkn-racing:showAutoRacePanel')
AddEventHandler('frkn-racing:showAutoRacePanel', function(data)
    if not FRKN.AutoRaceSystem.AnnouncementNotifyOnly then
        SendNUIMessage({
            action = "showAutoRacePanel",
            trackName = data.trackName,
            laps = data.laps,
            buyIn = data.buyIn,
            prizes = data.prizes,
            countdownSeconds = data.countdownSeconds,
            playerCount = data.playerCount
        })
        SendNUIMessage({
            action = "triggerMainPageRefresh"
        })
    end

    if data.startCoords then
        local coords = vector3(data.startCoords.x, data.startCoords.y, data.startCoords.z)

        if autoRaceBlip and DoesBlipExist(autoRaceBlip) then
            RemoveBlip(autoRaceBlip)
        end
        autoRaceBlip = AddBlipForCoord(coords.x, coords.y, coords.z)
        SetBlipSprite(autoRaceBlip, 315)
        SetBlipColour(autoRaceBlip, 3)
        SetBlipScale(autoRaceBlip, 1.0)
        SetBlipRoute(autoRaceBlip, true)
        SetBlipRouteColour(autoRaceBlip, 3)
        BeginTextCommandSetBlipName("STRING")
        AddTextComponentSubstringPlayerName("Auto Race")
        EndTextCommandSetBlipName(autoRaceBlip)

        autoRaceMarkerCoords = coords
        if not autoRaceMarkerThread then
            autoRaceMarkerThread = true
            CreateThread(function()
                while autoRaceMarkerCoords do
                    Wait(0)
                    local mc = autoRaceMarkerCoords
                    if not mc then break end
                    DrawMarker(4, mc.x, mc.y, mc.z + 1.0, 0, 0, 0, 0, 0, 0, 7.0, 7.0, 7.0, 0, 255, 0, 200, false, true, 2, false, nil, nil, false)

                    local playerCoords = GetEntityCoords(PlayerPedId())
                    local distToMarker = #(playerCoords - mc)

                    if distToMarker < 100.0 then
                        local textZ = mc.z + 2.5
                        SetTextScale(0.45, 0.45)
                        SetTextFont(4)
                        SetTextProportional(true)
                        SetTextColour(40, 255, 253, 220)
                        SetTextDropShadow(0, 0, 0, 0, 255)
                        SetTextEdge(2, 0, 0, 0, 200)
                        SetTextOutline()
                        SetTextCentre(true)
                        SetDrawOrigin(mc.x, mc.y, textZ, 0)
                        BeginTextCommandDisplayText("STRING")
                        AddTextComponentSubstringPlayerName(Lang:t('general.auto_race_marker_text'))
                        EndTextCommandDisplayText(0.0, 0.0)
                        ClearDrawOrigin()
                    end
                end
                autoRaceMarkerThread = false
            end)
        end
    end
end)

RegisterNetEvent('frkn-racing:hideAutoRacePanel')
AddEventHandler('frkn-racing:hideAutoRacePanel', function()
    SendNUIMessage({ action = "hideAutoRacePanel" })
    autoRaceMarkerCoords = nil
    if autoRaceBlip and DoesBlipExist(autoRaceBlip) then
        RemoveBlip(autoRaceBlip)
        autoRaceBlip = nil
    end
end)
