Core = nil
CoreName = nil
CoreReady = false
Citizen.CreateThread(function()
    for k, v in pairs(Cores) do
        if GetResourceState(v.ResourceName) == "starting" or GetResourceState(v.ResourceName) == "started" then
            CoreName = v.ResourceName
            Core = v.GetFramework()
            CoreReady = true
            PlayerData = GetPlayerData()
        end
    end
end)

function TriggerCallback(name, cb, ...)
    FRKN.ServerCallbacks[name] = cb
    TriggerServerEvent('frkn-racing:server:triggerCallback', name, ...)
end

RegisterNetEvent('frkn-racing:client:triggerCallback', function(name, ...)
    if FRKN.ServerCallbacks[name] then
        FRKN.ServerCallbacks[name](...)
        FRKN.ServerCallbacks[name] = nil
    end
end)


exports('openTablet', function()
    TriggerEvent('frkn-racing:openTablet')
end)

function Notify(text, type, length)
    length = length or 5000
    if CoreName == "qb-core" or CoreName == "qbx_core" then
        Core.Functions.Notify(text, type, length)
    elseif CoreName == "es_extended" then
        Core.ShowNotification(text)
    end
end

function GetPlayerData()
    if CoreName == "qb-core" or CoreName == "qbx_core" then
        local player = Core.Functions.GetPlayerData()
        return player
    elseif CoreName == "es_extended" then
        local player = Core.GetPlayerData()
        return player
    end
end

function GetPlayerName()
    local playerData

    if CoreName == "qb-core" or CoreName == "qbx_core" then
        playerData = Core.Functions.GetPlayerData()
        return playerData and playerData.charinfo and playerData.charinfo.firstname .. " " .. playerData.charinfo.lastname or nil
    elseif CoreName == "es_extended" then
        playerData = Core.GetPlayerData()
        return playerData and playerData.getName() or nil
    end

    return nil
end

function GetPlayerMoney()
    local playerData

    if CoreName == "qb-core" or CoreName == "qbx_core" then
        playerData = Core.Functions.GetPlayerData()
        return playerData and playerData.money["cash"] or nil
    elseif CoreName == "es_extended" then
        playerData = Core.GetPlayerData()
        return playerData and playerData.getMoney() or nil
    end

    return nil
end


function GetPlayerJob(source)
    if CoreName == "qb-core" or CoreName == "qbx_core" then
        local player = Core.Functions.GetPlayerData()
        return player.job.name
    elseif CoreName == "es_extended" then
        local player = Core.GetPlayerData(source)
        return player.job.name
    end
end

function GetPlayerIdentifier()
    if CoreName == "qb-core" or CoreName == "qbx_core" then
        local player = Core.Functions.GetPlayerData()
        return player.citizenid
    elseif CoreName == "es_extended" then
        local player = Core.GetPlayerData()
        return player.identifier
    end
end

function getVehiclePlate(vehicle)
    return GetVehicleNumberPlateText(vehicle) or "UNKNOWN"
end


RegisterNetEvent('frkn-racingv2:giveKeys', function(plate)
    local qb = GetResourceState('qb-vehiclekeys')
    local t1gerState = GetResourceState('t1ger_keys')
    local qsState = GetResourceState('qs-vehiclekeys')
    local jaksamState = GetResourceState('jaksam')
    local renewedState = GetResourceState('Renewed-Vehiclekeys')
    local cdGarageState = GetResourceState('cd-garage')

    local vehicle = nil
    local vehicles = GetGamePool('CVehicle')

    for _, veh in ipairs(vehicles) do
        if DoesEntityExist(veh) then
            local vehPlate = GetVehicleNumberPlateText(veh)
            if vehPlate and vehPlate:gsub("%s+", "") == plate:gsub("%s+", "") then
                vehicle = veh
                break
            end
        end
    end

    if not vehicle then return end

    SetVehicleDoorsLocked(vehicle, 1)
    SetVehicleDoorsLockedForAllPlayers(vehicle, false)
    SetVehicleHasBeenOwnedByPlayer(vehicle, true)

    if qb == 'started' then
        TriggerEvent("vehiclekeys:client:SetOwner", plate)

    elseif t1gerState == 'started' then
        exports['t1ger_keys']:SetVehicleLocked(vehicle, 0)

    elseif qsState == 'started' then
        exports['qs-vehiclekeys']:GiveKeys(plate)

    elseif jaksamState == 'started' then
        TriggerServerEvent("vehicles_keys:selfGiveVehicleKeys", plate)

    elseif renewedState == 'started' then
        exports['Renewed-Vehiclekeys']:addKey(plate)

    elseif cdGarageState == 'started' then
        TriggerEvent('cd_garage:AddKeys', plate)
    end
end)