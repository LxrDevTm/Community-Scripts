let currentPage = 'main-page';
cachedRaces = [];
let selectedTrackId = null;
let raceTypes = [];
let playerCrew = null;
let currentRaceId = null;
let activeRaces = [];
let categoryImages = {};
let raceTypeToCategory = {
    'PLANE': 'AIRPLANE',
    'JETSKI': 'JETSKI',
    'FORMULA': 'FORMULA',
    'CAR': 'CAR',
    'BIKE': 'MOTORCYCLE',
    'DRIFT': 'DRIFT',
    'CIRCUIT': 'CAR'
};
let withdrawableAmount = 0;
let withdrawableBets = [];
let selectedRace = null;
let selectedPlayers = [];
let currentPlayerIndex = 0;
let trackControl = false;
let embeddedChatSyncInterval = null;
let lastEmbeddedBetsChatSignature = '';
let lastEmbeddedCrewChatSignature = '';
const tabletAppParams = new URLSearchParams(window.location.search);
const isEmbeddedTabletApp = tabletAppParams.has('embedded');
const tabletAppResourceName = (() => {
    const host = window.location.host || (window.location.href.match(/^https:\/\/([^/]+)/)?.[1]) || 'frkn-racingv2';
    return host.replace(/^cfx-nui-/, '') || 'frkn-racingv2';
})();

function postToTabletResource(endpoint, payload, callback) {
    return $.post(`https://${tabletAppResourceName}/${endpoint}`, JSON.stringify(payload || {}), callback);
}

function notifySmartTabClose() {
    if (!isEmbeddedTabletApp || !window.parent || window.parent === window) {
        return;
    }

    try {
        window.parent.postMessage({ type: '0r-smarttab-close' }, '*');
    } catch (error) {
    }
}

function bootstrapEmbeddedTabletApp() {
    if (!isEmbeddedTabletApp) {
        return;
    }

    postToTabletResource('tabletAppBootstrap', {}, function (payload) {
        if (!payload || payload.disabled) {
            return;
        }

        if (payload.alias && payload.alias.alias) {
            localStorage.setItem('playerAlias', payload.alias.alias);
        }

        openTablet(payload);
    });
}

function buildMessageSignature(messages) {
    if (!Array.isArray(messages)) {
        return '[]';
    }

    return JSON.stringify(messages.map((message) => ([
        message.id || '',
        message.identifier || '',
        message.message || message.text || '',
        message.time || message.created_at || '',
    ])));
}

function crewContainsIdentifier(crew, playerIdentifier) {
    if (!crew || !playerIdentifier) {
        return false;
    }

    if (crew.owner_identifier === playerIdentifier) {
        return true;
    }

    return Array.isArray(crew.members_data) && crew.members_data.some((member) => member.identifier === playerIdentifier);
}

function syncEmbeddedCrewChat() {
    if (!isEmbeddedTabletApp || currentPage !== 'crew-page' || !identifier) {
        return;
    }

    postToTabletResource('getCrews', {}, function (data) {
        if (!data || !Array.isArray(data.crews)) {
            return;
        }

        window.crewAliasData = data.alias || window.crewAliasData || {};

        if (typeof window.GetAliasName !== 'function') {
            window.GetAliasName = function (targetIdentifier, aliasData) {
                let aliasRow = aliasData && aliasData[targetIdentifier];
                if (!aliasRow) return GetPlayerNameFormatted(targetIdentifier);
                if (aliasRow.alias && aliasRow.alias !== "") {
                    return aliasRow.alias;
                }
                return GetPlayerNameFormatted(targetIdentifier);
            };
        }

        const refreshedCrew = data.crews.find((crew) => crewContainsIdentifier(crew, identifier));
        if (!refreshedCrew) {
            return;
        }

        playerCrew = refreshedCrew;
        const nextMessages = refreshedCrew.chat_data || [];
        const nextSignature = buildMessageSignature(nextMessages);
        if (nextSignature === lastEmbeddedCrewChatSignature) {
            return;
        }

        lastEmbeddedCrewChatSignature = nextSignature;
        updateCrewMessages(nextMessages);
    });
}

function syncEmbeddedBetsChat() {
    if (!isEmbeddedTabletApp || currentPage !== 'main-page') {
        return;
    }

    postToTabletResource('getChatMessages', {}, function (messages) {
        const nextMessages = Array.isArray(messages) ? messages : [];
        const nextSignature = buildMessageSignature(nextMessages);
        if (nextSignature === lastEmbeddedBetsChatSignature) {
            return;
        }

        lastEmbeddedBetsChatSignature = nextSignature;
        updateBetsMessages(nextMessages);
    });
}

function syncEmbeddedChats() {
    syncEmbeddedBetsChat();
    syncEmbeddedCrewChat();
}

function startEmbeddedChatSync() {
    if (!isEmbeddedTabletApp || embeddedChatSyncInterval) {
        return;
    }

    syncEmbeddedChats();
    embeddedChatSyncInterval = window.setInterval(syncEmbeddedChats, 1200);
}

if (isEmbeddedTabletApp) {
    document.documentElement.classList.add('embedded-smarttab');
    if (document.body) {
        document.body.classList.add('embedded-smarttab');
    } else {
        window.addEventListener('DOMContentLoaded', function () {
            if (document.body) {
                document.body.classList.add('embedded-smarttab');
            }
        }, { once: true });
    }
}

window.addEventListener("message", function (e) {
    e = e.data
    switch (e.action) {
        case "open":
            if (e.alias && e.alias.alias) {
                localStorage.setItem('playerAlias', e.alias.alias);
            }
            return openTablet(e);
        case "addCheckpoint":
            return addCPItem(e);
        case "removeCheckpoint":
            return removeCPItem(e);
        case "setActiveProp":
            return setActiveProp(e);
        case "crewChatUpdate":
            return updateCrewMessages(e.messages);
        case "chatUpdate":
            return updateBetsMessages(e.messages);
        case "updateRaceData":
            return updateRaceData(e);
        case "startRace":
            return startRace(e);
        case "showNotification":
            if ($('.tablet').is(':visible')) {
                return openNotify(e.type, e.header, e.message, false, 'normal');
            }
            return openAltNotify(e.type, e.header, e.message, e.duration);
        case "triggerMainPageRefresh":
            $('.menu-item[data-page="main-page"]').trigger('click');
            setTimeout(function () {
                $('.category-item[data-bg="autorace"]').trigger('click');
            }, 200);
            return;
        case "showAutoRacePanel":
            return showAutoRacePanel(e);
        case "hideAutoRacePanel":
            return hideAutoRacePanel();
        case "toggleAutoRacePanel":
            return toggleAutoRacePanel();
        case "raceFinishResult":
            return showRaceFinishOverlay(e);
        case "refreshLobby":
            return refreshRaceLobby(e.id);
        case "close":
            resetRaceCountdown();
            return $('.tablet , .page , .race-page').fadeOut(0);
        case "closeTrackPage":
            trackControl = false;
            $('.track-page , .tablet , .page , .race-page , .advanced-settings').fadeOut(0);
            $('body').fadeOut(0);
            $('.col-track-details .desc-input').prop('disabled', false);
            $('.col-track-details .select-box select').prop('disabled', false);
            $('.col-track-details .desc-input').val('');
            $('.continue-btn').attr('data-lang', 'create_advanced.new_track').text(t('create_advanced.new_track'));
            $('.cancel-btn').hide();
            $('.cp-list').empty();
            updateCPCount();
            return;
        case "autoSelectTrack":
            setTimeout(function () {
                let targetCard = $(`.track-card[data-id="${e.trackId}"]`);
                if (targetCard.length) {
                    targetCard.trigger('click');
                    setTimeout(function () {
                        $('.map-grid-header').trigger('click');
                    }, 400);
                }
            }, 500);
            return;
        case "clearCheckpoints":
            $('.cp-list').empty();
            updateCPCount();
            return;
        case "autoSaveTrack":
            setTimeout(function () {
                let saveBtn = $('.continue-btn');
                if (saveBtn.length && saveBtn.is(':visible')) {
                    saveBtn.trigger('click');
                    setTimeout(function () {
                        let createTrackBtn = $('.col-track-details .create-track');
                        if (createTrackBtn.length) {
                            createTrackBtn.trigger('click');
                        }
                    }, 800);
                }
            }, 300);
            return;

        default:
            return;
    }
});

let countdownTimer = null
let countdownFadeTimer = null

function startRace(e) {
    if (countdownTimer) {
        clearInterval(countdownTimer)
        countdownTimer = null
    }
    if (countdownFadeTimer) {
        clearTimeout(countdownFadeTimer)
        countdownFadeTimer = null
    }

    $('.tablet , .top-list , .pos-box , .lap-box').stop(true, true).fadeOut(0)

    $('body').stop(true, true).css({'display': 'flex', 'opacity': '1', 'visibility': 'visible'})

    let racePage = $('.race-page')
    let timerBox = $('.timer-box')
    racePage.stop(true, true).css({'display': 'block', 'opacity': '1', 'visibility': 'visible'})
    timerBox.stop(true, true).css({'display': 'flex', 'opacity': '1', 'visibility': 'visible'})

    $('.race-page .timer').css('width', '100%')

    let time = Math.max(Math.floor(e.time / 1000), 3)
    let maxTime = time

    $('.time').text(time)

    let colors = [
        { bg: '#E41E1E', shadow: '0 0 33px rgba(228,30,30,0.66)' },
        { bg: '#E41E1E', shadow: '0 0 33px rgba(228,30,30,0.66)' },
        { bg: '#E4D31E', shadow: '0 0 33px rgba(228,211,30,0.66)' },
        { bg: '#E4A11E', shadow: '0 0 33px rgba(228,161,30,0.66)' },
        { bg: '#1EE477', shadow: '0 0 33px rgba(30,228,119,0.66)' },
    ]

    let lights = $('.light-list .light-item')
    let lightCount = lights.length
    let secondsPerLight = maxTime / lightCount
    let currentLightIndex = lightCount - 1

    lights.each(function (i) {
        $(this).css({
            background: colors[i]?.bg || '#1EE477',
            boxShadow: colors[i]?.shadow || '0 0 33px rgba(30,228,119,0.66)'
        })
    })

    setTimeout(function () {
        countdownTimer = setInterval(function () {
            time--
            $('.time').text(time)

            let percent = (time / maxTime) * 100
            $('.race-page .timer').css('width', percent + '%')

            let expectedIndex = Math.floor(time / secondsPerLight)

            while (currentLightIndex > expectedIndex && currentLightIndex >= 0) {
                lights.eq(currentLightIndex).css({
                    background: 'rgba(255,255,255,0.06)',
                    boxShadow: 'none'
                })
                currentLightIndex--
            }

            if (time <= 0) {
                clearInterval(countdownTimer)
                countdownTimer = null

                $('.race-page .timer').css('width', '0%')
                $('.time').text('')

                lights.each(function () {
                    $(this).css({
                        background: '#1EE477',
                        boxShadow: '0 0 33px rgba(30,228,119,0.66)'
                    })
                })

                countdownFadeTimer = setTimeout(function () {
                    countdownFadeTimer = null
                    lights.each(function () {
                        $(this).css({
                            background: 'rgba(255,255,255,0.06)',
                            boxShadow: 'none'
                        })
                    })
                    $('.timer-box').fadeOut(500)
                }, 1000)
            }

        }, 1000)
    }, 50)
}

function resetRaceCountdown() {
    if (countdownTimer) {
        clearInterval(countdownTimer)
        countdownTimer = null
    }
    if (countdownFadeTimer) {
        clearTimeout(countdownFadeTimer)
        countdownFadeTimer = null
    }

    $('.race-page .timer').css('width', '100%')
    $('.time').text('')

    $('.light-list .light-item').each(function () {
        $(this).stop(true, true).css({
            background: 'rgba(255,255,255,0.06)',
            boxShadow: 'none'
        })
    })

    $('.race-page , .timer-box').stop(true, true).fadeOut(0)
}


function formatTime(sec) {
    sec = Number(sec);
    let m = Math.floor(sec / 60);
    let s = sec % 60;

    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
}


function formatNumber(num) {
    return num.toLocaleString('en-US');
}

function updateRaceData(d) {
    $('body').css('display', 'flex');
    $('.race-page').fadeIn(0);
    $('.top-list , .pos-box , .lap-box').fadeIn(0);

    $('.pos-box .pos-count').text(d.myPosition + "/" + d.totalRacers);
    $('.lap-box .pos-text').text(d.lap + "/" + d.totalLaps);

    $('.lap-list .lap-item').eq(0).find('.count').text(d.lap + "/" + d.totalLaps);
    $('.lap-list .lap-item').eq(1).find('.count').text(d.bestLapTime ? d.bestLapTime : "—");
    $('.lap-list .lap-item').eq(2).find('.count').text(d.currentCheckpoint + "/" + d.totalCheckpoints);
    $('.lap-list .lap-item').eq(3).find('.count').text(formatTime(d.time));

    const colorPalette = [
        { hex: '#FA32A0', rgba: 'rgba(250, 50, 160, 0.98)' },
        { hex: '#32FA8C', rgba: 'rgba(50, 250, 140, 0.98)' },
        { hex: '#3296FA', rgba: 'rgba(50, 150, 250, 0.98)' },
        { hex: '#FAD732', rgba: 'rgba(250, 215, 50, 0.98)' },
        { hex: '#FA5732', rgba: 'rgba(250, 87, 50, 0.98)' },
        { hex: '#C832FA', rgba: 'rgba(200, 50, 250, 0.98)' }
    ];

    let list = $('.top-list');
    list.empty();

    let myAliasName = d.myAlias?.alias || d.myAlias;

    d.racePositions.forEach(function (p, index) {
        let name = p.alias?.alias || p.aliasData?.alias || "Unknown";
        let timeText = p.timeDifference || "—";
        let pos = p.position || p.pos || "-";

        let isMe = myAliasName && (name === myAliasName);

        let colorIndex = index % colorPalette.length;
        let color = colorPalette[colorIndex].hex;
        let colorRgba = colorPalette[colorIndex].rgba;

        let leftBoxStyle = `border-radius: 0 33px 41px 0; background: ${color}; box-shadow: 0 0 11.9px 0 ${colorRgba};`;

        list.append(`
            <div class="top-item ${isMe ? 'you' : ''}">
                <div class="left-box" style="${leftBoxStyle}"></div>
                <div class="player-name">
                    ${name}
                    ${isMe ? '<span style="color: rgba(255,255,255,0.35);font-size: 12px;font-weight: 500;">(YOU)</span>' : ''}
                </div>
                <div class="time-box">${timeText}</div>
                <div class="number">${pos}</div>
            </div>
        `);
    });

    $('.top-item.you').each(function () {
        let bgColor = $(this).find('.left-box').css('background-color');
        let rgba0 = bgColor.replace('rgb', 'rgba').replace(')', ', 0)');
        let rgba33 = bgColor.replace('rgb', 'rgba').replace(')', ', 0.33)');

        $(this).css('background',
            `linear-gradient(90deg, ${rgba0} 30%, ${rgba33} 100%),
             linear-gradient(90deg, rgba(16,16,16,0.57), rgba(25,25,25,0.57))`
        );
    });
    if (d.raceType === "DRIFT") {
        const driftBox = $('.drift-box');
        const driftCount = $('.drift-count');
        const driftProgress = $('.drift-progress');
        const etsText = $('.ets-text');

        if (d.isDrifting) {
            driftBox.stop(true, true).fadeIn(0);

            let instantScore = d.driftScore || 0;
            let totalScore = d.totalDriftScore || 0;
            let maxScore = 10000;

            driftCount.text(formatNumber(instantScore));
            etsText.text(formatNumber(totalScore) + ' ETS');

            let percent = Math.min((instantScore / maxScore) * 100, 100);
            driftProgress.css('width', percent + '%');

            let hue = Math.max(0, 135 - (instantScore / maxScore) * 135);
            let glowColor = `hsl(${hue}, 100%, 55%)`;

            driftProgress.css({
                'background': `radial-gradient(100% 100% at 50% 0%, ${glowColor} 0%, hsl(${hue}, 60%, 45%) 100%)`,
                'box-shadow': `0 0 22px ${glowColor}`
            });

            let fontSize = 2.7;

            if (instantScore > 2000) fontSize = 2.9;
            if (instantScore > 4000) fontSize = 3.1;
            if (instantScore > 7000) fontSize = 3.3;
            if (instantScore > 10000) fontSize = 3.5;

            driftCount.css({
                'font-size': fontSize + 'vh',
                'font-weight': 700,
                'color': '#fff'
            });

            if (instantScore >= 10000) {
                driftBox.css('animation', 'shake 0.2s infinite');
            } else {
                driftBox.css('animation', 'pulse 1.5s infinite');
            }

        } else {
            driftBox.stop(true, true).fadeOut(0).css('animation', '');
            driftProgress.css('width', '0%');
            driftCount.text('0');
        }
    } else {
        $('.drift-box').fadeOut(0);
    }

}

function openTablet(e) {
    $('body, .tablet').fadeIn();

    $('.track-page').hide();

    initVehicleClassSelector();

    $('.col-track-details .select-box select').val('');
    $('.race-type-selector .selector-text').text('CIRCUIT');
    window._specialCategoryMode = null;
    window._formulaMode = false;
    window._pendingCategoryFilter = null;

    if (e.formulaTrackId) {
        window._formulaTrackId = e.formulaTrackId;
    }
    if (e.categoryTracks) {
        window._categoryTracks = e.categoryTracks;
    }
    if (e.devMode !== undefined) {
        window._devMode = e.devMode;
    }

    if (e.menuItems) {
        $('.side-menu .menu-item').each(function () {
            let page = $(this).data('page');
            if (page && e.menuItems[page] === false) {
                $(this).css('display', 'none');
            } else {
                $(this).css('display', '');
            }
        });
    }

    if (trackControl == false) {
        let firstVisible = $('.side-menu .menu-item:visible').first();
        if (firstVisible.length) {
            firstVisible.trigger('click');
        }
    }

    playerName = e.alias.alias || 'NAME NOT SET';
    playerAvatar = e.alias.data.avatar;
    xp = e.alias.data.xp;
    level = e.alias.data.level;
    rating = e.alias.data.rating;
    matches = e.alias.data.matches;
    moneyearned = e.alias.data.moneyearned;
    requiredXP = e.alias.data.requiredXP;

    allAlias = e.allAlias;
    identifier = e.identifier;

    $('.createcrew-btn').html(e.crew.Money + ' $');
    $('.profile-page .avatar , .profile-img').attr('src', playerAvatar);
    $('.profile-page .profil-name , .profil-det .name').text(playerName);
    $('.profile-page .xp-box .xp-value').text(xp + " XP");
    $('.profile-page .xp-box .level').text(level);
    let racesWon = Number(e.alias.data.races_won) || 0
    let totalRaces = Number(e.alias.data.matches) || 0

    let safeWins = Math.min(racesWon, totalRaces)
    let totalLost = Math.max(0, totalRaces - safeWins)

    $('.stat-item').eq(0).find('.stat-value').text(safeWins)
    $('.stat-item').eq(1).find('.stat-value').text(totalRaces)
    $('.stat-item').eq(2).find('.stat-value').text(totalLost)


    let checkpointColor = e.alias.data.checkpointcolor;
    let gpsColor = e.alias.data.gpscolor;

    $('.checkpoint-item').eq(0).find('.color-item').removeClass('active');
    $('.checkpoint-item').eq(1).find('.color-item').removeClass('active');

    $('.checkpoint-item').eq(0).find('.color-item').each(function () {
        if ($(this).css('background-color') === $('<div>').css('background-color', checkpointColor).css('background-color')) {
            $(this).addClass('active');
        }
    });

    $('.checkpoint-item').eq(1).find('.color-item').each(function () {
        if ($(this).css('background-color') === $('<div>').css('background-color', gpsColor).css('background-color')) {
            $(this).addClass('active');
        }
    });

}

$(function () {
    bootstrapEmbeddedTabletApp();
    startEmbeddedChatSync();
});


const categoryThemes = {
    all: {
        color: "#ffffff",
        rgb: "255, 255, 255",
        shadow: "0 0 7px rgba(255, 255, 255, 0.4)",
        bg: "radial-gradient(circle at center, rgba(255,255,255,0.08) 0%, rgba(255,255,255,0.02) 60%, rgba(255,255,255,0) 100%)"
    },
    formula: {
        color: "#ff0000",
        rgb: "255, 0, 0",
        shadow: "0 0 7px rgba(255, 0, 0, 0.6)",
        bg: "radial-gradient(circle at center, rgba(255,0,0,0.12) 0%, rgba(255,0,0,0.04) 60%, rgba(255,0,0,0) 100%)"
    },
    car: {
        color: "#3A8DFF",
        rgb: "58, 141, 255",
        shadow: "0 0 7px rgba(58, 141, 255, 0.6)",
        bg: "radial-gradient(circle at center, rgba(58,141,255,0.12) 0%, rgba(58,141,255,0.04) 60%, rgba(58,141,255,0) 100%)"
    },
    motorcycle: {
        color: "#FFD93A",
        rgb: "255, 217, 58",
        shadow: "0 0 7px rgba(255, 217, 58, 0.6)",
        bg: "radial-gradient(circle at center, rgba(255,217,58,0.12) 0%, rgba(255,217,58,0.04) 60%, rgba(255,217,58,0) 100%)"
    },
    jetski: {
        color: "#00E0FF",
        rgb: "0, 224, 255",
        shadow: "0 0 7px rgba(0, 224, 255, 0.6)",
        bg: "radial-gradient(circle at center, rgba(0,224,255,0.12) 0%, rgba(0,224,255,0.04) 60%, rgba(0,224,255,0) 100%)"
    },
    airplane: {
        color: "#9A5BFF",
        rgb: "154, 91, 255",
        shadow: "0 0 7px rgba(154, 91, 255, 0.6)",
        bg: "radial-gradient(circle at center, rgba(154,91,255,0.12) 0%, rgba(154,91,255,0.04) 60%, rgba(154,91,255,0) 100%)"
    },
    drift: {
        color: "#00ff44",
        rgb: "0, 255, 68",
        shadow: "0 0 7px rgba(0, 255, 68, 0.6)",
        bg: "radial-gradient(circle at center, rgba(0,255,68,0.12) 0%, rgba(0,255,68,0.04) 60%, rgba(0,255,68,0) 100%)"
    },
    myrace: {
        color: "#4CAF50",
        rgb: "76,175,80",
        shadow: "0 0 30px rgba(76,175,80,0.25)",
        bg: "radial-gradient(circle at center, rgba(76,175,80,0.12) 0%, rgba(76,175,80,0.04) 60%, rgba(76,175,80,0) 100%)"
    }
}


$(document).on('click', '.category-item:not(.my-race-box)', function () {
    let self = $(this);
    const id = self.data('bg');

    if (currentPage === 'create-page' && (id === 'all' || id === 'autorace')) {
        openNotify('error', t('create.category_restricted_header'), t('create.category_restricted'));
        return;
    }

    applyCategorySelection(self, id);
});

function applyCategorySelection(self, id) {
    $('.category-item').removeClass('active')
    self.addClass('active')

    const theme = categoryThemes[id];

    if (theme) {
        document.documentElement.style.setProperty('--category-color', theme.color)
        document.documentElement.style.setProperty('--category-rgb', theme.rgb)
        document.documentElement.style.setProperty('--category-shadow', theme.shadow)
        document.documentElement.style.setProperty('--category-bg', theme.bg)
    }

    const img = self.data('img');
    if (img) $('#previewImg').attr('src', img);

    const selectedType = self.data('bg');
    const filterType = (selectedType === 'all') ? null : selectedType;

    $.post('https://frkn-racingv2/getRaces', JSON.stringify({}), function (response) {
        cachedRaces = response || [];
        renderRaceList(filterType);
        renderFinishedRaces(filterType, $('.rh-filter-btn.active').data('filter') === 'my');
    });

    updateRaceTypeFromActiveCategory();


    let categoryToDropdownAll = {
        'formula': 'FORMULA',
        'jetski': 'JETSKI',
        'airplane': 'PLANE',
        'car': 'CAR',
        'motorcycle': 'BIKE',
        'drift': 'DRIFT'
    };

    let categoryTrackNames = (window._categoryTracks && window._categoryTracks[id]) ? window._categoryTracks[id] : null;
    if (categoryTrackNames && categoryTrackNames.length > 0 && !window._devMode) {
        window._specialCategoryMode = id;
        window._pendingCategoryFilter = categoryTrackNames;
        if (id === 'formula') {
            window._formulaMode = true;
        } else {
            window._formulaMode = false;
        }

        $('.type-select-box').hide();


        let dropdownVal = categoryToDropdownAll[id] || '';
        if (dropdownVal) {
            $('.col-track-details .select-box select').val(dropdownVal);
            $('.race-type-selector .selector-text').text(dropdownVal);
        }

        let mapWrapper = $('.col-track-details .map-grid-wrapper');
        if (!mapWrapper.is(':visible')) {
            $('.col-track-details .create-track').trigger('click');
        } else {
            $.post('https://frkn-racingv2/getTracks', JSON.stringify({}), function (tracks) {
                if (tracks && tracks.length > 0) {
                    applyCategoryFilter(tracks, categoryTrackNames);
                }
            });
        }

        setTimeout(function () {
            $('.col-track-details .create-track').hide();
        }, 250);
    } else {
        window._specialCategoryMode = null;
        window._formulaMode = false;
        window._pendingCategoryFilter = null;
        let col = $('.col-track-details');
        col.find('.create-track').show();
        $('.type-select-box').show();
        $('.enableAlerts-toggle').closest('.toggle-row').show();

        let dropdownVal = categoryToDropdownAll[id] || '';
        if (dropdownVal) {
            $('.col-track-details .select-box select').val(dropdownVal);
            $('.race-type-selector .selector-text').text(dropdownVal);

        }

        let mapWrapper = col.find('.map-grid-wrapper');
        if (mapWrapper.is(':visible')) {
            mapWrapper.slideUp(200);
            col.find('.field-group').slideDown(200);
            col.find('.continue-btn').show();
            col.find('.col-title').text(t('create_advanced.track_details'));
            col.find('.col-desc').text(t('create_advanced.track_desc'));
            col.find('.create-track').text(t('create.select_track'));
        }

        if (cachedTrackList && cachedTrackList.length > 0) {
            renderTrackCards(cachedTrackList, null, false);
            $('.track-card').css({ 'pointer-events': '', 'opacity': '' });
        }
    }
}

function applyCategoryFilter(tracks, allowedNamesList) {
    let allowedNames = allowedNamesList.map(n => n.toLowerCase());
    let filteredTracks = tracks.filter(t => {
        let trackName = (t.name || '').toLowerCase();
        return allowedNames.some(an => trackName.includes(an) || an.includes(trackName));
    });

    renderTrackCards(filteredTracks, null, false);

    setTimeout(function () {
        let firstCard = $('.track-card').first();
        if (firstCard.length) {
            $('.track-card').removeClass('active');
            firstCard.addClass('active');
            selectedTrackId = firstCard.data('id');
            $('.track-id-input').val(`${selectedTrackId} (${t('create_advanced.track_id_auto')})`);
        }
    }, 300);
}

$('.category-item:not(.my-race-box)').each(function () {
    let type = $(this).data('bg');
    if (type && type.toUpperCase() !== 'ALL' && type.toUpperCase() !== 'AUTORACE') raceTypes.push(type.toUpperCase());
});

$(document).on('click', '.profile-img', function () {
    $('.page , .advanced-settings , .popup-bg , .password-box').fadeOut(0);
    $('.profile-page').fadeIn(0);
});



const speed = 250;


$('.upcoming-list , .scroll-wrapper , .detail-scroll ').on('wheel', function (e) {
    e.preventDefault();
    const delta = e.originalEvent.deltaY;
    $(this).scrollTop($(this).scrollTop() + (delta > 0 ? speed : -speed));
});

function scrollToBottom(selector) {
    const box = $(selector);
    if (box.length) box.scrollTop(box[0].scrollHeight);
}

$(document).on('click', '.bets-box', function () {
    $(this).addClass('open')
    let list = $('.bets-box .messages-list')
    setTimeout(() => {
        list.scrollTop(list[0].scrollHeight)
    }, 10)
})

$(document).on('click', function (e) {
    if (!$(e.target).closest('.bets-box').length) {
        $('.bets-box').removeClass('open')
    }

    let list = $('.bets-box .messages-list')
    setTimeout(() => {
        list.scrollTop(list[0].scrollHeight)
    }, 10)
})


$(document).on('click', '.bets-box .sent-icon', function () {
    sendBetsMessage();
});

$('.bets-box .message-input').on('keypress', function (e) {
    if (e.which === 13) {
        sendBetsMessage();
    }
});

function sendBetsMessage() {
    let text = $('.bets-box .message-input').val().trim();
    if (text.length === 0) return;

    $.post('https://frkn-racingv2/sendBetsMessage', JSON.stringify({
        message: text
    }), function (resp) {
        syncEmbeddedBetsChat();
    });

    $('.bets-box .message-input').val('');
}

function loadInitialBetsMessages() {
    $.post('https://frkn-racingv2/getChatMessages', JSON.stringify({}), function (msgs) {
        updateBetsMessages(msgs)
    })
}


function updateBetsMessages(msgs) {
    let list = $('.bets-box .messages-list')
    list.empty()

    if (!Array.isArray(msgs)) {
        return
    }

    $.post('https://frkn-racingv2/getAlias', JSON.stringify({}), function (aliasData) {
        aliasData = aliasData || {}

        msgs.forEach(m => {
            let aliasName = aliasData[m.identifier] || m.sender || m.identifier

            let timeText = ""
            let ts = m.time || m.created_at
            if (ts) {
                let d = new Date(ts * 1000)
                let hh = d.getHours().toString().padStart(2, '0')
                let mm = d.getMinutes().toString().padStart(2, '0')
                timeText = `[${hh}:${mm}]`
            }
            let row = `
                <div class="msg-item">
                    <p class="msg-text">
                        ${aliasName.alias} : ${m.message}
                        <span class="msg-time">${timeText}</span>
                    </p>
                </div>
            `
            list.append(row)
        })

        setTimeout(() => {
            list.scrollTop(list[0].scrollHeight)
        }, 10)
    })
}



let clickAudio = new Audio('click.mp3')
clickAudio.preload = 'auto'

let audioUnlocked = false

function unlockAudio() {
    if (audioUnlocked) return
    clickAudio.volume = 0
    clickAudio.play().then(() => {
        clickAudio.pause()
        clickAudio.currentTime = 0
        audioUnlocked = true
    }).catch(() => { })
}

function getClickVolume() {
    let slider = $('input.settings-page-audio-range').first()
    if (!slider.length) return 1
    return Number(slider.val()) / 100
}

$(document).on('click', '.menu-item ,  .category-item', function () {
    unlockAudio()
    clickAudio.pause()
    clickAudio.currentTime = 0
    clickAudio.volume = getClickVolume()

    clickAudio.play().catch(() => { })
})

$('input.frkn-slider, input.settings-page-audio-range').each(function () {
    this.style.setProperty('--value', this.value)

    const percentText = $(this)
        .closest('.settings-page-audio-row')
        .find('.settings-page-audio-label span')
        .eq(1)

    percentText.text(`(${this.value}%)`)
})

$('input.frkn-slider, input.settings-page-audio-range').on('input', function () {
    this.style.setProperty('--value', this.value)

    const percentText = $(this)
        .closest('.settings-page-audio-row')
        .find('.settings-page-audio-label span')
        .eq(1)

    percentText.text(`(${this.value}%)`)
})


$(document).on('click', '.frkn-switch', function () {
    $(this).toggleClass('on');
});


const durationSlider = $('.duration-slider');
const participantSlider = $('.participant-slider');

durationSlider.on('input change', function () {
    $(this).closest('.field-group').find('.field-value-display').text(this.value + ' min');
});

participantSlider.on('input change', function () {
    $(this).closest('.field-group').find('.participant-count').text('[' + this.value + ']');
});

durationSlider.trigger('input');
participantSlider.trigger('input');


$(document).on('click', '.up-item', function () {
    const img = $(this).find('.race-img').attr('src');
    const name = $(this).find('.race-name').text();
    const desc = $(this).find('.race-desc').text();

    $('.up-big img').attr('src', img);
    $('.up-big .race-name').text(name);
    $('.up-big .race-desc').text(desc);
});

$(document).on('click', '.menu-item', function () {
    let clickedPage = $(this).data('page');
    let clickedBtn = $(this);

    doMenuNavigation(clickedPage, clickedBtn);
});

function doMenuNavigation(currentPageParam, btn) {
    currentPage = currentPageParam;
    $('.crew-page .crew-leaderboard , .delete-crew').hide();

    if (btn.text() === t('create_advanced.save')) {
        $('.desc-input').prop('disabled', false);
        $('.select-box select').prop('disabled', false);
        $('.desc-input').val('');
        $('.continue-btn').attr('data-lang', 'create_advanced.new_track').text(t('create_advanced.new_track'));
        $('.cancel-btn').hide();

        $('.track-page , .advanced-settings , .track-box , .tablet').fadeOut(150);
        trackControl = false;
        $.post('https://frkn-racingv2/cancelTrack', JSON.stringify({}), function (response) {
        });
    }

    $('.page').fadeOut(0);
    if (currentPage !== 'garage-page') {
        $('.' + currentPage).fadeIn(0);
    }

    $('.menu-item').removeClass('active');
    btn.addClass('active');
    $('.popup-bg , .password-box , .change-avatar-box , .createcrew-box , .advanced-box , .advanced-settings , .track-box').hide();

    if (currentPage == 'main-page') {
        loadInitialBetsMessages();
        const selectedType = $('.category-item.active').data('bg');
        const filterType = (selectedType === 'all') ? null : selectedType;
        $.post('https://frkn-racingv2/getRaces', JSON.stringify({}), function (response) {
            cachedRaces = response || [];
            renderRaceList(filterType);
            renderFinishedRaces(filterType, $('.rh-filter-btn.active').data('filter') === 'my');
        });

    } else if (currentPage == 'create-page') {
        let activeCategory = $('.category-item.active:not(.my-race-box)');
        let activeBg = activeCategory.length ? activeCategory.data('bg') : 'all';

        if (activeBg === 'all' || activeBg === 'autorace') {
            $('.col-track-details .select-box select').val('');
            $('.race-type-selector .selector-text').text('-');
            window._specialCategoryMode = null;
            window._formulaMode = false;
            window._pendingCategoryFilter = null;
            $('.type-select-box').show();
            let col = $('.col-track-details');
            col.find('.create-track').show();
            let mapWrapper = col.find('.map-grid-wrapper');
            if (mapWrapper.is(':visible')) {
                mapWrapper.slideUp(200);
                col.find('.field-group').slideDown(200);
                col.find('.continue-btn').show();
                col.find('.col-title').text(t('create_advanced.track_details'));
                col.find('.col-desc').text(t('create_advanced.track_desc'));
                col.find('.create-track').text(t('create.select_track'));
            }
            $('#col-advanced').addClass('locked');
            $('#col-options').addClass('locked');
        } else {
            applyCategorySelection(activeCategory, activeBg);
        }

        if (activeBg === 'all' || activeBg === 'autorace') {
            $.post('https://frkn-racingv2/getTracks', JSON.stringify({}), function (tracks) {
                if (tracks && tracks.length > 0) {
                    if (window._pendingCategoryFilter && window._pendingCategoryFilter.length > 0) {
                        applyCategoryFilter(tracks, window._pendingCategoryFilter);
                    } else {
                        renderTrackCards(tracks);
                    }
                }
            });
        }

    } else if (currentPage == 'crew-page') {
        $.post('https://frkn-racingv2/getCrews', JSON.stringify({}), function (data) {

            function GetAliasName(identifier, aliasData) {
                let aliasRow = aliasData[identifier];
                if (!aliasRow) return GetPlayerNameFormatted(identifier);
                if (aliasRow.alias && aliasRow.alias !== "") {
                    return aliasRow.alias;
                }
                return GetPlayerNameFormatted(identifier);
            }

            window.crewAliasData = data.alias || {};
            window.GetAliasName = GetAliasName;

            playerCrew = null;

            data.crews.forEach(c => {
                if (c.owner_identifier === identifier) {
                    playerCrew = c;
                } else if (Array.isArray(c.members_data)) {
                    c.members_data.forEach(m => {
                        if (m.identifier === identifier) {
                            playerCrew = c;
                        }
                    });
                }
            });

            if (playerCrew == null) {
                $('.joinsystem').show();
                $('.crewsystem').hide();

                let joinList = $('.crew-joinlist');
                joinList.empty();

                data.crews.forEach(c => {
                    let ownerName = GetAliasName(c.owner_identifier, data.alias || {});
                    let desc = c.crew_description || t('crew.no_desc');

                    let html = `
                        <div class="join-item" data-id="${c.id}">
                            <img src="../html/images/race-formula.png" class="car-img">
                            <div class="join-name">${c.crew_name}</div>
                            <div class="join-desc">${desc}</div>
                            <div class="join-xp">${t('crew.request_status')}</div>
                        </div>
                    `;
                    joinList.append(html);
                });

                $(document).off('click', '.join-item');
                $(document).on('click', '.join-item', function () {
                    let crewId = $(this).data('id');
                    $.post('https://frkn-racingv2/requestCrewJoin', JSON.stringify({
                        crew_id: crewId
                    }), function (response) {
                        openNotify(response.type, response.header, response.message)
                    });
                });

                return;
            }

            $('.crew-page .crew-leaderboard , .delete-crew').show();
            $('.joinsystem').hide();
            $('.crewsystem').show();

            if (playerCrew.owner_identifier === identifier) {
                $('.delete-crew').css('display', 'flex');
            } else {
                $('.delete-crew').css('display', 'none');
            }

            let isLeader = playerCrew.owner_identifier === identifier;
            let aliasData = data.alias || {};
            let members = [];

            if (playerCrew.owner_identifier) {
                members.push({
                    identifier: playerCrew.owner_identifier,
                    name: GetAliasName(playerCrew.owner_identifier, aliasData),
                    role: "leader"
                });
            }

            playerCrew.members_data.forEach(m => {
                if (m.identifier !== playerCrew.owner_identifier) {
                    members.push({
                        identifier: m.identifier,
                        name: GetAliasName(m.identifier, aliasData),
                        role: m.role || "member"
                    });
                }
            });

            let list = $('.score-list');
            list.empty();

            members.forEach(m => {
                let showFire = false;

                if (isLeader) {
                    if (m.identifier !== identifier) showFire = true;
                } else {
                    if (m.identifier === identifier) showFire = true;
                }

                let roleText = m.role === "leader" ? t('crew.role_leader') : t('crew.role_member');

                let row = `
                <div class="score-item">
                    <img src="../html/images/race-formula.png" class="car-img" alt="">
                    <div class="score-name">${m.name}</div>
                    <div class="score-desc">${roleText}</div>
                    <div class="score-xp">0</div>
                    <div class="score-rank">${m.role}</div>

                    <div class="fire-icon" data-id="${m.identifier}" style="visibility:${showFire ? 'visible' : 'hidden'}">
                        <img src="../html/images/fire-icon.svg">
                    </div>
                </div>
            `;
                list.append(row);
            });


            let leaderboard = [];

            members.forEach(m => {
                let aliasRow = aliasData[m.identifier];
                if (!aliasRow) return;

                let aliasJSON = {};
                try {
                    aliasJSON = JSON.parse(aliasRow.data);
                } catch { aliasJSON = {}; }

                leaderboard.push({
                    identifier: m.identifier,
                    role: m.role,
                    xp: aliasJSON.xp || 0,
                    avatar: aliasJSON.avatar || "../html/images/default.png"
                });
            });

            leaderboard.sort((a, b) => b.xp - a.xp);

            let leaderList = $('.crew-page .leader-list');
            leaderList.empty();

            leaderboard.forEach((row, i) => {
                let rank = i + 1;
                let rankImg = "../html/images/rank-" + rank + ".svg";
                if (rank > 3) rankImg = "../html/images/rank-default.svg";

                let playerName = GetAliasName(row.identifier, aliasData);

                let html = `
                <div class="leader-item">
                    <div class="number">${rank}</div>
                    <div class="player-name">${playerName}</div>
                    <div class="player-score">${row.xp}</div>
                    <img src="${rankImg}" class="rank-icon" alt="">
                </div>
            `;
                leaderList.append(html);
            });

            let chatList = playerCrew.chat_data || [];
            let chatBox = $('.crew-page .messages-list');
            chatBox.empty();

            chatList.forEach(msg => {
                let aliasName = GetAliasName(msg.identifier, aliasData);
                let timeText = "";
                if (msg.time) {
                    let d = new Date(msg.time * 1000);
                    let hh = d.getHours().toString().padStart(2, '0');
                    let mm = d.getMinutes().toString().padStart(2, '0');
                    timeText = `[${hh}:${mm}]`;
                }

                let html = `
                <div class="msg-item">
                    <p class="msg-text">${aliasName} : ${msg.text} <span class="msg-time">${timeText}</span></p>
                </div>
            `;
                chatBox.append(html);
            });

            setTimeout(() => {
                chatBox.scrollTop(chatBox[0].scrollHeight);
            }, 20);


            let requestList = $('.past-list');
            requestList.empty();

            if (isLeader) {
                let requests = data.requests || [];

                requests.forEach(r => {
                    let timeText = "";
                    if (r.time) {
                        let d = new Date(r.time * 1000);
                        let hh = d.getHours().toString().padStart(2, "0");
                        let mm = d.getMinutes().toString().padStart(2, "0");
                        timeText = `[${hh}:${mm}]`;
                    }

                    let html = `
                        <div class="past-item" data-cid="${r.cid}">
                            <img src="../html/images/race-formula.png" class="car-img">

                            <div class="past-name">${r.alias}</div>
                            <div class="past-desc">${t('crew.join_request')} ${timeText}</div>

                            <div class="past-actions">
                                <i class="fa fa-check past-accept"></i>
                                <i class="fa fa-times past-deny"></i>
                            </div>
                        </div>
                    `;
                    requestList.append(html);
                });
            } else {
                requestList.empty();
            }


            let rewardList = $('.past-rewards-list');
            rewardList.empty();

            let rewards = data.rewards || [];
            let myCrewId = playerCrew.id;
            let myIdentifier = identifier;

            let crewRewards = rewards.filter(r => Number(r.crew_id) === Number(myCrewId));

            crewRewards.forEach(r => {
                let claimed = Boolean(r.claimed_by);
                let isLeader = playerCrew.owner_identifier === myIdentifier;

                let rd = r.reward || {};
                let claimText = "";
                let clickableClass = "";

                if (claimed) {
                    claimText = `<span class='claimed-text'>${t('crew.claimed')}</span>`;
                    clickableClass = "reward-disabled";
                } else {
                    if (isLeader) {
                        claimText = `<span class='claimable-text'>${t('crew.click_to_claim')}</span>`;
                        clickableClass = "reward-claim";
                    } else {
                        claimText = `<span class='claimable-text'>${t('crew.leader_only')}</span>`;
                        clickableClass = "reward-disabled";
                    }
                }


                let rewardText = "";

                switch (rd.type) {
                    case "money":
                        rewardText = `${rd.money} $`;
                        break;

                    case "item":
                        if (rd.item && rd.item.name) {
                            rewardText = `${rd.item.amount}x ${rd.item.name}`;
                        }
                        break;

                    case "car":
                        rewardText = `${t('crew.reward_vehicle')} ${rd.car}`;
                        break;

                    default:
                        rewardText = t('crew.reward_unknown');
                        break;
                }


                let html = `
                    <div class="reward-item ${clickableClass}" data-id="${r.id}">
                        <div class="number">#${r.id}</div>
                        <div class="player-name">${rewardText} ${claimText}</div>
                        <img src="../html/images/rank-1.svg" class="rank-icon" alt="">
                    </div>
                `;
                rewardList.append(html);
            });
        });

    } else if (currentPage == 'garage-page') {
        $('.garage-page').hide();
        $.post('https://frkn-racingv2/getPlayerGarage', JSON.stringify({}), function (response) {
            if (!response || !Array.isArray(response.vehicles) || response.vehicles.length === 0) {
                $('.menu-item[data-page="main-page"]').trigger('click');
                currentPage = 'main-page';
                openNotify('error', t('menu.garage'), t('garage.no_vehicles'));
                return;
            }
            $('.garage-page').fadeIn(0);
            loadGaragePage(response.vehicles, response.stats);
        });

    } else if (currentPage == 'betting-page') {
        $.post('https://frkn-racingv2/getRaces', JSON.stringify({}), function (response) {
            cachedRaces = response || [];

            activeRaces = cachedRaces.filter(race => {
                let raceEnded = Array.isArray(race.raceResult) && race.raceResult.length > 0;
                return !raceEnded;
            });

            if (activeRaces.length === 0) {
                $('.menu-item[data-page="main-page"]').trigger('click');
                currentPage = 'main-page';
                openNotify('error', t('menu.betting'), t('betting.no_active_races'));
                return;
            }

            $('.up-big').empty();
            $('.up-list').empty();

            let firstRace = activeRaces[0];

            let type = firstRace.type ? firstRace.type.toUpperCase() : "CAR";
            let rawName = (raceTypeToCategory && raceTypeToCategory[type]) ? (categoryImages[raceTypeToCategory[type]] || "car") : (categoryImages[type] || "car");
            let bigImg = `../html/images/race-${rawName}.png`;

            $('.up-big').html(`
            <img class="car-img" src="${bigImg}">
            <div class="race-name">${firstRace.eventName || t('betting.unnamed_race')}</div>
            <div class="race-desc">${firstRace.type || "---"}</div>
            <div class="start-text">${t('betting.ongoing_race')}</div>
        `);

            for (let i = 1; i < activeRaces.length; i++) {
                let r = activeRaces[i];
                let t = r.type ? r.type.toUpperCase() : "CAR";
                let rn = (raceTypeToCategory && raceTypeToCategory[t]) ? (categoryImages[raceTypeToCategory[t]] || "car") : (categoryImages[t] || "car");
                let img = `../html/images/race-${rn}.png`;

                $('.up-list').append(`
                <div class="up-item" data-index="${i}">
                    <img src="${img}" class="race-img">
                    <div class="race-name">${r.eventName || t('betting.unnamed_race')}</div>
                    <div class="race-desc">${r.type || "---"}</div>
                </div>
            `);
            }

            loadRacePlayers(firstRace);
        });

        $.post('https://frkn-racingv2/getBets', JSON.stringify({}), function (bets) {
            withdrawableAmount = 0;
            withdrawableBets = [];

            (bets || []).forEach(b => {
                if (b.status === "won" && Number(b.paid) === 0) {
                    withdrawableAmount += Number(b.payout_amount || 0);
                    withdrawableBets.push(b.id);
                }
            });

            $('.past-prize').text(`$${withdrawableAmount.toLocaleString()}`);
        });

    } else if (currentPage == 'settings-page') {
        let saved = localStorage.getItem('altNotify');

        if (saved === '0') {
            $('.settings-page-on').removeClass('active');
            $('.settings-page-off').addClass('active');
        } else {
            $('.settings-page-off').removeClass('active');
            $('.settings-page-on').addClass('active');
        }
    }
}
function updateClock() {
    let now = new Date();

    let h = now.getHours().toString().padStart(2, "0");
    let m = now.getMinutes().toString().padStart(2, "0");

    $(".timer").text(`${h}:${m}`);
}

updateClock();
setInterval(updateClock, 1000);

$(document).on('click', '.past-prize', function () {
    if (withdrawableAmount <= 0 || withdrawableBets.length === 0) return;

    $.post('https://frkn-racingv2/withdrawBets', JSON.stringify({
        betIds: withdrawableBets
    }), function (res) {
        if (res && res.success) {
            withdrawableAmount = 0;
            withdrawableBets = [];
            $('.past-prize').text('$0');
            openNotify('success', t('betting.withdrawal_success'), t('betting.withdrawal_success_desc'));
        }
    });
});

$(".change-button-right").on("click", function () {
    if (!selectedPlayers.length) return;
    currentPlayerIndex = (currentPlayerIndex + 1) % selectedPlayers.length;
    updatePlayerUI();
});

$(".change-button").on("click", function () {
    if (!selectedPlayers.length) return;
    currentPlayerIndex = (currentPlayerIndex - 1 + selectedPlayers.length) % selectedPlayers.length;
    updatePlayerUI();
});

function loadBettingPage() {

    $.post('https://frkn-racingv2/getRaces', JSON.stringify({}), function (response) {

        cachedRaces = response || [];

        let activeRaces = cachedRaces.filter(r => {
            let ended = Array.isArray(r.raceResult) && r.raceResult.length > 0;
            return !ended;
        });

        $('.up-big').empty();
        $('.up-list').empty();

        if (activeRaces.length === 0) return;

        selectedRace = activeRaces[0];

        let type = selectedRace.type ? selectedRace.type.toUpperCase() : "CAR";
        let rawName = (raceTypeToCategory && raceTypeToCategory[type]) ? (categoryImages[raceTypeToCategory[type]] || "car") : (categoryImages[type] || "car");
        let imgName = `race-${rawName}.png`;

        $('.up-big').html(`
            <img class="car-img" src="../html/images/${imgName}">
            <div class="race-name">${selectedRace.eventName || selectedRace.name}</div>
            <div class="race-desc">${selectedRace.category || "---"}</div>
            <div class="start-text">${t('betting.ongoing')}</div>
            <div class="start-time"></div>
        `);

        for (let i = 1; i < activeRaces.length; i++) {
            let r = activeRaces[i];
            let ttype = r.type ? r.type.toUpperCase() : "CAR";
            let rn = (raceTypeToCategory && raceTypeToCategory[ttype]) ? (categoryImages[raceTypeToCategory[ttype]] || "car") : (categoryImages[ttype] || "car");
            let im = `race-${rn}.png`;

            $('.up-list').append(`
                <div class="up-item" data-index="${i}">
                    <img class="race-img" src="../html/images/${im}">
                    <div class="race-name">${r.eventName || r.name}</div>
                    <div class="race-desc">${r.category || "---"}</div>
                </div>
            `);
        }

        selectedRace = activeRaces[0];
        renderUpBig(selectedRace);
        rebuildUpList(null, 0);
        loadRacePlayers(selectedRace);

    });
}


function loadPlayerBets() {

    if (!selectedRace || !selectedPlayers.length) return;

    let targetId = selectedPlayers[currentPlayerIndex].identifier;
    let raceId = selectedRace.id;

    $.post('https://frkn-racingv2/getBets', JSON.stringify({}), function (bets) {

        bets = bets || [];
        $('.total-list').empty();

        let filtered = bets.filter(b =>
            Number(b.race_id) === Number(raceId) &&
            b.target_identifier === targetId
        );

        if (filtered.length === 0) {
            $('.total-list').html(`
                <div class="total-item">
                    <div class="race-name">${t('betting.no_bets')}</div>
                </div>
            `);
            return;
        }

        $.post('https://frkn-racingv2/getAlias', JSON.stringify({}), function (aliasData) {

            aliasData = aliasData || {};

            filtered.forEach(b => {

                let bettorId = b.bettor_identifier;

                let aliasEntry = aliasData[bettorId] || {};

                let bettorAlias = aliasEntry.alias || "Unknown";
                let bettorAvatar = aliasEntry.data?.avatar || "../html/images/user-icon.svg";

                let type = selectedRace.type ? selectedRace.type.toUpperCase() : "CAR";
                let raw = (raceTypeToCategory && raceTypeToCategory[type]) ? (categoryImages[raceTypeToCategory[type]] || "car") : (categoryImages[type] || "car");
                let img = `race-${raw}.png`;

                $('.total-list').append(`
                    <div class="total-item">
                        <img src="${bettorAvatar}" class="race-img">
                        <div class="race-name">${bettorAlias}</div>
                        <div class="race-desc">$ ${b.amount}</div>
                    </div>
                `);
            });

        });
    });
}

function updatePlayerUI() {

    if (!selectedPlayers.length) {
        $(".user-name").text(t('betting.no_players'));
        $(".won-count").text("");
        $(".main-item .car-img").attr("src", "../html/images/race-car.png");
        return;
    }

    let p = selectedPlayers[currentPlayerIndex];

    let modelName = p.carName;
    let fallbackImg = "../html/images/race-car.png";

    if (!modelName || typeof modelName !== "string") {
        $(".main-item .car-img").attr("src", fallbackImg);
    } else {
        modelName = modelName.toLowerCase().replace(/\s+/g, '_');
        let playerCarImg = `https://raw.githubusercontent.com/matthias18771/v-vehicle-images/refs/heads/main/images/${modelName}.png`;

        $(".main-item .car-img")
            .attr("src", playerCarImg)
            .off("error")
            .on("error", function () {
                $(this).attr("src", fallbackImg);
            });
    }


    $(".user-name").text(p.alias || "Unknown");
    $(".won-count").text(`(${p.extraData.races_won || 0} Races Won)`);
    let pos = currentPlayerIndex + 1;
    let suffix = 'th';

    if (pos % 10 === 1 && pos % 100 !== 11) suffix = 'st';
    else if (pos % 10 === 2 && pos % 100 !== 12) suffix = 'nd';
    else if (pos % 10 === 3 && pos % 100 !== 13) suffix = 'rd';

    $('.main-item .st').text(pos + suffix);
    $(".user-button").html(`
        ${p.alias} <img src="../html/images/user-icon.svg">
    `);
    loadPlayerBets();
}


function loadRacePlayers(race) {

    if (!race) return;

    selectedRace = race;
    selectedPlayers = race.players || [];
    currentPlayerIndex = 0;

    updatePlayerUI();
}

function renderUpBig(race) {
    let type = race.type ? race.type.toUpperCase() : "CAR";
    let rawName = (raceTypeToCategory && raceTypeToCategory[type]) ? (categoryImages[raceTypeToCategory[type]] || "car") : (categoryImages[type] || "car");
    let imgName = `race-${rawName}.png`;
    $('.up-big').html(`
        <img class="car-img" src="../html/images/${imgName}">
        <div class="race-name">${race.eventName || race.name}</div>
        <div class="race-desc">${race.type || "---"}</div>
        <div class="start-text">${t('betting.ongoing')}</div>
        <div class="start-time"></div>
    `);
}

function rebuildUpList(oldRace, clickedIndex) {
    $('.up-list').empty();

    activeRaces.forEach((r, i) => {
        if (r === selectedRace) return;

        let type = r.type ? r.type.toUpperCase() : "CAR";
        let raw = (raceTypeToCategory && raceTypeToCategory[type]) ? (categoryImages[raceTypeToCategory[type]] || "car") : (categoryImages[type] || "car");
        let img = `race-${raw}.png`;

        $('.up-list').append(`
            <div class="up-item" data-index="${i}">
                <img class="race-img" src="../html/images/${img}">
                <div class="race-name">${r.eventName || r.name}</div>
                <div class="race-desc">${r.type || "---"}</div>
            </div>
        `);
    });
}


$(document).on("click", ".up-big", function () {
    loadRacePlayers(activeRaces[0]);
});

$(document).on("click", ".up-item", function () {
    let newIndex = Number($(this).data('index'));

    let newRace = activeRaces[newIndex];
    let oldRace = selectedRace;

    selectedRace = newRace;

    renderUpBig(newRace);
    rebuildUpList(oldRace, newIndex);

    loadRacePlayers(newRace);
});

let currentBetAmount = 0;

$(document).on('input', '.bet-input', function () {
    let val = Number($(this).val());
    currentBetAmount = val > 0 ? val : 0;

    $('.place-bet').text(`$ ${currentBetAmount.toLocaleString()}`);
});

$(document).on('click', '.cancel-button', function () {
    if (!selectedRace) return openNotify("error", t('betting.bet_error'), t('betting.no_race_selected'));
    if (!selectedPlayers.length) return openNotify("error", t('betting.bet_error'), t('betting.no_players'));

    let player = selectedPlayers[currentPlayerIndex];
    let betAmount = currentBetAmount;

    if (betAmount <= 0) {
        return openNotify("error", t('betting.bet_error'), t('betting.invalid_amount'));
    }

    $.post('https://frkn-racingv2/placeBet', JSON.stringify({
        raceId: selectedRace.id,
        playerId: player.identifier,
        betAmount: betAmount
    }), function (response) {
        if (response && response.type && response.message) {
            openNotify(response.type, response.header || "", response.message);
        }

        loadPlayerBets();
        $('.bet-input').val('');
        currentBetAmount = 0;
        $('.place-bet').text(`$ 0`);
    });
});

$(document).on('click', '.place-box', function () {
    $('.bet-input').val('');
    currentBetAmount = 0;
    $('.place-bet').text(`$ 0`);
});



$(document).off('click', '.past-accept');
$(document).on('click', '.past-accept', function () {
    let cid = $(this).closest('.past-item').data('cid');

    $.post('https://frkn-racingv2/acceptCrewRequest', JSON.stringify({
        cid: cid
    }));

    setTimeout(() => {
        $('.menu-item[data-page="crew-page"]').trigger('click');

    }, 200);
});

$(document).off('click', '.past-deny');
$(document).on('click', '.past-deny', function () {
    let cid = $(this).closest('.past-item').data('cid');

    $.post('https://frkn-racingv2/denyCrewRequest', JSON.stringify({
        cid: cid
    }));

    setTimeout(() => {
        $('.menu-item[data-page="crew-page"]').trigger('click');

    }, 200);
});



$(document).on('click', '.garage-page .vehicle-item', function () {
    const plate = $(this).data('plate');

    $('.garage-page .vehicle-item').removeClass('selected-vehicle');
    $(this).addClass('selected-vehicle');
    $.post('https://frkn-racingv2/selectGarageCar', JSON.stringify({ plate: plate }), function (response) {
        openNotify(response.type, response.header, response.message);

        $.post('https://frkn-racingv2/getPlayerGarage', JSON.stringify({}), function (data) {
            loadGaragePage(data.vehicles);
        });
    });
});


function loadGaragePage(vehicles) {
    const list = $('.garage-page .vehicle-list');
    const historyBox = $('.race-history');
    const storyList = $('.story-list');

    list.empty();
    historyBox.find('.history-row').remove();
    storyList.empty();

    let selectedCar = null;

    vehicles.forEach(v => {
        let modelRaw = v.model || t('garage.unknown_model');
        let modelName = String(modelRaw).toLowerCase().replace(/\s+/g, '_');
        let displayName = modelName.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase());
        const img = `https://raw.githubusercontent.com/matthias18771/v-vehicle-images/refs/heads/main/images/${modelName}.png`;
        const fallbackImg = '../html/images/race-car.png';

        if (v.stats.selected === 1) selectedCar = v;

        let activeClass = v.stats.selected === 1 ? "selected-vehicle" : "";

        list.append(`
            <div class="vehicle-item ${activeClass}" data-plate="${v.plate}">
                <img src="${img}" class="car-img" onerror="this.onerror=null;this.src='${fallbackImg}';">
                <div class="car-name">${displayName}</div>
            </div>
        `);
    });

    if (!selectedCar && vehicles.length > 0) {
        selectedCar = vehicles[0];
    }

    if (!selectedCar) return;

    setGarageMain(selectedCar);

    $.post('https://frkn-racingv2/getRaces', JSON.stringify({}), function (races) {
        if (!Array.isArray(races)) return;

        let plate = selectedCar.plate;
        let carHistory = [];
        let myStory = [];

        races.forEach(race => {
            if (!Array.isArray(race.raceResult)) return;

            race.raceResult.forEach(res => {

                if (res.carPlate && res.carPlate.toUpperCase() === plate.toUpperCase()) {
                    carHistory.push({
                        raceName: race.type || t('garage.race_default'),
                        trackName: race.eventName || t('garage.unknown_track'),
                        position: res.position
                    });
                }

                if (res.identifier === identifier) {
                    myStory.push({
                        raceName: race.type || t('garage.race_default'),
                        position: res.position,
                        cash: res.cash || 0,
                        time: res.timestamp
                    });
                }
            });
        });

        if (!carHistory.length) {
            historyBox.append(`
                <div class="history-row">
                    <span>-</span>
                    <span>${t('garage.no_races')}</span>
                    <span class="pos">-</span>
                </div>
            `);
        } else {
            carHistory.forEach(h => {
                let suffix = t('garage.suffix_th');
                if (h.position === 1) suffix = t('garage.suffix_st');
                else if (h.position === 2) suffix = t('garage.suffix_nd');
                else if (h.position === 3) suffix = t('garage.suffix_rd');

                historyBox.append(`
                    <div class="history-row">
                        <span>${h.raceName}</span>
                        <span>${h.trackName}</span>
                        <span class="pos pos-${h.position}">${h.position}${suffix}</span>
                    </div>
                `);
            });
        }

        if (!myStory.length) {
            storyList.append(`
                <div class="story-item">
                    <span class="race-name">${t('garage.no_races_yet')}</span>
                    <div class="right-group">
                        <span class="race-pos">-</span>
                        <span class="race-date">-</span>
                        <span class="race-money">-</span>
                    </div>
                </div>
            `);
        } else {
            myStory.forEach(s => {
                let suffix = t('garage.suffix_th');
                if (s.position === 1) suffix = t('garage.suffix_st');
                else if (s.position === 2) suffix = t('garage.suffix_nd');
                else if (s.position === 3) suffix = t('garage.suffix_rd');

                let d = new Date(s.time * 1000);
                let dateText = d.toLocaleDateString('en-GB', {
                    day: '2-digit',
                    month: 'short'
                });

                let moneyText = s.cash > 0 ? `+$${s.cash.toLocaleString()}` : "-";

                storyList.append(`
                    <div class="story-item">
                        <span class="race-name">${s.raceName}</span>
                        <div class="right-group">
                            <span class="race-pos">${s.position}${suffix}</span>
                            <span class="race-date">${dateText}</span>
                            <span class="race-money">${moneyText}</span>
                        </div>
                    </div>
                `);
            });
        }
    });
}


function setGarageMain(car) {
    const modelRaw = car.model || "Unknown";
    const modelName = String(modelRaw).toLowerCase().replace(/\s+/g, '_');
    const displayName = modelName.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase());
    const category = car.category || "Sport";
    const img = `https://raw.githubusercontent.com/matthias18771/v-vehicle-images/refs/heads/main/images/${modelName}.png`;
    const fallbackImg = '../html/images/race-car.png';

    $('.garage-page .main-box .car-name').text(displayName);
    $('.garage-page .main-box .car-category').text(category);
    $('.garage-page .main-box .car-img')
        .attr('src', img)
        .off('error')
        .on('error', function () { $(this).off('error').attr('src', fallbackImg); });

    $('.garage-page .stat-box:eq(0) .stat-value').text(car.stats.total_races || 0);
    $('.garage-page .stat-box:eq(1) .stat-value').text(car.stats.total_wins || 0);
    $('.garage-page .stat-box:eq(2) .stat-value').text(numberWithDots(car.stats.total_xp || 0));

    setHistory(car.stats.history || []);
    setStoryList(car.stats.story || []);
}

function numberWithDots(x) {
    if (x == null) return "0";
    return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
}

function setHistory(history) {
    const box = $('.garage-page .race-history');
    box.find('.history-row').remove();

    history.forEach(h => {
        let posClass = "";
        if (h.position === 1) posClass = "pos-1";
        else if (h.position === 2) posClass = "pos-2";
        else if (h.position === 3) posClass = "pos-3";

        let html = `
            <div class="history-row">
                <span>${h.race}</span>
                <span>${h.track}</span>
                <span class="pos ${posClass}">${h.position}st</span>
            </div>
        `;
        box.append(html);
    });
}

function setStoryList(listData) {
    const box = $('.garage-page .story-list');
    box.empty();

    listData.forEach(s => {
        let color = s.money >= 0 ? "green" : "red";
        let html = `
            <div class="story-item">
                <span class="race-name">${s.race}</span>
                <div class="right-group">
                    <span class="race-pos">${s.position}st</span>
                    <span class="race-date">${s.date}</span>
                    <span class="race-money" style="color:${color}">${s.money >= 0 ? "+" : ""}$${s.money}</span>
                </div>
            </div>
        `;
        box.append(html);
    });
}


$(document).on('click', '.reward-claim', function () {
    let el = $(this);
    let rewardId = el.data('id');


    $.post('https://frkn-racingv2/claimReward', JSON.stringify({
        id: rewardId
    }), function (resp) {

        if (resp.type !== "success") return;

        let rw = resp.reward;
        if (rw.type === "money") {
            $('.box-body .img').attr("src", "/images/money.png");
        }

        if (rw.type === "item") {
            $('.box-body .img').attr(
                "src",
                resp.inventoryPath + rw.itemName + ".png"
            );
        }

        if (rw.type === "car") {
            $('.box-body .img').attr(
                "src",
                "https://raw.githubusercontent.com/matthias18771/v-vehicle-images/refs/heads/main/images/"
                + rw.carModel + ".png"
            );
        }
        $('.popup-bg').fadeIn(0);
        $('.crew-page .container').css('display', 'flex');
        $('.box-body').addClass('active');

        el.removeClass('reward-claim').addClass('reward-disabled');
        el.find('.claimable-text').remove();
        el.find('.player-name').append(" <span class='claimed-text'>(Claimed)</span>");
    });

    setTimeout(() => {
        $('.box-body').removeClass('active');
        $('.crew-page .container').css('display', 'none');
        $('.popup-bg').fadeOut(0);
    }, 3500);
});


function GetPlayerNameFormatted(identifier) {
    return "Player " + identifier;
}

$(document).on('click', '.chat-box .sent-icon', function () {
    sendCrewMessage();
});

$('.crew-page .message-input').on('keypress', function (e) {
    if (e.which === 13) {
        sendCrewMessage();
    }
});

function sendCrewMessage() {
    let text = $('.crew-page .message-input').val().trim();
    if (text.length === 0) return;

    $.post('https://frkn-racingv2/sendCrewMessage', JSON.stringify({
        message: text
    }), function (resp) {
        syncEmbeddedCrewChat();
    });

    $('.crew-page .message-input').val('');
}

function updateCrewMessages(msgs) {
    let list = $('.crew-page .messages-list');
    list.empty();

    let aliasData = window.crewAliasData || {};

    msgs.forEach(m => {

        let aliasName = GetAliasName(m.identifier, aliasData);

        let timeText = "";
        if (m.time) {
            let d = new Date(m.time * 1000);
            let hh = d.getHours().toString().padStart(2, '0');
            let mm = d.getMinutes().toString().padStart(2, '0');
            timeText = `[${hh}:${mm}]`;
        }

        let row = `
            <div class="msg-item">
                <p class="msg-text">${aliasName} : ${m.text} <span class="msg-time">${timeText}</span></p>
            </div>
        `;
        list.append(row);
    });

    setTimeout(() => {
        list.scrollTop(list[0].scrollHeight);
    }, 10);
}



$(document).on('click', '.fire-icon', function () {
    let targetId = $(this).attr('data-id');
    if (!targetId) return;
    if (playerCrew.owner_identifier !== identifier) return;

    $.post('https://frkn-racingv2/kickMember', JSON.stringify({
        crewId: playerCrew.id,
        memberId: targetId
    }), function (resp) {
        openNotify(resp.type, resp.header, resp.message);
        setTimeout(function () {
            $('.menu-item[data-page="crew-page"]').trigger('click');
        }, 300);
    });
});


$(document).on('click', '.delete-crew', function () {
    if (!playerCrew) return;

    $.post('https://frkn-racingv2/deleteCrew', JSON.stringify({
        id: playerCrew.id
    }), function (resp) {
        openNotify(resp.type, resp.header, resp.message);

        if (resp.type === "success") {
            playerCrew = null;

            setTimeout(function () {
                $('.menu-item[data-page="crew-page"]').trigger('click');
            }, 300);
        }
    });
});

$(document).on('click', '.settings-page-toggle span', function () {
    $(this).addClass('active').siblings().removeClass('active');

    let isOn = $(this).hasClass('settings-page-on');
    localStorage.setItem('altNotify', isOn ? '1' : '0');
});


$(document).on('click', '.change-avatar', function () {
    $('.change-avatar-box , .popup-bg').fadeIn(0).css('display', 'flex');
    $('.change-avatar-box .head').text(t('profile.change_avatar'));
    $('.change-avatar-box .des').text(t('profile.change_avatar_desc'));
    $('.avatar-input').attr('placeholder', t('profile.change_avatar_placeholder')).val('');
    $('.change-avatar-box').data('mode', 'avatar');
});

$(document).on('click', '.change-name', function () {
    $('.change-avatar-box , .popup-bg').fadeIn(0).css('display', 'flex');
    $('.change-avatar-box .head').text(t('profile.change_name'));
    $('.change-avatar-box .des').text(t('profile.change_name_desc'));
    $('.avatar-input').attr('placeholder', t('profile.change_name_placeholder')).val('');
    $('.change-avatar-box').data('mode', 'name');
});

$(document).on('click', '.save', function () {
    let mode = $('.change-avatar-box').data('mode');
    let value = $('.profile-page .avatar-input').val();
    if (!value || value.trim() === '') return;

    if (mode === 'avatar') {
        $.post('https://frkn-racingv2/changeAvatar', JSON.stringify({
            avatar: value
        }));
        openNotify('success', t('profile.avatar_updated'), t('profile.avatar_updated_desc'));
        $('.profile-page .avatar , .profile-img').attr('src', value);
    }

    if (mode === 'name') {
        $.post('https://frkn-racingv2/changeName', JSON.stringify({
            name: value
        }));
        openNotify('success', t('profile.name_updated'), t('profile.name_updated_desc'));
        $('.profile-page .profil-name , .profil-det .name').text(value);
    }

    $('.change-avatar-box , .popup-bg').fadeOut(0);
});

$(document).on('click', '.checkpoint-color .color-item', function () {
    $(".checkpoint-color .color-item").removeClass("active").css("box-shadow", "none");

    $(this).addClass("active");

    let hex = $(this).data("color");
    $(this).css("box-shadow", `0 0 12px ${hex}, 0 0 6px ${hex}`);

    $.post('https://frkn-racingv2/changeColor', JSON.stringify({
        type: 'checkpointcolor',
        color: hex
    }));
});


$(document).on('click', '.gps-color .color-item', function () {
    $(".gps-color .color-item").removeClass("active").css("box-shadow", "none");

    $(this).addClass("active");

    let hex = $(this).data("color");
    $(this).css("box-shadow", `0 0 12px ${hex}, 0 0 6px ${hex}`);

    $.post('https://frkn-racingv2/changeColor', JSON.stringify({
        type: 'gpscolor',
        color: hex
    }));
});




$(document).on('click', '.settings-page-value', function (e) {
    e.stopPropagation()

    const dropdown = $(this).siblings('.settings-page-lang-dropdown')
    $('.settings-page-lang-dropdown').not(dropdown).hide()
    dropdown.toggle()
})

$(document).on('click', '.settings-page-lang-dropdown div', function () {
    const lang = $(this).data('lang-code')
    const parent = $(this).closest('.settings-page-dropdown-wrapper')

    setLanguage(lang)
    localStorage.setItem('ui_language', lang)

    parent.find('.settings-page-value').html(`
        ${t($(this).data('lang'))}
        <svg xmlns="http://www.w3.org/2000/svg" width="8" height="13" viewBox="0 0 8 13">
            <path d="M0.73999 0.672852L5.73999 6.17285L0.73999 11.6729"
                  stroke="white" stroke-opacity="0.28" stroke-width="2"/>
        </svg>
    `)

    parent.find('.settings-page-lang-dropdown').hide()
})

$(document).on('click', function () {
    $('.settings-page-lang-dropdown').hide();
});


$(document).on('click', '.settings-page-dropdown', function () {
    const menu = $(this).next('.settings-page-dropdown-menu');
    $('.settings-page-dropdown-menu').not(menu).hide();
    menu.toggle();
});

$(document).on('click', '.settings-page-dropdown-menu div', function () {
    const text = $(this).data('value');
    $(this).closest('.settings-page-dropdown-wrapper2').find('.settings-page-dropdown').text(text);
    $('.settings-page-dropdown-menu').hide();
});

$(document).on('click', function (e) {
    if (!$(e.target).closest('.settings-page-dropdown-wrapper2').length) {
        $('.settings-page-dropdown-menu').hide();
    }
});


function brightenColor(color, percent) {
    let num = parseInt(color.replace("#", ""), 16),
        r = (num >> 16),
        g = (num >> 8) & 0x00FF,
        b = num & 0x0000FF;

    r = Math.min(255, r + (255 - r) * percent);
    g = Math.min(255, g + (255 - g) * percent);
    b = Math.min(255, b + (255 - b) * percent);

    return "#" + (
        (1 << 24) + (Math.round(r) << 16) + (Math.round(g) << 8) + (Math.round(b) << 0)
    ).toString(16).slice(1).toUpperCase();
}

function rgbToHex(rgb) {
    let result = rgb.match(/\d+/g);
    return "#" +
        ("0" + parseInt(result[0]).toString(16)).slice(-2) +
        ("0" + parseInt(result[1]).toString(16)).slice(-2) +
        ("0" + parseInt(result[2]).toString(16)).slice(-2);
}

$(".color-item").hover(
    function () {
        if ($(this).hasClass("active")) return;

        let original = $(this).css("background-color");
        let hex = rgbToHex(original);
        let bright = brightenColor(hex, 0.25);

        $(this).attr("data-original", hex);
        $(this).css("background-color", bright);
        $(this).css("box-shadow", `0 0 12px ${bright}, 0 0 6px ${bright}`);
    },
    function () {
        if ($(this).hasClass("active")) return;

        let original = $(this).attr("data-original");
        $(this).css("background-color", original);
        $(this).css("box-shadow", "none");
    }
);
$(document).on('click', '.cancel-btn', function () {
    $('.col-track-details .desc-input').prop('disabled', false);
    $('.col-track-details .select-box select').prop('disabled', false);
    $('.col-track-details .desc-input').val('');
    $('.continue-btn').attr('data-lang', 'create_advanced.new_track').text(t('create_advanced.new_track'));
    $('.cancel-btn').hide();
    $('.track-page , .advanced-settings , .tablet').fadeOut(150);
    $.post('https://frkn-racingv2/cancelTrack', JSON.stringify({}), function (response) {
        openNotify(response.type, response.header, response.message);
    });
});

$(document).on('keypress', '.col-track-details input.desc-input', function (e) {
    if (e.which === 13) {
        e.preventDefault();
        let btn = $('.continue-btn');
        if (btn.is(':visible') && btn.text() === t('create_advanced.save')) {
            btn.trigger('click');
        }
    }
});

$(document).on('click', '.continue-btn', function () {
    let btn = $(this);
    if (btn.text() === t('create_advanced.new_track')) {
        let type = $('.col-track-details .select-box select').val();
        let name = $('.col-track-details input.desc-input').val().trim();
        let desc = $('.col-track-details textarea.desc-input').val().trim();

        if (!type || type === "" || type === null) {
            openNotify("error", t('create_advanced.missing_field'), t('create_advanced.select_type_error'));
            return;
        }

        if (name.length === 0) {
            openNotify("error", t('create_advanced.missing_field'), t('create_advanced.enter_name_error'));
            return;
        }

        if (desc.length === 0) {
            openNotify("error", t('create_advanced.missing_field'), t('create_advanced.enter_desc_error'));
            return;
        }

        $.post('https://frkn-racingv2/createTrack', JSON.stringify({
            selectedMode: type,
            name: name,
            description: desc
        }), function (response) {

            openNotify(response.type, response.header, response.message);

            if (!response.success) return;

            if (type === "JETSKI") {
                $('.rotate-left').text(t('create_advanced.move_down'));
                $('.rotate-right').text(t('create_advanced.move_up'));
            } else {
                $('.rotate-left').text(t('create_advanced.rotate_left'));
                $('.rotate-right').text(t('create_advanced.rotate_right'));
            }

            $('.tablet').fadeOut();
            $('.track-page').fadeIn();
            $('.track-page .type-value').text(type);

            $('.col-track-details .desc-input').prop('disabled', true);
            $('.col-track-details .select-box select').prop('disabled', true);
            $('.cancel-btn').show();

            btn.attr('data-lang', 'create_advanced.save').text(t('create_advanced.save'));
            trackControl = true;
        });

        return;
    }

    if (btn.text() === t('create_advanced.save')) {
        $('.col-track-details .desc-input').prop('disabled', false);
        $('.col-track-details .select-box select').prop('disabled', false);
        $('.continue-btn').attr('data-lang', 'create_advanced.new_track').text(t('create_advanced.new_track'));
        $('.cancel-btn').hide();
        $('.advanced-settings , .track-page').fadeOut(150);
        trackControl = false;
        $.post('https://frkn-racingv2/finishTrack', JSON.stringify({
            finish: true,
            trackName: $('.col-track-details input.desc-input').val().trim(),
            trackDesc: $('.col-track-details textarea.desc-input').val().trim()
        }), function (response) {
            openNotify(response.type, response.header, response.message);

            if (response.type === 'success') {
                setTimeout(function () {
                    let col = $('.col-track-details');
                    let formFields = col.find('.field-group');
                    let mapWrapper = col.find('.map-grid-wrapper');
                    let continueBtn2 = col.find('.continue-btn');
                    let createTrackBtn = col.find('.create-track');

                    formFields.slideUp(200);
                    continueBtn2.hide();
                    mapWrapper.slideDown(200);
                    col.find('.col-title').text(t('create_advanced.select_track_header'));
                    col.find('.col-desc').text(t('create_advanced.select_track_desc'));
                    createTrackBtn.text(t('create.back'));

                    $.post('https://frkn-racingv2/getTracks', JSON.stringify({}), function (tracks) {
                        if (tracks && tracks.length > 0) {
                            renderTrackCards(tracks);
                            setTimeout(function () {
                                let firstCard = $('.track-card').first();
                                if (firstCard.length) {
                                    firstCard.trigger('click');
                                }
                            }, 300);
                        }
                    });
                }, 500);
            }
        });

        $('.rotate-left').text(t('create_advanced.rotate_left'));
        $('.rotate-right').text(t('create_advanced.rotate_right'));

        $('.col-track-details .desc-input').val('');
        return;
    }
});

$(document).on('click', '.createcrew-btn', function () {

    let name = $('.createcrew-box .desc-input').eq(0).val().trim();
    let desc = $('.createcrew-box .desc-input').eq(1).val().trim();

    if (name.length === 0) {
        openNotify("error", t('crew_page.missing_field'), t('crew_page.enter_name_error'));
        return;
    }

    if (desc.length === 0) {
        openNotify("error", t('crew_page.missing_field'), t('crew_page.enter_desc_error'));
        return;
    }

    $.post('https://frkn-racingv2/createCrew', JSON.stringify({
        crew_name: name,
        crew_description: desc
    }), function (response) {
        openNotify(response.type, response.header, response.message);
        $('.createcrew-box').fadeOut(150);
        $('.createcrew-box .desc-input').val('');
        setTimeout(function () {
            $('.menu-item[data-page="crew-page"]').trigger('click');
        }, 300);
    });

});

$(document).on('click', '.createcrew-box .cancel-btn', function () {
    $('.createcrew-box').fadeOut(150);
    $('.createcrew-box .desc-input').val('');
});


function setActiveProp(e) {
    let index = e.index - 1;

    $('.obj-item').removeClass('active');
    $('.obj-item').eq(index).addClass('active');
}


function addCPItem(e) {
    let index = e.index;
    let x = e.x;
    let y = e.y;

    $('.cp-list').append(`
        <div class="cp-item" data-index="${index}">
            <div class="cp-index">${index}</div>
            <div class="cp-text">X: ${x.toFixed(3)} Y: ${y.toFixed(3)}</div>
            <div class="cp-delete"></div>
        </div>
    `);

    updateCPCount();
}

function removeCPItem(e) {
    let index = e.index;

    $(`.cp-item[data-index="${index}"]`).remove();

    $('.cp-item').each(function (i) {
        let newIndex = i + 1;
        $(this).attr('data-index', newIndex);
        $(this).find('.cp-index').text(newIndex);
    });

    updateCPCount();
}

function updateCPCount() {
    let count = $('.cp-item').length;
    $('.cp-title').text(`Checkpoints (${count})`);
}



$(document).on('click', '.col-track-details .create-track', function () {
    let col = $('.col-track-details');
    let formFields = col.find('.field-group');
    let mapWrapper = col.find('.map-grid-wrapper');
    let continueBtn = col.find('.continue-btn');
    let btn = $(this);

    if (mapWrapper.is(':visible')) {
        mapWrapper.slideUp(200);
        formFields.slideDown(200);
        continueBtn.show();
        col.find('.col-title').text(t('create_advanced.track_details'));
        col.find('.col-desc').text(t('create_advanced.track_desc'));
        btn.text(t('create.select_track'));
    } else {
        formFields.slideUp(200);
        continueBtn.hide();
        mapWrapper.slideDown(200);
        col.find('.col-title').text(t('create_advanced.select_track_header'));
        col.find('.col-desc').text(t('create_advanced.select_track_desc'));
        btn.text(t('create.back'));

        $.post('https://frkn-racingv2/getTracks', JSON.stringify({}), function (tracks) {
            if (tracks && tracks.length > 0) {
                if (window._pendingCategoryFilter) {
                    applyCategoryFilter(tracks, window._pendingCategoryFilter);
                    window._pendingCategoryFilter = null;
                } else {
                    renderTrackCards(tracks);
                }
            }
        });
    }
})

$(document).on('change', '.col-track-details .select-box select', function () {
    let val = $(this).val();

    if (!val) {
        $('.race-type-selector .selector-text').text('-');
        $('.race-type-selector .arrow-left, .race-type-selector .arrow-right').removeClass('disabled-arrow');

        $('.category-item').removeClass('active');
        let allCategory = $('.category-item[data-bg="all"]');
        if (allCategory.length) {
            allCategory.addClass('active');
            const theme = categoryThemes['all'];
            if (theme) {
                document.documentElement.style.setProperty('--category-color', theme.color);
                document.documentElement.style.setProperty('--category-rgb', theme.rgb);
                document.documentElement.style.setProperty('--category-shadow', theme.shadow);
                document.documentElement.style.setProperty('--category-bg', theme.bg);
            }
        }

        window._specialCategoryMode = null;
        window._formulaMode = false;
        window._pendingCategoryFilter = null;
        $('.type-select-box').show();
        $('.enableAlerts-toggle').closest('.toggle-row').show();

        let col = $('.col-track-details');
        let mapWrapper = col.find('.map-grid-wrapper');
        if (mapWrapper.is(':visible')) {
            mapWrapper.slideUp(200);
            col.find('.field-group').slideDown(200);
            col.find('.continue-btn').show();
            col.find('.col-title').text(t('create_advanced.track_details'));
            col.find('.col-desc').text(t('create_advanced.track_desc'));
            col.find('.create-track').text(t('create.select_track'));
        }
        col.find('.create-track').show();
        return;
    }

    $('.race-type-selector .selector-text').text(val);
    $('.race-type-selector .arrow-left, .race-type-selector .arrow-right').addClass('disabled-arrow');

    let dropdownToCategoryBg = { 'FORMULA': 'formula', 'JETSKI': 'jetski', 'PLANE': 'airplane', 'CAR': 'car', 'BIKE': 'motorcycle', 'DRIFT': 'drift' };
    let categoryBg = dropdownToCategoryBg[val];

    if (categoryBg) {
        let matchingCategory = $(`.category-item[data-bg="${categoryBg}"]`);
        if (matchingCategory.length && !matchingCategory.hasClass('active')) {
            $('.category-item').removeClass('active');
            matchingCategory.addClass('active');
            const theme = categoryThemes[categoryBg];
            if (theme) {
                document.documentElement.style.setProperty('--category-color', theme.color);
                document.documentElement.style.setProperty('--category-rgb', theme.rgb);
                document.documentElement.style.setProperty('--category-shadow', theme.shadow);
                document.documentElement.style.setProperty('--category-bg', theme.bg);
            }
            const img = matchingCategory.data('img');
            if (img) $('#previewImg').attr('src', img);

            const filterType = categoryBg;
            $.post('https://frkn-racingv2/getRaces', JSON.stringify({}), function (response) {
                cachedRaces = response || [];
                renderRaceList(filterType);
                renderFinishedRaces(filterType, $('.rh-filter-btn.active').data('filter') === 'my');
            });
        }
    }

    let categoryMap = { 'FORMULA': 'formula', 'JETSKI': 'jetski', 'PLANE': 'airplane' };
    let configKey = categoryMap[val];
    let categoryTrackNames = configKey && window._categoryTracks ? window._categoryTracks[configKey] : null;

    if (categoryTrackNames && categoryTrackNames.length > 0) {
        window._specialCategoryMode = configKey;
        window._pendingCategoryFilter = categoryTrackNames;
        window._formulaMode = (configKey === 'formula');

        $('.type-select-box').hide();

        let mapWrapper = $('.col-track-details .map-grid-wrapper');
        if (mapWrapper.is(':visible')) {
            mapWrapper.hide();
        }
        $('.col-track-details .create-track').show();
        setTimeout(function () {
            $('.col-track-details .create-track').trigger('click');
            setTimeout(function () {
                $('.col-track-details .create-track').hide();
            }, 300);
        }, 50);
    } else {
        window._specialCategoryMode = null;
        window._formulaMode = false;
        window._pendingCategoryFilter = null;

        $('.type-select-box').show();
        $('.enableAlerts-toggle').closest('.toggle-row').show();

        let col = $('.col-track-details');
        col.find('.create-track').css('display', 'flex').show();

        let mapWrapper = col.find('.map-grid-wrapper');
        if (mapWrapper.is(':visible')) {
            mapWrapper.slideUp(200);
            col.find('.field-group').slideDown(200);
            col.find('.continue-btn').show();
            col.find('.col-title').text(t('create_advanced.track_details'));
            col.find('.col-desc').text(t('create_advanced.track_desc'));
            col.find('.create-track').text(t('create.select_track'));
        }
    }
});

$(document).on('change', '.col-track-details .select-box select', function () {
    let val = $(this).val();
    if (val && val !== '') {
        if (selectedTrackId) {
            $('#col-advanced').removeClass('locked');
            $('.progress-dot[data-step="2"]').addClass('active');
        }
    } else {
        $('#col-advanced').addClass('locked');
        $('#col-options').addClass('locked');
    }
});

$(document).on('click', '.map-grid-header', function () {
    let col = $('.col-track-details');
    let mapWrapper = col.find('.map-grid-wrapper');
    let formFields = col.find('.field-group');
    let continueBtn = col.find('.continue-btn');

    col.find('.choose-map-dropdown select').val('').trigger('change');

    mapWrapper.slideUp(200);
    formFields.slideDown(200);
    continueBtn.show();
    col.find('.col-title').text(t('create_advanced.track_details'));
    col.find('.col-desc').text(t('create_advanced.track_desc'));
    col.find('.create-track').text(t('create.select_track'));
})


$(document).on('click', '.crew-create', function () {
    $('.popup-bg').toggle();
    $('.createcrew-box').css('display', 'flex').hide().fadeIn(0);
});


$(document).on('click', '.crew-leaderboard', function () {
    $('.page').fadeOut(0);
    $('.crew-leaderboard-page').css('display', 'flex').hide().fadeIn(0);

    $.post('https://frkn-racingv2/getCrews', JSON.stringify({}), function (data) {

        function GetAliasName(identifier, aliasData) {
            let aliasRow = aliasData[identifier];
            if (!aliasRow) return GetPlayerNameFormatted(identifier);
            if (aliasRow.alias && aliasRow.alias !== "") return aliasRow.alias;
            return GetPlayerNameFormatted(identifier);
        }

        let aliasData = data.alias || {};
        let leaderboard = [];

        Object.entries(aliasData).forEach(([identifier, aliasRow]) => {
            if (!aliasRow || !aliasRow.data) return;

            let aliasJSON = aliasRow.data;
            leaderboard.push({
                identifier,
                name: aliasRow.alias || GetPlayerNameFormatted(identifier),
                avatar: aliasJSON.avatar || "../html/images/default.png",
                elo: aliasJSON.rating || 0,
                normalRaces: aliasJSON.matches || 0,
                ratingRaces: aliasJSON.races_won || 0,
                score: aliasJSON.xp || 0
            });
        });

        leaderboard.sort((a, b) => b.score - a.score);

        let leaderList = $('.crew-leaderboard-page .leader-list');
        leaderList.empty();

        leaderboard.forEach((p, i) => {
            let html = `
                <div class="leader-item">
                    <img class="leader-avatar" src="${p.avatar}">

                    <div class="leader-mid">
                        <div class="leader-name">${p.name}</div>
                        ${i === 0 ? `<img class="trophy" src="../html/images/trophy.svg">` : ``}

                        <div class="leader-stats">
                            <div class="stat-block">
                                <div class="stat-title">${t('leaderboard.elo')}</div>
                                <div class="stat-value">${p.elo}</div>
                            </div>

                            <div class="stat-block">
                                <div class="stat-title">${t('leaderboard.normal_races')}</div>
                                <div class="stat-value">${p.normalRaces}</div>
                            </div>

                            <div class="stat-block">
                                <div class="stat-title">${t('leaderboard.rating_races')}</div>
                                <div class="stat-value">${p.ratingRaces}</div>
                            </div>
                        </div>
                    </div>

                    <div class="leader-line"></div>
                    <div class="leader-score">${p.score}</div>
                </div>
            `;
            leaderList.append(html);
        });

        let raceTable = $('.crew-leaderboard-page .race-table');
        raceTable.find('.race-row').remove();

        data.crews.forEach(c => {

            let crewName = c.crew_name || t('leaderboard.unknown_crew');
            let crewPoints = 0;
            let rewardText = "-";

            if (Array.isArray(data.rewards)) {
                let crewRewards = data.rewards.filter(r => Number(r.crew_id) === Number(c.id));
                if (crewRewards.length) {
                    let rd = crewRewards[0].reward || {};
                    if (rd.type === "money") rewardText = rd.money + " $";
                    else if (rd.type === "car") rewardText = rd.car;
                    else if (rd.type === "item" && rd.item) rewardText = rd.item.amount + "x " + rd.item.name;
                }
            }

            let members = [];

            if (c.owner_identifier) members.push(c.owner_identifier);
            if (Array.isArray(c.members_data)) {
                c.members_data.forEach(m => members.push(m.identifier));
            }

            members.forEach(id => {
                let aliasRow = aliasData[id];
                if (!aliasRow || !aliasRow.data) return;
                crewPoints += aliasRow.data.xp || 0;
            });

            let row = `
                <div class="race-row">
                    <div class="category-text">${crewName}</div>
                    <div class="category-text">${rewardText}</div>
                    <div>${crewPoints}</div>
                </div>
            `;
            raceTable.append(row);
        });
    });
});

$('.toggle-switch').on('click', function () {
    $(this).toggleClass('active');
});


const vehicleItems = ['NON', 'X', 'S', 'A', 'B', 'C', 'D'];
let vehicleIndex = 0;
let allowedVehicleClasses = ['NON'];

function initVehicleClassSelector() {
    $.post('https://frkn-racingv2/getVehicleClass', JSON.stringify({}), function (result) {
        if (result && result.inVehicle && result.class) {
            allowedVehicleClasses = ['NON', result.class];
            vehicleIndex = 1;
            $('.vehicle-selector .selector-text').text(result.class);
        } else {
            allowedVehicleClasses = ['NON'];
            vehicleIndex = 0;
            $('.vehicle-selector .selector-text').text('NON');
        }
    });
}

$(document).on('click', '.vehicle-selector .arrow-left', function (e) {
    e.stopPropagation();
    vehicleIndex--;
    if (vehicleIndex < 0) vehicleIndex = allowedVehicleClasses.length - 1;
    let selectedClass = allowedVehicleClasses[vehicleIndex];
    $('.vehicle-selector .selector-text').text(selectedClass);
});

$(document).on('click', '.vehicle-selector .arrow-right', function (e) {
    e.stopPropagation();
    vehicleIndex++;
    if (vehicleIndex >= allowedVehicleClasses.length) vehicleIndex = 0;
    let selectedClass = allowedVehicleClasses[vehicleIndex];
    $('.vehicle-selector .selector-text').text(selectedClass);
});


let prizeTypes = ["Cash", "Car", "None"];
let prizeIndex = 0;

$(document).on('click', '.prize-type-selector .arrow-left', function () {
    prizeIndex = (prizeIndex - 1 + prizeTypes.length) % prizeTypes.length;
    $('.prize-type-selector .selector-text').text(prizeTypes[prizeIndex]);
});

$(document).on('click', '.prize-type-selector .arrow-right', function () {
    prizeIndex = (prizeIndex + 1) % prizeTypes.length;
    $('.prize-type-selector .selector-text').text(prizeTypes[prizeIndex]);
});

let raceTypeIndex = 0;

$(document).on('click', '.race-type-selector .arrow-left', function () {
    if ($(this).hasClass('disabled-arrow')) return;
    raceTypeIndex = (raceTypeIndex - 1 + raceTypes.length) % raceTypes.length;

    let newType = raceTypes[raceTypeIndex];
    $('.race-type-selector .selector-text').text(newType);

    $(`.category-item[data-bg="${newType.toLowerCase()}"]`).trigger('click');
});

$(document).on('click', '.race-type-selector .arrow-right', function () {
    if ($(this).hasClass('disabled-arrow')) return;
    raceTypeIndex = (raceTypeIndex + 1) % raceTypes.length;

    let newType = raceTypes[raceTypeIndex];
    $('.race-type-selector .selector-text').text(newType);

    $(`.category-item[data-bg="${newType.toLowerCase()}"]`).trigger('click');
});


function updateRaceTypeFromActiveCategory() {
    let activeType = $('.category-item.active').data('bg');

    if (!activeType || activeType === 'all' || activeType === 'autorace') {
        raceTypeIndex = -1;
        $('.race-type-selector .selector-text').text('-');
        return;
    }

    raceTypeIndex = raceTypes.indexOf(activeType.toUpperCase());
    if (raceTypeIndex < 0) raceTypeIndex = 0;

    $('.race-type-selector .selector-text').text(raceTypes[raceTypeIndex]);
}

updateRaceTypeFromActiveCategory();



$('.top-item.you').each(function () {
    let lb = $(this).find('.left-box');
    if (lb.length) {
        let color = lb.css('background-color');

        let rgba0 = color.replace('rgb', 'rgba').replace(')', ', 0.00)');
        let rgba33 = color.replace('rgb', 'rgba').replace(')', ', 0.33)');

        $(this).css('background',
            `linear-gradient(90deg, ${rgba0} 29.33%, ${rgba33} 100%),
             linear-gradient(90deg, rgba(16,16,16,0.57) 0%, rgba(25,25,25,0.57) 100%)`
        );

        $(this).css('--item-color', color);
    }
});



setTyreStatus({ tl: "perfect", tr: "critic", bl: "ok", br: "ok" });

function setTyreStatus(data) {

    const posMap = {
        tl: "top-left",
        tr: "top-right",
        bl: "bottom-left",
        br: "bottom-right"
    };

    const statusMap = {
        perfect: { title: "PERFECT", subtitle: "KEEP", color: "green" },
        ok: { title: "OK", subtitle: "ATTENTION", color: "yellow" },
        critic: { title: "CRITIC", subtitle: "REPLACE", color: "red" }
    };

    $.each(data, function (pos, state) {

        let info = statusMap[state.toLowerCase()];
        let cornerClass = posMap[pos];
        let box = $(`.corner.${cornerClass}`);

        let head = box.find('.head');
        let dot = box.find('.dot');

        head.html(`${info.title} <span>${info.subtitle}</span>`);

        if (info.color === "green") {
            dot.css({ background: "#00ff55", filter: "blur(3px)" });
        } else if (info.color === "yellow") {
            dot.css({ background: "#ffee55", filter: "blur(3px)" });
        } else if (info.color === "red") {
            dot.css({ background: "#ff4444", filter: "blur(3px)" });
        }
    });
}



$(document).on('click', '.right-timer .close', function () {
    handleCloseActions();
});

$(document).on('keydown', function (e) {
    if (e.keyCode == 27) {
        handleCloseActions();
    }
});

function handleCloseActions() {
    let advButton = $('.crew-create');
    let advBox = $('.advanced-settings , .createcrew-box , .popup-bg , .change-avatar-box');

    let advOpen = advButton.hasClass('active') || advBox.is(':visible');

    if (advOpen) {
        advBox.fadeOut(150);
        return;
    }

    closeTablet();
}

$(document).on('click', '.map-icon', function (e) {
    e.stopPropagation();

    let card = $(this).closest('.track-card');

    $('.track-card').removeClass('active');
    card.addClass('active');

    selectedTrackId = card.data('id');
    $('.track-id-input').val(`${selectedTrackId} (${t('create_advanced.track_id_auto')})`);

    $.post('https://frkn-racingv2/setTracksPreview', JSON.stringify({
        trackId: selectedTrackId
    }), function (response) {
        openNotify(response.type, response.header, response.message);
    });
});

$(document).on('click', '.track-card', function () {
    $('.track-card').removeClass('active');
    $(this).addClass('active');
    selectedTrackId = $(this).data('id');
    $('.track-id-input').val(`${selectedTrackId} (${t('create_advanced.track_id_auto')})`);
    $.post('https://frkn-racingv2/setTrackGPS', JSON.stringify({
        trackId: selectedTrackId
    }), function (response) {
        openNotify(response.type, response.header, response.message);
    });
});

function closeTablet() {
    let panelVisible = $('.auto-race-panel').is(':visible');
    let raceActive = $('.race-page').is(':visible') || $('.timer-box').is(':visible');
    $('.tablet').fadeOut(0);
    if (!panelVisible && !raceActive) {
        $('body').fadeOut(0);
    }

    if (trackControl) {
        trackControl = false;
        $('.track-page , .advanced-settings').fadeOut(0);
        $('.col-track-details .desc-input').prop('disabled', false);
        $('.col-track-details .select-box select').prop('disabled', false);
        $('.col-track-details .desc-input').val('');
        $('.continue-btn').attr('data-lang', 'create_advanced.new_track').text(t('create_advanced.new_track'));
        $('.cancel-btn').hide();
        $('.cp-list').empty();
        updateCPCount();
    }

    postToTabletResource('closeTablet', {}, function () {
    });
    notifySmartTabClose();
}

let cachedTrackList = [];

function renderTrackCards(tracks, filterOverride, formulaMode) {
    cachedTrackList = tracks;
    let container = $('.track-list');
    container.empty();

    let searchQuery = $('.track-search-input').val() ? $('.track-search-input').val().toLowerCase().trim() : '';
    let filterMode = filterOverride || ($('.track-filter-btn.active').data('filter') || 'all');
    let formulaTrackId = window._formulaTrackId || 20;

    // Build list of reserved track names from CategoryTracks (formula, jetski, airplane)
    let reservedNames = [];
    if (!window._specialCategoryMode && window._categoryTracks) {
        for (let cat in window._categoryTracks) {
            let names = window._categoryTracks[cat] || [];
            names.forEach(n => reservedNames.push(n.toLowerCase()));
        }
    }

    let filtered = tracks.filter(track => {
        let name = (track.name || '').toLowerCase();
        if (searchQuery && !name.includes(searchQuery)) return false;
        if (filterMode === 'my' && identifier && track.identifier !== identifier) return false;
        // Exclude reserved category tracks when not in special category mode
        if (reservedNames.length > 0) {
            if (reservedNames.some(rn => name.includes(rn) || rn.includes(name))) return false;
        }
        return true;
    });

    const sortedTracks = [...filtered].sort((a, b) => {
        const idA = parseInt(a.id) || 0;
        const idB = parseInt(b.id) || 0;
        return idB - idA;
    });

    sortedTracks.forEach(track => {
        let name = track.name || t('lobby.unknown_track');
        let desc = track.description || t('lobby.no_desc');
        let isOwner = identifier && track.identifier === identifier;

        let isFormulaTrack = parseInt(track.id) === formulaTrackId;
        let disabledStyle = '';
        let disabledClass = '';
        if (formulaMode && !isFormulaTrack) {
            disabledStyle = 'opacity: 0.3; pointer-events: none;';
            disabledClass = 'track-disabled';
        }

        let deleteBtn = isOwner ? `<div class="track-delete-btn" data-track-id="${track.id}" title="${t('create_advanced.delete_track')}">
            <svg width="10" height="10" viewBox="0 0 24 24" fill="none"><path d="M18 6L6 18M6 6l12 12" stroke="white" stroke-width="2.5" stroke-linecap="round"/></svg>
        </div>` : '';

        let card = `
            <div class="track-card ${disabledClass}" data-id="${track.id}" style="position:relative; ${disabledStyle}">
                ${deleteBtn}
                <img src="../html/images/sprint.svg" class="track-img">
                <h3 class="track-title">${name}</h3>
                <div class="most">${t('lobby.most_used')}</div>
                <p class="track-desc">${desc}</p>
                  <svg class="info-icon" xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 14 14"
                    fill="none">
                    <path
                      d="M6.4165 9.9165H7.58317V6.4165H6.4165V9.9165ZM6.99984 5.24984C7.16512 5.24984 7.30375 5.19384 7.41575 5.08184C7.52775 4.96984 7.58356 4.83139 7.58317 4.6665C7.58278 4.50161 7.52678 4.36317 7.41517 4.25117C7.30356 4.13917 7.16512 4.08317 6.99984 4.08317C6.83456 4.08317 6.69612 4.13917 6.5845 4.25117C6.47289 4.36317 6.41689 4.50161 6.4165 4.6665C6.41612 4.83139 6.47212 4.97003 6.5845 5.08242C6.69689 5.19481 6.83534 5.25061 6.99984 5.24984ZM6.99984 12.8332C6.19289 12.8332 5.43456 12.6799 4.72484 12.3735C4.01512 12.0671 3.39775 11.6515 2.87275 11.1269C2.34775 10.6023 1.93223 9.98495 1.62617 9.27484C1.32012 8.56473 1.16689 7.80639 1.1665 6.99984C1.16612 6.19328 1.31934 5.43495 1.62617 4.72484C1.933 4.01473 2.34853 3.39737 2.87275 2.87275C3.39698 2.34814 4.01434 1.93262 4.72484 1.62617C5.43534 1.31973 6.19367 1.1665 6.99984 1.1665C7.806 1.1665 8.56434 1.31973 9.27484 1.62617C9.98534 1.93262 10.6027 2.34814 11.1269 2.87275C11.6511 3.39737 12.0669 4.01473 12.3741 4.72484C12.6813 5.43495 12.8343 6.19328 12.8332 6.99984C12.832 7.80639 12.6788 8.56473 12.3735 9.27484C12.0682 9.98495 11.6527 10.6023 11.1269 11.1269C10.6011 11.6515 9.98378 12.0673 9.27484 12.3741C8.56589 12.6809 7.80756 12.8339 6.99984 12.8332Z"
                      fill="white" />
                </svg>
                <div class="info-text">${t('lobby.info')}</div>

                <svg data-id="${track.id}" class="map-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                    <path fill="white" d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5S10.62 6.5 12 6.5s2.5 1.12 2.5 2.5S13.38 11.5 12 11.5z"/>
                </svg>
            <div class="map-text">${t('lobby.preview')}</div>

            </div>
        `;
        container.append(card);
    });

    if (sortedTracks.length > 0) {
        let firstCard = $('.track-card').first();
        firstCard.addClass('active');
        selectedTrackId = firstCard.data('id');
        $('.track-id-input').val(`${selectedTrackId} (${t('create_advanced.track_id_auto')})`);
    }
}

$(document).on('input', '.track-search-input', function () {
    renderTrackCards(cachedTrackList);
});

$(document).on('click', '.track-filter-btn', function () {
    $('.track-filter-btn').removeClass('active');
    $(this).addClass('active');
    renderTrackCards(cachedTrackList);
});

$(document).on('click', '.track-delete-btn', function (e) {
    e.stopPropagation();
    let trackId = $(this).data('track-id');
    if (!trackId) return;

    $.post('https://frkn-racingv2/deleteTrack', JSON.stringify({ id: trackId }), function (response) {
        if (response && response.type === 'success') {
            openNotify(response.type, response.header, response.message);
            cachedTrackList = cachedTrackList.filter(t => t.id != trackId);
            renderTrackCards(cachedTrackList);
        } else if (response) {
            openNotify(response.type, response.header, response.message);
        }
    });
});

$(document).on('click', '.map-grid .track-card', function (e) {
    if ($(e.target).closest('.track-delete-btn').length) return;
    $('.map-grid .track-card').removeClass('active');
    $(this).addClass('active');

    selectedTrackId = $(this).data('id');
    $('.track-id-input').val(`${selectedTrackId} (${t('create_advanced.track_id_auto')})`);

    let currentType = $('.col-track-details .select-box select').val();

    if (!currentType || currentType === '') {
        let trackData = cachedTrackList.find(t => t.id == selectedTrackId);
        if (trackData && trackData.type) {
            let typeMap = {
                'Lap': 'CAR', 'Sprint': 'CAR', 'CAR': 'CAR',
                'FORMULA': 'FORMULA', 'JETSKI': 'JETSKI', 'PLANE': 'PLANE',
                'MOTORCYCLE': 'BIKE', 'DRIFT': 'DRIFT', 'BIKE': 'BIKE'
            };
            let mappedType = typeMap[trackData.type] || trackData.type.toUpperCase();
            $('.col-track-details .select-box select').val(mappedType);
            currentType = mappedType;
        }
    }

    if (currentType && currentType !== '') {
        $('#col-advanced').removeClass('locked');
        $('.progress-dot[data-step="2"]').addClass('active');

        if ($('.col-advanced .event-name').val().trim().length > 0) {
            unlockRaceOptions();
        }
    } else {
        openNotify('error', t('create_advanced.missing_data'), t('create_advanced.select_type'));
    }
});

$(document).on('click', '.toggle-switch.password-toggle', function () {
    let input = $(this).closest('.field-group').find('input[type="password"]');
    if ($(this).hasClass('active')) {
        input.prop('disabled', false).focus();
    } else {
        input.prop('disabled', true).val('');
    }
});

function unlockRaceOptions() {
    $('#col-options').removeClass('locked');
    $('.progress-dot[data-step="3"]').addClass('active');
}

$(document).on('change input', '.col-advanced .event-name', function () {
    if ($(this).val().trim().length > 0) {
        unlockRaceOptions();
    }
});

$(document).on('click', '.col-chevron', function () {
    let targetId = $(this).data('target');
    let targetEl = $('#' + targetId);
    if (targetEl.length && targetEl.hasClass('locked')) {
        targetEl.removeClass('locked');
    }
});

var _prizeKeys = ['cash', 'car', 'none'];
var _currentPrizeIndex = 0;

function getPrizeLabel(key) {
    return t('prize_options.' + key);
}

function updatePrizeDisplay() {
    $('.prize-type-selector .selector-text').text(getPrizeLabel(_prizeKeys[_currentPrizeIndex]));
}

function cyclePrizeType(direction) {
    _currentPrizeIndex = (_currentPrizeIndex + direction + _prizeKeys.length) % _prizeKeys.length;
    updatePrizeDisplay();
}

$(document).on('click', '.prize-type-selector .arrow-right', function (e) {
    e.stopPropagation();
    cyclePrizeType(1);
});

$(document).on('click', '.prize-type-selector .arrow-left', function (e) {
    e.stopPropagation();
    cyclePrizeType(-1);
});

$('.category-item').each(function () {
    let bg = $(this).data('bg').toString().toUpperCase();
    categoryImages[bg] = bg.toLowerCase();
});

function renderFinishedRaces(selectedType, myOnly) {
    $('.race-history-list').empty();

    const finished = cachedRaces.filter(race => {
        let raceEnded = Array.isArray(race.raceResult) && race.raceResult.length > 0;
        if (!raceEnded) return false;

        if (myOnly && identifier) {
            let participated = race.raceResult.some(r => r.identifier === identifier) || race.creator === identifier;
            if (!participated) return false;
        }

        if (!selectedType) return true;
        if (selectedType === 'autorace') return race.isAutoRace === true;
        if (race.isAutoRace) return false;
        let raceCategory = raceTypeToCategory[String(race.type).toUpperCase()] || String(race.type).toLowerCase();
        return raceCategory.toLowerCase() === String(selectedType).toLowerCase();
    });

    finished.sort((a, b) => {
        const idA = parseInt(a.id) || 0;
        const idB = parseInt(b.id) || 0;
        return idB - idA;
    });

    finished.forEach((race, index) => {
        let type = race.type ? race.type.toUpperCase() : 'CAR';
        let results = race.raceResult || [];
        let totalPlayers = results.length;
        let maxPlayers = race.maxPlayers || totalPlayers;
        let vehicleClass = race.vehicleClass || 'A';

        let dateStr = '—';
        let timeStr = '—';
        if (race.createTime) {
            let d = new Date(race.createTime * 1000);
            let dd = d.getDate().toString().padStart(2, '0');
            let mm = (d.getMonth() + 1).toString().padStart(2, '0');
            let yy = d.getFullYear().toString().slice(-2);
            dateStr = dd + '.' + mm + '.' + yy;
            timeStr = d.getHours().toString().padStart(2, '0') + ':' + d.getMinutes().toString().padStart(2, '0');
        }

        let raceType = race.raceType || 'CIRCUIT';
        let raceName = race.eventName || race.name || 'Race';
        let rank = index + 1;

        let avatarSrc = '../html/images/profil.png';
        if (results.length > 0 && allAlias) {
            let firstResult = results[0];
            let aliasRow = allAlias[firstResult.identifier];
            if (aliasRow && aliasRow.data) {
                try {
                    let parsed = typeof aliasRow.data === 'string' ? JSON.parse(aliasRow.data) : aliasRow.data;
                    if (parsed.avatar) avatarSrc = parsed.avatar;
                } catch (e) { }
            }
        }

        let rhHtml = `
            <div class="rh-item" data-id="${race.id}">
                <div class="rh-rank-wrap">
                    <img src="${avatarSrc}" class="rh-avatar">
                    <span class="rh-rank">${rank}</span>
                </div>
                <div class="rh-name">${raceName}</div>
                <div class="rh-players">${totalPlayers}/${maxPlayers}</div>

                <div class="rh-date">${dateStr}</div>
                <div class="rh-time">${timeStr}</div>
                <div class="rh-category">${raceType}</div>
                <span class="rh-view-btn" data-id="${race.id}">${t('race_history.view')}</span>
            </div>
        `;

        $('.race-history-list').append(rhHtml);
    });
}

$(document).on('click', '.rh-item', function () {
    let raceId = Number($(this).data('id'));
    if (!raceId) return;
    $('.page').fadeOut(150);
    $('.lobby-page').fadeIn(150);
    showRaceResults(raceId);
});

$(document).on('click', '.rh-filter-btn', function () {
    $('.rh-filter-btn').removeClass('active');
    $(this).addClass('active');

    const selectedType = $('.category-item.active').data('bg');
    const filterType = (selectedType === 'all') ? null : selectedType;
    const myOnly = $(this).data('filter') === 'my';
    renderFinishedRaces(filterType, myOnly);
});

function updateMyRaceBox() {
    let myRaceId = null;
    if (cachedRaces && identifier) {
        for (let i = 0; i < cachedRaces.length; i++) {
            let race = cachedRaces[i];
            let raceEnded = Array.isArray(race.raceResult) && race.raceResult.length > 0;
            if (raceEnded) continue;
            if (Array.isArray(race.players)) {
                for (let j = 0; j < race.players.length; j++) {
                    if (race.players[j].identifier === identifier) {
                        myRaceId = race.id;
                        break;
                    }
                }
            }
            if (myRaceId) break;
        }
    }
    if (myRaceId) {
        window._playerInRace = true;
        window._playerInRaceId = myRaceId;
        $('.my-race-box').data('race-id', myRaceId).fadeIn(200);
    } else {
        window._playerInRace = false;
        window._playerInRaceId = null;
        $('.my-race-box').fadeOut(200);
    }
}

$(document).on('click', '.my-race-box', function () {
    let raceId = $(this).data('race-id');
    if (!raceId) return;
    $('.page').fadeOut(150);
    $('.lobby-page').fadeIn(150);
    lobbyRender(raceId);
});



function renderRaceList(selectedType) {
    $('.upcoming-list').empty();

    const filtered = cachedRaces.filter(race => {
        let raceEnded = Array.isArray(race.raceResult) && race.raceResult.length > 0;
        if (raceEnded) return false;

        if (!selectedType) return true;
        if (selectedType === 'autorace') return race.isAutoRace === true;
        if (race.isAutoRace) return false;
        let raceCategory = raceTypeToCategory[String(race.type).toUpperCase()] || String(race.type).toLowerCase();
        return raceCategory.toLowerCase() === String(selectedType).toLowerCase();
    });

    filtered.sort((a, b) => {
        const idA = parseInt(a.id) || 0;
        const idB = parseInt(b.id) || 0;
        return idB - idA;
    });

    filtered.forEach(race => {
        let type = race.type ? race.type.toString().toUpperCase() : 'CAR';
        let id = race.id;
        let password = race.password || '';
        let mappedCategory = raceTypeToCategory[type] || type.toLowerCase();
        let rawName = categoryImages[mappedCategory] || categoryImages[type] || 'car';
        let img = `race-${rawName}.png`;

        let vehicleClass = race.vehicleClass || 'A';
        let currentPlayers = Array.isArray(race.players) ? race.players.length : 0;
        let maxPlayers = race.maxPlayers || 10;
        let buyIn = race.buyIn || 0;
        let laps = race.laps || 1;
        let raceName = race.eventName || race.name || t('race.unnamed');

        let dateStr = '—';
        let timeStr = '—';
        let countdownStr = '—';

        if (race.isAutoRace && race.createTime) {
            let d = new Date(race.createTime * 1000);
            let dd = d.getDate().toString().padStart(2, '0');
            let mm = (d.getMonth() + 1).toString().padStart(2, '0');
            let yy = d.getFullYear().toString().slice(-2);
            dateStr = dd + '.' + mm + '.' + yy;
            timeStr = d.getHours().toString().padStart(2, '0') + ':' + d.getMinutes().toString().padStart(2, '0');

            let duration = race.duration || 600;
            let endTime = race.createTime + duration;
            let now = Math.floor(Date.now() / 1000);
            let remaining = Math.max(0, endTime - now);
            let hh = Math.floor(remaining / 3600).toString().padStart(2, '0');
            let mi = Math.floor((remaining % 3600) / 60).toString().padStart(2, '0');
            let ss = (remaining % 60).toString().padStart(2, '0');
            countdownStr = hh + ':' + mi + ':' + ss;
        } else if (race.createTime) {
            let d = new Date(race.createTime * 1000);
            let dd = d.getDate().toString().padStart(2, '0');
            let mm = (d.getMonth() + 1).toString().padStart(2, '0');
            let yy = d.getFullYear().toString().slice(-2);
            dateStr = dd + '.' + mm + '.' + yy;
            timeStr = d.getHours().toString().padStart(2, '0') + ':' + d.getMinutes().toString().padStart(2, '0');
        }

        const html = `
            <div class="upcoming-item">
                <div class="race-thumb">
                    <img src="../html/images/${img}" alt="">
                    <div class="race-name-text">${raceName}</div>
                </div>
                <div class="race-data">
                    <div class="ui-countdown">${countdownStr}</div>

                    <div class="ui-players">${currentPlayers}/${maxPlayers}</div>
                    <div class="ui-prize">${buyIn > 0 ? buyIn + '$' : '—'}</div>
                    <div class="ui-lap">${laps}</div>
                    <div class="ui-date">${dateStr}</div>
                    <div class="ui-time">${timeStr}</div>
                    <div class="ui-actions">
                        <span class="btn-view" data-id="${id}">${t('upcoming_races.view')}</span>
                        ${window._playerInRaceId == id ? `<span class="btn-leave" data-id="${id}">${t('upcoming_races.leave')}</span>` : `<span class="btn-join" data-id="${id}" data-password="${password}">${t('upcoming_races.join')}</span>`}
                    </div>
                </div>
            </div>
        `;

        $('.upcoming-list').append(html);
    });

    updateMyRaceBox();
}


$(document).on('click', '#race-preview', function (e) {
    openNotify('success', 'Preview', 'Preview has been set successfully.', false, 'normal');
    $.post('https://frkn-racingv2/racepreview', JSON.stringify({ id: currentRaceId }))
})

$(document).on('click', '#set-gps', function (e) {
    openNotify('success', 'GPS Set', 'GPS has been set successfully.', false, 'normal');
    $.post('https://frkn-racingv2/setGPS', JSON.stringify({ id: currentRaceId }))
})

$(document).on('click', '#start-race', function (e) {
    $.post('https://frkn-racingv2/startRace', JSON.stringify({ id: currentRaceId }), function (response) {
        if (response.type == "success") {
            setTimeout(() => {
                openNotify(response.type, response.header, response.message, false, 'normal');
            }, 200);
            closeTablet();
        } else {
            openNotify(response.type, response.header, response.message, false, 'normal');
        }
    });
});


$(document).on('click', '#join-race', function (e) {
    joinRace(currentRaceId, "");
});

$(document).on('click', '#leave-race', function (e) {

    $.post('https://frkn-racingv2/leaveRace', JSON.stringify({ id: currentRaceId, type: 'leave' }), function (response) {
        if (response.type == "success") {
            setTimeout(() => {
                openNotify(response.type, response.header, response.message, false, 'normal');
            }, 200);
            $('.my-race-box').fadeOut(200);
            window._playerInRace = false;
            window._playerInRaceId = null;
            setTimeout(() => {
                $('.menu-item[data-page="main-page"]').trigger('click');
                setTimeout(() => {
                    let activeCategory = $('.category-item.active');
                    if (activeCategory.length) {
                        activeCategory.trigger('click');
                    }
                }, 200);
            }, 500);
        } else {
            openNotify(response.type, response.header, response.message, false, 'normal');
        }
    });

})

$(document).on('click', '#end-race', function (e) {

    $.post('https://frkn-racingv2/endRace', JSON.stringify({ id: currentRaceId }), function (response) {
        openNotify(response.type, response.header, response.message, false, 'normal')

        setTimeout(() => {
            $('.menu-item[data-page="main-page"]').trigger('click')
        }, 1000)
    })

})

function showRaceResults(raceId) {
    currentRaceId = raceId;
    $('.detail-scroll').css('top', '36%');
    $('.lobby-page .results-list').css({ 'height': '39%', 'top': '50.5%' });
    $('.lobby-page .header-box .header').text(t('lobby.race_results'));
    $('.raceuser-list').empty();
    $('.results-list').empty();
    $('.race-menu').hide();
    $('.lobby-page .time-box').css('right', '-60.5%');

    $.post('https://frkn-racingv2/getRaces', JSON.stringify({}), function (races) {

        races.forEach(race => {
            if (race.id !== raceId) return;

            $('#track-feature , #race-feature').html('| ' + t('lobby.type') + ' : ' + race.type);
            $('#buy-feature').html('| ' + t('lobby.login_prize') + ' : ' + race.buyIn + ' $');
            $('#class-feature').html('| ' + t('lobby.car_class') + ' :' + race.vehicleClass);
            $('#distance-feature').html('| ' + t('lobby.distance') + ' : ' + race.distance + ' n');
            $('#lap-feature').html('| ' + race.laps);
            $('#time-feature').html('| ' + formatTime(race.createTime));

            let results = race.raceResult || [];

            results.sort((a, b) => a.position - b.position);

            results.forEach((res, index) => {
                let aliasData = allAlias[res.identifier] || {
                    alias: res.alias,
                    data: { avatar: '../html/images/player.png', rating: 0 }
                };

                let bestLap = res.bestLapTime ? res.bestLapTime.toFixed(3) : "---";
                let finishTime = res.finishTime ? new Date(res.finishTime * 1000).toLocaleTimeString() : "---";

                $('.results-list').append(`
                    <div class="result-item">
                        <img src="${aliasData.data.avatar}" class="avatar">

                        <div class="info">
                            <div class="name">${aliasData.alias}</div>
                            <div class="badge place-${res.position}">${res.position} ${t('lobby.place_upper')}</div>
                        </div>

                        <div class="position">#${res.position}</div>

                        <div class="time-box">
                            <span>${t('lobby.best_lap')}</span>
                            <div class="join-time">${bestLap}</div>
                        </div>

                        <div class="time-box">
                            <span>${t('lobby.finish')}</span>
                            <div class="join-time">${finishTime}</div>
                        </div>

                        <div class="time-box">
                            <span>${t('lobby.reward')}</span>
                            <div class="join-time">${res.cash || 0} $</div>
                        </div>
                    </div>
                `);
            });
        });
    });
}

function refreshRaceLobby(id) {
    if (typeof selectedRaceId !== 'undefined' && selectedRaceId == id) {
        lobbyRender(id);
    }
}

function lobbyRender(raceId) {
    currentRaceId = raceId
    $('.raceuser-list').empty().hide()
    $('.detail-scroll').css('top', '42%')
    $('.lobby-page .results-list').css({ height: '34%', top: '56%' })
    $('.lobby-page .header-box .header').text(t('lobby.title'))
    $('.results-list').empty()
    $('.race-menu').empty().show()

    window._lobbyRenderCounter = (window._lobbyRenderCounter || 0) + 1;
    let thisRender = window._lobbyRenderCounter;

    $.post('https://frkn-racingv2/getRaces', JSON.stringify({}), function (races) {
        if (thisRender !== window._lobbyRenderCounter) return;

        races.forEach(race => {
            if (race.id != raceId) return

            $('#track-feature').html(`| ${t('lobby.type')} : ${race.type}`)
            $('#buy-feature').html(`| ${t('lobby.login_prize')} : ${race.buyIn} $`)
            $('#class-feature').html(`| ${t('lobby.car_class')} : ${race.vehicleClass}`)
            $('#distance-feature').html(`| ${t('lobby.distance')} : ${race.distance} n`)
            $('#lap-feature').html(`| ${t('lobby.laps')} : ${race.laps}`)
            $('#time-feature').html(`| ${formatTime(race.createTime)}`)

            if (race.isAutoRace) {
                let isPlayerJoined = race.players.some(p => p.identifier === identifier)
                $('.race-menu').html(`
                    <div id="set-gps" class="race-btn active">${t('lobby.set_gps')}</div>
                    <div id="race-preview" class="race-btn">${t('lobby.preview')}</div>
                    <div id="${isPlayerJoined ? 'leave-race' : 'join-race'}" class="race-btn">
                        ${isPlayerJoined ? t('lobby.leave_race') : t('lobby.join_race')}
                    </div>
                `)
            } else if (race.creator === identifier) {
                $('.race-menu').html(`
                    <div id="set-gps" class="race-btn active">${t('lobby.set_gps')}</div>
                    <div id="race-preview" class="race-btn">${t('lobby.preview')}</div>
                    <div id="start-race" class="race-btn">${t('lobby.start_race')}</div>
                    <div id="end-race" class="race-btn">${t('lobby.end_race')}</div>
                `)
            } else {
                let isPlayerJoined = race.players.some(p => p.identifier === identifier)

                $('.race-menu').html(`
                    <div id="set-gps" class="race-btn active">${t('lobby.set_gps')}</div>
                    <div id="race-preview" class="race-btn">${t('lobby.preview')}</div>
                    <div id="${isPlayerJoined ? 'leave-race' : 'join-race'}" class="race-btn">
                        ${isPlayerJoined ? t('lobby.leave_race') : t('lobby.join_race')}
                    </div>
                `)
            }

            race.players.sort((a, b) => {
                const ratingA = allAlias[a.identifier]?.data?.rating || 0
                const ratingB = allAlias[b.identifier]?.data?.rating || 0
                return ratingB - ratingA
            })

            let seenIdentifiers = new Set();
            race.players.forEach((player, index) => {
                if (seenIdentifiers.has(player.identifier)) return;
                seenIdentifiers.add(player.identifier);

                let aliasData = allAlias[player.identifier] || {
                    alias: 'Unknown',
                    data: { avatar: '../html/images/player.png', rating: 0 }
                }

                $('.raceuser-list').append(`
                    <div class="raceuser" data-identifier="${player.identifier}">
                        <div class="number">#${index + 1}</div>
                        <div class="username">${aliasData.alias}</div>
                        <div class="place">${index + 1} ${t('lobby.place')}</div>
                        <div class="rating">${t('lobby.rating')}</div>
                        <div class="rating-text">${aliasData.data.rating}</div>
                    </div>
                `)
            })

            let seenResults = new Set();
            race.players.forEach((player, index) => {
                if (seenResults.has(player.identifier)) return;
                seenResults.add(player.identifier);

                let aliasData = allAlias[player.identifier] || {
                    alias: 'Unknown',
                    data: { avatar: '../html/images/player.png', rating: 0 }
                }

                $('.results-list').append(`
                    <div class="result-item">
                        <img src="${aliasData.data.avatar}" class="avatar">
                        <div class="info">
                            <div class="name">${aliasData.alias}</div>
                            <div class="badge place-${index + 1}">
                                ${index + 1} ${t('lobby.place').toUpperCase()}
                            </div>
                        </div>
                        <div class="position">#${index + 1}</div>
                        <div style="right:-78.5% !important" class="time-box">
                            <span>${t('lobby.time')}</span>
                            <div class="join-time">${player.joinTime || '00:00'}</div>
                        </div>
                    </div>
                `)
            })

        })
    })
}



let selectedRaceId = null;
let selectedRacePassword = null;

$(document).on('click', '.upcoming-item .btn-join', function (e) {
    e.stopPropagation();
    selectedRaceId = $(this).data('id');
    selectedRacePassword = $(this).data('password');

    $.post('https://frkn-racingv2/getRaces', JSON.stringify({}), function (races) {

        let alreadyInRace = false;

        races.forEach(race => {
            if (race.id === selectedRaceId) {
                if (race.players) {
                    race.players.forEach(p => {
                        if (p.identifier === identifier) {
                            alreadyInRace = true;
                        }
                    });
                }
            }
        });

        if (alreadyInRace) {
            $('.page').fadeOut(150);
            $('.lobby-page').fadeIn(150);
            lobbyRender(selectedRaceId);
            $('.my-race-box').data('race-id', selectedRaceId).fadeIn(200);
            return;
        }

        if (selectedRacePassword && selectedRacePassword !== "" && selectedRacePassword !== "undefined") {
            $('.popup-bg').fadeIn(150);
            $('.password-box').fadeIn(150);
            return;
        }

        joinRace(selectedRaceId, "");
    });
});

$(document).on('click', '.upcoming-item .btn-view', function (e) {
    e.stopPropagation();
    let raceId = $(this).data('id');
    if (!raceId) return;
    $('.page').fadeOut(150);
    $('.lobby-page').fadeIn(150);
    lobbyRender(raceId);
});

$(document).on('click', '.upcoming-item .btn-leave', function (e) {
    e.stopPropagation();
    let raceId = $(this).data('id');
    if (!raceId) return;
    $.post('https://frkn-racingv2/leaveRace', JSON.stringify({ id: raceId, type: 'leave' }), function (response) {
        if (response.type == "success") {
            openNotify(response.type, response.header, response.message, false, 'normal');
            window._playerInRace = false;
            window._playerInRaceId = null;
            $('.my-race-box').fadeOut(200);
            setTimeout(function () {
                $('.menu-item[data-page="main-page"]').trigger('click');
                setTimeout(function () {
                    $('.category-item[data-bg="autorace"]').trigger('click');
                }, 200);
            }, 500);
        } else {
            openNotify(response.type, response.header, response.message, false, 'normal');
        }
    });
});

$(document).on('click', '.password-box .save', function () {
    let enteredPassword = $('.password-box .avatar-input').val().trim();

    if (enteredPassword === "") {
        openNotify("error", t('password.missing_password'), t('password.enter_password_error'));
        return;
    }

    $('.popup-bg').fadeOut(150);
    $('.password-box').fadeOut(150);

    joinRace(selectedRaceId, enteredPassword);
});

function joinRace(raceId, password) {
    $.post('https://frkn-racingv2/joinRace', JSON.stringify({
        id: raceId,
        password: password
    }), function (response) {

        openNotify(response.type, response.header, response.message);

        if (response.type === "success") {
            $('.page').fadeOut(150);
            $('.lobby-page').fadeIn(150);
            lobbyRender(raceId);
            $('.my-race-box').data('race-id', raceId).fadeIn(200);
        }

        if (response.type === "already") {
            $('.page').fadeOut(150);
            $('.lobby-page').fadeIn(150);
            lobbyRender(raceId);
        }
    }).fail(function (err) {
    });
}




$(document).on('click', '.race-create', function () {
    let eventName = $('.event-name').val();
    let vehicleClass = $('.vehicle-selector .selector-text').text();
    let prizeType = _prizeKeys[_currentPrizeIndex].toUpperCase();
    let laps = Number($('.laps-input').val());
    let countdown = Number($('.countdown-input').val());
    let raceTime = Number($('.duration-slider').val());
    let participationFee = Number($('.col-advanced .price-input').val());
    let password = $('.col-race-options input[type="password"]').val();
    let maxParticipants = Number($('.participant-slider').val());

    const fields = [
        { name: t('create_advanced.field_event_name'), value: $('.event-name').val() },
        { name: t('create_advanced.field_prize_type'), value: prizeType },
        { name: t('create_advanced.field_laps'), value: Number($('.laps-input').val()), numeric: true },
        { name: t('create_advanced.field_countdown'), value: Number($('.countdown-input').val()), numeric: true },
        { name: t('create_advanced.field_race_duration'), value: Number($('.duration-slider').val()), numeric: true },
        { name: t('create_advanced.field_participation_fee'), value: Number($('.col-advanced .price-input').val()), numeric: true },
        { name: t('create_advanced.field_max_participants'), value: Number($('.participant-slider').val()), numeric: true }
    ];

    for (let f of fields) {

        if (f.value === null || f.value === undefined) {
            setTimeout(() => {
                $('.advanced-settings').fadeOut(150);
            }, 1500);
            openNotify("error", t('create_advanced.missing_data'), `${f.name} ${t('create_advanced.error_missing')}`);
            return;
        }

        if (typeof f.value === "string" && f.value.trim() === "") {
            setTimeout(() => {
                $('.advanced-settings').fadeOut(150);
            }, 1500);
            openNotify("error", t('create_advanced.missing_data'), `${f.name} ${t('create_advanced.error_empty')}`);
            return;
        }

        if (f.invalid && f.value === f.invalid) {
            setTimeout(() => {
                $('.advanced-settings').fadeOut(150);
            }, 1500);
            openNotify("error", t('create_advanced.missing_data'), `${t('create_advanced.error_select_valid')} ${f.name}.`);
            return;
        }

        if (f.numeric && (isNaN(f.value) || f.value <= 0)) {
            setTimeout(() => {
                $('.advanced-settings').fadeOut(150);
            }, 1500);
            openNotify("error", t('create_advanced.missing_data'), `${f.name} ${t('create_advanced.error_numeric')}`);
            return;
        }
    }

    let showPosition = $('.show-position').hasClass('active');
    let reverseControls = $('.reverse-controls').hasClass('active');
    let collisions = $('.collisions-toggle').hasClass('active');
    let forceFPP = $('.forcefpp-toggle').hasClass('active');
    let enableAlerts = $('.enableAlerts-toggle').hasClass('active');
    let raceType = $('.race-type-selector .selector-text').text();
    let pistTuruVal = $('.col-track-details .select-box select').val();
    if (pistTuruVal) raceType = pistTuruVal;

    if (!raceType || raceType === '-' || raceType.trim() === '') {
        openNotify('error', t('create_advanced.missing_data'), t('create.category_restricted'));
        return;
    }

    let data = {
        id: Date.now(),
        trackId: selectedTrackId,
        eventName: eventName,
        prizeType: prizeType,
        participationFee: participationFee,
        laps: laps,
        countdown: countdown,
        raceTime: raceTime,
        password: password,
        maxParticipants: maxParticipants,
        reverseControls: reverseControls,
        showPosition: showPosition,
        collisions: collisions,
        forceFPP: forceFPP,
        enableAlerts: enableAlerts,
        type: raceType
    };

    $.post('https://frkn-racingv2/createRace', JSON.stringify(data), function (response) {
        openNotify(response.type, response.header, response.message);

        if (response.type === 'success') {
            setTimeout(() => {
                $('.event-name').val('');
                $('.col-advanced .price-input').val('');
                $('.laps-input').val('');
                $('.countdown-input').val('');
                $('.col-race-options input[type="password"]').val('').prop('disabled', true);
                $('.track-id-input').val('');


                _currentPrizeIndex = 0;
                $('.prize-type-selector .selector-text').text(getPrizeLabel('cash'));
                $('.race-type-selector .selector-text').text('CIRCUIT');

                $('.show-position, .reverse-controls, .collisions-toggle, .forcefpp-toggle, .password-toggle, .enableAlerts-toggle').removeClass('active');
                $('.show-position, .enableAlerts-toggle, .collisions-toggle').addClass('active');

                let dSlider = $('.duration-slider')[0];
                let pSlider = $('.participant-slider')[0];
                if (dSlider) { dSlider.value = dSlider.defaultValue; dSlider.style.setProperty('--value', dSlider.value); }
                if (pSlider) { pSlider.value = pSlider.defaultValue; pSlider.style.setProperty('--value', pSlider.value); }
                $('.duration-slider').trigger('input');
                $('.participant-slider').trigger('input');

                selectedTrackId = null;

                $('#col-advanced').addClass('locked');
                $('#col-options').addClass('locked');
                $('.progress-dot').removeClass('active');
                $('.progress-dot[data-step="1"]').addClass('active');

                let col = $('.col-track-details');
                col.find('.map-grid-wrapper').slideUp(0);
                col.find('.field-group').slideDown(0);
                col.find('.continue-btn').show();
                col.find('.col-title').text(t('create_advanced.track_details'));
                col.find('.col-desc').text(t('create_advanced.track_desc'));
                col.find('.create-track').text(t('create.select_track'));

                $('.menu-item[data-page="main-page"]').trigger('click');
            }, 1000);
        }
    });
});


function openAltNotify(type, header, text, duration) {
    if (localStorage.getItem('altNotify') === '0') return;

    let box = $('.notify-box');

    $('.tablet , body').css({ top: '150%' });

    setTimeout(() => {
        $('.tablet').css({ top: '124%', overflow: 'initial' });
    }, 50);

    $('.notify-box').css({
        bottom: '99%',
        right: '35%',
        'border-bottom-left-radius': '0',
        'border-bottom-right-radius': '0'
    });

    $('body, .tablet').fadeIn(0);

    let alias = localStorage.getItem('playerAlias') || '';
    $('#notify-alias').text(alias);

    box.find('.h').text(header);
    box.find('.text').html(text.replace(/\n/g, '<br>'));

    if (type === "error") {
        box.addClass('notify-error');
        animateNotifySVG();
    }

    box.fadeIn(150);
    setTimeout(() => closeAltNotify(), duration || 3000);
}



function closeAltNotify() {
    $('.notify-box').fadeOut(150, function () {
        $('.notify-box')
            .removeClass('notify-error')
            .css({
                bottom: '3%',
                right: '3%',
                'border-bottom-left-radius': '12px',
                'border-bottom-right-radius': '12px'
            });

        $('.tablet').css({
            top: '50%',
            overflow: 'hidden'
        });
    });

    let panelVisible = $('.auto-race-panel').is(':visible');
    let raceActive = $('.race-page').is(':visible') || $('.timer-box').is(':visible');
    $('.notify-box').fadeOut(0);
    $('.tablet').css({ top: '50%', overflow: 'hidden' }).fadeOut(0);
    if (!panelVisible && !raceActive) {
        $('body').fadeOut(0);
    }
}


function openNotify(type, header, text) {
    let box = $('.notify-box');

    box.css({
        bottom: '3%',
        right: '3%',
        'border-bottom-left-radius': '12px',
        'border-bottom-right-radius': '12px'
    });
    let alias = localStorage.getItem('playerAlias') || '';
    $('#notify-alias').text(alias);

    box.find('.h').text(header);
    box.find('.text').html(text.replace(/\n/g, '<br>'));

    animateNotifySVG();

    box.fadeIn(150);
}



function animateNotifySVG() {
    let box = $('.notify-box');
    let svg = box.find('svg');
    let value = 0;

    let timer = setInterval(() => {
        value += 6;
        svg.css('stroke-dasharray', value + ' 1500');

        if (value >= 110) {
            clearInterval(timer);

            setTimeout(() => {
                box.fadeOut(150, function () {
                    svg.css('stroke-dasharray', '0 1500');
                    $('.popup-bg , .change-avatar-box , .createcrew-box , .advanced-box').hide();
                });
            }, 1000);
        }
    }, 25);
}


$(document).on('click', '.race-btn:not(.disabled)', function () {
    $('.race-btn').removeClass('active');
    $(this).addClass('active');
});

$('.race-menu-scroll').on('wheel', function (e) {
    e.preventDefault();
    this.scrollLeft += e.originalEvent.deltaY;
});


let autoRacePanelTimer = null;

function showAutoRacePanel(data) {
    let panel = $('.auto-race-panel');

    panel.find('.arp-track').text(data.trackName || '—');
    panel.find('.arp-laps').text(data.laps || '—');
    panel.find('.arp-players').text(data.playerCount || '0');
    panel.find('.arp-buyin').text(data.buyIn > 0 ? ('$' + data.buyIn) : 'FREE');

    let prizeList = panel.find('.arp-prize-list');
    prizeList.empty();

    let prizeColors = ['gold', 'silver', 'bronze'];
    let prizeLabels = ['1.', '2.', '3.'];

    if (data.prizes) {
        for (let i = 0; i < 3; i++) {
            let key = (i + 1).toString();
            let prize = data.prizes[key] || data.prizes[i + 1];
            if (prize) {
                let colorClass = prizeColors[i] || '';
                let amount = prize.type === 'money' ? ('$' + (prize.amount || 0).toLocaleString()) : ((prize.amount || 1) + 'x ' + (prize.item || ''));
                prizeList.append(`
                    <div class="arp-prize-item ${colorClass}">
                        <span class="arp-prize-pos">${prizeLabels[i]}</span>
                        <span class="arp-prize-amount">${amount}</span>
                    </div>
                `);
            }
        }
    }

    let countdown = data.countdownSeconds || 120;

    function updateCountdown() {
        let m = Math.floor(countdown / 60);
        let s = countdown % 60;
        panel.find('.arp-countdown').text(
            m.toString().padStart(2, '0') + ':' + s.toString().padStart(2, '0')
        );
        if (countdown <= 0) {
            hideAutoRacePanel();
        }
        countdown--;
    }

    if (autoRacePanelTimer) clearInterval(autoRacePanelTimer);
    updateCountdown();
    autoRacePanelTimer = setInterval(updateCountdown, 1000);

    $('body').css('display', 'flex');
    panel.find('.arp-warning').text(t('auto_race.kick_warning'));
    panel.fadeIn(300);
}

function hideAutoRacePanel() {
    if (autoRacePanelTimer) {
        clearInterval(autoRacePanelTimer);
        autoRacePanelTimer = null;
    }
    $('.auto-race-panel').fadeOut(300);
}

function toggleAutoRacePanel() {
    let panel = $('.auto-race-panel');
    if (panel.is(':visible')) {
        panel.fadeOut(200);
    } else {
        $('body').css('display', 'flex');
        panel.fadeIn(200);
    }
}

$(document).on('mouseenter', '.toggle-info-icon', function (e) {
    let key = $(this).data('tooltip-key');
    if (!key) return;

    let parts = key.split('.');
    let text = t(key);
    if (!text || text === key) return;

    text = text.replace(/^\(/, '').replace(/\)$/, '');

    let tooltip = $('#toggleTooltip');
    tooltip.text(text);

    let rect = this.getBoundingClientRect();
    let tooltipWidth = 200;
    let left = rect.left + (rect.width / 2) - (tooltipWidth / 2);
    let top = rect.top - 36;

    tooltip.css({ left: left + 'px', top: top + 'px' });
    tooltip.addClass('visible');
});

$(document).on('mouseleave', '.toggle-info-icon', function () {
    $('#toggleTooltip').removeClass('visible');
});

function escapeFinishHtml(value) {
    return String(value ?? '').replace(/[&<>"']/g, function (char) {
        return {
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#39;'
        }[char];
    });
}

function formatFinishRaceTime(value) {
    if (typeof value === 'string') {
        let text = value.trim();
        if (!text) return '--:--.--';
        if (text.includes(':') || text.startsWith('-') || /[A-Za-z]/.test(text)) {
            return text;
        }
        value = Number(text);
    }

    let num = Number(value);
    if (!Number.isFinite(num) || num <= 0) return '--:--.--';

    let mins = Math.floor(num / 60);
    let secs = Math.floor(num % 60);
    let centiseconds = Math.round((num - Math.floor(num)) * 100);

    if (centiseconds >= 100) {
        centiseconds = 0;
        secs += 1;
    }
    if (secs >= 60) {
        secs = 0;
        mins += 1;
    }

    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}.${centiseconds.toString().padStart(2, '0')}`;
}

function normalizeFinishReward(value) {
    if (value === null || value === undefined || value === '') return '—';
    if (typeof value === 'number') return `$${formatNumber(value)}`;
    return String(value);
}

function normalizeFinishRows(data) {
    let rows = Array.isArray(data.standings) ? data.standings : [];

    return rows
        .filter(Boolean)
        .map(function (row, index) {
            let position = Number(row.position || row.rank || (index + 1)) || (index + 1);
            let name = row.name || row.playerName || row.alias?.alias || row.aliasData?.alias || `Racer ${position}`;
            let isPlayer = Boolean(row.isPlayer || row.isMe || row.you);
            let status = row.status || (isPlayer ? t('finish.you_tag') : '');
            let timeText = row.timeText || row.time || row.finishTimeText || '';

            if (!timeText && row.timeSeconds !== undefined) {
                timeText = formatFinishRaceTime(row.timeSeconds);
            } else if (!timeText && row.finishTime !== undefined) {
                timeText = formatFinishRaceTime(row.finishTime);
            }

            return {
                position,
                name: String(name),
                status: String(status || ''),
                timeText: timeText ? String(timeText) : '--:--.--',
                rewardText: normalizeFinishReward(row.rewardText || row.reward || row.prizeText || row.cashText),
                isPlayer
            };
        })
        .sort(function (a, b) {
            return a.position - b.position;
        });
}

function closeRaceFinishOverlay() {
    let overlay = $('.finishboard-overlay');
    if (window._finishOverlayTimer) {
        clearTimeout(window._finishOverlayTimer);
        window._finishOverlayTimer = null;
    }
    overlay.addClass('hiding');

    setTimeout(function () {
        overlay.css('display', 'none').removeClass('hiding');

        let panelVisible = $('.auto-race-panel').is(':visible');
        let raceActive = $('.race-page').is(':visible') || $('.timer-box').is(':visible');
        let tabletVisible = $('.tablet').is(':visible') || $('.page:visible').length > 0;

        if (!panelVisible && !raceActive && !tabletVisible) {
            $('body').fadeOut(0);
        }
    }, 450);
}

function showRaceFinishOverlay(data) {
    let overlay = $('.finishboard-overlay');
    let rows = normalizeFinishRows(data);
    let list = $('#finish2-standings');
    let emptyState = $('#finish2-empty-state');
    let position = Number(data.position) || 0;

    if (!position) {
        let myRow = rows.find(function (row) {
            return row.isPlayer;
        });
        position = myRow ? myRow.position : 0;
    }

    $('#finish2-race-name').text(data.raceName || t('finish.race_completed'));
    $('#finish2-player-name').text(data.playerName || t('finish.default_racer'));
    $('#finish2-position').text(position > 0 ? `#${position}` : '—');
    $('#finish2-total-time').text(formatFinishRaceTime(data.totalTime));
    $('#finish2-best-lap').text(formatFinishRaceTime(data.bestLap));
    $('#finish2-total-racers').text(data.totalRacers || rows.length || 0);

    list.empty();

    if (rows.length) {
        let visibleRows = rows.slice(0, 8);
        let playerIndex = rows.findIndex(function (row) {
            return row.isPlayer;
        });

        if (rows.length > 8 && playerIndex >= 8) {
            visibleRows = rows.slice(0, 7);
            visibleRows.push(rows[playerIndex]);
        }

        emptyState.hide();

        visibleRows.forEach(function (row) {
            list.append(`
                <div class="finishboard-row ${row.isPlayer ? 'player' : ''}">
                    <div class="finishboard-row-pos">${escapeFinishHtml(row.position)}</div>
                    <div class="finishboard-row-namebox">
                        <div class="finishboard-row-name">${escapeFinishHtml(row.name)}</div>
                        ${row.status ? `<span class="finishboard-row-badge ${row.isPlayer ? 'player' : ''}">${escapeFinishHtml(row.status)}</span>` : ''}
                    </div>
                    <div class="finishboard-row-time">${escapeFinishHtml(row.timeText)}</div>
                    <div class="finishboard-row-reward">${escapeFinishHtml(row.rewardText)}</div>
                </div>
            `);
        });
    } else {
        emptyState.show();
    }

    $('body').css('display', 'flex');
    overlay.removeClass('hiding').css('display', 'flex').css('animation', 'none');
    overlay[0].offsetHeight;
    overlay.css('animation', '');

    if (window._finishOverlayTimer) clearTimeout(window._finishOverlayTimer);
    window._finishOverlayTimer = setTimeout(function () {
        closeRaceFinishOverlay();
    }, 8000);
}
