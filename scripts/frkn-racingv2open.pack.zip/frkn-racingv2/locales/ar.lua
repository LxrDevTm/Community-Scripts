local Translations = {
    general = {
        race_owner_cannot_leave = "منشئ السباق لا يمكنه مغادرة السباق.",
        race_left = "لقد غادرت السباق.",
        not_in_race = "أنت لست جزءًا من هذا السباق.",
        race_not_found = "السباق غير موجود.",

        header_cant_get_out = "لا يمكنك الخروج",
        header_race_left = "غادرت السباق",
        header_not_joined = "غير منضم",
        header_error = "خطأ",

        must_select_vehicle = "يجب عليك اختيار مركبة من المرآب قبل الانضمام إلى السباق.",
        no_vehicle_owned = "لا تملك أي مركبات في المرآب. يرجى إضافة مركبة أولاً.",
        header_no_vehicle_selected = "لم يتم اختيار مركبة",
        header_no_vehicles = "لا توجد مركبات",

        password_incorrect = "كلمة المرور غير صحيحة.",
        header_access_denied = "تم رفض الوصول",

        class_mismatch = "هذا السباق يسمح فقط بفئة '%{required}'. فئة مركبتك: '%{current}'.",
        header_class_mismatch = "عدم تطابق الفئة",

        cannot_join_race = "لا يمكنك المشاركة في هذا السباق.",
        header_race_not_found = "السباق غير موجود",

        already_joined = "لقد انضممت إلى هذا السباق بالفعل.",
        header_already_joined = "منضم بالفعل",

        race_full = "هذا السباق ممتلئ.",
        header_race_full = "السباق ممتلئ",

        race_joined = "تم الانضمام إلى السباق بنجاح.",
        header_race_joined = "تم الانضمام إلى السباق",

        not_enough_money = "لا تملك المال الكافي للانضمام إلى هذا السباق.",
        header_insufficient_funds = "رصيد غير كافٍ",

        race_update = "تحديث السباق",
        player_joined_race = "%{player} انضم إلى سباقك.",

        chip_missing = "لا تملك الشريحة المطلوبة",
        header_chip_missing = "الشريحة مفقودة",

        not_authorized = "غير مصرح لك",
        header_not_authorized = "غير مصرح",

        cooldown_active = "فترة الانتظار نشطة",
        header_cooldown = "فترة انتظار",

        race_started = "بدأ السباق بنجاح",
        header_race_start = "بدء السباق",

        header_invalid_race = "سباق غير صالح",
        delete_not_authorized = "غير مصرح لك بحذف هذا السباق.",
        header_permission_denied = "تم رفض الإذن",

        race_deleted = "تم حذف السباق بنجاح.",
        header_race_removed = "تمت إزالة السباق",
        car_selected = "لقد اخترت هذه المركبة للسباق.",
        header_car_selected = "تم اختيار المركبة",

        weekly_crew_reward = "مكافأة الطاقم الأسبوعية",
        weekly_crew_reward_msg = "طاقمك '%{crew}' فاز بالمكافأة الأسبوعية!",
        invalid_crew_id = "معرف الطاقم غير صالح.",
        already_sent_join_request = "لقد أرسلت طلب انضمام لهذا الطاقم بالفعل.",
                
        crew_join_request = "طلب انضمام للطاقم",
        crew_join_request_msg = "%{player} يريد الانضمام إلى طاقمك.",
        crew_request_denied = "تم رفض طلب الانضمام إلى الطاقم.",
        header_crew = "الطاقم",
        no_owned_crew = "لا تملك أي طاقم.",
        no_pending_requests = "لا توجد طلبات معلقة.",

        crew_request_accepted = "تم قبول طلب انضمامك إلى الطاقم.",
        request_accepted = "تم قبول الطلب.",

        invalid_bet = "رهان غير صالح",
        bet_info_missing = "معلومات الرهان مفقودة.",
        cannot_bet_self = "لا يمكنك المراهنة على نفسك.",
        not_enough_money_bet = "لا تملك المال الكافي لوضع هذا الرهان.",
        sql_error = "خطأ في قاعدة البيانات",
        bet_not_saved = "لم يتم حفظ الرهان.",

        bet_placed = "تم وضع الرهان",
        bet_placed_success = "تم وضع رهانك بنجاح!",

        new_bet_placed = "تم وضع رهان جديد",
        someone_bet_on_you = "شخص ما راهن عليك.",

        reward_not_found = "المكافأة غير موجودة",
        reward_claimed = "تم استلام المكافأة!",

        need_money_create_crew = "تحتاج إلى $%{money} لإنشاء طاقم.",
        missing_field = "حقل مفقود",
        enter_crew_name = "يرجى إدخال اسم الطاقم.",
        enter_crew_description = "يرجى إدخال وصف الطاقم.",

        duplicate_crew_name = "اسم الطاقم مكرر",
        crew_name_exists = "يوجد طاقم بهذا الاسم بالفعل.",

        crew_exists = "الطاقم موجود",
        already_own_crew = "أنت تملك طاقمًا بالفعل.",
        already_in_crew = "أنت عضو في طاقم بالفعل.",

        crew_create_failed = "فشل إنشاء الطاقم. حاول مرة أخرى.",
        crew_created = "تم إنشاء الطاقم بنجاح!",
        header_crew_created = "تم إنشاء الطاقم",

        crew_error = "خطأ في الطاقم",
        not_in_crew = "أنت لست ضمن أي طاقم.",

        crew_not_found = "الطاقم غير موجود.",
        unauthorized = "غير مصرح",
        only_leader_can_kick = "فقط قائد الطاقم يمكنه إزالة الأعضاء.",

        member_removed = "تمت إزالة العضو",
        member_removed_success = "تمت إزالة عضو الطاقم بنجاح.",

        crew_not_found_header = "الطاقم غير موجود",
        crew_not_exist = "الطاقم المحدد غير موجود.",

        only_owner_can_delete_crew = "فقط مالك الطاقم يمكنه حذف الطاقم.",

        crew_deleted = "تم حذف الطاقم",
        crew_deleted_success = "تم حذف طاقمك بنجاح.",

        not_enough_money_race = "رسوم الدخول التي حددتها لبدء هذا السباق منخفضة جدًا.",
        missing_item = "عنصر مفقود",
        race_chip_required = "يتطلب إنشاء سباق شريحة سباق. تأكد من وجودها في حقيبتك.",

        not_authorized_create_race = "غير مصرح لك بإنشاء سباق. تواصل مع مدير السباقات إذا كنت تعتقد أن هذا خطأ.",

        duplicate_race_name = "اسم سباق مكرر",
        race_name_exists = "يوجد سباق بهذا الاسم بالفعل. يرجى اختيار اسم مختلف.",

        race_created = "تم إنشاء السباق",
        race_created_success = "تم إنشاء السباق بنجاح. يمكنك الآن انتظار انضمام الآخرين وبدء السباق عندما تكون جاهزًا.",
        auto_race = "سباق تلقائي",
        auto_race_message = "سيبدأ هذا السباق تلقائيًا خلال %{time} دقائق.",
        join_request_sent = "تم إرسال طلب الانضمام",
        too_far_start = "أنت بعيد جدًا عن نقطة بدء السباق.",
        track_error_header = "خطأ في المسار",
        track_error_message = "تعذر العثور على بيانات المسار! يرجى المحاولة مرة أخرى.",
    }
}

return Translations
