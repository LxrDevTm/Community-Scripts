local Translations = {
    general = {
        race_owner_cannot_leave = "Der Rennveranstalter kann das Rennen nicht selbst verlassen.",
        race_left = "Du hast das Rennen verlassen.",
        not_in_race = "Du bist kein Teil dieses Rennens.",
        race_not_found = "Rennen nicht gefunden.",

        header_cant_get_out = "Du kannst nicht raus",
        header_race_left = "Rennen verlassen",
        header_not_joined = "Nicht beigetreten",
        header_error = "Fehler",

        must_select_vehicle = "Du musst vor dem Beitritt ein Fahrzeug aus deiner Garage auswählen.",
        no_vehicle_owned = "Du hast keine Fahrzeuge in deiner Garage. Bitte füge zuerst eines hinzu.",
        header_no_vehicle_selected = "Kein Fahrzeug ausgewählt",
        header_no_vehicles = "Keine Fahrzeuge",

        password_incorrect = "Passwort ist falsch.",
        header_access_denied = "Zugriff verweigert",

        class_mismatch = "Dieses Rennen erlaubt nur die Klasse '%{required}'. Deine Fahrzeugklasse: '%{current}'.",
        header_class_mismatch = "Klassenkonflikt",

        cannot_join_race = "Du kannst an diesem Rennen nicht teilnehmen.",
        header_race_not_found = "Rennen nicht gefunden",

        already_joined = "Du bist diesem Rennen bereits beigetreten.",
        header_already_joined = "Bereits beigetreten",

        race_full = "Dieses Rennen ist bereits voll.",
        header_race_full = "Rennen voll",

        race_joined = "Du bist dem Rennen erfolgreich beigetreten.",
        header_race_joined = "Rennen beigetreten",

        not_enough_money = "Du hast nicht genug Geld, um diesem Rennen beizutreten.",
        header_insufficient_funds = "Unzureichende Mittel",

        race_update = "Renn-Update",
        player_joined_race = "%{player} ist deinem Rennen beigetreten.",

        chip_missing = "Du hast nicht den erforderlichen Chip",
        header_chip_missing = "Chip fehlt",

        not_authorized = "Nicht autorisiert",
        header_not_authorized = "Nicht autorisiert",

        cooldown_active = "Abklingzeit aktiv",
        header_cooldown = "Abklingzeit",

        race_started = "Rennen erfolgreich gestartet",
        header_race_start = "Rennstart",

        header_invalid_race = "Ungültiges Rennen",
        delete_not_authorized = "Du bist nicht berechtigt, dieses Rennen zu löschen.",
        header_permission_denied = "Berechtigung verweigert",

        race_deleted = "Rennen erfolgreich gelöscht.",
        header_race_removed = "Rennen entfernt",
        car_selected = "Du hast dieses Fahrzeug für das Rennen ausgewählt.",
        header_car_selected = "Fahrzeug ausgewählt",

        weekly_crew_reward = "Wöchentliche Crew-Belohnung",
        weekly_crew_reward_msg = "Deine Crew '%{crew}' hat die wöchentliche Belohnung gewonnen!",
        invalid_crew_id = "Ungültige Crew-ID.",
        already_sent_join_request = "Du hast bereits eine Beitrittsanfrage an diese Crew gesendet.",
                
        crew_join_request = "Crew-Beitrittsanfrage",
        crew_join_request_msg = "%{player} möchte deiner Crew beitreten.",
        crew_request_denied = "Deine Crew-Beitrittsanfrage wurde abgelehnt.",
        header_crew = "Crew",
        no_owned_crew = "Du besitzt keine Crew.",
        no_pending_requests = "Keine ausstehenden Anfragen.",

        crew_request_accepted = "Deine Crew-Beitrittsanfrage wurde akzeptiert.",
        request_accepted = "Anfrage akzeptiert.",

        invalid_bet = "Ungültige Wette",
        bet_info_missing = "Wettinformationen fehlen.",
        cannot_bet_self = "Du kannst nicht auf dich selbst wetten.",
        not_enough_money_bet = "Du hast nicht genug Geld, um diese Wette zu platzieren.",
        sql_error = "SQL-Fehler",
        bet_not_saved = "Wette konnte nicht gespeichert werden.",

        bet_placed = "Wette platziert",
        bet_placed_success = "Deine Wette wurde erfolgreich platziert!",

        new_bet_placed = "Neue Wette platziert",
        someone_bet_on_you = "Jemand hat auf dich gewettet.",

        reward_not_found = "Belohnung nicht gefunden",
        reward_claimed = "Belohnung eingelöst!",

        need_money_create_crew = "Du benötigst $%{money}, um eine Crew zu erstellen.",
        missing_field = "Fehlendes Feld",
        enter_crew_name = "Bitte gib einen Crew-Namen ein.",
        enter_crew_description = "Bitte gib eine Crew-Beschreibung ein.",

        duplicate_crew_name = "Doppelter Crew-Name",
        crew_name_exists = "Eine Crew mit diesem Namen existiert bereits.",

        crew_exists = "Crew existiert",
        already_own_crew = "Du besitzt bereits eine Crew.",
        already_in_crew = "Du bist bereits Mitglied einer Crew.",

        crew_create_failed = "Crew-Erstellung fehlgeschlagen. Bitte versuche es erneut.",
        crew_created = "Crew erfolgreich erstellt!",
        header_crew_created = "Crew erstellt",

        crew_error = "Crew-Fehler",
        not_in_crew = "Du bist in keiner Crew.",

        crew_not_found = "Crew nicht gefunden.",
        unauthorized = "Nicht autorisiert",
        only_leader_can_kick = "Nur Crew-Leiter können Mitglieder entfernen.",

        member_removed = "Mitglied entfernt",
        member_removed_success = "Crew-Mitglied wurde erfolgreich entfernt.",

        crew_not_found_header = "Crew nicht gefunden",
        crew_not_exist = "Die ausgewählte Crew existiert nicht.",

        only_owner_can_delete_crew = "Nur der Crew-Besitzer kann die Crew löschen.",

        crew_deleted = "Crew gelöscht",
        crew_deleted_success = "Deine Crew wurde erfolgreich gelöscht.",

        not_enough_money_race = "Die von dir festgelegte Startgebühr für dieses Rennen ist zu niedrig.",
        missing_item = "Fehlender Gegenstand",
        race_chip_required = "Zum Erstellen eines Rennens ist ein Rennchip erforderlich. Bitte stelle sicher, dass du einen im Inventar hast.",

        not_authorized_create_race = "Du bist nicht berechtigt, ein Rennen zu erstellen. Kontaktiere einen Rennmanager, wenn du denkst, dass dies ein Fehler ist.",

        duplicate_race_name = "Doppelter Rennname",
        race_name_exists = "Ein Rennen mit diesem Namen existiert bereits. Bitte wähle einen anderen Namen.",

        race_created = "Rennen erstellt",
        race_created_success = "Rennen erfolgreich erstellt. Du kannst nun auf weitere Teilnehmer warten und das Rennen starten, wenn du bereit bist.",
        auto_race = "AUTORENNEN",
        auto_race_message = "Dieses Rennen startet automatisch in %{time} Minuten.",
        join_request_sent = "Beitrittsanfrage gesendet",
        too_far_start = "Du bist zu weit vom Rennstartpunkt entfernt.",
        track_error_header = "Streckenfehler",
        track_error_message = "Streckendaten konnten nicht gefunden werden! Bitte versuche es erneut.",
    }
}

return Translations
