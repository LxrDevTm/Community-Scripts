local Translations = {
    general = {
        race_owner_cannot_leave = "Race founder cannot remove himself from the race.",
        race_left = "You have left the race.",
        not_in_race = "You are not part of this race.",
        race_not_found = "Race not found.",

        header_cant_get_out = "You cant get out",
        header_race_left = "Race Left",
        header_not_joined = "Not Joined",
        header_error = "Error",

        must_select_vehicle = "You must select a vehicle from your garage before joining a race.",
        no_vehicle_owned = "You don't have any vehicles in your garage. Please add a vehicle first.",
        header_no_vehicle_selected = "No Vehicle Selected",
        header_no_vehicles = "No Vehicles",

        password_incorrect = "Password is incorrect.",
        header_access_denied = "Access Denied",

        class_mismatch = "This race only allows class '%{required}'. Your vehicle class: '%{current}'.",
        header_class_mismatch = "Class Mismatch",

        cannot_join_race = "You can't take part in this race.",
        header_race_not_found = "Race Not Found",

        already_joined = "You have already joined this race.",
        header_already_joined = "Already Joined",

        race_full = "This race is already full.",
        header_race_full = "Race Full",

        race_joined = "You have joined the race successfully.",
        header_race_joined = "Race Joined",

        not_enough_money = "You do not have enough money to join this race.",
        header_insufficient_funds = "Insufficient Funds",

        race_update = "Race Update",
        player_joined_race = "%{player} joined your race.",

        chip_missing = "You don't have the necessary chip",
        header_chip_missing = "Chip Missing",

        not_authorized = "You are not authorized",
        header_not_authorized = "Not Authorized",
        not_enough_players = "Minimum 2 players required.",

        cooldown_active = "Cooldown active",
        header_cooldown = "Cooldown",

        race_started = "Race started successfully",
        header_race_start = "Race Start",

        header_invalid_race = "Invalid Race",
        delete_not_authorized = "You are not authorized to delete this race.",
        header_permission_denied = "Permission Denied",

        race_deleted = "Race deleted successfully.",
        header_race_removed = "Race Removed",
        car_selected = "You selected this car for racing.",
        header_car_selected = "Car Selected",

        header_success = "Success",
        track_deleted = "Track deleted successfully.",
        track_not_found = "Track not found.",
        invalid_track_id = "Invalid track ID.",

        weekly_crew_reward = "Weekly Crew Reward",
        weekly_crew_reward_msg = "Your crew '%{crew}' won the weekly reward!",
        invalid_crew_id = "Invalid crew ID.",
        already_sent_join_request = "You have already sent a join request to this crew.",
                
        crew_join_request = "Crew Join Request",
        crew_join_request_msg = "%{player} wants to join your crew.",
        crew_request_denied = "Your crew join request was denied.",
        header_crew = "Crew",
        no_owned_crew = "You do not own a crew.",
        no_pending_requests = "No pending requests.",

        crew_request_accepted = "Your crew join request has been accepted.",
        request_accepted = "Request accepted.",

        invalid_bet = "Invalid Bet",
        bet_info_missing = "Bet information is missing.",
        bet_race_started = "This race has already started. You can no longer place bets.",
        bet_already_placed = "You have already placed a bet on this race. Only 1 bet per race is allowed.",
        cannot_bet_self = "You cannot place a bet on yourself.",
        not_enough_money_bet = "You do not have enough money to place this bet.",
        sql_error = "SQL Error",
        bet_not_saved = "Bet could not be saved.",

        bet_placed = "Bet Placed",
        bet_placed_success = "Your bet has been successfully placed!",

        new_bet_placed = "New Bet Placed",
        someone_bet_on_you = "Someone placed a bet on you.",

        reward_not_found = "Reward not found",
        reward_claimed = "Reward claimed!",

        need_money_create_crew = "You need $%{money} to create a crew.",
        missing_field = "Missing Field",
        enter_crew_name = "Please enter a crew name.",
        enter_crew_description = "Please enter a crew description.",

        duplicate_crew_name = "Duplicate Crew Name",
        crew_name_exists = "A crew with this name already exists.",

        crew_exists = "Crew Exists",
        already_own_crew = "You already own a crew.",
        already_in_crew = "You are already a member of a crew.",

        crew_create_failed = "Crew creation failed. Please try again.",
        crew_created = "Crew created successfully!",
        header_crew_created = "Crew Created",

        crew_error = "Crew Error",
        not_in_crew = "You are not in a crew.",

        crew_not_found = "Crew not found.",
        unauthorized = "Unauthorized",
        only_leader_can_kick = "Only crew leaders can remove members.",

        member_removed = "Member Removed",
        member_removed_success = "Crew member has been removed successfully.",

        crew_not_found_header = "Crew Not Found",
        crew_not_exist = "The selected crew does not exist.",

        only_owner_can_delete_crew = "Only the crew owner can delete the crew.",

        crew_deleted = "Crew Deleted",
        crew_deleted_success = "Your crew has been deleted successfully.",

        not_enough_money_race = "The entrance fee you have set to start this race is quite low.",
        missing_item = "Missing Item",
        race_chip_required = "A race chip is required to create a race. Please make sure you have one in your inventory.",

        not_authorized_create_race = "You're not authorized to create a race. Contact a race manager if you think this is a mistake.",

        duplicate_race_name = "Duplicate Race Name",
        race_name_exists = "A race with the same name already exists. Please choose a different name.",

        race_created = "Race Created",
        race_created_success = "Race created successfully. You can now wait for others to join and start the race when you're ready.",
        auto_race = "AUTO RACE",
        auto_race_message = "This race will start automatically in %{time} minutes.",
        join_request_sent = "Join Request Sent",
        too_far_start = "You are too far from the race start point.",
        track_error_header = "Track Error",
        track_error_message = "Track data could not be found! Please try again.",

        auto_race_header = "Auto Race",
        auto_race_announce_header = "Auto Race Announcement",
        auto_race_no_active = "There is no active auto race at the moment.",
        auto_race_joined = "You have successfully joined the auto race!",
        auto_race_join_failed = "Could not join the race. If you are already in a race, type /leaverace.",
        auto_race_starting_soon = "Race starts in %{seconds} seconds! Type /autorace to join.",
        auto_race_started = "Auto race started with %{count} racers!",
        auto_race_not_in_vehicle = "You were removed from the auto race because you are not in a vehicle.",

        race_prize_header = "Race Prize",
        race_prize_money = "You finished %{position}th! Prize: $%{amount}",
        race_prize_item = "You finished %{position}th! Prize: %{count}x %{item}",

        race_error_header = "Race Error",
        already_in_active_race = "You are already in an active race! Type /leaverace to leave.",
        player_offline = "Player offline",
        player_not_in_vehicle = "Not in a vehicle",
        race_cancelled_header = "Race Cancelled",

        leave_race_header = "Race",
        leave_race_success = "You have successfully left %{count} race(s).",
        leave_race_not_in = "You are not in any race.",

        auto_race_buyin = "Entry",
        auto_race_free = "Free",
        auto_race_laps = "Laps",
        auto_race_minutes_left = "min until start! Type /autorace to join",
        auto_race_marker_text = "~w~AUTO RACE AREA",
        race_start_marker_text = "~w~RACE START AREA",

        invalid_track_id = "Invalid track ID.",
        track_deleted = "Track deleted successfully.",
        track_not_found = "Track not found or already deleted.",
        not_enough_racers = "Not enough racers remaining (%{count} removed). Race cancelled.",
        not_enough_racers_disqualified = "Not enough racers remaining, race cancelled.",
        header_chat_error = "Chat Error",
        invalid_message = "Invalid message.",
        cooldown_time_remaining = "You must wait %{minutes} more minute(s) before starting a new race.",

        race_not_active = "Race is not currently active.",
        no_checkpoint_teleport = "No checkpoint to teleport to.",
        teleported_checkpoint = "Teleported to last checkpoint.",
        teleport_failed = "Failed to find the last checkpoint.",
        must_be_in_vehicle = "You must be in a vehicle to use the gearbox system.",
        max_gear_reached = "Max gear reached!",
        min_gear_reached = "Min gear reached!",

        notify_join = "You successfully participated in the race.",
        notify_incar = "Get back in the car!",
        notify_disqualified = "You are disqualified from the race.",
        notify_disqualifyreason = "You have been disqualified because you can only race with the car you entered in the race.",
        notify_raceover = "The race is over! You've completed all the laps.",
        notify_raceovertime = "Race is over! Time's up.",
        notify_racejoin = "You have joined the race.",

        gearbox_enabled = "Gearbox system enabled.",
        gearbox_disabled = "Gearbox system disabled.",
        gearbox_manual = "Gearbox: Manual",
        gearbox_automatic = "Gearbox: Automatic",

        auto_race_join_info = "Entry Fee",

        race_already_started = "This race has already been started and is ongoing.",
        tablet_blocked_racing = "You cannot open the tablet while in a race.",
        too_far_from_start = "Removed from race: too far from the starting point (%{distance}m).",
        race_ended_by_owner = "The race has been ended by the owner. Your entry fee has been refunded.",

        no_checkpoints_added = "You haven't added any checkpoints! Add at least one checkpoint before saving.",
        track_saved = "Track saved successfully!",
        track_saved_select = "Track saved! You can select it from the 'Select Track' section.",
        cannot_create_in_race = "You cannot create a race while you are in an active race. Please leave the current race first (/leaverace).",
        owner_too_far = "You are too far from the race starting area! Go to the marked location on the map.",
        owner_disqualified = "Race owner was disqualified, race has been cancelled.",
        must_be_in_vehicle_create = "You must be in a vehicle to create a race.",
        vehicle_class_mismatch_create = "Your vehicle is class '%{current}'. You cannot select '%{required}' class.",
        track_cancelled = "Track creation cancelled.",
        leader_transferred = "Race leadership has been transferred to you!",
        must_be_on_motorcycle = "You must be on a motorcycle to create or join a motorcycle race.",
        must_be_in_car = "You must be in a car to create or join a car race.",
        track_busy = "Another race is currently in progress on this track. You cannot race on this track until it finishes.",
        race_auto_deleted = "The race was automatically deleted because it was not started in time. Your entry fee has been refunded.",
    }
}

return Translations
