local Translations = {
    general = {
        race_owner_cannot_leave = "El creador de la carrera no puede abandonarla.",
        race_left = "Has salido de la carrera.",
        not_in_race = "No eres parte de esta carrera.",
        race_not_found = "Carrera no encontrada.",

        header_cant_get_out = "No puedes salir",
        header_race_left = "Carrera Abandonada",
        header_not_joined = "No Unido",
        header_error = "Error",

        must_select_vehicle = "Debes seleccionar un vehículo de tu garaje antes de unirte a una carrera.",
        no_vehicle_owned = "No tienes ningún vehículo en tu garaje. Por favor, añade uno primero.",
        header_no_vehicle_selected = "Vehículo No Seleccionado",
        header_no_vehicles = "Sin Vehículos",

        password_incorrect = "La contraseña es incorrecta.",
        header_access_denied = "Acceso Denegado",

        class_mismatch = "Esta carrera solo permite la clase '%{required}'. Tu clase de vehículo: '%{current}'.",
        header_class_mismatch = "Clase Incorrecta",

        cannot_join_race = "No puedes participar en esta carrera.",
        header_race_not_found = "Carrera No Encontrada",

        already_joined = "Ya te has unido a esta carrera.",
        header_already_joined = "Ya Unido",

        race_full = "Esta carrera ya está llena.",
        header_race_full = "Carrera Llena",

        race_joined = "Te has unido a la carrera con éxito.",
        header_race_joined = "Carrera Unida",

        not_enough_money = "No tienes suficiente dinero para unirte a esta carrera.",
        header_insufficient_funds = "Fondos Insuficientes",

        race_update = "Actualización de Carrera",
        player_joined_race = "%{player} se unió a tu carrera.",

        chip_missing = "No tienes el chip necesario",
        header_chip_missing = "Chip Faltante",

        not_authorized = "No autorizado",
        header_not_authorized = "No Autorizado",

        cooldown_active = "Tiempo de espera activo",
        header_cooldown = "Enfriamiento",

        race_started = "La carrera comenzó con éxito",
        header_race_start = "Inicio de Carrera",

        header_invalid_race = "Carrera Inválida",
        delete_not_authorized = "No estás autorizado para eliminar esta carrera.",
        header_permission_denied = "Permiso Denegado",

        race_deleted = "Carrera eliminada con éxito.",
        header_race_removed = "Carrera Eliminada",
        car_selected = "Has seleccionado este coche para competir.",
        header_car_selected = "Vehículo Seleccionado",

        weekly_crew_reward = "Recompensa Semanal de la Crew",
        weekly_crew_reward_msg = "¡Tu crew '%{crew}' ganó la recompensa semanal!",
        invalid_crew_id = "ID de crew inválido.",
        already_sent_join_request = "Ya has enviado una solicitud para unirte a esta crew.",
                
        crew_join_request = "Solicitud de Unión a Crew",
        crew_join_request_msg = "%{player} quiere unirse a tu crew.",
        crew_request_denied = "Tu solicitud para unirte a la crew fue rechazada.",
        header_crew = "Crew",
        no_owned_crew = "No tienes ninguna crew.",
        no_pending_requests = "No hay solicitudes pendientes.",

        crew_request_accepted = "Tu solicitud para unirte a la crew fue aceptada.",
        request_accepted = "Solicitud aceptada.",

        invalid_bet = "Apuesta Inválida",
        bet_info_missing = "Falta información de la apuesta.",
        cannot_bet_self = "No puedes apostar por ti mismo.",
        not_enough_money_bet = "No tienes suficiente dinero para realizar esta apuesta.",
        sql_error = "Error SQL",
        bet_not_saved = "La apuesta no pudo guardarse.",

        bet_placed = "Apuesta Realizada",
        bet_placed_success = "¡Tu apuesta se realizó con éxito!",

        new_bet_placed = "Nueva Apuesta Realizada",
        someone_bet_on_you = "Alguien apostó por ti.",

        reward_not_found = "Recompensa no encontrada",
        reward_claimed = "¡Recompensa reclamada!",

        need_money_create_crew = "Necesitas $%{money} para crear una crew.",
        missing_field = "Campo Faltante",
        enter_crew_name = "Por favor ingresa un nombre para la crew.",
        enter_crew_description = "Por favor ingresa una descripción para la crew.",

        duplicate_crew_name = "Nombre de Crew Duplicado",
        crew_name_exists = "Ya existe una crew con este nombre.",

        crew_exists = "La Crew Existe",
        already_own_crew = "Ya eres dueño de una crew.",
        already_in_crew = "Ya eres miembro de una crew.",

        crew_create_failed = "La creación de la crew falló. Inténtalo de nuevo.",
        crew_created = "¡Crew creada con éxito!",
        header_crew_created = "Crew Creada",

        crew_error = "Error de Crew",
        not_in_crew = "No estás en una crew.",

        crew_not_found = "Crew no encontrada.",
        unauthorized = "No autorizado",
        only_leader_can_kick = "Solo los líderes de la crew pueden expulsar miembros.",

        member_removed = "Miembro Eliminado",
        member_removed_success = "El miembro de la crew fue eliminado con éxito.",

        crew_not_found_header = "Crew No Encontrada",
        crew_not_exist = "La crew seleccionada no existe.",

        only_owner_can_delete_crew = "Solo el dueño de la crew puede eliminarla.",

        crew_deleted = "Crew Eliminada",
        crew_deleted_success = "Tu crew fue eliminada con éxito.",

        not_enough_money_race = "La tarifa de entrada que estableciste para esta carrera es demasiado baja.",
        missing_item = "Objeto Faltante",
        race_chip_required = "Se requiere un chip de carrera para crear una carrera. Asegúrate de tener uno en tu inventario.",

        not_authorized_create_race = "No estás autorizado para crear una carrera. Contacta a un administrador de carreras si crees que es un error.",

        duplicate_race_name = "Nombre de Carrera Duplicado",
        race_name_exists = "Ya existe una carrera con este nombre. Por favor elige un nombre diferente.",

        race_created = "Carrera Creada",
        race_created_success = "Carrera creada con éxito. Ahora puedes esperar a que otros se unan e iniciar la carrera cuando estés listo.",
        auto_race = "CARRERA AUTOMÁTICA",
        auto_race_message = "Esta carrera comenzará automáticamente en %{time} minutos.",
        join_request_sent = "Solicitud de Unión Enviada",
        too_far_start = "Estás demasiado lejos del punto de inicio de la carrera.",
        track_error_header = "Error de Pista",
        track_error_message = "¡No se pudieron encontrar los datos de la pista! Por favor, inténtalo de nuevo.",
    }
}

return Translations
