local Translations = {
    general = {
        race_owner_cannot_leave = "Le créateur de la course ne peut pas quitter la course.",
        race_left = "Vous avez quitté la course.",
        not_in_race = "Vous ne faites pas partie de cette course.",
        race_not_found = "Course introuvable.",

        header_cant_get_out = "Vous ne pouvez pas sortir",
        header_race_left = "Course quittée",
        header_not_joined = "Non inscrit",
        header_error = "Erreur",

        must_select_vehicle = "Vous devez sélectionner un véhicule dans votre garage avant de rejoindre une course.",
        no_vehicle_owned = "Vous n’avez aucun véhicule dans votre garage. Veuillez en ajouter un d’abord.",
        header_no_vehicle_selected = "Aucun véhicule sélectionné",
        header_no_vehicles = "Aucun véhicule",

        password_incorrect = "Le mot de passe est incorrect.",
        header_access_denied = "Accès refusé",

        class_mismatch = "Cette course autorise uniquement la classe '%{required}'. Classe de votre véhicule : '%{current}'.",
        header_class_mismatch = "Classe incompatible",

        cannot_join_race = "Vous ne pouvez pas participer à cette course.",
        header_race_not_found = "Course introuvable",

        already_joined = "Vous avez déjà rejoint cette course.",
        header_already_joined = "Déjà inscrit",

        race_full = "Cette course est déjà complète.",
        header_race_full = "Course complète",

        race_joined = "Vous avez rejoint la course avec succès.",
        header_race_joined = "Course rejointe",

        not_enough_money = "Vous n’avez pas assez d’argent pour rejoindre cette course.",
        header_insufficient_funds = "Fonds insuffisants",

        race_update = "Mise à jour de la course",
        player_joined_race = "%{player} a rejoint votre course.",

        chip_missing = "Vous n’avez pas la puce requise",
        header_chip_missing = "Puce manquante",

        not_authorized = "Non autorisé",
        header_not_authorized = "Non autorisé",

        cooldown_active = "Temps de recharge actif",
        header_cooldown = "Temps de recharge",

        race_started = "La course a démarré avec succès",
        header_race_start = "Début de la course",

        header_invalid_race = "Course invalide",
        delete_not_authorized = "Vous n’êtes pas autorisé à supprimer cette course.",
        header_permission_denied = "Permission refusée",

        race_deleted = "Course supprimée avec succès.",
        header_race_removed = "Course supprimée",
        car_selected = "Vous avez sélectionné ce véhicule pour la course.",
        header_car_selected = "Véhicule sélectionné",

        weekly_crew_reward = "Récompense hebdomadaire de l’équipe",
        weekly_crew_reward_msg = "Votre équipe '%{crew}' a remporté la récompense hebdomadaire !",
        invalid_crew_id = "ID d’équipe invalide.",
        already_sent_join_request = "Vous avez déjà envoyé une demande pour rejoindre cette équipe.",
                
        crew_join_request = "Demande d’adhésion à l’équipe",
        crew_join_request_msg = "%{player} souhaite rejoindre votre équipe.",
        crew_request_denied = "Votre demande d’adhésion à l’équipe a été refusée.",
        header_crew = "Équipe",
        no_owned_crew = "Vous ne possédez aucune équipe.",
        no_pending_requests = "Aucune demande en attente.",

        crew_request_accepted = "Votre demande d’adhésion à l’équipe a été acceptée.",
        request_accepted = "Demande acceptée.",

        invalid_bet = "Pari invalide",
        bet_info_missing = "Les informations du pari sont manquantes.",
        cannot_bet_self = "Vous ne pouvez pas parier sur vous-même.",
        not_enough_money_bet = "Vous n’avez pas assez d’argent pour placer ce pari.",
        sql_error = "Erreur SQL",
        bet_not_saved = "Le pari n’a pas pu être enregistré.",

        bet_placed = "Pari placé",
        bet_placed_success = "Votre pari a été placé avec succès !",

        new_bet_placed = "Nouveau pari placé",
        someone_bet_on_you = "Quelqu’un a parié sur vous.",

        reward_not_found = "Récompense introuvable",
        reward_claimed = "Récompense réclamée !",

        need_money_create_crew = "Vous avez besoin de $%{money} pour créer une équipe.",
        missing_field = "Champ manquant",
        enter_crew_name = "Veuillez entrer un nom d’équipe.",
        enter_crew_description = "Veuillez entrer une description de l’équipe.",

        duplicate_crew_name = "Nom d’équipe en double",
        crew_name_exists = "Une équipe avec ce nom existe déjà.",

        crew_exists = "L’équipe existe",
        already_own_crew = "Vous possédez déjà une équipe.",
        already_in_crew = "Vous êtes déjà membre d’une équipe.",

        crew_create_failed = "La création de l’équipe a échoué. Veuillez réessayer.",
        crew_created = "Équipe créée avec succès !",
        header_crew_created = "Équipe créée",

        crew_error = "Erreur d’équipe",
        not_in_crew = "Vous n’êtes dans aucune équipe.",

        crew_not_found = "Équipe introuvable.",
        unauthorized = "Non autorisé",
        only_leader_can_kick = "Seuls les chefs d’équipe peuvent exclure des membres.",

        member_removed = "Membre supprimé",
        member_removed_success = "Le membre de l’équipe a été supprimé avec succès.",

        crew_not_found_header = "Équipe introuvable",
        crew_not_exist = "L’équipe sélectionnée n’existe pas.",

        only_owner_can_delete_crew = "Seul le propriétaire de l’équipe peut la supprimer.",

        crew_deleted = "Équipe supprimée",
        crew_deleted_success = "Votre équipe a été supprimée avec succès.",

        not_enough_money_race = "Les frais d’inscription que vous avez définis pour cette course sont trop bas.",
        missing_item = "Objet manquant",
        race_chip_required = "Une puce de course est requise pour créer une course. Assurez-vous d’en avoir une dans votre inventaire.",

        not_authorized_create_race = "Vous n’êtes pas autorisé à créer une course. Contactez un responsable des courses si vous pensez qu’il s’agit d’une erreur.",

        duplicate_race_name = "Nom de course en double",
        race_name_exists = "Une course avec ce nom existe déjà. Veuillez choisir un nom différent.",

        race_created = "Course créée",
        race_created_success = "La course a été créée avec succès. Vous pouvez maintenant attendre que d’autres rejoignent la course et la démarrer lorsque vous serez prêt.",
        auto_race = "COURSE AUTOMATIQUE",
        auto_race_message = "Cette course commencera automatiquement dans %{time} minutes.",
        join_request_sent = "Demande d’adhésion envoyée",
        too_far_start = "Vous êtes trop loin du point de départ de la course.", 
        track_error_header = "Erreur de piste",
        track_error_message = "Les données de la piste n’ont pas pu être trouvées ! Veuillez réessayer.",
    }
}

return Translations
