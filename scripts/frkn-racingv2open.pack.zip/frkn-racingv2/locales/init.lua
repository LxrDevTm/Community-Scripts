local default = "en"
local locale = FRKN.language or default

local filePath = ("locales/%s.lua"):format(locale)

local content = LoadResourceFile(GetCurrentResourceName(), filePath)

if not content then
    print(("^1[Locale] File '%s' not found. Using fallback '%s'.^0"):format(locale, default))
    filePath = ("locales/%s.lua"):format(default)
    content = LoadResourceFile(GetCurrentResourceName(), filePath)
end

local fn = load(content)
if fn then fn() end
