local Translations = {
    general = {
        race_owner_cannot_leave = "Создатель гонки не может покинуть гонку.",
        race_left = "Вы покинули гонку.",
        not_in_race = "Вы не участвуете в этой гонке.",
        race_not_found = "Гонка не найдена.",

        header_cant_get_out = "Вы не можете выйти",
        header_race_left = "Гонка покинута",
        header_not_joined = "Не присоединился",
        header_error = "Ошибка",

        must_select_vehicle = "Перед вступлением в гонку вы должны выбрать транспорт в своем гараже.",
        no_vehicle_owned = "У вас нет транспорта в гараже. Пожалуйста, сначала добавьте транспорт.",
        header_no_vehicle_selected = "Транспорт не выбран",
        header_no_vehicles = "Нет транспорта",

        password_incorrect = "Неверный пароль.",
        header_access_denied = "Доступ запрещён",

        class_mismatch = "Эта гонка допускает только класс '%{required}'. Класс вашего транспорта: '%{current}'.",
        header_class_mismatch = "Несоответствие класса",

        cannot_join_race = "Вы не можете участвовать в этой гонке.",
        header_race_not_found = "Гонка не найдена",

        already_joined = "Вы уже присоединились к этой гонке.",
        header_already_joined = "Уже присоединились",

        race_full = "Эта гонка уже заполнена.",
        header_race_full = "Гонка заполнена",

        race_joined = "Вы успешно присоединились к гонке.",
        header_race_joined = "Вы в гонке",

        not_enough_money = "У вас недостаточно денег, чтобы присоединиться к этой гонке.",
        header_insufficient_funds = "Недостаточно средств",

        race_update = "Обновление гонки",
        player_joined_race = "%{player} присоединился к вашей гонке.",

        chip_missing = "У вас нет необходимого чипа",
        header_chip_missing = "Чип отсутствует",

        not_authorized = "Нет доступа",
        header_not_authorized = "Не авторизован",

        cooldown_active = "Активен период ожидания",
        header_cooldown = "Перезарядка",

        race_started = "Гонка успешно началась",
        header_race_start = "Старт гонки",

        header_invalid_race = "Недействительная гонка",
        delete_not_authorized = "У вас нет прав на удаление этой гонки.",
        header_permission_denied = "Доступ запрещён",

        race_deleted = "Гонка успешно удалена.",
        header_race_removed = "Гонка удалена",
        car_selected = "Вы выбрали этот транспорт для гонки.",
        header_car_selected = "Транспорт выбран",

        weekly_crew_reward = "Еженедельная награда команды",
        weekly_crew_reward_msg = "Ваша команда '%{crew}' выиграла еженедельную награду!",
        invalid_crew_id = "Неверный ID команды.",
        already_sent_join_request = "Вы уже отправили запрос на вступление в эту команду.",
                
        crew_join_request = "Запрос на вступление в команду",
        crew_join_request_msg = "%{player} хочет вступить в вашу команду.",
        crew_request_denied = "Ваш запрос на вступление в команду был отклонён.",
        header_crew = "Команда",
        no_owned_crew = "У вас нет собственной команды.",
        no_pending_requests = "Нет ожидающих запросов.",

        crew_request_accepted = "Ваш запрос на вступление в команду был принят.",
        request_accepted = "Запрос принят.",

        invalid_bet = "Недействительная ставка",
        bet_info_missing = "Отсутствует информация о ставке.",
        cannot_bet_self = "Вы не можете ставить на себя.",
        not_enough_money_bet = "У вас недостаточно денег для этой ставки.",
        sql_error = "Ошибка SQL",
        bet_not_saved = "Ставка не была сохранена.",

        bet_placed = "Ставка сделана",
        bet_placed_success = "Ваша ставка успешно сделана!",

        new_bet_placed = "Новая ставка сделана",
        someone_bet_on_you = "Кто-то сделал ставку на вас.",

        reward_not_found = "Награда не найдена",
        reward_claimed = "Награда получена!",

        need_money_create_crew = "Для создания команды требуется $%{money}.",
        missing_field = "Отсутствует поле",
        enter_crew_name = "Пожалуйста, введите название команды.",
        enter_crew_description = "Пожалуйста, введите описание команды.",

        duplicate_crew_name = "Дублирующееся название команды",
        crew_name_exists = "Команда с таким названием уже существует.",

        crew_exists = "Команда существует",
        already_own_crew = "У вас уже есть команда.",
        already_in_crew = "Вы уже состоите в команде.",

        crew_create_failed = "Не удалось создать команду. Пожалуйста, попробуйте снова.",
        crew_created = "Команда успешно создана!",
        header_crew_created = "Команда создана",

        crew_error = "Ошибка команды",
        not_in_crew = "Вы не состоите в команде.",

        crew_not_found = "Команда не найдена.",
        unauthorized = "Нет доступа",
        only_leader_can_kick = "Только лидер команды может исключать участников.",

        member_removed = "Участник удалён",
        member_removed_success = "Участник команды успешно удалён.",

        crew_not_found_header = "Команда не найдена",
        crew_not_exist = "Выбранная команда не существует.",

        only_owner_can_delete_crew = "Только владелец команды может удалить команду.",

        crew_deleted = "Команда удалена",
        crew_deleted_success = "Ваша команда успешно удалена.",

        not_enough_money_race = "Установленный вами вступительный взнос для этой гонки слишком низкий.",
        missing_item = "Отсутствует предмет",
        race_chip_required = "Для создания гонки требуется гоночный чип. Убедитесь, что он есть в вашем инвентаре.",

        not_authorized_create_race = "У вас нет прав на создание гонки. Свяжитесь с менеджером гонок, если считаете, что это ошибка.",

        duplicate_race_name = "Дублирующееся название гонки",
        race_name_exists = "Гонка с таким названием уже существует. Пожалуйста, выберите другое название.",

        race_created = "Гонка создана",
        race_created_success = "Гонка успешно создана. Теперь вы можете ждать других участников и начать гонку, когда будете готовы.",
        auto_race = "АВТОЗАЕЗД",
        auto_race_message = "Этот заезд автоматически начнётся через %{time} минут.",
        join_request_sent = "Запрос на вступление отправлен",
        too_far_start = "Вы слишком далеко от точки старта гонки.",
        track_error_header = "Ошибка трассы",
        track_error_message = "Данные трассы не найдены! Пожалуйста, попробуйте снова.",

    }
}

return Translations
