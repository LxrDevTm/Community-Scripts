local Translations = {
    general = {
        race_owner_cannot_leave = "Yarış kurucusu yarıştan kendisi ayrılamaz.",
        race_left = "Yarıştan ayrıldın.",
        not_in_race = "Bu yarışın bir parçası değilsin.",
        race_not_found = "Yarış bulunamadı.",

        header_cant_get_out = "Çıkamazsın",
        header_race_left = "Yarıştan Ayrıldın",
        header_not_joined = "Katılmadın",
        header_error = "Hata",

        must_select_vehicle = "Yarışa katılmadan önce garajından bir araç seçmelisin.",
        no_vehicle_owned = "Garajında hiç araç yok. Lütfen önce bir araç ekle.",
        header_no_vehicle_selected = "Araç Seçilmedi",
        header_no_vehicles = "Araç Yok",

        password_incorrect = "Şifre yanlış.",
        header_access_denied = "Erişim Reddedildi",

        class_mismatch = "Bu yarış sadece '%{required}' sınıfına izin veriyor. Senin araç sınıfın: '%{current}'.",
        header_class_mismatch = "Sınıf Uyuşmazlığı",

        cannot_join_race = "Bu yarışa katılamazsın.",
        header_race_not_found = "Yarış Bulunamadı",

        already_joined = "Bu yarışa zaten katıldın.",
        header_already_joined = "Zaten Katıldın",

        race_full = "Bu yarış dolu.",
        header_race_full = "Yarış Dolu",

        race_joined = "Yarışa başarıyla katıldın.",
        header_race_joined = "Yarışa Katıldın",

        not_enough_money = "Bu yarışa katılmak için yeterli paran yok.",
        header_insufficient_funds = "Yetersiz Bakiye",

        race_update = "Yarış Güncellemesi",
        player_joined_race = "%{player} yarışına katıldı.",

        chip_missing = "Gerekli çipe sahip değilsin",
        header_chip_missing = "Çip Eksik",

        not_authorized = "Yetkin yok",
        header_not_authorized = "Yetkisiz",

        cooldown_active = "Bekleme süresi aktif",
        header_cooldown = "Bekleme Süresi",

        race_started = "Yarış başarıyla başladı",
        header_race_start = "Yarış Başladı",

        header_invalid_race = "Geçersiz Yarış",
        delete_not_authorized = "Bu yarışı silmeye yetkin yok.",
        header_permission_denied = "İzin Reddedildi",

        race_deleted = "Yarış başarıyla silindi.",
        header_race_removed = "Yarış Kaldırıldı",
        car_selected = "Bu aracı yarış için seçtin.",
        header_car_selected = "Araç Seçildi",

        header_success = "Başarılı",
        track_deleted = "Pist başarıyla silindi.",
        track_not_found = "Pist bulunamadı.",
        invalid_track_id = "Geçersiz pist ID.",

        weekly_crew_reward = "Haftalık Ekip Ödülü",
        weekly_crew_reward_msg = "'%{crew}' ekibin haftalık ödülü kazandı!",
        invalid_crew_id = "Geçersiz ekip ID.",
        already_sent_join_request = "Bu ekibe zaten katılma isteği gönderdin.",
                
        crew_join_request = "Ekip Katılım İsteği",
        crew_join_request_msg = "%{player} ekibine katılmak istiyor.",
        crew_request_denied = "Ekip katılım isteğin reddedildi.",
        header_crew = "Ekip",
        no_owned_crew = "Sahip olduğun bir ekip yok.",
        no_pending_requests = "Bekleyen istek yok.",

        crew_request_accepted = "Ekip katılım isteğin kabul edildi.",
        request_accepted = "İstek kabul edildi.",

        invalid_bet = "Geçersiz Bahis",
        bet_info_missing = "Bahis bilgileri eksik.",
        bet_race_started = "Bu yarış başlamış, artık bahis yapamazsınız.",
        bet_already_placed = "Bu yarışa zaten bahis yaptınız. Sadece 1 adet bahis yapabilirsiniz.",
        cannot_bet_self = "Kendine bahis oynayamazsın.",
        not_enough_money_bet = "Bu bahsi oynamak için yeterli paran yok.",
        sql_error = "SQL Hatası",
        bet_not_saved = "Bahis kaydedilemedi.",

        bet_placed = "Bahis Yapıldı",
        bet_placed_success = "Bahsin başarıyla yapıldı!",

        new_bet_placed = "Yeni Bahis Yapıldı",
        someone_bet_on_you = "Biri sana bahis oynadı.",

        reward_not_found = "Ödül bulunamadı",
        reward_claimed = "Ödül alındı!",

        need_money_create_crew = "Ekip kurmak için $%{money} gerekiyor.",
        missing_field = "Eksik Alan",
        enter_crew_name = "Lütfen bir ekip adı gir.",
        enter_crew_description = "Lütfen bir ekip açıklaması gir.",

        duplicate_crew_name = "Aynı İsimde Ekip",
        crew_name_exists = "Bu isimde bir ekip zaten mevcut.",

        crew_exists = "Ekip Mevcut",
        already_own_crew = "Zaten bir ekibe sahipsin.",
        already_in_crew = "Zaten bir ekibin üyesisin.",

        crew_create_failed = "Ekip oluşturulamadı. Lütfen tekrar dene.",
        crew_created = "Ekip başarıyla oluşturuldu!",
        header_crew_created = "Ekip Oluşturuldu",

        crew_error = "Ekip Hatası",
        not_in_crew = "Bir ekipte değilsin.",

        crew_not_found = "Ekip bulunamadı.",
        unauthorized = "Yetkisiz",
        only_leader_can_kick = "Sadece ekip liderleri üyeleri çıkarabilir.",

        member_removed = "Üye Çıkarıldı",
        member_removed_success = "Ekip üyesi başarıyla çıkarıldı.",

        crew_not_found_header = "Ekip Bulunamadı",
        crew_not_exist = "Seçilen ekip mevcut değil.",

        only_owner_can_delete_crew = "Sadece ekip sahibi ekibi silebilir.",

        crew_deleted = "Ekip Silindi",
        crew_deleted_success = "Ekibin başarıyla silindi.",

        not_enough_money_race = "Bu yarışı başlatmak için belirlediğin giriş ücreti çok düşük.",
        missing_item = "Eksik Eşya",
        race_chip_required = "Yarış oluşturmak için bir yarış çipi gerekiyor. Envanterinde olduğundan emin ol.",

        not_authorized_create_race = "Yarış oluşturmaya yetkin yok. Bunun bir hata olduğunu düşünüyorsan bir yarış yöneticisiyle iletişime geç.",

        duplicate_race_name = "Aynı İsimde Yarış",
        race_name_exists = "Bu isimde bir yarış zaten mevcut. Lütfen farklı bir isim seç.",

        race_created = "Yarış Oluşturuldu",
        race_created_success = "Yarış başarıyla oluşturuldu. Diğerlerinin katılmasını bekleyebilir ve hazır olduğunda yarışı başlatabilirsin.",
        auto_race = "OTOMATİK YARIŞ",
        auto_race_message = "Bu yarış %{time} dakika sonra otomatik olarak başlayacak.",
        join_request_sent = "Katılma Talebi Gönderildi",
        too_far_start = "Yarış başlangıç noktasından çok uzaktasın.",
        track_error_header = "Parkur Hatası",
        track_error_message = "Parkur verileri bulunamadı! Lütfen tekrar dene.",

        auto_race_header = "Otomatik Yarış",
        auto_race_announce_header = "Otomatik Yarış Duyurusu",
        auto_race_no_active = "Şu anda aktif bir otomatik yarış bulunmuyor.",
        auto_race_joined = "Otomatik yarışa başarıyla katıldınız!",
        auto_race_join_failed = "Yarışa katılamadınız. Zaten bir yarıştaysanız /leaverace yazın.",
        auto_race_starting_soon = "Yarış %{seconds} saniye sonra başlıyor! Katılmak için /autorace yazın.",
        auto_race_started = "%{count} yarışmacı ile otomatik yarış başladı!",
        auto_race_not_in_vehicle = "Araçta olmadığınız için otomatik yarıştan çıkarıldınız.",

        race_prize_header = "Yarış Ödülü",
        race_prize_money = "%{position}. sırada bitirdiniz! Ödül: $%{amount}",
        race_prize_item = "%{position}. sırada bitirdiniz! Ödül: %{count}x %{item}",

        race_error_header = "Yarışma Hatası",
        already_in_active_race = "Zaten aktif bir yarışta bulunuyorsunuz! Çıkmak için /leaverace yazın.",
        player_offline = "Oyuncu çevrimdışı",
        player_not_in_vehicle = "Araçta değil",
        race_cancelled_header = "Yarış İptal",

        leave_race_header = "Yarış",
        leave_race_success = "%{count} yarıştan başarıyla ayrıldınız.",
        leave_race_not_in = "Herhangi bir yarışta bulunmuyorsunuz.",

        auto_race_buyin = "Giriş",
        auto_race_free = "Ücretsiz",
        auto_race_laps = "Tur",
        auto_race_minutes_left = "dk sonra başlıyor! /autorace ile katıl",
        auto_race_marker_text = "~w~OTOMATİK YARIŞ ALANI",
        race_start_marker_text = "~w~YARIŞ BAŞLANGIÇ ALANI",

        invalid_track_id = "Geçersiz track ID.",
        track_deleted = "Pist başarıyla silindi.",
        track_not_found = "Pist bulunamadı veya zaten silinmiş.",
        not_enough_racers = "Yeterli yarışmacı kalmadı (%{count} kişi atıldı). Yarış iptal edildi.",
        not_enough_racers_disqualified = "Yeterli yarışmacı kalmadı, yarış iptal edildi.",
        header_chat_error = "Sohbet Hatası",
        invalid_message = "Geçersiz mesaj.",
        cooldown_time_remaining = "Yeni bir yarış başlatmak için %{minutes} dakika daha beklemelisiniz.",

        race_not_active = "Yarış şu anda aktif değil.",
        no_checkpoint_teleport = "Işınlanacak kontrol noktası yok.",
        teleported_checkpoint = "Son kontrol noktasına ışınlandınız.",
        teleport_failed = "Son kontrol noktası bulunamadı.",
        must_be_in_vehicle = "Vites kutusu sistemini kullanmak için bir araçta olmalısınız.",
        max_gear_reached = "Maksimum vitese ulaşıldı!",
        min_gear_reached = "Minimum vitese ulaşıldı!",

        notify_join = "Yarışa başarıyla katıldınız.",
        notify_incar = "Aracınıza geri binin!",
        notify_disqualified = "Yarıştan diskalifiye oldunuz.",
        notify_disqualifyreason = "Yarışa girdiğiniz araçla yarışmanız gerektiği için diskalifiye edildiniz.",
        notify_raceover = "Yarış bitti! Tüm turları tamamladınız.",
        notify_raceovertime = "Yarış bitti! Süre doldu.",
        notify_racejoin = "Yarışa katıldınız.",

        gearbox_enabled = "Vites kutusu sistemi açıldı.",
        gearbox_disabled = "Vites kutusu sistemi kapatıldı.",
        gearbox_manual = "Vites: Manuel",
        gearbox_automatic = "Vites: Otomatik",

        auto_race_join_info = "Giriş Ücreti",

        race_already_started = "Bu yarış zaten başlatılmış ve devam ediyor.",
        tablet_blocked_racing = "Yarıştayken tableti açamazsınız.",
        too_far_from_start = "Yarıştan çıkarıldınız: başlangıç noktasına çok uzak (%{distance}m).",
        race_ended_by_owner = "Yarış sahibi tarafından sonlandırıldı. Giriş ücretiniz iade edildi.",

        no_checkpoints_added = "Hiç checkpoint eklemediniz! Kaydetmeden önce en az bir checkpoint ekleyin.",
        track_saved = "Parkur başarıyla kaydedildi!",
        track_saved_select = "Parkur kaydedildi! 'Pist Seç' kısmından seçebilirsiniz.",
        cannot_create_in_race = "Aktif bir yarıştayken yarış oluşturamazsınız. Lütfen önce mevcut yarıştan çıkın (/leaverace).",
        owner_too_far = "Yarış başlangıç alanından çok uzaksınız! Haritada işaretlenen alana gidin.",
        owner_disqualified = "Yarış sahibi diskalifiye oldu, yarış iptal edildi.",
        must_be_in_vehicle_create = "Yarış oluşturmak için bir araçta olmalısınız.",
        vehicle_class_mismatch_create = "Altınızdaki araç '%{current}' sınıfında. '%{required}' sınıfını seçemezsiniz.",
        track_cancelled = "Parkur oluşturma iptal edildi.",
        leader_transferred = "Yarış liderliği size devredildi!",
        must_be_on_motorcycle = "Motor yarışı oluşturmak veya katılmak için bir motosikletin üzerinde olmalısınız.",
        must_be_in_car = "Araba yarışı oluşturmak veya katılmak için bir arabanın içinde olmalısınız.",
        track_busy = "Bu pistte başka bir yarış devam ediyor. Yarış bitene kadar bu pistte yarışamazsınız.",
        race_auto_deleted = "Yarış zamanında başlatılmadığı için otomatik olarak silindi. Giriş ücretiniz iade edildi.",
    }
}

return Translations
