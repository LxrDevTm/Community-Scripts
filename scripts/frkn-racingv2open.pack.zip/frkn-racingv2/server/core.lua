Core = nil
CoreName = nil
CoreReady = false
Citizen.CreateThread(function()
    for k, v in pairs(Cores) do
        if GetResourceState(v.ResourceName) == "starting" or GetResourceState(v.ResourceName) == "started" then
            CoreName = v.ResourceName
            Core = v.GetFramework()
            CoreReady = true
        end
    end
end)


function GetActiveInventory()
    if GetResourceState("qb-inventory") == "started" then
        return "qb-inventory"
    elseif GetResourceState("qs-inventory") == "started" then
        return "qs-inventory"
    elseif GetResourceState("ps-inventory") == "started" then
        return "ps-inventory"
    elseif GetResourceState("lj-inventory") == "started" then
        return "lj-inventory"
    elseif GetResourceState("ox_inventory") == "started" then
        return "ox_inventory"
    elseif GetResourceState("codem-inventory") == "started" then
        return "codem-inventory"
    end
    return nil
end

function AddItem(source, name, amount, metadata)
    if CoreName == "qb-core" or CoreName == "qbx_core" then
        local player = Core.Functions.GetPlayer(source)
        return player and player.Functions.AddItem(name, amount, false, metadata)

    elseif CoreName == "es_extended" then
        local player = Core.GetPlayerFromId(source)
        local hasQs = GetResourceState('qs-inventory') == 'started'
        local hasEsx = GetResourceState('esx_inventoryhud') == 'started'
        local hasOx = GetResourceState('ox_inventory') == 'started'
        local hasCheeza = GetResourceState('inventory') == 'started'

        if hasQs then
            return exports['qs-inventory']:AddItem(source, name, amount, false, metadata)
        elseif hasEsx then
            return player and player.addInventoryItem(name, amount)
        elseif hasOx then
            return exports['ox_inventory']:AddItem(source, name, amount, metadata)
        elseif hasCheeza then
            local item = { type = "item_standard", name = name, metadata = metadata }
            local inv = { type = "player", id = source }
            return exports['inventory']:AddItemToInventory(source, item, amount, inv)
        end
    end
end




function GetPlayer(source)
    if CoreName == "qb-core" or CoreName == "qbx_core" then
        local player = Core.Functions.GetPlayer(source)
        return player
    elseif CoreName == "es_extended" then
        local player = Core.GetPlayerFromId(source)
        return player
    end
end

function Notify(text, length, type)
    if CoreName == "qb-core" or CoreName == "qbx_core" then
        Core.Functions.Notify(message, type, time)
    elseif CoreName == "es_extended" then
        Core.ShowNotification(text)
    end
end


function AddMoney(src, moneyType, amount, description)
    amount = tonumber(amount) or 0
    src = tonumber(src) or 0
    if amount <= 0 or src <= 0 then return end

    if CoreName == "qb-core" or CoreName == "qbx_core" then
        local player = Core.Functions.GetPlayer(src)
        if player then
            if moneyType == "cash" or moneyType == "bank" then
                player.Functions.AddMoney(moneyType, amount, description or "frkn-racing")
            end
        end

    elseif CoreName == "es_extended" then
        local player = Core.GetPlayerFromId(src)
        if player then
            if moneyType == "bank" then
                player.addAccountMoney("bank", amount, description or "frkn-racing")
            elseif moneyType == "cash" then
                player.addMoney(amount, description or "frkn-racing")
            end
        end
    end
end



function RemoveMoney(src, type, amount, description)
    if CoreName == "qb-core" or CoreName == "qbx_core" then
        local player = Core.Functions.GetPlayer(src)
        player.Functions.RemoveMoney(type, amount, description)
    elseif CoreName == "es_extended" then
        local player = Core.GetPlayerFromId(src)
        if type == "bank" then
            player.removeAccountMoney("bank", amount, description)
        elseif type == "cash" then
            player.removeMoney(amount, description)
        else
        end
    end
end


function GetPlayerMoney(src, type)
    if CoreName == "qb-core" or CoreName == "qbx_core" then
        local player = Core.Functions.GetPlayer(src)
        return player.PlayerData.money[type]
    elseif CoreName == "es_extended" then
        local player = Core.GetPlayerFromId(src)
        local acType = "bank"
        if type == "cash" then
            acType = "money"
        end
        local account = player.getAccount(acType).money
        return account
    end
end

function TransferVehicle(loserIdentifier, winnerIdentifier, carPlate, loserLicense)
    if not loserIdentifier or not winnerIdentifier or not carPlate then return end

    if CoreName == "qb-core" then
        local vehicles = MySQL.Sync.fetchAll("SELECT * FROM player_vehicles WHERE citizenid = @citizenid AND plate = @plate", {
            ['@citizenid'] = loserIdentifier,
            ['@plate'] = carPlate
        })

        for _, veh in pairs(vehicles) do
            MySQL.Sync.execute("DELETE FROM player_vehicles WHERE id = @id", {
                ['@id'] = veh.id
            })

            MySQL.Sync.execute("INSERT INTO player_vehicles (license, citizenid, plate, vehicle, mods, hash, garage, state) VALUES (@license, @cid, @plate, @vehicle, @mods, @hash, @garage, @state)", {
                ['@license'] = loserLicense or veh.license or "UNKNOWN_LICENSE",
                ['@cid'] = winnerIdentifier,
                ['@plate'] = veh.plate,
                ['@vehicle'] = veh.vehicle,
                ['@mods'] = veh.mods,
                ['@hash'] = veh.hash,
                ['@garage'] = veh.garage or "pillboxgarage",
                ['@state'] = veh.state or 0
            })
        end

    elseif CoreName == "es_extended" then
        local vehicles = MySQL.Sync.fetchAll("SELECT * FROM owned_vehicles WHERE owner = @owner AND plate = @plate", {
            ['@owner'] = loserIdentifier,
            ['@plate'] = carPlate
        })

        for _, veh in pairs(vehicles) do
            MySQL.Sync.execute("DELETE FROM owned_vehicles WHERE id = @id", {
                ['@id'] = veh.id
            })

            MySQL.Sync.execute("INSERT INTO owned_vehicles (owner, plate, vehicle, stored, type) VALUES (@owner, @plate, @vehicle, @stored, @type)", {
                ['@owner'] = winnerIdentifier,
                ['@plate'] = veh.plate,
                ['@vehicle'] = veh.vehicle,
                ['@stored'] = veh.stored or 1,
                ['@type'] = veh.type or "car"
            })
        end
    end
end


function GetPlayerCid(source)
    if CoreName == "qb-core" or CoreName == "qbx_core" then
        local player = Core.Functions.GetPlayer(source)
        if player ~= nil then
            return player.PlayerData.citizenid
        else
            return nil
        end
    elseif CoreName == "es_extended" then
        local player = Core.GetPlayerFromId(source)
        if player ~= nil and player.getIdentifier ~= nil then
            return player.getIdentifier()
        else
            return nil
        end    
    else
    end
end

function GetIdentifier(source)
    local source = tonumber(source)
    if CoreName == "qb-core" or CoreName == "qbx_core" then
        local player = Core.Functions.GetPlayer(source)
        return player.PlayerData.citizenid
    elseif CoreName == "es_extended" then
        local player = Core.GetPlayerFromId(source)
        return player.identifier
    end
end

function GetPlayerCharName(source)
    if CoreName == "qb-core" or CoreName == "qbx_core" then
        local player = Core.Functions.GetPlayer(source)
        if player and player.PlayerData and player.PlayerData.charinfo then
            local charinfo = player.PlayerData.charinfo
            local first = charinfo.firstname or ""
            local last = charinfo.lastname or ""
            local name = (first .. " " .. last):gsub("^%s+", ""):gsub("%s+$", "")
            if name ~= "" then return name end
        end
    elseif CoreName == "es_extended" then
        local player = Core.GetPlayerFromId(source)
        if player and player.getName then
            local name = player.getName()
            if name and name ~= "" then return name end
        end
    end
    return GetPlayerName(source) or "Unknown"
end

function Notify(source, text, length, type)
    if CoreName == "qb-core" or CoreName == "qbx_core" then
        Core.Functions.Notify(source, text, type, length)
    elseif CoreName == "es_extended" then
        local player = Core.GetPlayerFromId(source)
        player.showNotification(text)
    end
end

function GetPlayerJob(source)
    if CoreName == "qb-core" or CoreName == "qbx_core" then
        local player = Core.Functions.GetPlayer(source)
        return player.PlayerData.job
    elseif CoreName == "es_extended" then
        local player = Core.GetPlayerFromId(source)
        return player.job
    end
end

function GetPlayerGrade(source)
    if CoreName == "qb-core" or CoreName == "qbx_core" then
        local player = Core.Functions.GetPlayer(source)
        return player.PlayerData.job.grade.level
    elseif CoreName == "es_extended" then
        local player = Core.GetPlayerFromId(source)
        return player.job.grade
    end
end

function RemoveItem(source, name, amount, metadata)
    if CoreName == "qb-core" or CoreName == "qbx_core" then
        local player = Core.Functions.GetPlayer(source)
        if player then
            player.Functions.RemoveItem(name, amount, metadata)
        end

    elseif CoreName == "es_extended" then
        local player = Core.GetPlayerFromId(source)
        local hasQs = GetResourceState('qs-inventory') == 'started'
        local hasEsx = GetResourceState('esx_inventoryhud') == 'started'
        local hasOx = GetResourceState('qb-inventory') == 'started'
        local hasCodem = GetResourceState('codem-inventory') == 'started'

        if hasQs then
            return exports['qs-inventory']:RemoveItem(source, name, amount, metadata)

        elseif hasEsx then
            return player.removeInventoryItem(name, amount)

        elseif hasOx then
            return exports["qb-inventory"]:RemoveItem(source, name, amount, metadata)

        elseif hasCodem then
            return exports["codem-inventory"]:RemoveItem(source, name, amount, metadata)
        else
        end
    end
end


function GetItemByName(player, name)
    if CoreName == "qb-core" or CoreName == "qbx_core" then
        return player.Functions.GetItemByName(name)
    elseif CoreName == "es_extended" then
        local hasQs = GetResourceState('qs-inventory') == 'started'
        local hasEsx = GetResourceState('esx_inventoryhud') == 'started'
        local hasOx = GetResourceState('qb-inventory') == 'started'
        local hasCodem = GetResourceState('codem-inventory') == 'started'

        if hasQs then
            return exports['qs-inventory']:GetItem(source, name)
        elseif hasEsx then
            return player.getInventoryItem(name)
        elseif hasOx then
            return exports["qb-inventory"]:GetItem(source, name)
        elseif hasCodem then
            return exports["codem-inventory"]:GetItemByName(source, name)
        else
        end
    end
end

function HasAnyItem(xPlayer, items)
    for k , itemName in pairs(items) do
        local item = nil
        if CoreName == 'es_extended' then
            item = xPlayer.hasItem(k)
        else
            item = xPlayer.Functions.GetItemByName(k)
        end
        if item and (item.amount or item.count or 0) > 0 then
            return true
        end
    end
    return false 
end

function PlayerHasTablet(src)
    local itemName = FRKN.RacingTablet or "racing_tablet"
    local player = GetPlayer(src)
    if not player then return false end

    if CoreName == "qb-core" or CoreName == "qbx_core" then
        local item = player.Functions.GetItemByName(itemName)
        return item and (item.amount or item.count or 0) > 0

    elseif CoreName == "es_extended" then
        local hasQs = GetResourceState('qs-inventory') == 'started'
        local hasEsx = GetResourceState('esx_inventoryhud') == 'started'
        local hasOx = GetResourceState('qb-inventory') == 'started'
        local hasCodem = GetResourceState('codem-inventory') == 'started'

        if hasQs then
            local item = exports['qs-inventory']:GetItem(src, itemName)
            return item and (item.amount or item.count or 0) > 0
        elseif hasEsx then
            local item = player.getInventoryItem(itemName)
            return item and (item.count or item.amount or 0) > 0
        elseif hasOx then
            local item = exports["qb-inventory"]:GetItem(src, itemName)
            return item and (item.amount or item.count or 0) > 0
        elseif hasCodem then
            local item = exports["codem-inventory"]:GetItemByName(src, itemName)
            return item and (item.amount or item.count or 0) > 0
        else
            local item = player.hasItem(itemName)
            return item and (item.count or item.amount or 0) > 0
        end
    end

    return false
end

function GetPlayerFromIdentifier(identifier)
    for _, src in pairs(GetPlayers()) do
        if GetPlayerCid(tonumber(src)) == identifier then
            return tonumber(src)
        end
    end
    return nil
end


function GetItem(p, name)
    if CoreName == "qb-core" or CoreName == "qbx_core" then
        local player = p
        return player.Functions.GetItemByName(name)
    elseif CoreName == "es_extended" then
        local player = p
        local hasQs = GetResourceState('qs-inventory') == 'started'
        local hasEsx = GetResourceState('esx_inventoryhud') == 'started'
        local hasOx = GetResourceState('qb-inventory') == 'started'
        local hasCodem = GetResourceState('codem-inventory') == 'started'

        if hasQs then
            return exports['qs-inventory']:GetItem(source, name)
        elseif hasEsx then
            return player.getInventoryItem(name)
        elseif hasOx then
            return exports["qb-inventory"]:GetItem(source, name)
        elseif hasCodem then
            return exports["qb-inventory"]:GetItemByName(source, name)
        else
        end
    end
end

function GetItemCount(source,item)
    if CoreName == "qb-core" or CoreName == "qbx_core" then
        local player = Core.Functions.GetPlayer(source)
        if player.Functions.GetItemByName(item) == nil then
            return 0
        end
        return player.Functions.GetItemByName(item).amount
    elseif CoreName == "es_extended" then
        local player = Core.GetPlayerFromId(source)
        local hasQs = GetResourceState('qs-inventory') == 'started'
        local hasEsx = GetResourceState('esx_inventoryhud') == 'started'
        local hasOx = GetResourceState('ox_inventory') == 'started'

        if hasQs then
            return exports['qs-inventory']:GetItem(source, item).amount
        elseif hasOx or hasEsx then
            return player.getInventoryItem(item).count
        elseif hasOx then
            return exports["ox_inventory"]:Search(source, item).count
        else
        end
    end
end

function FetchPlayerVehicles(identifier, optionalPlate)
    local tableName = FRKN.VehicleTableName or "owned_vehicles"
    local result = {}
    local query = ""
    local params = {}

    if tableName == "owned_vehicles" then
        if optionalPlate then
            query = "SELECT * FROM owned_vehicles WHERE owner = ? AND plate = ?"
            params = {identifier, optionalPlate}
        else
            query = "SELECT * FROM owned_vehicles WHERE owner = ?"
            params = {identifier}
        end

        local rows = MySQL.query.await(query, params)
        for i = 1, #rows do
            local row = rows[i]
            local vehicleModel = row.vehicle
            if type(vehicleModel) == "string" and vehicleModel:sub(1,1) == "{" then
                local decoded = json.decode(vehicleModel)
                if decoded then
                    vehicleModel = decoded.model or decoded.hash or row.vehicle
                end
            end
            result[#result + 1] = {
                source_table = tableName,
                owner = row.owner,
                plate = row.plate,
                vehicle = vehicleModel,
                type = row.type or "car",
                job = row.job or "civ",
                stored = tonumber(row.stored) or 0,
                parking = row.parking,
                pound = row.pound,
                mileage = tonumber(row.mileage) or 0,
                fuel = 100,
                engine = 1000,
                body = 1000,
                state = 1,
                garage = nil,
                mods = nil,
                hash = nil,
                glovebox = row.glovebox,
                trunk = row.trunk
            }
        end

    elseif tableName == "player_vehicles" then
        if optionalPlate then
            query = "SELECT * FROM player_vehicles WHERE citizenid = ? AND plate = ?"
            params = {identifier, optionalPlate}
        else
            query = "SELECT * FROM player_vehicles WHERE citizenid = ?"
            params = {identifier}
        end

        local rows = MySQL.query.await(query, params)
        for i = 1, #rows do
            local row = rows[i]
            result[#result + 1] = {
                source_table = tableName,
                owner = row.license,
                plate = row.plate,
                vehicle = row.vehicle,
                type = "car",
                job = "civ",
                stored = 1,
                parking = row.garage,
                pound = nil,
                mileage = tonumber(row.drivingdistance) or 0,
                fuel = tonumber(row.fuel) or 100,
                engine = tonumber(row.engine) or 1000,
                body = tonumber(row.body) or 1000,
                state = tonumber(row.state) or 1,
                garage = row.garage,
                mods = row.mods,
                hash = row.hash,
                glovebox = nil,
                trunk = nil
            }
        end
    end

    return result
end



function RegisterUsableItem(name)
    while CoreReady == false do Citizen.Wait(0) end

    local hasQs = GetResourceState('qs-inventory') == 'started'
    if hasQs then
        exports['qs-inventory']:CreateUsableItem(name, function(source, item)
            if name == FRKN.RacingTablet then
                TriggerClientEvent('frkn-racing:openTablet', source, item.metadata or item.info)
            end
        end)
    elseif CoreName == "qb-core" or CoreName == "qbx_core" then
        Core.Functions.CreateUseableItem(name, function(source, item)
            if name == FRKN.RacingTablet then
                TriggerClientEvent('frkn-racing:openTablet', source, item.metadata or item.info)
            end
        end)
    elseif CoreName == "es_extended" then
        Core.RegisterUsableItem(name, function(source, item)
            if name == FRKN.RacingTablet then
                TriggerClientEvent('frkn-racing:openTablet', source, item.metadata or item.info)
            end
        end)
    end
end



FRKN.ServerCallbacks = {}
function CreateCallback(name, cb)
    FRKN.ServerCallbacks[name] = cb
end

function TriggerCallback(name, source, cb, ...)
    if not FRKN.ServerCallbacks[name] then return end
    FRKN.ServerCallbacks[name](source, cb, ...)
end

RegisterNetEvent('frkn-racing:server:triggerCallback', function(name, ...)
    local src = source
    TriggerCallback(name, src, function(...)
        TriggerClientEvent('frkn-racing:client:triggerCallback', src, name, ...)
    end, ...)
end)