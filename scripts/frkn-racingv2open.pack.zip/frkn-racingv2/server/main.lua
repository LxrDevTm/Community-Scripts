local cacheData = {}
local playersByIdentifier = {}
local playerPositions = {}
local trackCheckpointsCache = {}

local activeRaceTimers = {}
local notifiedRaceEnd = {}
local playerLastJoinTime = {}
local playerPreRacePositions = {}

local playerOriginalBuckets = {}  
local raceBuckets = {}            
local nextRaceBucketId = 100      

function SetRaceBucket(raceId, raceType, players)
    local rt = raceType and raceType:upper() or ""
    if rt ~= "FORMULA" and rt ~= "JETSKI" and rt ~= "PLANE" then return end

    local bucketId = nextRaceBucketId
    nextRaceBucketId = nextRaceBucketId + 1
    raceBuckets[raceId] = bucketId

    SetRoutingBucketPopulationEnabled(bucketId, true)

    for _, player in ipairs(players) do
        local pSrc = playersByIdentifier[player.identifier]
        if pSrc then
            playerOriginalBuckets[pSrc] = GetPlayerRoutingBucket(pSrc)
            SetPlayerRoutingBucket(pSrc, bucketId)
            local ped = GetPlayerPed(pSrc)
            if ped and ped ~= 0 then
                local veh = GetVehiclePedIsIn(ped, false)
                if veh and veh ~= 0 then
                    SetEntityRoutingBucket(veh, bucketId)
                end
                SetEntityRoutingBucket(ped, bucketId)
            end
        end
    end
end

function ResetPlayerBucket(src)
    if not src then return end
    local originalBucket = playerOriginalBuckets[src] or 0
    playerOriginalBuckets[src] = nil
    SetPlayerRoutingBucket(src, originalBucket)
    local ped = GetPlayerPed(src)
    if ped and ped ~= 0 then
        local veh = GetVehiclePedIsIn(ped, false)
        if veh and veh ~= 0 then
            SetEntityRoutingBucket(veh, originalBucket)
        end
        SetEntityRoutingBucket(ped, originalBucket)
    end
end

function ResetAllRaceBuckets(raceId)
    raceBuckets[raceId] = nil
end
local autoRaceState = {
    announced = {},
    created = {},
    started = {},
    activeRaceId = nil,
    lastUsedTrackIds = {},
}

exports('IsTabletAppEnabled', function()
    return FRKN.UseTabletApp == true
end)


function TriggerTabletHolders(event, ...)
    local args = {...}
    for _, ply in pairs(GetPlayers()) do
        local pSrc = tonumber(ply)
        if pSrc and PlayerHasTablet(pSrc) then
            TriggerClientEvent(event, pSrc, table.unpack(args))
        end
    end
end

RegisterNetEvent('frkn-racing:getData')
AddEventHandler('frkn-racing:getData', function()
    local src = source

    MySQL.Async.fetchAll('SELECT * FROM frkn_racing', {}, function(result)

        local data = {}
        for k, v in pairs(result) do
            local races = json.decode(v.races) or {}

            if races[1] then
                races[1].id = v.id
            end

            if not v.track_id then
                missingTrackId = true
            end

            local entry = {
                id = v.id,
                races = races,
                track_id = v.track_id,
            }

            table.insert(data, entry)
        end

        cacheData = data
        for i = #cacheData, 1, -1 do
            local entry = cacheData[i]
            if entry and entry.races then
                local race = nil
                if type(entry.races) == "table" then
                    race = entry.races[1]
                elseif type(entry.races) == "string" then
                    local decoded = json.decode(entry.races)
                    if decoded then race = decoded[1] end
                end
                if race and race.isAutoRace and not race.startTime and race.completed ~= true then
                    MySQL.Async.execute("DELETE FROM frkn_racing WHERE id = @id", { ['@id'] = entry.id })
                    table.remove(cacheData, i)
                end
            end
        end

        for _, entry in ipairs(cacheData) do
            if entry and entry.races then
                local race = nil
                if type(entry.races) == "table" then
                    race = entry.races[1]
                elseif type(entry.races) == "string" then
                    local decoded = json.decode(entry.races)
                    if decoded then race = decoded[1] end
                end
                if race and race.startTime and not race.completed then
                    race.startTime = nil
                    race.completed = false
                    race.players = {}
                    race.raceResult = nil
                    updateCorrectRaceRow(tonumber(entry.id), entry.races)
                end
            end
        end

        MySQL.Async.fetchAll('SELECT * FROM frkn_racing_alias', {}, function(aliasResult)
            local aliasData = {}
            for k, v in pairs(aliasResult) do
                aliasData[v.identifier] = {
                    alias = v.alias,
                    data = json.decode(v.data) or {},
                    ratingData = json.decode(v.ratingData) or {}
                }
            end
            cacheData['alias'] = aliasData

            MySQL.Async.fetchAll('SELECT id, identifier, track_data FROM frkn_racing_track', {}, function(trackResult)
                local trackData = {}
                for k, v in pairs(trackResult) do
                    table.insert(trackData, {
                        id = v.id,
                        identifier = v.identifier,
                        track_data = json.decode(v.track_data) or {}
                    })
                end
                cacheData['tracks'] = trackData

                MySQL.Async.fetchAll('SELECT * FROM frkn_racing_crews', {}, function(crewResult)
                    local crewData = {}

                    for _, crew in pairs(crewResult) do
                        table.insert(crewData, {
                            id = crew.id,
                            crew_name = crew.crew_name,
                            crew_description = crew.crew_description,
                            owner_identifier = crew.owner_identifier,

                            members_data = json.decode(crew.members_data) or {},
                            chat_data = json.decode(crew.chat_data) or {},
                            races_data = json.decode(crew.races_data) or {},

                            xp = tonumber(crew.xp) or 0,
                            level = tonumber(crew.level) or 1,
                            created_at = crew.created_at
                        })
                    end

                    cacheData['crews'] = crewData

                    MySQL.Async.fetchAll('SELECT * FROM frkn_racing_rewards', {}, function(rewardResult)
                        local rewardData = {}

                        for _, r in pairs(rewardResult) do
                            table.insert(rewardData, {
                                id = r.id,
                                crew_id = r.crew_id,
                                crew_name = r.crew_name,
                                reward = json.decode(r.reward) or {},
                                week_year = r.week_year,
                                created_at = r.created_at,
                                claimed_by = r.claimed_by or "",
                            })
                        end

                        cacheData['rewards'] = rewardData

                        MySQL.Async.fetchAll('SELECT * FROM frkn_racing_bets', {}, function(betResult)
                            local bets = {}
                            for _, v in pairs(betResult) do
                                table.insert(bets, {
                                    id = v.id,
                                    race_id = v.race_id,
                                    bettor_identifier = v.bettor_identifier,
                                    target_identifier = v.target_identifier,
                                    amount = v.amount,
                                    status = v.status,
                                    created_at = v.created_at,
                                    payout_amount = v.payout_amount,
                                    paid = v.paid,
                                })
                            end
                        
                            cacheData['bets'] = bets                        
                        end)
                        MySQL.Async.fetchAll('SELECT * FROM frkn_racing_chat', {}, function(betResult)
                            local chats = {}
                            for _, v in pairs(betResult) do
                                table.insert(chats, {
                                    id = v.id,
                                    identifier = v.identifier,
                                    sender = v.sender,
                                    message = v.message,
                                    created_at = v.created_at,
                                })
                            end
                        
                            cacheData['chat'] = chats                        
                        end)


                        MySQL.Async.fetchAll('SELECT * FROM frkn_racing_cars', {}, function(carsResult)
                            local carsData = {}

                            for _, car in pairs(carsResult) do
                                table.insert(carsData, {
                                    id = car.id,
                                    owner_identifier = car.owner_identifier,
                                    plate = car.plate,
                                    model = car.model,
                                    selected = car.selected and 1 or 0,
                                    total_races = tonumber(car.total_races) or 0,
                                    total_wins = tonumber(car.total_wins) or 0,
                                    total_xp = tonumber(car.total_xp) or 0,
                                    last_race = car.last_race and json.decode(car.last_race) or {}
                                })
                            end

                            cacheData['cars'] = carsData
                        end)
                    end)
                end)
            end)
        end)
    end)
end)


RegisterNetEvent('frkn-racing:dataPostClient')
AddEventHandler('frkn-racing:dataPostClient',function()
    TriggerClientEvent('frkn-racing:setClient',source,cacheData)
end)

AddEventHandler('onResourceStart', function(resourceName)
    if (GetCurrentResourceName() ~= resourceName) then
      return
    end
    TriggerEvent('frkn-racing:getData')
end)
  

RegisterNetEvent('frkn-racing:addSource')
AddEventHandler('frkn-racing:addSource',function()
    local src = source
    local identifier = GetPlayerCid(src)
    if identifier then
        playersByIdentifier[identifier] = src

        for _, wrapper in pairs(cacheData) do
            if type(wrapper.races) == "table" then
                for _, race in pairs(wrapper.races) do
                    if race.isAutoRace and race.players and not race.completed then
                        for _, p in ipairs(race.players) do
                            if p.identifier == identifier then
                                local cfg = FRKN.AutoRaceSystem or {}
                                local remainSecs = 0
                                if autoRaceState and autoRaceState.countdownEndTime then
                                    remainSecs = math.max(0, autoRaceState.countdownEndTime - os.time())
                                elseif autoRaceState and autoRaceState.remainingSeconds and autoRaceState.remainingSeconds > 0 then
                                    remainSecs = autoRaceState.remainingSeconds
                                elseif race.scheduleTime then
                                    remainSecs = math.max(0, race.scheduleTime + (cfg.joinTimeSeconds or 120) - os.time())
                                else
                                    remainSecs = cfg.joinTimeSeconds or 120
                                end

                                local panelData = {
                                    trackName = (autoRaceState and autoRaceState.trackName) or race.eventName or "—",
                                    laps = race.laps or cfg.laps or 1,
                                    buyIn = race.buyIn or cfg.buyIn or 0,
                                    prizes = {},
                                    countdownSeconds = remainSecs,
                                    playerCount = #race.players,
                                    startCoords = nil
                                }

                                if cfg.prizes then
                                    for pos, prize in pairs(cfg.prizes) do
                                        panelData.prizes[tostring(pos)] = prize
                                    end
                                end

                                local cps = race.checkpoints or wrapper.checkpoints
                                if cps and cps[1] then
                                    local cp = cps[1]
                                    if cp.x then
                                        panelData.startCoords = { x = cp.x, y = cp.y, z = cp.z }
                                    elseif cp.pos then
                                        panelData.startCoords = cp.pos
                                    end
                                end

                                SetTimeout(3000, function()
                                    TriggerClientEvent('frkn-racing:showAutoRacePanel', src, panelData)
                                end)
                                break
                            end
                        end
                    end
                end
            end
        end
    end
end)

RegisterNetEvent('frkn-racing:removeSource',function()
    local src = source
    local identifier = GetPlayerCid(src)
    if identifier then
        playersByIdentifier[identifier] = nil
    end
end)


RegisterNetEvent('frkn-racing:requestAlias')
AddEventHandler('frkn-racing:requestAlias', function()
    local src = source
    local playerCid = GetPlayerCid(src)
    local playerName = GetPlayerCharName(src)

    RegisterAliasForPlayer(src, playerCid, playerName)

    TriggerClientEvent('frkn-racing:setClient', src, cacheData)
    TriggerClientEvent('frkn-racing:aliasReady', src) 
end)

CreateCallback('frkn-racing:requestAlias', function(source, cb)
    local src = source
    local cid =  GetPlayerCid(src)
    local playerName = GetPlayerCharName(src)
    local result = RegisterAliasForPlayer(src, cid, playerName)
    cb(result)
end)

function RegisterAliasForPlayer(src, playerCid, playerName)
    if not playerCid then return nil end

    cacheData['alias'] = cacheData['alias'] or {}

    if cacheData['alias'][playerCid] then
        return cacheData
    end

    local defaultData = {
        avatar = "https://cdn.dribbble.com/userupload/5333518/file/original-638e9ac15bbc689ac7ef45fa35bac373.png?resize=752x&vertical=center",
        checkpointcolor = "#cccccc",
        gpscolor = "#cccccc",
        rating = 0,
        matches = 0,
        moneyearned = 0,
        xp = 0,
        level = 1,
        requiredXP = 100,
        races_won = 0
    }

    MySQL.Sync.execute(
        [[
            INSERT INTO frkn_racing_alias (identifier, alias, data)
            VALUES (?, ?, ?)
            ON DUPLICATE KEY UPDATE identifier = identifier
        ]],
        {
            playerCid,
            playerName,
            json.encode(defaultData)
        }
    )

    cacheData['alias'][playerCid] = {
        alias = playerName,
        data = defaultData,
        ratingData = {}
    }

    TriggerClientEvent('frkn-racing:setClient', src, cacheData)
    return cacheData
end



RegisterNetEvent('frkn-racing:requestIdentifier')
AddEventHandler('frkn-racing:requestIdentifier', function()
    local src = source
    local identifier = GetPlayerCid(src)
    
    TriggerClientEvent('frkn-racing:setIdentifier', src, identifier)
end)

RegisterNetEvent('frkn-racing:changeName')
AddEventHandler('frkn-racing:changeName', function(name)
    local src = source
    local playerCid = GetPlayerCid(src)

    if not name or name == "" then return end

    local alias = cacheData['alias'][playerCid]
    if alias then
        MySQL.Sync.execute("UPDATE frkn_racing_alias SET alias = @alias WHERE identifier = @identifier", {
            ['@identifier'] = playerCid,
            ['@alias'] = name
        })

        cacheData['alias'][playerCid].alias = name

        TriggerClientEvent('frkn-racing:setClient', src, cacheData)
    end
end)

RegisterNetEvent('frkn-racing:changeAvatar')
AddEventHandler('frkn-racing:changeAvatar', function(avatar)
    local src = source
    local playerCid = GetPlayerCid(src)
    local alias = cacheData['alias'][playerCid]

    if alias then
        local currentData = alias.data or {}
        currentData.avatar = avatar

        MySQL.Sync.execute("UPDATE frkn_racing_alias SET data = @data WHERE identifier = @identifier", {
            ['@identifier'] = playerCid,
            ['@data'] = json.encode(currentData)
        })

        cacheData['alias'][playerCid].data.avatar = avatar

        TriggerClientEvent('frkn-racing:setClient', src, cacheData)
    end
end)


RegisterNetEvent('frkn-racing:changeColor')
AddEventHandler('frkn-racing:changeColor', function(data)
    local src = source
    local playerCid = GetPlayerCid(src)

    if not data or not data.type or not data.color then return end
    local alias = cacheData['alias'] and cacheData['alias'][playerCid]
    if not alias then return end

    local currentData = alias.data or {}

    if data.type == 'gpscolor' then
        currentData.gpscolor = data.color
    elseif data.type == 'checkpointcolor' then
        currentData.checkpointcolor = data.color
    else
        return 
    end

    MySQL.Sync.execute("UPDATE frkn_racing_alias SET data = @data WHERE identifier = @identifier", {
        ['@identifier'] = playerCid,
        ['@data'] = json.encode(currentData)
    })

    cacheData['alias'][playerCid].data = currentData

    TriggerClientEvent('frkn-racing:setClient', src, cacheData)
end)


RegisterNetEvent("frkn-racing:recieveCreateData")
AddEventHandler("frkn-racing:recieveCreateData", function(pRaceName, pRaceType, pRaceMinLaps, pCheckpoints , pDescription)
    local src = source
    local playerCid = GetPlayerCid(src)
    local alias = cacheData['alias'][playerCid]

    local distanceMap = 0.0
    for i, v in ipairs(pCheckpoints) do
        if i == #pCheckpoints and pRaceType == "Lap" then
            distanceMap = #(vector3(v["pos"]["x"], v["pos"]["y"], v["pos"]["z"]) - vector3(pCheckpoints[1]["pos"]["x"], pCheckpoints[1]["pos"]["y"], pCheckpoints[1]["pos"]["z"])) + distanceMap
        elseif i ~= #pCheckpoints then
            distanceMap = #(vector3(v["pos"]["x"], v["pos"]["y"], v["pos"]["z"]) - vector3(pCheckpoints[i+1]["pos"]["x"], pCheckpoints[i+1]["pos"]["y"], pCheckpoints[i+1]["pos"]["z"])) + distanceMap
        end
    end
    distanceMap = math.ceil(distanceMap)

    local newRace = {
        eventName = pRaceName,
        vehicleClass = "Open",
        laps = pRaceMinLaps,
        distance = distanceMap,
        type = pRaceType,
        description = pDescription,
        creator = playerCid,
        createTime = os.time(),
    }

    local insertId = MySQL.Sync.insert(
        "INSERT INTO frkn_racing_track (identifier, track_data, checkpoints) VALUES (@identifier, @track_data, @checkpoints)", {
        ['@identifier'] = playerCid, 
        ['@track_data'] = json.encode(newRace),
        ['@checkpoints'] = json.encode(pCheckpoints),
    })

    trackCheckpointsCache[insertId] = pCheckpoints

    table.insert(cacheData['tracks'], {
        track_data = newRace,
        checkpointCount = #pCheckpoints,
        id = insertId,
        identifier = playerCid 
    })

    TriggerClientEvent('frkn-racing:update', -1, cacheData)
    TriggerClientEvent('frkn-racing:trackCreated', src, insertId)
end)



CreateCallback("frkn-racing:deleteTrack", function(source, cb, trackId)
    if not trackId then
        cb({ type = "error", header = Lang:t('general.header_error'), message = Lang:t('general.invalid_track_id') })
        return
    end

    local src = source
    local playerIdentifier = GetPlayerCid(src)

    local trackFound = false
    for _, v in ipairs(cacheData['tracks'] or {}) do
        if tonumber(v.id) == tonumber(trackId) then
            trackFound = true
            if v.identifier and v.identifier ~= " " and v.identifier ~= playerIdentifier then
                cb({ type = "error", header = Lang:t('general.header_error'), message = Lang:t('general.not_authorized') })
                return
            end
            break
        end
    end

    if not trackFound then
        cb({ type = "error", header = Lang:t('general.header_error'), message = Lang:t('general.track_not_found') })
        return
    end

    local affectedRows = MySQL.Sync.execute("DELETE FROM frkn_racing_track WHERE id = @id", {
        ['@id'] = trackId
    })

    if affectedRows and affectedRows > 0 then
        for i, v in ipairs(cacheData['tracks']) do
            if tonumber(v.id) == tonumber(trackId) then
                table.remove(cacheData['tracks'], i)
                trackCheckpointsCache[tonumber(trackId)] = nil
                break
            end
        end

        TriggerClientEvent("frkn-racing:update", -1, cacheData)

        cb({ type = "success", header = Lang:t('general.header_success'), message = Lang:t('general.track_deleted') })
    else
        cb({ type = "error", header = Lang:t('general.header_error'), message = Lang:t('general.track_not_found') })
    end
end)

CreateCallback("frkn-racing:getTrackCheckpoints", function(source, cb, trackId)
    if not trackId then
        cb({})
        return
    end

    local tId = tonumber(trackId)
    if trackCheckpointsCache[tId] then
        cb(trackCheckpointsCache[tId])
        return
    end

    MySQL.Async.fetchAll('SELECT checkpoints FROM frkn_racing_track WHERE id = @id', {
        ['@id'] = tId
    }, function(result)
        if result and result[1] and result[1].checkpoints then
            local cps = json.decode(result[1].checkpoints) or {}
            trackCheckpointsCache[tId] = cps
            cb(cps)
        else
            cb({})
        end
    end)
end)


totalCheckpoints = 0

RegisterNetEvent('frkn-racing:updatePlayerPosition')
AddEventHandler('frkn-racing:updatePlayerPosition', function(data)
    local src = source
    local identifier = GetPlayerCid(src)
    if not identifier then
        return
    end

    playerPositions[identifier] = playerPositions[identifier] or {}
    local pos = playerPositions[identifier]
    pos.source = src
    pos.identifier = identifier
    pos.lap = data.lap
    pos.checkpoint = data.checkpoint
    pos.totalCheckpoints = data.totalCheckpoints
    pos.checkpointTime = data.checkpointTime
    pos.carName = data.carName or "UNKNOWN"
    pos.carTransmission = data.carTransmission or "Unknown"
    pos.carTurbo = data.carTurbo or "Stock"
    pos.carType = data.carType or "Unknown"
    pos.totalDriftScore = data.totalDriftScore or 0
    pos.raceType = data.raceType or "NORMAL"
    pos.carPlate = data.carPlate or "UNKNOWN"
    pos.completed = data.completed or false
    pos.bestLapTime = data.bestLapTime or 0
    pos.distanceToNext = data.distanceToNext or 9999.0

    totalCheckpoints = data.totalCheckpoints or totalCheckpoints

    updatePlayerPositions(data.raceId, identifier, data.raceType, data.totalDriftScore)
end)



RegisterNetEvent('frkn-racing:finish')
AddEventHandler('frkn-racing:finish', function(raceId,raceposition,force)
    local src = source
    ResetPlayerBucket(src)
    local res  = CheckRaceCompletion(raceId,raceposition,src,force)
end)

RegisterNetEvent('frkn-racing:disqualify')
AddEventHandler('frkn-racing:disqualify', function(raceId)
    local src = source
    local identifier = GetPlayerCid(src)

    for idx, race in ipairs(cacheData) do
        if tonumber(race.id) == tonumber(raceId) then
            local raceData = race.races[1] or race.races['1']
            if not raceData then return end

            local isOwner = (raceData.creator and raceData.creator == identifier)

            if isOwner then
                for _, player in ipairs(raceData.players or {}) do
                    local pSrc = playersByIdentifier[player.identifier]
                    if pSrc then
                        ResetPlayerBucket(pSrc)
                        local refundAmount = tonumber(player.cash) or 0
                        if refundAmount > 0 then
                            AddMoney(pSrc, FRKN.MoneyType or "cash", refundAmount, "frkn-racing-refund")
                        end
                        TriggerClientEvent('frkn-racing:disqualified', pSrc, Lang:t('general.owner_disqualified'))
                    end
                    playerPositions[player.identifier] = nil
                end
                ResetAllRaceBuckets(tonumber(raceId))

                if activeRaceTimers and activeRaceTimers[tonumber(raceId)] then
                    activeRaceTimers[tonumber(raceId)] = nil
                end
                if notifiedRaceEnd then
                    notifiedRaceEnd[tonumber(raceId)] = true
                end

                table.remove(cacheData, idx)

                MySQL.Async.execute("DELETE FROM frkn_racing WHERE id = @id", {
                    ['@id'] = tonumber(raceId)
                })

                TriggerClientEvent('frkn-racing:update', -1, cacheData)
                return
            end

            for i, player in ipairs(raceData.players or {}) do
                if player.identifier == identifier then
                    table.remove(raceData.players, i)
                    break
                end
            end

            playerPositions[identifier] = nil  
            ResetPlayerBucket(src)

            TriggerClientEvent('frkn-racing:disqualified', src , Lang:t('general.notify_disqualified'))
            TriggerClientEvent('frkn-racing:update', -1, cacheData)
            TriggerClientEvent('frkn-racing:client:refreshLobby', -1, tonumber(raceId))
            CheckRaceCompletion(raceId, 0, src, true) 
            return
        end
    end
end)

RegisterNetEvent('frkn-racing:serverDisqualify')
AddEventHandler('frkn-racing:serverDisqualify', function(raceId, identifier)

    local src = playersByIdentifier[identifier]
    if not src then
        return
    end

    for _, race in ipairs(cacheData) do
        if tonumber(race.id) == tonumber(raceId) then
            local raceData = race.races[1] or race.races['1']
            if not raceData then return end

            for i, player in ipairs(raceData.players or {}) do
                if player.identifier == identifier then
                    table.remove(raceData.players, i)
                    break
                end
            end

            playerPositions[identifier] = nil  

            TriggerClientEvent('frkn-racing:disqualified', src , Lang:t('general.notify_disqualifyreason'))
            TriggerClientEvent('frkn-racing:update', -1, cacheData)
            TriggerClientEvent('frkn-racing:client:refreshLobby', -1, tonumber(raceId))
            CheckRaceCompletion(raceId, 0, src, true) 
            return
        end
    end
end)


function updatePlayerPositions(raceId, identifier, raceType, totalDriftScore)

    for _, race in ipairs(cacheData) do
        if tonumber(race.id) == raceId then

            if type(race.races) == "string" then
                race.races = json.decode(race.races)
            end

            if type(race.races) == "table" then
                for _, r in pairs(race.races) do
                    if type(r) == "table" and r.players then

                        table.sort(r.players, function(a, b)
                            local posA = playerPositions[a.identifier] or {}
                            local posB = playerPositions[b.identifier] or {}

                            if raceType and raceType:upper() == "DRIFT" then
                                local driftA = posA.totalDriftScore or 0
                                local driftB = posB.totalDriftScore or 0
                                return driftA > driftB
                            else
                                local lapA = posA.lap or 0
                                local lapB = posB.lap or 0
                                local chkA = posA.checkpoint or 0
                                local chkB = posB.checkpoint or 0

                                if lapA ~= lapB then
                                    return lapA > lapB
                                elseif chkA ~= chkB then
                                    return chkA > chkB
                                else
                                    local distA = posA.distanceToNext or 9999
                                    local distB = posB.distanceToNext or 9999
                                    return distA < distB
                                end
                            end
                        end)

                        local playerCount = #r.players
                        local raceMoney = (r.buyIn or 0) * playerCount

                        local rr = race.races[1] or race.races['1']
                        local raceStartTime = rr and rr.startTime or os.time()

                        
                        for i, player in ipairs(r.players) do
                            local posData = playerPositions[player.identifier] or {}
                            local posCurrent = posData
                            r.laps = tonumber(r.laps)

                            if FRKN.DisqualifySystem.enabled and FRKN.DisqualifySystem.plateCheck then 
                                local storedPlate = tostring(player.plate or "")
                                local currentPlate = tostring(posData.carPlate or "")
                                storedPlate = string.upper(storedPlate)
                                currentPlate = string.upper(currentPlate)
                                
                                
                                if storedPlate ~= "" and currentPlate ~= "" and storedPlate ~= currentPlate then
                                    
                                    TriggerEvent('frkn-racing:serverDisqualify', raceId, player.identifier)
                                    
                                    player.completed = false
                                    player.forceDisqualify = true
                                end
                            end

                            player.position = i

                            if i == 1 then
                                player.timeDifference = "0.000"
                            else
                                local prevPlayer = r.players[i - 1]
                                local prevPos = playerPositions[prevPlayer.identifier] or {}

                                local diff = math.abs(
                                    ((posCurrent.lap or 0) * totalCheckpoints + (posCurrent.checkpoint or 0)) -
                                    ((prevPos.lap or 0) * totalCheckpoints + (prevPos.checkpoint or 0))
                                )
                                local randomTime = math.random(100, 500) / 1000
                                player.timeDifference = string.format("-%0.3f", diff * randomTime)
                            end

                            if (posCurrent.lap or 0) >= r.laps then
                                player.finishTime = os.time() - raceStartTime
                            else
                                player.finishTime = nil
                            end

                            player.cash = 0
                            player.bestLapTime = posData.bestLapTime or 0
                            player.carName = posData.carName or "UNKNOWN"
                            player.carType = posData.carType or "UNKNOWN"
                            player.carTransmission = posData.carTransmission or "UNKNOWN"
                            player.carTurbo = posData.carTurbo or "Stock"
                            player.alias = cacheData['alias'] and cacheData['alias'][player.identifier] or {}
                            player.totalDriftScore = posData.totalDriftScore or 0
                            player.carPlate = posData.carPlate or "UNKNOWN"
                            player.completed = posData.completed or false
                        end

                        for _, player in ipairs(r.players) do
                            local src = playerPositions[player.identifier] and playerPositions[player.identifier].source
                            if src and GetPlayerPing(src) > 0 then
                                TriggerClientEvent('frkn-racing:positionsUpdated', src, raceId, r.players)
                            end
                        end
                    end
                end
            end
        end
    end
end



function getPlayerPosition(playerIdentifier)
    for _, pos in pairs(playerPositions) do
        if pos.identifier == playerIdentifier then
            return pos
        end
    end
    return {lap = 0, checkpoint = 0}
end

function calculateLevelFromXP(xp)
    local level = 1
    local requiredXP = 100

    while xp >= requiredXP do
        level = level + 1
        xp = xp - requiredXP
        requiredXP = level * 100
    end

    return level
end

function ResolveBets(raceId, raceData)
    local results = raceData.raceResult or {}
    if #results == 0 then return end

    local winnerIdentifier = nil
    for _, r in ipairs(results) do
        if r.position == 1 then
            winnerIdentifier = r.identifier
            break
        end
    end

    if not winnerIdentifier then return end

    local bets = cacheData['bets'] or {}
    for _, bet in ipairs(bets) do
        if tonumber(bet.race_id) == tonumber(raceId) and bet.status == "pending" then
            if bet.target_identifier == winnerIdentifier then
                bet.status = "won"
                bet.payout_amount = (tonumber(bet.amount) or 0) * 2
                MySQL.Async.execute(
                    "UPDATE frkn_racing_bets SET status = 'won', payout_amount = ? WHERE id = ?",
                    { bet.payout_amount, bet.id }
                )
            else
                bet.status = "lost"
                bet.payout_amount = 0
                MySQL.Async.execute(
                    "UPDATE frkn_racing_bets SET status = 'lost', payout_amount = 0 WHERE id = ?",
                    { bet.id }
                )
            end
        end
    end
end


function CheckRaceCompletion(raceId, snapshot, source, forceFinish)
    local identifier = GetPlayerCid(source)
    if not identifier then return end

    for _, race in ipairs(cacheData) do
        if tonumber(race.id) == raceId and type(race.races) == "table" then
            for _, raceData in pairs(race.races) do

                local playerPos = playerPositions[identifier]
                if not playerPos then return end

                local lapNow = tonumber(playerPos.lap) or 0
                local totalLaps = tonumber(raceData.laps) or 1
                local totalCheckpointsServer = (raceData.checkpoints and #raceData.checkpoints) or 0
                local checkpointNow = tonumber(playerPos.checkpoint) or 0

                local lapFinished = lapNow >= totalLaps
                local checkpointFinished = totalCheckpointsServer > 0 and checkpointNow > totalCheckpointsServer

                if (lapFinished and checkpointFinished) or forceFinish then

                    if not playerPos.completed then
                        playerPos.completed = true

                        for _, player in ipairs(raceData.players or {}) do
                            if player.identifier == identifier then
                                player.completed = true
                                player.finishTime = os.time()
                            end
                        end
                    end

                    local totalPrizePool = (raceData.buyIn or 0) * #(raceData.players or {})
                    local finishedPlayers = 0

                    for _, p in ipairs(raceData.players or {}) do
                        local pos = playerPositions[p.identifier]
                        if pos and pos.completed then
                            finishedPlayers = finishedPlayers + 1
                        end
                    end

                    local isWinner = finishedPlayers == 1 and not playerPos.winProcessed

                    if isWinner then
                        playerPos.winProcessed = true
                        AddMoney(source, FRKN.MoneyType or "cash", totalPrizePool, "frkn-racing")
                    end

                    if cacheData['alias'] and cacheData['alias'][identifier] then
                        local aliasEntry = cacheData['alias'][identifier]
                        aliasEntry.data = aliasEntry.data or {}
                    
                        local winXp = FRKN.WinXP or 250
                        local ratingGain = FRKN.RatingWin or 15
                    
                        aliasEntry.data.matches =
                            (tonumber(aliasEntry.data.matches) or 0) + 1
                    
                        if isWinner then
                            aliasEntry.data.races_won =
                                (tonumber(aliasEntry.data.races_won) or 0) + 1
                        
                            aliasEntry.data.moneyearned =
                                (tonumber(aliasEntry.data.moneyearned) or 0) + totalPrizePool
                        
                            aliasEntry.data.xp =
                                (tonumber(aliasEntry.data.xp) or 0) + winXp
                        
                            aliasEntry.data.rating =
                                (tonumber(aliasEntry.data.rating) or 0) + ratingGain
                        end
                    
                        local newLevel = calculateLevelFromXP(tonumber(aliasEntry.data.xp) or 0)
                        aliasEntry.data.level = newLevel
                        aliasEntry.data.requiredXP = newLevel * 100
                    
                        MySQL.update.await(
                            "UPDATE frkn_racing_alias SET data = ? WHERE identifier = ?",
                            { json.encode(aliasEntry.data), identifier }
                        )
                    end


                    if isWinner and cacheData['cars'] then
                        local winPlate = playerPos.carPlate
                        local winXp = FRKN.WinXP or 250

                        if winPlate then
                            for _, car in ipairs(cacheData['cars']) do
                                if car.owner_identifier == identifier
                                and string.upper(car.plate) == string.upper(winPlate) then

                                    car.total_wins = (tonumber(car.total_wins) or 0) + 1
                                    car.total_races = (tonumber(car.total_races) or 0) + 1
                                    car.total_xp = (tonumber(car.total_xp) or 0) + winXp

                                    car.last_race = {
                                        raceId = raceId,
                                        position = 1,
                                        timestamp = os.time()
                                    }

                                    MySQL.update.await(
                                        [[
                                            UPDATE frkn_racing_cars
                                            SET total_wins = total_wins + 1,
                                                total_races = total_races + 1,
                                                total_xp = total_xp + ?,
                                                last_race = ?
                                            WHERE owner_identifier = ? AND plate = ?
                                        ]],
                                        {
                                            winXp,
                                            json.encode(car.last_race),
                                            identifier,
                                            winPlate
                                        }
                                    )
                                    break
                                end
                            end
                        end
                    end

                    raceData.raceResult = raceData.raceResult or {}

                    local exists = false
                    for _, r in ipairs(raceData.raceResult) do
                        if r.identifier == identifier then
                            exists = true
                            break
                        end
                    end

                    if not exists then
                        local aliasData = cacheData['alias'] and cacheData['alias'][identifier] or {}

                        table.insert(raceData.raceResult, {
                            identifier = identifier,
                            source = source,
                            alias = aliasData.alias or "UNKNOWN",
                            position = finishedPlayers,
                            carName = playerPos.carName or "UNKNOWN",
                            carType = playerPos.carType or "UNKNOWN",
                            carTransmission = playerPos.carTransmission or "UNKNOWN",
                            carTurbo = playerPos.carTurbo or "Stock",
                            carPlate = playerPos.carPlate or "UNKNOWN",
                            totalDriftScore = playerPos.totalDriftScore or 0,
                            bestLapTime = playerPos.bestLapTime or 0,
                            finishTime = os.time(),
                            timestamp = os.time(),
                            completed = true,
                            cash = isWinner and totalPrizePool or 0
                        })
                    end

                    TriggerClientEvent('frkn-racing:finished', source, race.id)
                end

                local everyoneFinished = true
                for _, p in ipairs(raceData.players or {}) do
                    local pos = playerPositions[p.identifier]
                    if not (pos and pos.completed) then
                        everyoneFinished = false
                        break
                    end
                end

                if everyoneFinished or forceFinish then
                    raceData.completed = true
                    race.completed = true

                    updateCorrectRaceRow(tonumber(race.id), race.races)
                    BroadcastRaceEnded(raceId, "All racers finished")
                    ResolveBets(raceId, raceData)

                    if raceData.isAutoRace then
                        AutoRace_DistributePrizes(raceId, raceData)
                        CreateThread(function()
                            Wait(30000)
                            AutoRace_Cleanup(raceId)
                        end)
                    end

                    TriggerClientEvent('frkn-racing:setClient', -1, cacheData)
                end
            end
        end
    end
end



function updateCorrectRaceRow(raceId, updatedRaces)


    local rows = MySQL.Sync.fetchAll(
        "SELECT id, races FROM frkn_racing WHERE id = @id",
        { ['@id'] = raceId }
    )

    for _, row in ipairs(rows) do
        local decoded = json.decode(row.races) or {}
        local hasUnfinished = false

        for _, r in ipairs(decoded) do
            if not r.completed then
                hasUnfinished = true
                break
            end
        end

        if hasUnfinished then
            MySQL.Sync.execute(
                "UPDATE frkn_racing SET races = @races WHERE id = @id",
                {
                    ['@id'] = row.id,
                    ['@races'] = json.encode(updatedRaces)
                }
            )

            for _, cacheRace in ipairs(cacheData) do
                if tonumber(cacheRace.id) == tonumber(raceId) then
                    cacheRace.races = updatedRaces
                    break
                end
            end

            TriggerClientEvent('frkn-racing:update', -1, cacheData)
            return
        end
    end
end



CreateCallback('frkn-racing:withdrawBets', function(source, cb, betIds)

    local src = source
    local identifier = GetPlayerCid(src)

    if not identifier then
        cb({ success = false })
        return
    end

    if not betIds or type(betIds) ~= "table" or #betIds == 0 then
        cb({ success = false })
        return
    end

    local totalPayout = 0

    for _, betId in ipairs(betIds) do

        local bet = MySQL.single.await(
            "SELECT id, payout_amount FROM frkn_racing_bets WHERE id = ? AND bettor_identifier = ? AND status = 'won' AND paid = 0",
            { betId, identifier }
        )

        if bet and tonumber(bet.payout_amount) > 0 then
            totalPayout = totalPayout + tonumber(bet.payout_amount)

            MySQL.update.await(
                "UPDATE frkn_racing_bets SET paid = 1, payout_amount = 0 WHERE id = ?",
                { betId }
            )

            for _, cBet in ipairs(cacheData['bets'] or {}) do
                if tonumber(cBet.id) == tonumber(betId) then
                    cBet.paid = 1
                    cBet.payout_amount = 0
                end
            end
        end
    end

    if totalPayout > 0 then
        AddMoney(src, FRKN.MoneyType or "cash", totalPayout, "frkn-racing-bet-withdraw")
    end

    TriggerClientEvent('frkn-racing:setClient', -1, cacheData)

    cb({
        success = true,
        amount = totalPayout
    })
end)




function getLicense(source)
    local identifiers = GetPlayerIdentifiers(source)
    for _, id in pairs(identifiers) do
        if string.find(id, "license:") then
            return id
        end
    end
    return nil
end


function GetSourceByIdentifier(identifier)
    for _, playerSrc in ipairs(GetPlayers()) do
        if GetPlayerCid(playerSrc) == identifier then
            return tonumber(playerSrc)
        end
    end
    return nil
end


CreateCallback('frkn-racing:leave', function(source, cb, raceId, playerCid, lType)
    raceId = tonumber(raceId)
    local cid = playerCid or GetPlayerCid(source)
    local requesterCid = GetPlayerCid(source)

    for raceIndex, race in ipairs(cacheData) do
        if tonumber(race.id) == raceId then
            if type(race.races) == "string" then
                race.races = json.decode(race.races)
            end

            for _, r in pairs(race.races) do
                if lType == "fire" and cid == requesterCid then
                    cb({
                        message = Lang:t('general.race_owner_cannot_leave'),
                        header = Lang:t('general.header_cant_get_out'),
                        type = "error"
                    })
                    return
                end

                local removed = false
                local wasCreator = (cid == r.creator)
                for i = #r.players, 1, -1 do
                    if r.players[i].identifier == cid then
                        table.remove(r.players, i)
                        removed = true
                        break
                    end
                end

                if removed then
                    playerPositions[source] = nil
                    ResetPlayerBucket(source)

                    if wasCreator then
                        if #r.players > 0 then
                            local newLeader = r.players[1]
                            r.creator = newLeader.identifier
                            r.identifier = newLeader.identifier
                            race.owner_identifier = newLeader.identifier

                            local newLeaderSource = playersByIdentifier[newLeader.identifier]
                            if newLeaderSource then
                                TriggerClientEvent('frkn-racing:altNotify', newLeaderSource, {
                                    type = "info",
                                    header = Lang:t('general.race_update'),
                                    message = Lang:t('general.leader_transferred')
                                })
                            end

                            TriggerClientEvent('frkn-racing:update', -1, cacheData)
                            MySQL.Sync.execute("UPDATE frkn_racing SET races = @races WHERE id = @id", {
                                ['@id'] = race.id,
                                ['@races'] = json.encode(race.races)
                            })
                        else
                            MySQL.Sync.execute("DELETE FROM frkn_racing WHERE id = @id", {
                                ['@id'] = race.id
                            })
                            table.remove(cacheData, raceIndex)
                            TriggerClientEvent('frkn-racing:update', -1, cacheData)
                        end
                    else
                        TriggerClientEvent('frkn-racing:update', -1, cacheData)
                        MySQL.Sync.execute("UPDATE frkn_racing SET races = @races WHERE id = @id", {
                            ['@id'] = race.id,
                            ['@races'] = json.encode(race.races)
                        })
                    end

                    cb({
                        message = Lang:t('general.race_left'),
                        header = Lang:t('general.header_race_left'),
                        type = "success"
                    })
                    return
                else
                    cb({
                        message = Lang:t('general.not_in_race'),
                        header = Lang:t('general.header_not_joined'),
                        type = "error"
                    })
                    return
                end
            end
        end
    end

    cb({
        message = Lang:t('general.race_not_found'),
        header = Lang:t('general.header_error'),
        type = "error"
    })
end)


local pendingCarTypes = {}

RegisterNetEvent("frkn-racing:returnCarType")
AddEventHandler("frkn-racing:returnCarType", function(callbackUUID, carType)
    if pendingCarTypes[callbackUUID] then
        pendingCarTypes[callbackUUID](carType)
        pendingCarTypes[callbackUUID] = nil
    end
end)

function requestCarTypeFromClient(src, model, cb)
    local uuid = tostring(math.random(111111, 999999)) .. os.time()

    pendingCarTypes[uuid] = cb

    TriggerClientEvent("frkn-racing:client:getCarType", src, model, uuid)
end

function SyncPlayerGarage(identifier)
    local vehicles = FetchPlayerVehicles(identifier)

    local stats = {}
    local q = MySQL.query.await("SELECT * FROM frkn_racing_cars WHERE owner_identifier = ?", {identifier})

    for _, row in pairs(q) do
        local plate = normalizePlate(row.plate)

        stats[plate] = {
            model = row.model,
            selected = row.selected and 1 or 0,
            total_races = tonumber(row.total_races) or 0,
            total_wins = tonumber(row.total_wins) or 0,
            total_xp = tonumber(row.total_xp) or 0,
            last_race = row.last_race and json.decode(row.last_race) or {}
        }
    end

    for _, veh in pairs(vehicles) do
        local plate = normalizePlate(veh.plate)

        if stats[plate] == nil then
            local insertId = MySQL.insert.await(
                "INSERT INTO frkn_racing_cars (owner_identifier, plate, model, selected, total_races, total_wins, total_xp, last_race) VALUES (?, ?, ?, ?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE owner_identifier = VALUES(owner_identifier)",
                {identifier, plate, veh.vehicle, 0, 0, 0, 0, json.encode({})}
            )

            stats[plate] = {
                model = veh.vehicle,
                selected = 0,
                total_races = 0,
                total_wins = 0,
                total_xp = 0,
                last_race = {}
            }

            if cacheData['cars'] then
                table.insert(cacheData['cars'], {
                    id = insertId,
                    owner_identifier = identifier,
                    plate = plate,
                    model = veh.vehicle,
                    selected = 0,
                    total_races = 0,
                    total_wins = 0,
                    total_xp = 0,
                    last_race = {}
                })
            end
        else
            if not stats[plate].model or stats[plate].model == "" then
                MySQL.update.await(
                    "UPDATE frkn_racing_cars SET model = ? WHERE owner_identifier = ? AND plate = ?",
                    {veh.vehicle, identifier, plate}
                )
                stats[plate].model = veh.vehicle

                if cacheData['cars'] then
                    for _, car in ipairs(cacheData['cars']) do
                        if normalizePlate(car.plate) == plate and car.owner_identifier == identifier then
                            car.model = veh.vehicle
                            break
                        end
                    end
                end
            end
        end
    end

    return stats, vehicles
end



CreateCallback('frkn-racing:join', function(source, cb, raceId, password)
    raceId = tonumber(raceId)
    local src = source
    local identifier = GetPlayerCid(src)

    local ped = GetPlayerPed(src)
    local currentVeh = GetVehiclePedIsIn(ped, false)
    local currentPlate = "UNKNOWN"
    local currentModel = "unknown"

    if currentVeh and currentVeh ~= 0 then
        currentPlate = GetVehicleNumberPlateText(currentVeh) or "UNKNOWN"
        currentModel = GetEntityModel(currentVeh)
    end

    local selectedCar = { plate = currentPlate, model = tostring(currentModel) }

    requestCarTypeFromClient(src, currentModel, function(carType)
        carType = string.lower(carType or "")
        for _, race in ipairs(cacheData) do
            if tonumber(race.id) == raceId then

                if type(race.races) == "string" then
                    race.races = json.decode(race.races)
                end

                for _, r in pairs(race.races) do
                    if r.password and r.password ~= "" and r.password ~= password then
                        cb({
                            message = Lang:t('general.password_incorrect'),
                            header = Lang:t('general.header_access_denied'),
                            type = "error"
                        })
                        return
                    end



                    local result = addPlayerToRace(source, race, r, selectedCar)

                    if result.type == "success" then
                        TriggerClientEvent('frkn-racing:client:refreshLobby', -1, raceId)

                        if r.isAutoRace then
                            local cfg = FRKN.AutoRaceSystem or {}
                            local remainSecs = 0
                            if autoRaceState and autoRaceState.countdownEndTime then
                                remainSecs = math.max(0, autoRaceState.countdownEndTime - os.time())
                            elseif autoRaceState and autoRaceState.remainingSeconds and autoRaceState.remainingSeconds > 0 then
                                remainSecs = autoRaceState.remainingSeconds
                            elseif r.scheduleTime then
                                remainSecs = math.max(0, r.scheduleTime + (cfg.joinTimeSeconds or 120) - os.time())
                            else
                                remainSecs = cfg.joinTimeSeconds or 120
                            end

                            local panelData = {
                                trackName = (autoRaceState and autoRaceState.trackName) or r.eventName or "—",
                                laps = r.laps or cfg.laps or 1,
                                buyIn = r.buyIn or cfg.buyIn or 0,
                                prizes = {},
                                countdownSeconds = remainSecs,
                                playerCount = r.players and #r.players or 0,
                                startCoords = nil
                            }

                            if cfg.prizes then
                                for pos, prize in pairs(cfg.prizes) do
                                    panelData.prizes[tostring(pos)] = prize
                                end
                            end

                            local cps = r.checkpoints or race.checkpoints
                            if cps and cps[1] then
                                local cp = cps[1]
                                if cp.x then
                                    panelData.startCoords = { x = cp.x, y = cp.y, z = cp.z }
                                elseif cp.pos then
                                    panelData.startCoords = cp.pos
                                end
                            end

                            TriggerClientEvent('frkn-racing:showAutoRacePanel', src, panelData)
                        end
                    end

                    cb(result)
                    return
                end
            end
        end

        cb({
            message = Lang:t('general.cannot_join_race'),
            header = Lang:t('general.header_race_not_found'),
            type = "error"
        })
    end)
end)


function IsPlayerInActiveRace(playerCid, excludeRaceId)
    for _, raceEntry in ipairs(cacheData) do
        if type(raceEntry.races) == "table" then
            for _, r in pairs(raceEntry.races) do
                if type(r) == "table" and r.players and not r.completed then
                    if excludeRaceId and tonumber(raceEntry.id) == tonumber(excludeRaceId) then
                        goto skipRace
                    end
                    for _, p in ipairs(r.players) do
                        if p.identifier == playerCid then
                            return true, raceEntry.id
                        end
                    end
                    ::skipRace::
                end
            end
        end
    end
    return false, nil
end

function addPlayerToRace(source, race, r, selectedCar)
    local playerCid = GetPlayerCid(source)

    for _, player in ipairs(r.players) do
        if player.identifier == playerCid then
            return {
                message = Lang:t('general.already_joined'),
                header = Lang:t('general.header_already_joined'),
                type = "error"
            }
        end
    end

    local alreadyInRace, existingRaceId = IsPlayerInActiveRace(playerCid, race.id)
    if alreadyInRace then
        return {
            message = Lang:t('general.already_in_active_race') .. " /leaverace",
            header = Lang:t('general.race_error_header'),
            type = "error"
        }
    end

    local cooldownConfig = FRKN.RaceJoinCooldown or {}
    if cooldownConfig.enabled then
        local cooldownMin = cooldownConfig.time or 0
        if cooldownMin > 0 then
            local lastJoin = playerLastJoinTime[playerCid]
            if lastJoin and (os.time() - lastJoin) < cooldownMin * 60 then
                local remaining = math.ceil((cooldownMin * 60 - (os.time() - lastJoin)) / 60)
                return {
                    message = remaining .. " dakika beklemeniz gerekiyor.",
                    header = Lang:t('general.race_error_header'),
                    type = "error"
                }
            end
        end
    end

    if r.maxPlayers and #r.players >= r.maxPlayers then
        return {
            message = Lang:t('general.race_full'),
            header = Lang:t('general.header_race_full'),
            type = "error"
        }
    end

    local buyInAmount = tonumber(r.buyIn) or 0

    if GetPlayerMoney(source, FRKN.MoneyType) >= buyInAmount then
        RemoveMoney(source, FRKN.MoneyType, buyInAmount)

        local aliasData = cacheData['alias'][playerCid] or {}
        local playerAlias = aliasData.alias or "Unknown"

        table.insert(r.players, {
            identifier = playerCid,
            alias = playerAlias,
            source = source,
            aliasData = aliasData,
            cash = buyInAmount,
            plate = selectedCar.plate,
            model = selectedCar.model
        })

        local raceOwner = race.owner_identifier
        if raceOwner then
            for _, ply in pairs(GetPlayers()) do
                local pSrc = tonumber(ply)
                if GetPlayerCid(pSrc) == raceOwner then
                    TriggerClientEvent('frkn-racing:altNotify', pSrc, {
                        type = "info",
                        header = Lang:t('general.race_update'),
                        message = Lang:t('general.player_joined_race', {
                            player = playerAlias
                        })
                    })
                    break
                end
            end
        end

        TriggerClientEvent('frkn-racing:update', -1, cacheData)

        MySQL.Sync.execute("UPDATE frkn_racing SET races = @races WHERE id = @id", {
            ['@id'] = race.id,
            ['@races'] = json.encode(race.races)
        })

        return {
            message = Lang:t('general.race_joined'),
            header = Lang:t('general.header_race_joined'),
            type = "success",
            players = r.players
        }
    else
        return {
            message = Lang:t('general.not_enough_money'),
            header = Lang:t('general.header_insufficient_funds'),
            type = "error"
        }
    end
end

function checkpointsMatch(a, b)
    if #a ~= #b then return false end
    for i = 1, #a do
        for k, v in pairs(a[i]) do
            if type(v) == "table" then
                for subK, subV in pairs(v) do
                    if math.abs(subV - b[i][k][subK]) > 0.001 then
                        return false
                    end
                end
            elseif v ~= b[i][k] then
                return false
            end
        end
    end
    return true
end

CreateCallback('frkn-racing:start', function(source, cb, raceId)
    local src = source
    local identifier = GetPlayerCid(source)
    raceId = tonumber(raceId)
    local raceFound = false


    if FRKN.Item.config then
        if GetItemCount(src, FRKN.Item['racechip']) == 0 then
            cb({
                message = Lang:t('general.chip_missing'),
                header = Lang:t('general.header_chip_missing'),
                type = "error"
            })
            return
        end
    end

    for _, wrapper in pairs(cacheData) do
        local race = (wrapper.races and wrapper.races[1]) or wrapper

        if race and type(race) == "table" and race.checkpoints then
            race.id = race.id or wrapper.id

            if tonumber(race.id) == raceId then
                raceFound = true

                if race.identifier ~= identifier then
                    cb({
                        message = Lang:t('general.not_authorized'),
                        header = Lang:t('general.header_not_authorized'),
                        type = "error"
                    })
                    return
                end

                if race.startTime and race.startTime > 0 and not race.completed then
                    cb({
                        message = Lang:t('general.race_already_started'),
                        header = Lang:t('general.header_error'),
                        type = "error"
                    })
                    return
                end

                local rType = race.type and race.type:upper() or ""
                if rType ~= "FORMULA" and rType ~= "JETSKI" and rType ~= "PLANE" then
                    local currentTrackId = wrapper.track_id
                    if currentTrackId then
                        for _, otherWrapper in pairs(cacheData) do
                            if otherWrapper ~= wrapper then
                                local otherRace = (otherWrapper.races and otherWrapper.races[1]) or otherWrapper
                                if otherRace and type(otherRace) == "table"
                                    and otherWrapper.track_id == currentTrackId
                                    and otherRace.startTime and otherRace.startTime > 0
                                    and not otherRace.completed then
                                    cb({
                                        message = Lang:t('general.track_busy'),
                                        header = Lang:t('general.header_error'),
                                        type = "error"
                                    })
                                    return
                                end
                            end
                        end
                    end
                end

                local now = os.time()
                local lastStartTime = race.startTime or 0
                if lastStartTime > 0 and FRKN.CountdownTime > 0 then
                    local hoursPassed = (now - lastStartTime) / 3600
                    if hoursPassed < FRKN.CountdownTime then
                        local remainMinutes = math.ceil((FRKN.CountdownTime * 3600 - (now - lastStartTime)) / 60)
                        cb({
                            message = Lang:t('general.cooldown_time_remaining', { minutes = remainMinutes }),
                            header = Lang:t('general.header_cooldown'),
                            type = "error"
                        })
                        return
                    end
                end

                local startCoords = nil
                if race.checkpoints and race.checkpoints[1] and race.checkpoints[1].pos then
                    startCoords = race.checkpoints[1].pos
                end

                local removedPlayers = {}
                local validPlayers = {}

                for i = #(race.players or {}), 1, -1 do
                    local player = race.players[i]
                    local pSource = playersByIdentifier[player.identifier]
                    local removeReason = nil

                    if not pSource or GetPlayerPing(pSource) <= 0 then
                        removeReason = Lang:t('general.player_offline')
                    elseif race.type and (race.type:upper() == "FORMULA" or race.type:upper() == "PLANE" or race.type:upper() == "JETSKI") then

                    else
                        local pPed = GetPlayerPed(pSource)
                        local pVeh = GetVehiclePedIsIn(pPed, false)

                        if not pVeh or pVeh == 0 then
                            removeReason = Lang:t('general.player_not_in_vehicle')
                        elseif startCoords then
                            local pCoords = GetEntityCoords(pPed)
                            local targetVec = vector3(startCoords.x, startCoords.y, startCoords.z)
                            local dist = #(pCoords - targetVec)
                            local maxDist = (FRKN.RaceStartLimit and FRKN.RaceStartLimit.distance) or 150.0

                            if dist > maxDist then
                                if player.identifier == race.creator then

                                    Notify(pSource, Lang:t('general.owner_too_far'), 8000, "warning")
                                    TriggerClientEvent('frkn-racing:setStartGPS', pSource, startCoords)
                                    cb({
                                        message = Lang:t('general.owner_too_far'),
                                        header = Lang:t('general.race_cancelled_header'),
                                        type = "error"
                                    })
                                    return
                                else
                                    removeReason = Lang:t('general.too_far_from_start', { distance = math.floor(dist) })
                                end
                            end
                        end
                    end

                    if removeReason then
                        table.insert(removedPlayers, { player = player, reason = removeReason, source = pSource })
                        table.remove(race.players, i)
                    else
                        table.insert(validPlayers, 1, player)
                    end
                end

                for _, removed in ipairs(removedPlayers) do
                    local refundAmount = tonumber(removed.player.cash) or 0
                    if removed.source and refundAmount > 0 then
                        AddMoney(removed.source, FRKN.MoneyType or "cash", refundAmount, "frkn-racing-refund")
                    end
                    if removed.source then
                        TriggerClientEvent('frkn-racing:disqualified', removed.source, removed.reason)
                    end
                    playerPositions[removed.player.identifier] = nil
                end

                if #race.players < (FRKN.MinUser or 1) then
                    for _, p in ipairs(race.players) do
                        local pSrc = playersByIdentifier[p.identifier]
                        local refundAmount = tonumber(p.cash) or 0
                        if pSrc and refundAmount > 0 then
                            AddMoney(pSrc, FRKN.MoneyType or "cash", refundAmount, "frkn-racing-refund")
                        end
                        if pSrc then
                            TriggerClientEvent('frkn-racing:disqualified', pSrc, Lang:t('general.not_enough_racers_disqualified'))
                        end
                    end
                    race.players = {}
                    TriggerClientEvent('frkn-racing:update', -1, cacheData)
                    cb({
                        message = Lang:t('general.not_enough_racers', { count = #removedPlayers }),
                        header = Lang:t('general.race_cancelled_header'),
                        type = "error"
                    })
                    return
                end

                local picked =
                    tonumber(race.raceTime)
                    or tonumber(race.timeLimit)
                    or tonumber(FRKN.RaceTimeLimit)
                    or 600

                race.timeLimit = picked
                race.startTime = os.time()
                notifiedRaceEnd[raceId] = nil

                for _, p in ipairs(race.players or {}) do
                    playerLastJoinTime[p.identifier] = os.time()
                end

                if activeRaceTimers[raceId] then
                    activeRaceTimers[raceId] = nil
                end

                TriggerClientEvent('frkn-racing:timeSync', -1, raceId, race.startTime, race.timeLimit)
                StartRaceDeadline(raceId, race.timeLimit)

                race.raceResult = {}
                race.completed = false

                for _, p in ipairs(race.players or {}) do
                    p.completed = false
                    p.winProcessed = nil
                end

                local racerlist = {}
                for _, player in ipairs(race.players or {}) do
                    local raceSource = playersByIdentifier[player.identifier]
                    if raceSource then
                        playerPositions[player.identifier] = {
                            lap = 1,
                            checkpoint = 1,
                            source = raceSource,
                            identifier = player.identifier,
                            completed = false,
                            winProcessed = false
                        }
                        table.insert(racerlist, raceSource)
                    end
                end

                SetRaceBucket(raceId, race.type, race.players)

                for _, raceSource in ipairs(racerlist) do
                    TriggerClientEvent('frkn-racing:started', raceSource, raceId, racerlist)
                    TriggerClientEvent('frkn-racing:update', raceSource, cacheData)
                end

                TriggerClientEvent('frkn-racing:update', -1, cacheData)

                local removedMsg = ""
                if #removedPlayers > 0 then
                    removedMsg = " (" .. #removedPlayers .. " removed)"
                end

                cb({
                    message = Lang:t('general.race_started') .. removedMsg,
                    header = Lang:t('general.header_race_start'),
                    type = "success"
                })
                return
            end
        end
    end

    if not raceFound then
        cb({
            message = Lang:t('general.race_not_found'),
            header = Lang:t('general.header_invalid_race'),
            type = "error"
        })
    end
end)

function BuildRacePositionSnapshot(raceId)
    local out = {}
    for _, wrapper in pairs(cacheData) do
        local race = (wrapper.races and wrapper.races[1]) or wrapper
        if tonumber((race and race.id) or wrapper.id) == raceId then
            for _, p in ipairs(race.players or {}) do
                local s = playersByIdentifier[p.identifier]
                if s then table.insert(out, { identifier = p.identifier, source = s, cash = p.cash or 0 }) end
            end
            break
        end
    end
    return out
end

function GetParticipantSources(raceId)
    local out = {}
    for _, wrapper in pairs(cacheData) do
        local race = (wrapper.races and wrapper.races[1]) or wrapper
        if tonumber((race and race.id) or wrapper.id) == raceId then
            for _, p in ipairs(race.players or {}) do
                local s = playersByIdentifier[p.identifier]
                if s then table.insert(out, s) end
            end
            break
        end
    end
    return out
end

function BroadcastRaceEnded(raceId, reason)
    if notifiedRaceEnd[raceId] then return end
    notifiedRaceEnd[raceId] = true
    local participants = GetParticipantSources(raceId)
    for _, s in ipairs(participants) do
        TriggerClientEvent('frkn-racing:raceEnd', s, raceId, reason)
    end
end

function GetRaceMeta(raceId)
    for _, wrapper in pairs(cacheData) do
        local race = (wrapper.races and wrapper.races[1]) or wrapper
        if tonumber((race and race.id) or wrapper.id) == raceId then
            local laps = tonumber(race.laps) or 1
            local totalCheckpoints = (race.checkpoints and #race.checkpoints) or 0
            return laps, totalCheckpoints
        end
    end
    return 1, 0
end

function EveryoneFinishedByProgress(raceId)
    local laps, totalCps = GetRaceMeta(raceId)
    local snapshot = BuildRacePositionSnapshot(raceId)
    if #snapshot == 0 then return false end
    for _, p in ipairs(snapshot) do
        local identifier = p.identifier 
        local pos = playerPositions[identifier]
        if not pos then return false end
        local done = pos.completed or ((tonumber(pos.lap) or 0) >= laps and totalCps > 0 and (tonumber(pos.checkpoint) or 0) > totalCps)
        if not done then return false end
    end
    return true
end



function StartRaceDeadline(raceId, seconds)
    if activeRaceTimers[raceId] then return end
    activeRaceTimers[raceId] = true
    CreateThread(function()
        local t0 = os.time()
        while activeRaceTimers[raceId] do
            Wait(1000)
            local remain = seconds - (os.time() - t0)
            if notifiedRaceEnd[raceId] then break end

            if EveryoneFinishedByProgress(raceId) then
                local snapshot = BuildRacePositionSnapshot(raceId)
                for _, p in ipairs(snapshot) do
                    playerPositions[p.identifier] = playerPositions[p.identifier] or {}
                    playerPositions[p.identifier].completed = true
                end
                activeRaceTimers[raceId] = nil
                BroadcastRaceEnded(raceId, "All racers finished")
                for _, p in ipairs(snapshot) do
                    CheckRaceCompletion(raceId, snapshot, playersByIdentifier[p.identifier], true)
                end
                break
            end

            if remain <= 0 then
                local snapshot = BuildRacePositionSnapshot(raceId)
                for _, p in ipairs(snapshot) do
                    playerPositions[p.identifier] = playerPositions[p.identifier] or {}
                    playerPositions[p.identifier].completed = true
                end
                activeRaceTimers[raceId] = nil
                BroadcastRaceEnded(raceId, "Time limit reached")
                for _, p in ipairs(snapshot) do
                    CheckRaceCompletion(raceId, snapshot, playersByIdentifier[p.identifier], true)
                end
                break
            end
        end
        activeRaceTimers[raceId] = nil
    end)
end

CreateCallback('frkn-racing:delete', function(source, cb, raceId)
    local src = source
    local playerCid = GetPlayerCid(src)
    local raceFound = false
    raceId = tonumber(raceId)

    for i, race in ipairs(cacheData) do
        if tonumber(race.id) == raceId then
            local raceData = race.races[1] or race.races['1']
            if raceData and raceData.creator == playerCid then
                if raceData.startTime and raceData.startTime > 0 and not raceData.completed then
                    for _, p in ipairs(raceData.players or {}) do
                        local pSrc = playersByIdentifier[p.identifier]
                        if pSrc then
                            local refundAmount = tonumber(p.cash) or 0
                            if refundAmount > 0 then
                                AddMoney(pSrc, FRKN.MoneyType or "cash", refundAmount, "frkn-racing-refund")
                            end
                            TriggerClientEvent('frkn-racing:finished', pSrc, false, nil, nil, true)
                        end
                        playerPositions[p.identifier] = nil
                    end
                    if activeRaceTimers[raceId] then
                        activeRaceTimers[raceId] = nil
                    end
                    notifiedRaceEnd[raceId] = true
                end

                table.remove(cacheData, i)
                raceFound = true
                break
            else
                cb({
                    message = Lang:t('general.delete_not_authorized'),
                    header = Lang:t('general.header_permission_denied'),
                    type = "error"
                })
                return
            end
        end
    end

    if raceFound then
        MySQL.Sync.execute("DELETE FROM frkn_racing WHERE id = @id", {
            ['@id'] = raceId
        })

        TriggerClientEvent('frkn-racing:update', -1, cacheData)

        cb({
            message = Lang:t('general.race_deleted'),
            header = Lang:t('general.header_race_removed'),
            type = "success"
        })
    else
        cb({
            message = Lang:t('general.race_not_found'),
            header = Lang:t('general.header_error'),
            type = "error"
        })
    end
end)

function table_contains(tbl, val)
    for _, v in ipairs(tbl) do
        if v == val then
            return true
        end
    end
    return false
end

function normalizePlate(p)
    return string.upper((p or ""):gsub("%s+", ""))
end

CreateCallback('frkn-racing:getPlayerGarage', function(source, cb)
    local src = source
    local identifier = GetPlayerCid(src)

    local stats, vehicles = SyncPlayerGarage(identifier)

    local garageData = {}

    for _, v in pairs(vehicles) do
        local plate = normalizePlate(v.plate)
        garageData[#garageData+1] = {
            plate = plate,
            model = v.vehicle,
            mpg = v.mileage,
            fuel = v.fuel,
            stats = stats[plate] or {
                model = v.vehicle,
                selected = 0,
                total_races = 0,
                total_wins = 0,
                total_xp = 0,
                last_race = {}
            }
        }
    end

    cacheData['garage'] = garageData

    cb({
        vehicles = garageData
    })
end)


CreateCallback('frkn-racing:selectGarageCar', function(source, cb, plate)
    local src = source
    local identifier = GetPlayerCid(src)
    local normalizedPlate = normalizePlate(plate)

    MySQL.update.await(
        "UPDATE frkn_racing_cars SET selected = 0 WHERE owner_identifier = ?",
        {identifier}
    )

    MySQL.update.await(
        "UPDATE frkn_racing_cars SET selected = 1 WHERE plate = ?",
        {normalizedPlate}
    )

    local row = MySQL.single.await(
        "SELECT * FROM frkn_racing_cars WHERE plate = ?",
        {normalizedPlate}
    )

    if cacheData and cacheData['cars'] then
        for _, car in ipairs(cacheData['cars']) do
            if car.owner_identifier == identifier then
                car.selected = 0
            end
        end

        for _, car in ipairs(cacheData['cars']) do
            if normalizePlate(car.plate) == normalizedPlate then
                car.selected = 1
                break
            end
        end
    end

    if cacheData and cacheData['garage'] then
        for _, veh in ipairs(cacheData['garage']) do
            if veh.stats then
                veh.stats.selected = 0
            end
        end

        for _, veh in ipairs(cacheData['garage']) do
            if normalizePlate(veh.plate) == normalizedPlate then
                veh.stats = veh.stats or {}
                veh.stats.selected = 1
                break
            end
        end
    end

    cb({
        type = "success",
        header = Lang:t('general.header_car_selected'),
        message = Lang:t('general.car_selected'),
        selectedCar = row
    })
end)


local function GetTodayTimestamp(hour, minute)
    local now = os.date("*t")
    now.hour = hour
    now.min = minute
    now.sec = 0
    return os.time(now)
end

local function ParseTime(str)
    local h, m = str:match("(%d+):(%d+)")
    return tonumber(h), tonumber(m)
end

function AutoRace_PickRandomTrack()
    local tracks = cacheData['tracks']
    if not tracks or #tracks == 0 then return nil end

    local cfg = FRKN.AutoRaceSystem
    local pool = {}

    if cfg.trackIds and #cfg.trackIds > 0 then
        for _, track in ipairs(tracks) do
            for _, allowedId in ipairs(cfg.trackIds) do
                if tonumber(track.id) == tonumber(allowedId) then
                    table.insert(pool, track)
                    break
                end
            end
        end
    else
        for _, track in ipairs(tracks) do
            local td = track.track_data
            local trackType = td and td.type or ""
            if string.lower(trackType) ~= "formula" then
                table.insert(pool, track)
            end
        end
    end

    if #pool == 0 then return nil end

    local available = {}
    for _, track in ipairs(pool) do
        local wasRecent = false
        for _, usedId in ipairs(autoRaceState.lastUsedTrackIds) do
            if tonumber(track.id) == tonumber(usedId) then
                wasRecent = true
                break
            end
        end
        if not wasRecent then
            table.insert(available, track)
        end
    end

    if #available == 0 then
        autoRaceState.lastUsedTrackIds = {}
        available = pool
    end

    local picked = available[math.random(#available)]

    table.insert(autoRaceState.lastUsedTrackIds, picked.id)
    if #autoRaceState.lastUsedTrackIds > math.floor(#pool / 2) then
        table.remove(autoRaceState.lastUsedTrackIds, 1)
    end

    return picked
end

function AutoRace_CreateRace(track, scheduleTime)
    local cfg = FRKN.AutoRaceSystem
    local trackData = track.track_data or {}
    local trackName = trackData.name or ("Track #" .. track.id)
    local trackId = track.id

    local trackCheckpoints = {}
    local tId = tonumber(trackId)
    if tId then
        if trackCheckpointsCache[tId] then
            trackCheckpoints = trackCheckpointsCache[tId]
        else
            local result = MySQL.Sync.fetchAll('SELECT checkpoints FROM frkn_racing_track WHERE id = @id', {
                ['@id'] = tId
            })
            if result and result[1] and result[1].checkpoints then
                trackCheckpoints = json.decode(result[1].checkpoints) or {}
                trackCheckpointsCache[tId] = trackCheckpoints
            end
        end
    end

    local racesData = {{
        track_id = trackId,
        creator = "SYSTEM_AUTO_RACE",
        creatorName = "Auto Race",
        eventName = "[AUTO] " .. trackName,
        vehicleClass = cfg.vehicleClass or "NON",
        prizeType = "Cash",
        buyIn = cfg.buyIn or 0,
        laps = cfg.laps or 2,
        countdownStart = 5,
        maxPlayers = cfg.maxPlayers or 20,
        raceTime = cfg.raceTime or 600,
        password = "",
        enableAlerts = cfg.enableAlerts ~= false,
        reverse = false,
        forceFPP = cfg.forceFPP == true,
        showPosition = cfg.showPosition ~= false,
        collision = cfg.collision == true,
        checkpoints = trackCheckpoints,
        distance = trackData.distance or 0.0,
        type = cfg.type or "default",
        players = {},
        raceResult = {},
        startTime = nil,
        identifier = "SYSTEM_AUTO_RACE",
        completed = false,
        createTime = scheduleTime or os.time(),
        scheduleTime = scheduleTime or os.time(),
        isAutoRace = true,
    }}

    local insertedId = MySQL.Sync.insert(
        "INSERT INTO frkn_racing (track_id, races) VALUES (@track_id, @races)",
        {
            ['@track_id'] = trackId,
            ['@races'] = json.encode(racesData)
        }
    )

    if racesData[1] then
        racesData[1].id = insertedId
    end

    local newRaceEntry = {
        id = insertedId,
        races = racesData,
        track_id = trackId,
        owner_identifier = "SYSTEM_AUTO_RACE",
    }

    table.insert(cacheData, newRaceEntry)
    TriggerClientEvent('frkn-racing:update', -1, cacheData)

    return insertedId
end

function AutoRace_AddPlayer(raceId, playerSource)
    local playerCid = GetPlayerCid(playerSource)
    if not playerCid then return false end

    local alreadyInRace = IsPlayerInActiveRace(playerCid)
    if alreadyInRace then return false end

    local cooldownConfig = FRKN.RaceJoinCooldown or {}
    if cooldownConfig.enabled then
        local cooldownMin = cooldownConfig.time or 0
        if cooldownMin > 0 then
            local lastJoin = playerLastJoinTime[playerCid]
            if lastJoin and (os.time() - lastJoin) < cooldownMin * 60 then
                local remaining = math.ceil((cooldownMin * 60 - (os.time() - lastJoin)) / 60)
                TriggerClientEvent('frkn-racing:altNotify', playerSource, {
                    type = "error",
                    header = Lang:t('general.auto_race_header'),
                    message = remaining .. " dakika beklemeniz gerekiyor."
                })
                return false
            end
        end
    end

    local cfg = FRKN.AutoRaceSystem

    for _, race in ipairs(cacheData) do
        if tonumber(race.id) == tonumber(raceId) then
            if type(race.races) == "string" then
                race.races = json.decode(race.races)
            end

            for _, r in pairs(race.races) do
                for i = #r.players, 1, -1 do
                    if r.players[i].identifier == playerCid then
                        table.remove(r.players, i)
                    end
                end

                if r.maxPlayers and r.maxPlayers > 0 and #r.players >= r.maxPlayers then
                    return false
                end

                local buyIn = tonumber(r.buyIn) or 0
                if buyIn > 0 then
                    local money = GetPlayerMoney(playerSource, FRKN.MoneyType)
                    if tonumber(money) < buyIn then
                        return false
                    end
                    RemoveMoney(playerSource, FRKN.MoneyType, buyIn)
                end

                local aliasData = cacheData['alias'] and cacheData['alias'][playerCid] or {}
                local playerAlias = aliasData.alias or "Unknown"

                local ped = GetPlayerPed(playerSource)
                local currentVeh = GetVehiclePedIsIn(ped, false)
                local currentPlate = "UNKNOWN"
                if currentVeh and currentVeh ~= 0 then
                    currentPlate = GetVehicleNumberPlateText(currentVeh) or "UNKNOWN"
                end

                table.insert(r.players, {
                    identifier = playerCid,
                    alias = playerAlias,
                    source = playerSource,
                    aliasData = aliasData,
                    cash = buyIn,
                    plate = currentPlate,
                    model = "unknown"
                })

                playerLastJoinTime[playerCid] = os.time()

                TriggerClientEvent('frkn-racing:update', -1, cacheData)
                return true
            end
        end
    end
    return false
end

function AutoRace_StartRace(raceId)
    raceId = tonumber(raceId)

    for _, wrapper in pairs(cacheData) do
        local race = (wrapper.races and wrapper.races[1]) or wrapper

        if race and race.id and tonumber(race.id) == raceId then
            if not race.players or #race.players < 1 then
                AutoRace_Cleanup(raceId)
                return
            end

            for i = #race.players, 1, -1 do
                local player = race.players[i]
                local pSource = playersByIdentifier[player.identifier]
                if not pSource or GetPlayerPing(pSource) <= 0 then
                    local refundAmount = tonumber(player.cash) or 0
                    if pSource and refundAmount > 0 then
                        AddMoney(pSource, FRKN.MoneyType or "cash", refundAmount, "frkn-racing-refund")
                    end
                    table.remove(race.players, i)
                else
                    local pPed = GetPlayerPed(pSource)
                    local pVeh = GetVehiclePedIsIn(pPed, false)
                    if not pVeh or pVeh == 0 then
                        local refundAmount = tonumber(player.cash) or 0
                        if refundAmount > 0 then
                            AddMoney(pSource, FRKN.MoneyType or "cash", refundAmount, "frkn-racing-refund")
                        end
                        TriggerClientEvent('frkn-racing:disqualified', pSource, Lang:t('general.auto_race_not_in_vehicle'))
                        table.remove(race.players, i)
                    else
                        local startCoords = nil
                        local cps = race.checkpoints
                        if cps and cps[1] then
                            local cp = cps[1]
                            if cp.x then
                                startCoords = vector3(cp.x, cp.y, cp.z)
                            elseif cp.pos then
                                startCoords = vector3(cp.pos.x, cp.pos.y, cp.pos.z)
                            end
                        end
                        if startCoords then
                            local pCoords = GetEntityCoords(pPed)
                            local dist = #(vector3(pCoords.x, pCoords.y, pCoords.z) - startCoords)
                            if dist > 200.0 then
                                local refundAmount = tonumber(player.cash) or 0
                                if refundAmount > 0 then
                                    AddMoney(pSource, FRKN.MoneyType or "cash", refundAmount, "frkn-racing-refund")
                                end
                                TriggerClientEvent('frkn-racing:altNotify', pSource, {
                                    type = "error",
                                    header = Lang:t('general.auto_race_header'),
                                    message = Lang:t('general.too_far_start')
                                })
                                TriggerClientEvent('frkn-racing:hideAutoRacePanel', pSource)
                                table.remove(race.players, i)
                            end
                        end
                    end
                end
            end

            if #race.players < 1 then
                AutoRace_Cleanup(raceId)
                return
            end

            local picked = tonumber(race.raceTime) or tonumber(FRKN.AutoRaceSystem.raceTime) or 600

            race.startTime = os.time()
            race.timeLimit = picked
            race.completed = false
            race.raceResult = {}
            notifiedRaceEnd[raceId] = nil

            if activeRaceTimers[raceId] then
                activeRaceTimers[raceId] = nil
            end

            for _, p in ipairs(race.players) do
                p.completed = false
                p.winProcessed = nil
            end

            local racerlist = {}
            for _, player in ipairs(race.players) do
                local raceSource = playersByIdentifier[player.identifier]
                if raceSource then
                    playerPositions[player.identifier] = {
                        lap = 1,
                        checkpoint = 1,
                        source = raceSource,
                        identifier = player.identifier,
                        completed = false,
                        winProcessed = false
                    }
                    table.insert(racerlist, raceSource)
                end
            end

            TriggerClientEvent('frkn-racing:timeSync', -1, raceId, race.startTime, race.timeLimit)
            StartRaceDeadline(raceId, race.timeLimit)

            for _, raceSource in ipairs(racerlist) do
                TriggerClientEvent('frkn-racing:started', raceSource, raceId, racerlist)
                TriggerClientEvent('frkn-racing:update', raceSource, cacheData)
            end

            TriggerClientEvent('frkn-racing:update', -1, cacheData)

            TriggerTabletHolders('frkn-racing:altNotify', {
                type = "success",
                header = Lang:t('general.auto_race_header'),
                message = Lang:t('general.auto_race_started', { count = #racerlist })
            })

            return
        end
    end
end

function AutoRace_Cleanup(raceId)
    raceId = tonumber(raceId)
    for i = #cacheData, 1, -1 do
        if tonumber(cacheData[i].id) == raceId then
            local race = (cacheData[i].races and cacheData[i].races[1]) or cacheData[i]
            if race and race.isAutoRace then
                table.remove(cacheData, i)
                MySQL.Async.execute("DELETE FROM frkn_racing WHERE id = @id", { ['@id'] = raceId })
                break
            end
        end
    end
    autoRaceState.activeRaceId = nil
    autoRaceState.countdownEndTime = nil
    autoRaceState.remainingSeconds = nil
    autoRaceState.trackName = nil
    TriggerClientEvent('frkn-racing:update', -1, cacheData)
end

function AutoRace_DistributePrizes(raceId, raceData)
    local cfg = FRKN.AutoRaceSystem
    if not cfg or not cfg.prizes then return end

    local sortedPlayers = {}
    for _, player in ipairs(raceData.players or {}) do
        local pos = playerPositions[player.identifier]
        if pos and pos.completed then
            table.insert(sortedPlayers, {
                identifier = player.identifier,
                source = playersByIdentifier[player.identifier],
                finishTime = player.finishTime or 999999,
            })
        end
    end

    table.sort(sortedPlayers, function(a, b)
        return a.finishTime < b.finishTime
    end)

    for position, playerData in ipairs(sortedPlayers) do
        local prize = cfg.prizes[position]
        if prize and playerData.source then
            if prize.type == "money" and prize.amount and prize.amount > 0 then
                AddMoney(playerData.source, FRKN.MoneyType or "cash", prize.amount, "frkn-racing-auto-prize")
                TriggerClientEvent('frkn-racing:altNotify', playerData.source, {
                    type = "success",
                    header = Lang:t('general.race_prize_header'),
                    message = Lang:t('general.race_prize_money', { position = position, amount = prize.amount })
                })
            elseif prize.type == "item" and prize.item then
                AddItem(playerData.source, prize.item, prize.amount or 1)
                TriggerClientEvent('frkn-racing:altNotify', playerData.source, {
                    type = "success",
                    header = Lang:t('general.race_prize_header'),
                    message = Lang:t('general.race_prize_item', { position = position, count = (prize.amount or 1), item = prize.item })
                })
            end
        end
    end
end

RegisterNetEvent('frkn-racing:autoRaceJoin')
AddEventHandler('frkn-racing:autoRaceJoin', function()
    local src = source
    if not autoRaceState.activeRaceId then
        TriggerClientEvent('frkn-racing:altNotify', src, {
            type = "error",
            header = Lang:t('general.auto_race_header'),
            message = Lang:t('general.auto_race_no_active')
        })
        return
    end

    if autoRaceState.countdownEndTime and os.time() > autoRaceState.countdownEndTime then
        TriggerClientEvent('frkn-racing:altNotify', src, {
            type = "error",
            header = Lang:t('general.auto_race_header'),
            message = Lang:t('general.auto_race_no_active')
        })
        return
    end

    local playerCid = GetPlayerCid(src)
    local alreadyInRace = IsPlayerInActiveRace(playerCid)
    if alreadyInRace then
        TriggerClientEvent('frkn-racing:altNotify', src, {
            type = "error",
            header = Lang:t('general.auto_race_header'),
            message = Lang:t('general.already_in_active_race') .. " /leaverace"
        })
        return
    end

    local success = AutoRace_AddPlayer(autoRaceState.activeRaceId, src)
    if not success then
        return
    end
    if success then
        TriggerClientEvent('frkn-racing:altNotify', src, {
            type = "success",
            header = Lang:t('general.auto_race_header'),
            message = Lang:t('general.auto_race_joined')
        })

        local cfg = FRKN.AutoRaceSystem
        local remainSecs = 0
        if autoRaceState.countdownEndTime then
            remainSecs = math.max(0, autoRaceState.countdownEndTime - os.time())
        elseif autoRaceState.remainingSeconds and autoRaceState.remainingSeconds > 0 then
            remainSecs = autoRaceState.remainingSeconds
        else
            for _, entry in ipairs(cacheData) do
                if entry.id == autoRaceState.activeRaceId then
                    local r = type(entry.races) == "table" and entry.races[1] or nil
                    if r and r.scheduleTime then
                        remainSecs = math.max(0, r.scheduleTime + (cfg.joinTimeSeconds or 120) - os.time())
                    end
                    break
                end
            end
            if remainSecs == 0 then
                remainSecs = cfg.joinTimeSeconds or 120
            end
        end

        local panelData = {
            trackName = autoRaceState.trackName or "—",
            laps = cfg.laps or 1,
            buyIn = cfg.buyIn or 0,
            prizes = {},
            countdownSeconds = remainSecs,
            playerCount = 0,
            startCoords = nil
        }

        if cfg.prizes then
            for pos, prize in pairs(cfg.prizes) do
                panelData.prizes[tostring(pos)] = prize
            end
        end

        local raceId = autoRaceState.activeRaceId
        for _, wrapper in pairs(cacheData) do
            local race = (wrapper.races and wrapper.races[1]) or wrapper
            if race and race.id and tonumber(race.id) == tonumber(raceId) then
                panelData.playerCount = race.players and #race.players or 0
                local cps = race.checkpoints or wrapper.checkpoints
                if cps and cps[1] then
                    local cp = cps[1]
                    if cp.x then
                        panelData.startCoords = { x = cp.x, y = cp.y, z = cp.z }
                    elseif cp.pos then
                        panelData.startCoords = cp.pos
                    end
                end
                if not panelData.startCoords and wrapper.track_id then
                    for _, track in ipairs(cacheData['tracks'] or {}) do
                        if tonumber(track.id) == tonumber(wrapper.track_id) and track.checkpoints and track.checkpoints[1] then
                            local tc = track.checkpoints[1]
                            if tc.x then
                                panelData.startCoords = { x = tc.x, y = tc.y, z = tc.z }
                            elseif tc.pos then
                                panelData.startCoords = tc.pos
                            end
                            break
                        end
                    end
                end
                break
            end
        end

        TriggerClientEvent('frkn-racing:showAutoRacePanel', src, panelData)
    else
        TriggerClientEvent('frkn-racing:altNotify', src, {
            type = "error",
            header = Lang:t('general.auto_race_header'),
            message = Lang:t('general.auto_race_join_failed')
        })
    end
end)

RegisterNetEvent('frkn-racing:leaveAllRaces')
AddEventHandler('frkn-racing:leaveAllRaces', function()
    local src = source
    local playerCid = GetPlayerCid(src)
    if not playerCid then return end
    ResetPlayerBucket(src)

    local leftCount = 0
    local updatedRaceIds = {}

    for _, race in ipairs(cacheData) do
        if type(race.races) == "string" then
            race.races = json.decode(race.races)
        end

        local raceModified = false
        for _, r in pairs(race.races or {}) do
            if type(r) == "table" and r.players then
                for i = #r.players, 1, -1 do
                    if r.players[i].identifier == playerCid then
                        local refundAmount = tonumber(r.players[i].cash) or 0
                        if refundAmount > 0 then
                            AddMoney(src, FRKN.MoneyType or "cash", refundAmount, "frkn-racing-leave")
                        end
                        table.remove(r.players, i)
                        leftCount = leftCount + 1
                        raceModified = true
                    end
                end
            end
        end

        if raceModified and race.id then
            table.insert(updatedRaceIds, race)
        end
    end

    for _, race in ipairs(updatedRaceIds) do
        MySQL.Async.execute("UPDATE frkn_racing SET races = @races WHERE id = @id", {
            ['@races'] = json.encode(race.races),
            ['@id'] = race.id
        })
    end

    playerPositions[playerCid] = nil

    if leftCount > 0 then
        TriggerClientEvent('frkn-racing:update', -1, cacheData)
        TriggerClientEvent('frkn-racing:finished', src, 0)
        Notify(src, Lang:t('general.leave_race_success', { count = leftCount }), 5000, "success")
    else
        Notify(src, Lang:t('general.leave_race_not_in'), 5000, "error")
    end
end)

CreateThread(function()
    if not FRKN.AutoRaceSystem or not FRKN.AutoRaceSystem.enabled then return end
    Wait(5000)

    while true do
        local now = os.time()
        local cfg = FRKN.AutoRaceSystem

        for _, timeStr in ipairs(cfg.schedules or {}) do
            local hour, minute = ParseTime(timeStr)
            if hour and minute then
                local raceTime = GetTodayTimestamp(hour, minute)
                local diff = raceTime - now
                local key = timeStr .. "_" .. os.date("%Y%m%d")

                local announceTime = (cfg.announceBeforeMinutes or 10) * 60


                if diff <= announceTime and diff > 0 and not autoRaceState.announced[key] then
                    autoRaceState.announced[key] = true

                    local track = AutoRace_PickRandomTrack()
                    if track then
                        local raceId = AutoRace_CreateRace(track, raceTime)
                        if raceId then
                            autoRaceState.activeRaceId = raceId
                            autoRaceState.created[key] = raceId
                            autoRaceState.trackName = (track.track_data and track.track_data.name) or ("Track #" .. track.id)

                            local joinTime = cfg.joinTimeSeconds or 120
                            autoRaceState.countdownEndTime = now + diff + joinTime
                            autoRaceState.remainingSeconds = diff + joinTime

                            local trackName = (track.track_data and track.track_data.name) or ("Track #" .. track.id)
                            local minsLeft = math.ceil(diff / 60)

                            TriggerTabletHolders('frkn-racing:autoRaceAnnounce', {
                                raceId = raceId,
                                trackName = trackName,
                                startTime = timeStr,
                                minutesLeft = minsLeft,
                                buyIn = cfg.buyIn or 0,
                                laps = cfg.laps or 2,
                                prizes = cfg.prizes or {},
                                joinTimeSeconds = cfg.joinTimeSeconds or 120,
                            })
                        end
                    end
                end

                if diff <= 0 and diff > -60 and autoRaceState.created[key] and not autoRaceState.started[key] then
                    autoRaceState.started[key] = true
                    local raceId = autoRaceState.created[key]

                    CreateThread(function()
                        local joinTime = cfg.joinTimeSeconds or 120
                        local remaining = math.max(0, (autoRaceState.countdownEndTime or (os.time() + joinTime)) - os.time())
                        autoRaceState.remainingSeconds = remaining
                        TriggerTabletHolders('frkn-racing:altNotify', {
                            type = "info",
                            header = Lang:t('general.auto_race_header'),
                            message = Lang:t('general.auto_race_starting_soon', { seconds = remaining })
                        })

                        local endTime = autoRaceState.countdownEndTime or (os.time() + joinTime)
                        while os.time() < endTime do
                            Wait(1000)
                            autoRaceState.remainingSeconds = math.max(0, endTime - os.time())
                        end

                        TriggerClientEvent('frkn-racing:hideAutoRacePanel', -1)

                        if autoRaceState.activeRaceId == raceId then
                            AutoRace_StartRace(raceId)
                        end
                    end)
                end

                if diff < -3600 then
                    autoRaceState.announced[key] = nil
                    autoRaceState.created[key] = nil
                    autoRaceState.started[key] = nil
                end
            end
        end

        local expireThreshold = ((cfg.announceBeforeMinutes or 10) * 60) + (cfg.joinTimeSeconds or 120)
        local cleanedUp = false
        for i = #cacheData, 1, -1 do
            local entry = cacheData[i]
            if entry and entry.races then
                local race = entry.races[1]
                if race and race.isAutoRace and not race.startTime and race.completed ~= true then
                    local raceCreateTime = race.createTime or 0
                    if (now - raceCreateTime) > expireThreshold then
                        MySQL.Async.execute("DELETE FROM frkn_racing WHERE id = @id", { ['@id'] = entry.id })
                        table.remove(cacheData, i)
                        cleanedUp = true
                    end
                end
            end
        end
        if cleanedUp then
            TriggerClientEvent('frkn-racing:update', -1, cacheData)
        end

        Wait(5000)
    end
end)




CreateThread(function()
    while true do
        Wait(FRKN.CrewSystem.RewardControlTime * 60 * 1000)

        local year, week = GetYearAndWeek()
        local weekId = ("%s-W%s"):format(year, week)

        local exists = MySQL.Sync.fetchScalar(
            "SELECT id FROM frkn_racing_rewards WHERE week_year = @w LIMIT 1",
            {["@w"] = weekId}
        )

        if exists then
            goto continue
        end

        local topCrew = MySQL.Sync.fetchAll(
            "SELECT id, crew_name, xp, members_data FROM frkn_racing_crews ORDER BY xp DESC LIMIT 1"
        )

        if topCrew and topCrew[1] then
            local c = topCrew[1]

            MySQL.Async.execute(
                "INSERT INTO frkn_racing_rewards (crew_id, crew_name, reward, week_year) VALUES (@id, @name, @reward, @week)",
                {
                    ['@id'] = c.id,
                    ['@name'] = c.crew_name,
                    ['@reward'] = json.encode(FRKN.WeeklyReward),
                    ['@week'] = weekId
                }
            )

            local members = type(c.members_data) == "string" and json.decode(c.members_data) or c.members_data

            if members then
                for _, ply in pairs(GetPlayers()) do
                    local src = tonumber(ply)
                    local cid = GetPlayerCid(src)

                    for _, m in ipairs(members) do
                        if m.identifier == cid then
                           TriggerClientEvent('frkn-racing:altNotify', src, {
                                type = "success",
                                header = Lang:t('general.weekly_crew_reward'),
                                message = Lang:t('general.weekly_crew_reward_msg', {
                                    crew = c.crew_name
                                })
                            })


                            break
                        end
                    end
                end
            end
        end

        ::continue::
    end
end)


function GetYearAndWeek()
    local t = os.date("*t")
    local year = t.year
    local day = t.yday
    local week = math.floor((day - 1) / 7) + 1
    return year, week
end

crewRequests = crewRequests or {}

CreateCallback('frkn-racingv2:requestCrewJoin', function(source, cb, data)
    local src = source
    local crewId = tonumber(data.crew_id)
    local playerCid = GetPlayerCid(src)

    if not crewId then
        cb({
            success = false,
            message = Lang:t('general.invalid_crew_id')
        })
        return
    end

    crewRequests[crewId] = crewRequests[crewId] or {}

    for _, req in ipairs(crewRequests[crewId]) do
        if req.cid == playerCid then
            cb({
                success = false,
                message = Lang:t('general.already_sent_join_request')
            })
            return
        end
    end

    table.insert(crewRequests[crewId], {
        cid = playerCid,
        time = os.time()
    })

    local crews = cacheData['crews'] or {}
    local alias = cacheData['alias'] or {}

    local crew
    for _, c in pairs(crews) do
        if tonumber(c.id) == crewId then
            crew = c
            break
        end
    end

    if crew and crew.owner_identifier then
        for _, player in pairs(GetPlayers()) do
            local pSrc = tonumber(player)
            if GetPlayerCid(pSrc) == crew.owner_identifier then
                local ad = alias[playerCid] or {}
                local aliasName = ad.alias or "Unknown"

                TriggerClientEvent('frkn-racing:altNotify', pSrc, {
                    type = "info",
                    header = Lang:t('general.crew_join_request'),
                    message = Lang:t('general.crew_join_request_msg', {
                        player = aliasName
                    })
                })
                break
            end
        end
    end

    cb({ success = true , message = Lang:t('general.join_request_sent') })
end)



CreateCallback('frkn-racingv2:getCrews', function(data, cb)
    local src = source
    local playerCid = GetPlayerCid(src)

    local crews = cacheData['crews'] or {}
    local alias = cacheData['alias'] or {}
    local rewards = cacheData['rewards'] or {}

    local playerCrew = nil

    for _, c in pairs(crews) do
        if c.owner_identifier == playerCid then
            playerCrew = c
            break
        end
        if c.members_data then
            for _, m in pairs(c.members_data) do
                if m.identifier == playerCid then
                    playerCrew = c
                    break
                end
            end
        end
    end

    local requests = {}

    if playerCrew then
        local crewId = playerCrew.id
        local stored = crewRequests and crewRequests[crewId] or {}

        for _, req in ipairs(stored) do
            local ad = alias[req.cid] or {}
            local aliasName = ad.alias or "Unknown"

            table.insert(requests, {
                cid = req.cid,
                alias = aliasName,
                time = req.time
            })
        end
    end
    cb({
        crews = crews,
        alias = alias,
        rewards = rewards,
        playerCrew = playerCrew,
        requests = requests
    })
end)

RegisterNetEvent('frkn-racingv2:denyCrewRequest')
AddEventHandler('frkn-racingv2:denyCrewRequest', function(data)
    local src = source
    local leaderCid = GetPlayerCid(src)
    local targetCid = data.cid

    local crews = cacheData['crews'] or {}
    local crew
    local crewIndex

    for i, c in ipairs(crews) do
        if c.owner_identifier == leaderCid then
            crew = c
            crewIndex = i
            break
        end
    end

    if not crew then return end

    local crewId = crew.id
    if not crewRequests or not crewRequests[crewId] then return end

    for i, req in ipairs(crewRequests[crewId]) do
        if req.cid == targetCid then
            table.remove(crewRequests[crewId], i)
            break
        end
    end

    TriggerClientEvent('frkn-racing:update', -1, cacheData)

    TriggerEvent('frkn-racing:altNotify', targetCid, {
        type = "error",
        header = Lang:t('general.header_crew'),
        message = Lang:t('general.crew_request_denied')
    })
end)

CreateCallback('frkn-racingv2:acceptCrewRequest', function(source, cb, data)
    local src = source
    local leaderCid = GetPlayerCid(src)
    local targetCid = data.cid

    local crews = cacheData['crews'] or {}
    local crew
    local crewIndex

    for i, c in ipairs(crews) do
        if c.owner_identifier == leaderCid then
            crew = c
            crewIndex = i
            break
        end
    end

    if not crew then
        cb({
            success = false,
            message = Lang:t('general.no_owned_crew')
        })
        return
    end

    local crewId = crew.id

    if not crewRequests or not crewRequests[crewId] then
        cb({
            success = false,
            message = Lang:t('general.no_pending_requests')
        })
        return
    end

    for i, req in ipairs(crewRequests[crewId]) do
        if req.cid == targetCid then
            table.remove(crewRequests[crewId], i)
            break
        end
    end

    table.insert(crew.members_data, {
        identifier = targetCid,
        role = "member"
    })

    MySQL.update.await(
        "UPDATE frkn_racing_crews SET members_data = @members WHERE id = @id",
        {
            ['@members'] = json.encode(crew.members_data),
            ['@id'] = crewId
        }
    )

    cacheData['crews'][crewIndex].members_data = crew.members_data

    TriggerClientEvent('frkn-racing:update', -1, cacheData)

    TriggerClientEvent('frkn-racing:altNotify', targetCid, {
        type = "success",
        header = Lang:t('general.header_crew'),
        message = Lang:t('general.crew_request_accepted')
    })

    cb({
        success = true,
        message = Lang:t('general.request_accepted')
    })
end)



RegisterNetEvent("frkn-racing:reward:addVehicleToDB", function(data)
    local src = source
    local identifier = GetPlayerCid(src)

    local model = data.model
    local plate = data.plate
    local modelHash = joaat(model)

    local VehicleTableName = FRKN.VehicleTableName or "owned_vehicles"

    if VehicleTableName == "owned_vehicles" then
        
        local vehicleProps = json.encode({
            model = modelHash,
            plate = plate
        })

        MySQL.insert.await(
            "INSERT INTO owned_vehicles (owner, plate, vehicle, type, job, stored, parking, pound, mileage, glovebox, trunk) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            {
                identifier,
                plate,
                vehicleProps,
                "car",
                "civ",
                1,
                FRKN.GarageName or "pillboxgarage",
                0,
                0,
                "[]",
                "[]"
            }
        )

    elseif VehicleTableName == "player_vehicles" then

        local license
        for _, id in ipairs(GetPlayerIdentifiers(src)) do
            if id:match("^license:") then
                license = id
                break
            end
        end

        MySQL.insert.await(
            [[
                INSERT INTO player_vehicles 
                (license, citizenid, vehicle, hash, mods, plate, fakeplate, garage, fuel, engine, body, state, depotprice, drivingdistance)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ]],
            {
                license,
                identifier,
                model,
                modelHash,
                "{}",
                plate,
                nil,
                FRKN.GarageName or "pillboxgarage",
                100,
                1000,
                1000,
                1,
                0,
                0
            }
        )

    end

    if FRKN.GiveVehicleKeys then
        FRKN.GiveVehicleKeys(src, plate, model)
    end
end)

CreateCallback('frkn-racing:placeBet', function(source, cb, raceId, targetIdentifier, amount)
    local src = source
    local bettor = GetPlayerCid(src)

    raceId = tonumber(raceId)
    amount = tonumber(amount)

    if not raceId or not targetIdentifier or not amount or amount <= 0 then
        cb({
            type = "error",
            header = Lang:t('general.invalid_bet'),
            message = Lang:t('general.bet_info_missing')
        })
        return
    end

    if bettor == targetIdentifier then
        cb({
            type = "error",
            header = Lang:t('general.invalid_bet'),
            message = Lang:t('general.cannot_bet_self')
        })
        return
    end

    local playerMoney = GetPlayerMoney(src, FRKN.MoneyType)
    if playerMoney < amount then
        cb({
            type = "error",
            header = Lang:t('general.not_enough_money'),
            message = Lang:t('general.not_enough_money_bet')
        })
        return
    end

    local raceStarted = false
    for _, race in ipairs(cacheData) do
        if tonumber(race.id) == raceId and type(race.races) == "table" then
            for _, rd in pairs(race.races) do
                if rd.startTime then
                    raceStarted = true
                    break
                end
            end
            break
        end
    end
    if raceStarted then
        cb({
            type = "error",
            header = Lang:t('general.invalid_bet'),
            message = Lang:t('general.bet_race_started')
        })
        return
    end

    local existingBet = false
    for _, bet in ipairs(cacheData['bets'] or {}) do
        if tonumber(bet.race_id) == raceId and bet.bettor_identifier == bettor and bet.status == "pending" then
            existingBet = true
            break
        end
    end
    if existingBet then
        cb({
            type = "error",
            header = Lang:t('general.invalid_bet'),
            message = Lang:t('general.bet_already_placed')
        })
        return
    end

    RemoveMoney(src, FRKN.MoneyType, amount)

    local insertedId = MySQL.Sync.insert(
        "INSERT INTO frkn_racing_bets (race_id, bettor_identifier, target_identifier, amount, created_at, status) VALUES (?, ?, ?, ?, ?, ?)",
        { raceId, bettor, targetIdentifier, amount, os.time(), "pending" }
    )

    if not insertedId then
        cb({
            type = "error",
            header = Lang:t('general.sql_error'),
            message = Lang:t('general.bet_not_saved')
        })
        return
    end


    cacheData['bets'] = cacheData['bets'] or {}
    table.insert(cacheData['bets'], {
        id = insertedId,
        race_id = raceId,
        bettor_identifier = bettor,
        target_identifier = targetIdentifier,
        amount = amount,
        created_at = os.time(),
        status = "pending"
    })

    TriggerClientEvent("frkn-racing:update", -1, cacheData)

    cb({
        type = "success",
        header = Lang:t('general.bet_placed'),
        message = Lang:t('general.bet_placed_success'),
        betId = insertedId
    })

    for _, ply in pairs(GetPlayers()) do
        local pSrc = tonumber(ply)
        local pCid = GetPlayerCid(pSrc)

        if pCid == targetIdentifier then
            TriggerClientEvent('frkn-racing:notify', pSrc, {
                type = "info",
                header = Lang:t('general.new_bet_placed'),
                message = Lang:t('general.someone_bet_on_you')
            })

            break
        end
    end
end)



CreateCallback('frkn-racing:claimReward', function(source, cb, rewardId)
    local src = source
    local playerCid = GetPlayerCid(src)

    local rewardIndex = nil
    local reward = nil

    for idx, r in ipairs(cacheData['rewards'] or {}) do
        if tonumber(r.id) == tonumber(rewardId) then
            reward = r
            rewardIndex = idx
            break
        end
    end

    if not reward then
    cb({
        type = "error",
        message = Lang:t('general.reward_not_found')
    })
    return
    end


    local rd = reward.reward or {}
    local rewardInfo = { id = reward.id }

    if rd.type == "money" then
        local amount = tonumber(rd.money) or 0
        AddMoney(src, amount)

        rewardInfo.type = "money"
        rewardInfo.money = amount
    end

    if rd.type == "item" then
        if rd.item and rd.item.name then
            AddItem(src, rd.item.name, rd.item.amount or 1)

            rewardInfo.type = "item"
            rewardInfo.itemName = rd.item.name
            rewardInfo.itemAmount = rd.item.amount or 1
        end
    end

    if rd.type == "car" then
        rewardInfo.type = "car"
        rewardInfo.carModel = rd.car
    end

    reward.claimed_by = playerCid

    MySQL.Async.execute(
        "UPDATE frkn_racing_rewards SET claimed_by = @cid WHERE id=@id",
        {
            ["@cid"] = playerCid,
            ["@id"] = rewardId
        }
    )

    if rewardIndex then
        cacheData['rewards'][rewardIndex].claimed_by = playerCid
    end

    TriggerClientEvent('frkn-racing:update', -1, cacheData)

    cb({
    type = "success",
    message = Lang:t('general.reward_claimed'),
    reward = rewardInfo
    })

end)


CreateCallback('frkn-racing:createCrew', function(source, cb, crew_name, crew_description)
    local src = source
    local playerCid = GetPlayerCid(src)

    local playerMoney = GetPlayerMoney(src, FRKN.MoneyType)

        if tonumber(playerMoney) < tonumber(FRKN.CrewSystem.Money) then
            cb({
                message = Lang:t('general.need_money_create_crew', {
                    money = FRKN.CrewSystem.Money
                }),
                type = "error",
                header = Lang:t('general.not_enough_money')
            })
            return
        end


        if not crew_name or crew_name == "" then
            cb({
                message = Lang:t('general.enter_crew_name'),
                type = "error",
                header = Lang:t('general.missing_field')
            })
            return
        end

        if not crew_description or crew_description == "" then
            cb({
                message = Lang:t('general.enter_crew_description'),
                type = "error",
                header = Lang:t('general.missing_field')
            })
            return
        end

            for _, crew in pairs(cacheData['crews'] or {}) do
                if string.lower(crew.crew_name) == string.lower(crew_name) then
                cb({
                    message = Lang:t('general.crew_name_exists'),
                    type = "error",
                    header = Lang:t('general.duplicate_crew_name')
                })

                    return
                end
            end
        
            for _, crew in pairs(cacheData['crews'] or {}) do
                if crew.owner_identifier == playerCid then
                cb({
                    message = Lang:t('general.already_own_crew'),
                    type = "error",
                    header = Lang:t('general.crew_exists')
                })

                    return
                end
                for _, member in pairs(crew.members_data or {}) do
                    if member.identifier == playerCid then
                cb({
                    message = Lang:t('general.already_in_crew'),
                    type = "error",
                    header = Lang:t('general.crew_exists')
                })

                return
            end
        end
    end

    RemoveMoney(src, FRKN.MoneyType, FRKN.CrewSystem.Money)

    local initialMembers = {{
        identifier = playerCid,
        name = GetPlayerName(src),
        role = "leader"
    }}

    local initialChat = {}
    local initialRaces = {}

    local insertedId = MySQL.Sync.insert(
        "INSERT INTO frkn_racing_crews (crew_name, crew_description, owner_identifier, members_data, chat_data, races_data, xp, level) VALUES (@name, @desc, @owner, @members, @chat, @races, 0, 1)",
        {
            ['@name'] = crew_name,
            ['@desc'] = crew_description,
            ['@owner'] = playerCid,
            ['@members'] = json.encode(initialMembers),
            ['@chat'] = json.encode(initialChat),
            ['@races'] = json.encode(initialRaces)
        }
    )

    if not insertedId then
        cb({
            message = Lang:t('general.crew_create_failed'),
            type = "error",
            header = Lang:t('general.sql_error')
        })
        return
    end

    local newCrewEntry = {
        id = insertedId,
        crew_name = crew_name,
        crew_description = crew_description,
        owner_identifier = playerCid,
        members_data = initialMembers,
        chat_data = initialChat,
        races_data = initialRaces,
        xp = 0,
        level = 1,
        created_at = os.time()
    }

    cacheData['crews'] = cacheData['crews'] or {}
    table.insert(cacheData['crews'], newCrewEntry)

    TriggerClientEvent('frkn-racing:update', -1, cacheData)
    Wait(1000)
    TriggerClientEvent('frkn-racing:nuiUpdate', src, cacheData)

    cb({
        message = Lang:t('general.crew_created'),
        type = "success",
        header = Lang:t('general.header_crew_created'),
        crew = newCrewEntry
    })

end)

CreateCallback('frkn-racing:sendBetsMessage', function(source, cb, message)
    local src = source
    local identifier = GetPlayerCid(src)

    if not identifier or not message or message == "" then
        cb({ type = "error", header = Lang:t('general.header_chat_error'), message = Lang:t('general.invalid_message') })
        return
    end

    local newMsg = {
        identifier = identifier,
        sender = GetPlayerName(src),
        message = message,
        time = os.time()
    }

    MySQL.Async.execute(
        "INSERT INTO frkn_racing_chat (identifier, sender, message, created_at) VALUES (@i, @s, @m, @t)",
        {
            ['@i'] = newMsg.identifier,
            ['@s'] = newMsg.sender,
            ['@m'] = newMsg.message,
            ['@t'] = newMsg.time
        }
    )

    cacheData['chat'] = cacheData['chat'] or {}
    table.insert(cacheData['chat'], newMsg)

    TriggerClientEvent('frkn-racing:chatUpdate', -1, cacheData['chat'])
    TriggerClientEvent('frkn-racing:update', -1, cacheData)
    cb({ type = "success" })
end)


CreateCallback('frkn-racing:sendCrewMessage', function(source, cb, message)
    local src = source
    local playerCid = GetPlayerCid(src)

    local foundCrew = nil
    for _, c in pairs(cacheData['crews'] or {}) do
        if c.owner_identifier == playerCid then
            foundCrew = c
            break
        elseif c.members_data then
            for _, m in ipairs(c.members_data) do
                if m.identifier == playerCid then
                    foundCrew = c
                    break
                end
            end
        end
    end

    if not foundCrew then
    cb({
        type = "error",
        header = Lang:t('general.crew_error'),
        message = Lang:t('general.not_in_crew')
    })
    return
    end

    local newMsg = {
        sender = GetPlayerName(src),
        identifier = playerCid,
        text = message,
        time = os.time()
    }

    local chatList = foundCrew.chat_data or {}
    table.insert(chatList, newMsg)
    foundCrew.chat_data = chatList

    MySQL.Async.execute(
        "UPDATE frkn_racing_crews SET chat_data = @c WHERE id = @id",
        {
            ['@c'] = json.encode(chatList),
            ['@id'] = foundCrew.id
        }
    )

    local crewIndex = nil
    for i, c in pairs(cacheData['crews']) do
        if c.id == foundCrew.id then
            crewIndex = i
            break
        end
    end

    if crewIndex then
        cacheData['crews'][crewIndex].chat_data = chatList
    end

    TriggerClientEvent('frkn-racing:crewChatUpdate', -1, foundCrew.id, chatList)

    TriggerClientEvent('frkn-racing:update', -1, cacheData)

    cb({ type = "success" })
end)


CreateCallback('frkn-racing:kickMember', function(source, cb, crewId, memberId)
    local src = source
    local playerCid = GetPlayerCid(src)

    local foundCrew
    for _, c in pairs(cacheData['crews'] or {}) do
        if c.id == tonumber(crewId) then
            foundCrew = c
            break
        end
    end

    if not foundCrew then
        cb({
            type = "error",
            header = Lang:t('general.crew_error'),
            message = Lang:t('general.crew_not_found')
        })
        return
    end

    if foundCrew.owner_identifier ~= playerCid then
        cb({
            type = "error",
            header = Lang:t('general.unauthorized'),
            message = Lang:t('general.only_leader_can_kick')
        })
        return
    end

    local newMembers = {}
    for _, m in ipairs(foundCrew.members_data) do
        if m.identifier ~= memberId then
            table.insert(newMembers, m)
        end
    end

    foundCrew.members_data = newMembers

    MySQL.Async.execute(
        "UPDATE frkn_racing_crews SET members_data = @m WHERE id = @id",
        {
            ['@m'] = json.encode(newMembers),
            ['@id'] = crewId
        }
    )

    TriggerClientEvent('frkn-racing:update', -1, cacheData)
    Wait(1000)
    TriggerClientEvent('frkn-racing:nuiUpdate', src, cacheData)

    cb({
        type = "success",
        header = Lang:t('general.member_removed'),
        message = Lang:t('general.member_removed_success')
    })
end)

CreateCallback('frkn-racingv2:deleteCrew', function(source, cb, crewId)
    local src = source
    local playerCid = GetPlayerCid(src)

    local foundCrew
    local foundIndex

    for i, crew in ipairs(cacheData['crews'] or {}) do
        if crew.id == crewId then
            foundCrew = crew
            foundIndex = i
            break
        end
    end

    if not foundCrew then
        cb({
            type = "error",
            header = Lang:t('general.crew_not_found_header'),
            message = Lang:t('general.crew_not_exist')
        })
        return
    end

    if tostring(foundCrew.owner_identifier) ~= tostring(playerCid) then
        cb({
            type = "error",
            header = Lang:t('general.header_permission_denied'),
            message = Lang:t('general.only_owner_can_delete_crew')
        })
        return
    end

    MySQL.Async.execute("DELETE FROM frkn_racing_crews WHERE id = @id", {
        ['@id'] = crewId
    })

    table.remove(cacheData['crews'], foundIndex)

    TriggerClientEvent('frkn-racing:update', -1, cacheData)
    Wait(1000)
    TriggerClientEvent('frkn-racing:nuiUpdate', src, cacheData)

    cb({
        type = "success",
        header = Lang:t('general.crew_deleted'),
        message = Lang:t('general.crew_deleted_success')
    })
end)

CreateCallback('frkn-racing:create', function(source, cb, raceData)
    local src = source
    local trackId = raceData.trackId
    local playerCid = GetPlayerCid(src)

    local alreadyInRace = IsPlayerInActiveRace(playerCid)
    if alreadyInRace then
        cb({
            type = "error",
            header = Lang:t('general.header_error'),
            message = Lang:t('general.cannot_create_in_race')
        })
        return
    end



    local money = GetPlayerMoney(src, FRKN.MoneyType)

    if tonumber(money) < tonumber(raceData.buyIn) then 
        cb({
            type = "error",
            header = Lang:t('general.not_enough_money'),
            message = Lang:t('general.not_enough_money_race')
        })
        return
    end

    RemoveMoney(src, FRKN.MoneyType, tonumber(raceData.buyIn))

    if FRKN.Item.config then 
        local item = GetItemCount(src, FRKN.Item['racechip'])
        if item == 0 then
            cb({
                type = "error",
                header = Lang:t('general.missing_item'),
                message = Lang:t('general.race_chip_required')
            })
            return
        end
    end

    if FRKN.Auth.config and not table_contains(FRKN.Auth.authorization, playerCid) then
        cb({
            type = "error",
            header = Lang:t('general.header_permission_denied'),
            message = Lang:t('general.not_authorized_create_race')
        })
        return
    end

    local aliasData = cacheData['alias'][playerCid] or {}
    local playerAlias = aliasData.alias or "Unknown"

    for _, race in ipairs(cacheData) do
        if race.races and race.races[1] and race.races[1].eventName == raceData.eventName then
            cb({
                type = "error",
                header = Lang:t('general.duplicate_race_name'),
                message = Lang:t('general.race_name_exists')
            })
            return
        end
    end

    local trackCheckpoints = {}
    local tId = tonumber(trackId)
    if tId then
        if trackCheckpointsCache[tId] then
            trackCheckpoints = trackCheckpointsCache[tId]
        else
            local result = MySQL.Sync.fetchAll('SELECT checkpoints FROM frkn_racing_track WHERE id = @id', {
                ['@id'] = tId
            })
            if result and result[1] and result[1].checkpoints then
                trackCheckpoints = json.decode(result[1].checkpoints) or {}
                trackCheckpointsCache[tId] = trackCheckpoints
            end
        end
    end

    local racesData = {{
        track_id = trackId,
        creator = playerCid,
        creatorName = playerAlias,
        eventName = raceData.eventName or "Unnamed Race",
        vehicleClass = raceData.vehicleClass or "NON",
        prizeType = raceData.prizeType or "Cash",
        buyIn = tonumber(raceData.buyIn) or 0,
        laps = tonumber(raceData.laps) or 1,
        countdownStart = tonumber(raceData.countdownStart) or 5,
        maxPlayers = tonumber(raceData.maxPlayers) or 0,
        raceTime = tonumber(raceData.raceTime) or 300,
        password = raceData.password or "",
        enableAlerts = raceData.enableAlerts == true,
        reverse = raceData.reverseControls == true,
        forceFPP = raceData.forceFPP == true,
        showPosition = raceData.showPosition == true,
        collision = raceData.collision == true,
        checkpoints = trackCheckpoints,
        distance = raceData.distance or 0.0,
        type = raceData.type or "default",
        players = {{
            identifier = playerCid,
            alias = playerAlias,
            source = src,
            aliasData = aliasData,
            cash = tonumber(raceData.buyIn)
        }},
        raceResult = {},
        startTime = nil,
        identifier = playerCid,
        completed = false,
        createTime = os.time()
    }}

    local insertedId = MySQL.Sync.insert(
        "INSERT INTO frkn_racing (track_id, races) VALUES (@track_id, @races)",
        {
            ['@track_id'] = trackId,
            ['@races'] = json.encode(racesData)
        }
    )

    if racesData[1] then
        racesData[1].id = insertedId
    end

    local newRaceEntry = {
        id = insertedId,
        track_id = tId,
        races = racesData
    }

    table.insert(cacheData, newRaceEntry)

    TriggerClientEvent('frkn-racing:update', -1, cacheData)
    Wait(1000)
    TriggerClientEvent('frkn-racing:nuiUpdate', src, cacheData)

    cb({
        type = "success",
        header = Lang:t('general.race_created'),
        message = Lang:t('general.race_created_success'),
        race = newRaceEntry
    })
end)



CreateThread(function()
    while true do
        Wait(60000) 
        if FRKN.RaceAutoDelete and FRKN.RaceAutoDelete.enabled then
            local timeoutSeconds = (FRKN.RaceAutoDelete.timeout or 30) * 60
            local now = os.time()
            local racesDeleted = false

            for i = #cacheData, 1, -1 do
                local wrapper = cacheData[i]
                local race = (wrapper.races and wrapper.races[1]) or wrapper
                if race and type(race) == "table" and race.createTime and not race.startTime then
                    local elapsed = now - race.createTime
                    if elapsed >= timeoutSeconds then
                        for _, player in ipairs(race.players or {}) do
                            local pSrc = playersByIdentifier[player.identifier]
                            if pSrc then
                                local refundAmount = tonumber(player.cash) or 0
                                if refundAmount > 0 then
                                    AddMoney(pSrc, FRKN.MoneyType or "cash", refundAmount, "frkn-racing-autodelete-refund")
                                end
                                ResetPlayerBucket(pSrc)
                                TriggerClientEvent('frkn-racing:disqualified', pSrc, Lang:t('general.race_auto_deleted'))
                            end
                            playerPositions[player.identifier] = nil
                        end

                        local rId = tonumber(wrapper.id)
                        if rId and activeRaceTimers[rId] then
                            activeRaceTimers[rId] = nil
                        end
                        if rId and notifiedRaceEnd then
                            notifiedRaceEnd[rId] = true
                        end

                        MySQL.Async.execute("DELETE FROM frkn_racing WHERE id = @id", {
                            ['@id'] = wrapper.id
                        })
                        table.remove(cacheData, i)
                        racesDeleted = true
                    end
                end
            end

            if racesDeleted then
                TriggerClientEvent('frkn-racing:update', -1, cacheData)
            end
        end
    end
end)

AddEventHandler('playerDropped', function(reason)
    local src = source
    local playerCid = GetPlayerCid(src)
    playerOriginalBuckets[src] = nil

    for _, race in ipairs(cacheData) do
        for _, r in pairs(race.races) do
            for i = #r.players, 1, -1 do
                if r.players[i].identifier == playerCid then
                    table.remove(r.players, i)
                end
            end
        end
    end

    TriggerClientEvent('frkn-racing:update', -1, cacheData)
end)

RegisterNetEvent('frkn-racing:savePreRacePosition')
AddEventHandler('frkn-racing:savePreRacePosition', function(pos)
    local src = source
    local playerCid = GetPlayerCid(src)
    if playerCid and pos then
        playerPreRacePositions[playerCid] = pos
    end
end)

RegisterNetEvent('frkn-racing:clearPreRacePosition')
AddEventHandler('frkn-racing:clearPreRacePosition', function()
    local src = source
    local playerCid = GetPlayerCid(src)
    if playerCid then
        playerPreRacePositions[playerCid] = nil
    end
end)

CreateCallback('frkn-racing:checkSavedPosition', function(source, cb)
    local playerCid = GetPlayerCid(source)
    if playerCid and playerPreRacePositions[playerCid] then
        local pos = playerPreRacePositions[playerCid]
        playerPreRacePositions[playerCid] = nil
        cb(pos)
    else
        cb(nil)
    end
end)


RegisterUsableItem(FRKN.RacingTablet)


