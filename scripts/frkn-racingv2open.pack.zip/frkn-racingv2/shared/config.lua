FRKN = {
	ServerCallbacks = {},

	language = 'en', -- tr , en , de

	DevMode = false, -- When true, all race categories allow free track creation without restrictions

	UseTabletApp = false, -- 0R Tablet Integration

	MenuItems = {
		["main-page"]     = true,  -- Dashboard
		["create-page"]   = true,  -- Races
		["crew-page"]     = true,  -- Crews
		["betting-page"]  = true,  -- Betting
		["garage-page"]   = true,  -- Garage
		["settings-page"] = true,  -- Settings
	},

 	HudOpen = function()
		-- Enter your export here to open the menu. See the example below.
        -- exports['esx_hud']:HudToggle(true)
    end,

    HudClose = function()
		-- Enter your export here to close the menu. See the example below.
        -- exports['esx_hud']:HudToggle(false)
    end,

	MoneyType = 'cash',

	VehicleTableName = 'owned_vehicles', -- Table name where the vehicles are stored in the database

	FlagProp = "tr_prop_tr_flag_01a",  -- stt_prop_flagpole_2e ,  stt_prop_flagpole_1e

	Item = {
		config = false, -- Set to true if you want to use the item system
		["racechip"] = "racechip",
		["trackchip"] = "trackchip",
	},

	CrewSystem = {
		Money = 3000, -- Amount of money to create a crew
		RewardControlTime = 10, -- Time (in minutes) to control the reward system again
	},

	RaceStartLimit = { 
        enable = true, -- Enable or disable the start distance check
        distance = 150.0 -- Maximum distance (in meters) allowed from the start point
    },

	RaceAutoDelete = {
		enabled = true, -- Enable or disable auto-deletion of unstarted races
		timeout = 30, -- Time in minutes before an unstarted race is automatically deleted
	},

	RaceLineSettings = {
    	enabled = true, -- line sytem on/off
    	formulaOnly = true, -- If true, it is only displayed in the formula race type. If false, it is displayed in all types. 
    	arrowDistance = 5.0, --Distance Between Arrows (meters). Smaller value = More frequent arrows, more detailed line. Larger value = Less frequent arrows, more efficient. Recommended: Between 3.0 and 7.0.
	},

	FormulaTrackId = 74, -- Default track ID to auto-select when formula category is chosen
	FormulaVehicle = "openwheel1", -- Vehicle model to spawn for formula races
	AirplaneVehicle = "velum", -- Vehicle model to spawn for airplane races
	JetSkiVehicle = "seashark", -- Vehicle model to spawn for jetski races

	SetFuel = function(vehicle, level)
		-- Customize this for your fuel system. Examples:
		-- exports["LegacyFuel"]:SetFuel(vehicle, level)
		-- exports["ox_fuel"]:SetFuel(vehicle, level)
		-- exports["cdn-fuel"]:SetFuel(vehicle, level)
		SetVehicleFuelLevel(vehicle, level)
		DecorSetFloat(vehicle, "_FUEL_LEVEL", level)
	end,

	CategoryTracks = {
		formula = { "Formula Race" },                          -- Track names shown when Formula category is selected
		jetski = { "Speedboat Showdown", "Beach Jetski Race" },  -- Track names shown when JetSki category is selected
		airplane = { "Skyline Prop Race" },                      -- Track names shown when Airplane category is selected
	},

	RaceJoinCooldown = {
		enabled = true,  -- Enable/disable the cooldown system (applies to both joining and starting races)
		time = 30,       -- Minutes a player must wait after a race before joining/starting another
	},

	AutoRaceSystem = {
		enabled = true,                  -- Enable/disable the automatic race system
		AnnouncementNotifyOnly = true,   -- If true, announcements will be a notification instead of opening the UI panel
		schedules = {                    -- Times when automatic races will start (server time, HH:MM format)
			"12:45",
			"11:16",
			"15:45",
			"15:55",
			"00:00",
		},
		announceBeforeMinutes = 30,      -- How many minutes before the race to announce it
		joinTimeSeconds = 120,           -- How many seconds players have to join after announcement
		trackIds = {},                   -- Empty = pick from ALL tracks randomly, or specify track IDs like {1, 5, 12}
		laps = 2,                        -- Number of laps
		buyIn = 0,                       -- Entry fee (0 = free)
		maxPlayers = 20,                 -- Maximum number of players
		raceTime = 600,                  -- Race time limit in seconds
		collision = false,               -- Enable/disable collision between racers
		showPosition = true,             -- Show position overlay
		enableAlerts = true,             -- Enable checkpoint markers on the road
		forceFPP = false,                -- Force first person perspective during race
		vehicleClass = "NON",            -- Vehicle class restriction ("NON" = no restriction)
		type = "default",                -- Race type (default, drift, formula, drag, sport)
		prizes = {                       -- Prizes by finishing position (money is added automatically)
			[1] = { type = "money", amount = 50000 },
			[2] = { type = "money", amount = 25000 },
			[3] = { type = "money", amount = 10000 },
		},
	},

	WinXP = 100, -- XP awarded to the winner
	RatingWin = 40, -- Rating points awarded to the winner


    InventoryImagePath = "nui://qb-inventory/html/images/", -- ox = nui://ox_inventory/web/images/

	WeeklyReward = {
		type = "car" , -- money , item , car
    	item = {name = "racechip", amount = 10}, -- if type is item
		car = "adder", -- if type is car
    	money = 10000 -- if type is money
	},

	GiveVehicleKeys = function(src, plate, model)
		-- Customize this export to give vehicle keys to the player
		-- Example for qb-vehiclekeys:
		TriggerEvent('frkn-racingv2:giveKeys', src, plate)
		-- Example for qs-vehiclekeys:
		-- exports['qs-vehiclekeys']:GiveKeys(src, plate, model)
	end,

	ManuelSystem = true, --If you set this to false, you cannot switch between manual and automatic modes using the caps lock key; the gear will remain in manual mode.

	RacePrizeType = "car",

	EndOfRaceMarker = true, -- If you set this to true, a finish marker will appear at the end of the race.

	MinUser = 1, -- Minimum number of players to

	RacingTablet = "racing_tablet", --tablet item name

	StartTime = 2, --Duration of car freeze at the start of the race

	CountdownTime = 0, --Enter how many hours apart you can restart a race

	DisqualifySystem = {
		enabled = false, -- Set to false to completely disable all disqualification checks
		time = 20, -- If a player gets out of the car during the race, they are disqualified from the race after this amount of time (seconds)
		plateCheck = false, -- If you set this to true, players can only race with the cars they selected when entering the race.
	},

	propList = {
		"tr_prop_tr_flag_01a",
		"prop_offroad_barrel01",
		"prop_offroad_barrel02",
		"prop_beachflag_le",
		"prop_air_bagloader",
		"prop_barrier_work06a",
		"prop_mp_cone_01",
		"prop_mp_barrier_02b",
		"prop_roadcone02a",
	},
	
	Sound = {
		EnableCheckpointSound = true, -- Set to false to disable the sound of Checkpoints
		CheckpointSound = "3_2_1", -- Sound name (GTA native sound)
		CheckpointSoundSet = "HUD_MINI_GAME_SOUNDSET" -- Sound set (GTA native sound set)
	},

	DriftBlacklist = { -- The cars you add here will not be able to open drift modes even in drift mode. (If you have a car with a special drift setting, you can write here)
		'adder',
		'bullet',
		'cheetah',
		'entityxf',
	},

	Notify = {
		["join"] = "You successfully participated in the race",
		["incar"] = "Get back in the car",
        ["disqualified"] = "You are disqualified from the race",
		["disqualifyreason"] = "You have been disqualified because you can only race with the car you entered in the race.",
		["raceover"] = "The race is over! You've completed all the laps.",
        ["raceovertime"] = "Race is over! Time's up.",
        ["racejoin"] = "You have joined the race.",
		["timeproblem"] = "You cannot start a race yet. You need to wait %d minutes to start a race"
	},

	Rating = { 	 --40 = 1st place , 30 = 2nd place , 20 = 3rd place ... -- Rating for the players
		40, 30, 20, 10, 0, -5, -10, -12, -14, -16, -20, -25, -30, -35, -40
	}, 

	XP = { --50 = 1st place , 40 = 2nd place , 30 = 3rd place ... XP for the players
		50, 40, 30, 20, 10, 5, 3, 2, 1
	},

	Auth = {
		config = false, -- Set to true if you want to use the authorization system
		authorization = {
			'AZI27977',
		}
	},


	Interaction = {
		Target = 'ox_target' -- ox_target , qb-target 
	},
	
	RacingNPC = { --If you get stuck, the NPC you need to go back to is here.
	    enabled = true,
	    coords = vector4(2277.7205, 7880.6743, 423.5204, 239.8997),

	    cityCoords = {
	        motel = {
	            coords = vector4(324.12, -212.52, 54.09, 160.0),
	            text = "Motel Teleport"
	        },
	        police = {
	            coords = vector4(425.1, -979.5, 30.7, 90.0),
	            text = "Police Station"
	        },
	        airport = {
	            coords = vector4(-1034.6, -2733.6, 13.8, 330.0),
	            text = "Airport"
	        }
	    },

	    model = "s_m_y_devinsec_01",
	    scenario = "WORLD_HUMAN_CLIPBOARD",

	    blip = {
	        enabled = false,
	        sprite = 315,
	        color = 5,
	        scale = 0.8,
	        label = "Race Organizer"
	    },

	    target = {
	        icon = "fas fa-location-dot",
	        label = "Teleport",
	        distance = 2.5
	    }
	},


	handlingPresets = {
		["sport"] = {
			fInitialDragCoeff = 8.0,
			fInitialDriveForce = 0.35,
			fBrakeForce = 1.2,
			fSteeringLock = 40.0
		},
		["drift"] = {
			fInitialDragCoeff = 0.5,
			fInitialDriveForce = 0.25,
			fBrakeForce = 0.3, 
			fSteeringLock = 65.0 
		},
		["normal"] = {
			fInitialDragCoeff = 10.0,
			fInitialDriveForce = 0.32,
			fBrakeForce = 1.0,
			fSteeringLock = 35.0
		},
		["drag"] = {
			fInitialDragCoeff = 1.0,
			fInitialDriveForce = 0.5,
			fBrakeForce = 0.8,
			fSteeringLock = 20.0
		}
	},	

}