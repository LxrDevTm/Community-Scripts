local currentLang = FRKN.language or "en"
local function LoadLocale(lang)
    local file = ('locales/%s.lua'):format(lang)
    local chunk = LoadResourceFile(GetCurrentResourceName(), file)

    if not chunk then
        local fallback = LoadResourceFile(GetCurrentResourceName(), "locales/en.lua")
        return load(fallback)()
    end

    return load(chunk)()
end

local Translations = LoadLocale(currentLang)

Lang = Locale:new({
    phrases = Translations,
    warnOnMissing = true
})

