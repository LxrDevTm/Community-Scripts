-- ============================================================================
-- Client-side AR Navigation System for FRKN Framework
-- Refactored for clarity, performance, and maintainability
-- ============================================================================

-- ----------------------------------------------------------------------------
-- Constants and Defaults
-- ----------------------------------------------------------------------------
local DEFAULT_COLOR = { r = 0, g = 180, b = 255 }
local DEFAULT_GLOBAL_SCALE = 0.85
local DEFAULT_COMPASS_SCALE = 0.75
local DEFAULT_ANCHOR_MODEL = "prop_ld_dummy_rope"
local DEFAULT_WAYPOINT_DUI_WIDTH = 1024
local DEFAULT_WAYPOINT_DUI_HEIGHT = 256
local DEFAULT_TURNSIGN_DUI_WIDTH = 1024
local DEFAULT_TURNSIGN_DUI_HEIGHT = 256

local TEX_WAYPOINT_TXD = "frkn_waypoint_dui_txd"
local TEX_WAYPOINT_TEXTURE = "frkn_waypoint_dui_tex"
local TEX_TURNSIGN_TXD = "frkn_turnsign_dui_txd"
local TEX_TURNSIGN_TEXTURE = "frkn_turnsign_dui_tex"

-- ----------------------------------------------------------------------------
-- State Variables (local to this module)
-- ----------------------------------------------------------------------------
local customRoutes = {}                 -- table of custom route coordinates by id
local routeActive = false               -- whether a route (waypoint or custom) exists
local routeTargetCoords = nil           -- target coordinates (vector3)
local currentDistance = 0.0             -- cached route distance
local currentEtaText = ""               -- formatted ETA string
local currentTurnInfo = nil             -- { pos, street, direction, curveLevel }
local turnMarkers = {}                  -- list of { pos, isRight, heading }
local isTurning = false                 -- flag for active turn detection
local routeNodes = {}                   -- list of navigation nodes
local previousCheckpoints = {}          -- checkpoint positions for turn validation
local compassAngle = 0.0                -- smoothed compass angle (relative to camera)
local lastNuiUpdateTime = 0             -- last time we sent NUI update
local arKnownVisible = nil              -- nil=unknown, true=AR shown, false=AR known hidden
local lastRouteScanTime = 0             -- last time we scanned route nodes
local groundZCache = {}                 -- cache for GetGroundZFor_3dCoord
local nodeSpacing = 4.0                 -- spacing between route nodes

-- Anchor / 3D entity support
local anchorModelHash = nil
local anchorModelRequested = false
local anchorEntities = {}               -- entity handles by key
local anchorEntityPosCache = {}         -- cached positions for anchor entities

-- Waypoint DUI (HTML overlay)
local waypointDui = nil
local waypointDuiReady = false
local waypointDuiLastMessage = nil
local waypointDuiLastMessageTime = 0
local waypointTxd = nil
local waypointDuiWarmupEnd = 0

-- Turn sign DUI
local turnSignDui = nil
local turnSignDuiReady = false
local turnSignDuiLastMessage = nil
local turnSignDuiLastMessageTime = 0
local turnSignTxd = nil
local turnSignDuiWarmupEnd = 0

-- Timing / caching for performance
local lastDistanceCalcTime = 0
local lastDistanceCalcTime2 = 0
local lastPosition = vector3(0, 0, 0)
local lastCachedDistance = nil
local lastGroundZCacheClear = 0

-- ----------------------------------------------------------------------------
-- Exported / Global Variables (used by other scripts)
-- ----------------------------------------------------------------------------
ShowAddressBar = false
ShowCompass = false
menuOpen = false
CurrentColor = DEFAULT_COLOR
ARGlobalState = true
EdgeIndicatorEnabled = false
ARCategoryStates = {}

-- ----------------------------------------------------------------------------
-- Utility Functions
-- ----------------------------------------------------------------------------

-- Formats a distance in meters to a human-readable string
function FormatDistance(meters)
    local unitSystem = FRKN.UnitSystem
    if unitSystem == "mil" then
        local feet = meters * 3.28084
        if feet >= 5280 then
            return string.format("%.2f mi", feet / 5280)
        else
            return math.floor(feet) .. " ft"
        end
    else
        if meters < 1000.0 then
            return math.floor(meters) .. " m"
        else
            return string.format("%.1f km", meters / 1000.0)
        end
    end
end

-- Calculates estimated time of arrival based on distance and speed (m/s)
function CalculateETA(distance, speed)
    if speed < 5.0 then speed = 15.0 end
    local seconds = distance / speed
    if seconds < 60 then
        return "1 min"
    else
        return math.floor(seconds / 60) .. " min"
    end
end

-- Merges color tables with fallback
function MergeColor(userColor, defaultColor)
    if type(userColor) ~= "table" then
        userColor = {}
    end
    local result = {}
    result.r = tonumber(userColor.r) or (defaultColor and defaultColor.r) or DEFAULT_COLOR.r
    result.g = tonumber(userColor.g) or (defaultColor and defaultColor.g) or DEFAULT_COLOR.g
    result.b = tonumber(userColor.b) or (defaultColor and defaultColor.b) or DEFAULT_COLOR.b
    return result
end

-- Gets FRKN.UI config or empty table
function GetFRKNUIConfig()
    local ui = FRKN.UI
    if type(ui) ~= "table" then ui = {} end
    return ui
end

-- Returns the global color from FRKN.UI (with fallback)
function GetGlobalColor()
    local ui = GetFRKNUIConfig()
    return MergeColor(ui.GlobalColor, DEFAULT_COLOR)
end

-- Retrieves a category's configuration
function GetCategoryConfig(categoryId)
    local ui = GetFRKNUIConfig()
    if type(ui.Categories) == "table" and type(ui.Categories[categoryId]) == "table" then
        return ui.Categories[categoryId]
    end
    return {}
end

-- Builds the state table for a given category
function GetCategoryState(categoryId, forceShow, forceStyle)
    local cfg = GetCategoryConfig(categoryId)

    local show = forceShow
    if cfg.Enabled ~= nil then
        show = (cfg.Enabled == true)
    end

    -- Matches original behavior: forceStyle (the per-category default passed by
    -- GetCategoryStates) takes priority over cfg.Style whenever forceStyle is set.
    local style = forceStyle or tonumber(cfg.Style)
    if not style then style = 1 end

    local scale = tonumber(cfg.Scale) or 1.0
    if scale < 0.5 then scale = 0.5 elseif scale > 1.5 then scale = 1.5 end

    return {
        show = show,
        style = style,
        scale = scale,
        color = MergeColor(cfg.Color, GetGlobalColor())
    }
end

-- Returns all category states
function GetCategoryStates()
    return {
        adres  = GetCategoryState("adres", false, 1),
        metre  = GetCategoryState("metre", true, 2),
        marker = GetCategoryState("marker", true, 1),
        ok     = GetCategoryState("ok", false, 1)
    }
end

-- Returns global scale from FRKN.UI
function GetGlobalScale()
    local ui = GetFRKNUIConfig()
    return tonumber(ui.GlobalScale) or DEFAULT_GLOBAL_SCALE
end

-- Returns compass default scale
function GetCompassDefaultScale()
    local ui = GetFRKNUIConfig()
    return tonumber(ui.CompassDefaultScale) or DEFAULT_COMPASS_SCALE
end

-- Computes final scale for a category (global * category scale)
function GetCategoryScaled(categoryId, baseScale)
    baseScale = baseScale or 1.0
    local categoryState = ARCategoryStates[categoryId]
    local categoryScale = (categoryState and tonumber(categoryState.scale)) or 1.0
    if categoryScale < 0.5 then categoryScale = 0.5 elseif categoryScale > 1.5 then categoryScale = 1.5 end
    return baseScale * GetGlobalScale() * categoryScale
end

-- Returns default configuration for the NUI
function GetDefaultConfig()
    return {
        global = (GetFRKNUIConfig().GlobalEnabled ~= false),
        globalColor = GetGlobalColor(),
        useSavedPreferences = (GetFRKNUIConfig().UseSavedPreferences == true),
        edgeIndicator = (GetFRKNUIConfig().EdgeIndicatorEnabled ~= false),
        compassScale = GetCompassDefaultScale(),
        categories = GetCategoryStates()
    }
end

-- Sends the default config to the NUI
function SendConfigDefaults()
    SendNUIMessage({
        type = "SET_CONFIG_DEFAULTS",
        defaults = GetDefaultConfig()
    })
end

-- Refreshes all state variables from FRKN.UI
function RefreshGlobalState()
    CurrentColor = GetGlobalColor()
    ARGlobalState = (GetFRKNUIConfig().GlobalEnabled ~= false)
    EdgeIndicatorEnabled = (GetFRKNUIConfig().EdgeIndicatorEnabled ~= false)

    ARCategoryStates = GetCategoryStates()
    ShowAddressBar = ARCategoryStates.adres.show
    ShowCompass = ARCategoryStates.ok.show
end

-- Initial refresh
RefreshGlobalState()

-- ----------------------------------------------------------------------------
-- Tick Rate Helper
-- ----------------------------------------------------------------------------
function GetTickRate(key, default)
    local rates = FRKN.TickRates
    if type(rates) ~= "table" then rates = {} end
    local val = tonumber(rates[key])
    if val == nil or val < 0 then return default end
    return val
end

-- ----------------------------------------------------------------------------
-- AR Visibility Helpers
-- ----------------------------------------------------------------------------
function IsAnyCategoryEnabled()
    return ARCategoryStates.adres.show
        or ARCategoryStates.metre.show
        or ARCategoryStates.marker.show
        or ARCategoryStates.ok.show
end

function IsARVisible()
    return ARGlobalState and IsAnyCategoryEnabled()
end

function HideAR(force)
    local now = GetGameTimer()
    if not force and arKnownVisible == false and lastNuiUpdateTime > 0 and now - lastNuiUpdateTime < 1000 then
        return
    end
    SendNUIMessage({ type = "UPDATE_AR", visible = false })
    lastNuiUpdateTime = now
    arKnownVisible = false
end

function ShouldSendNuiUpdate(now)
    local rate = GetTickRate("NuiUpdate", 100)
    return rate <= 0 or (now - lastNuiUpdateTime >= rate)
end

-- ----------------------------------------------------------------------------
-- Anchor / 3D Entity Management
-- ----------------------------------------------------------------------------
function GetAnchorProps()
    local props = FRKN.AnchorProps
    if type(props) ~= "table" then props = {} end
    return props
end

function IsAnchorEnabled()
    return GetAnchorProps().Enabled ~= false
end

function IsAnchorModelReady()
    if not IsAnchorEnabled() then return false end
    local props = GetAnchorProps()
    local modelName = props.Model or DEFAULT_ANCHOR_MODEL
    local hash
    if type(modelName) == "number" then
        hash = modelName
    else
        hash = GetHashKey(modelName)
    end

    if anchorModelHash ~= hash then
        anchorModelHash = hash
        anchorModelRequested = false
    end

    if HasModelLoaded(anchorModelHash) then
        return true
    end

    if not anchorModelRequested then
        RequestModel(anchorModelHash)
        anchorModelRequested = true
    end

    return HasModelLoaded(anchorModelHash)
end

function DeleteAnchorEntity(key)
    local entity = anchorEntities[key]
    if entity and DoesEntityExist(entity) then
        DeleteEntity(entity)
    end
    anchorEntities[key] = nil
    anchorEntityPosCache[key] = nil
end

function DeleteAllAnchors()
    DeleteAnchorEntity("waypoint")
    DeleteAnchorEntity("turnSign")
end

function UpdateAnchorEntity(key, targetPos, useAnchor)
    if not useAnchor or not IsAnchorEnabled() or not IsAnchorModelReady() then
        return targetPos
    end

    local entity = anchorEntities[key]
    local cache = anchorEntityPosCache[key]

    if entity and DoesEntityExist(entity) then
        local requested = cache and cache.requested
        if not requested or #(targetPos - requested) > 0.05 then
            SetEntityCoordsNoOffset(entity, targetPos.x, targetPos.y, targetPos.z, false, false, false)
            anchorEntityPosCache[key] = {
                requested = targetPos,
                cached = GetEntityCoords(entity)
            }
        end
    else
        local newEntity = CreateObjectNoOffset(anchorModelHash, targetPos.x, targetPos.y, targetPos.z, false, false, false)
        if newEntity and newEntity ~= 0 then
            anchorEntities[key] = newEntity
            SetEntityAsMissionEntity(newEntity, true, true)
            SetEntityVisible(newEntity, false, false)
            SetEntityAlpha(newEntity, 0, false)
            SetEntityCollision(newEntity, false, false)
            FreezeEntityPosition(newEntity, true)

            local newCache = {
                requested = targetPos,
                cached = GetEntityCoords(newEntity)
            }
            anchorEntityPosCache[key] = newCache
        else
            return targetPos
        end
    end

    if anchorEntityPosCache[key] and anchorEntityPosCache[key].cached then
        return anchorEntityPosCache[key].cached
    end
    return targetPos
end

function GetAnchorPropValue(key, default)
    local props = GetAnchorProps()
    local val = tonumber(props[key])
    if val == nil then return default end
    return val
end

-- ----------------------------------------------------------------------------
-- Drawing Helpers
-- ----------------------------------------------------------------------------
function DrawText(text, x, y, scale, r, g, b, a, font, centered)
    SetTextFont(font or 4)
    SetTextScale(0.0, scale)
    SetTextColour(r, g, b, a)
    SetTextCentre(centered == true)
    SetTextDropshadow(0, 0, 0, 0, 0)
    SetTextEdge(1, 0, 0, 0, 180)
    SetTextOutline()
    BeginTextCommandDisplayText("STRING")
    AddTextComponentSubstringPlayerName(text)
    EndTextCommandDisplayText(x, y)
end

function DrawCustomMarker(position, line1, line2, color, scale)
    if not position then return end
    color = color or CurrentColor
    scale = scale or 1.0

    local w = 0.0032 * scale
    local h = 0.036 * scale
    local bw = 0.07 * scale
    local bh = 0.027 * scale
    local offsetX = -0.033 * scale
    local offsetY = 0.014 * scale

    SetDrawOrigin(position.x, position.y, position.z, 0)

    DrawRect(offsetX, 0.0, w, h, color.r, color.g, color.b, 235)
    DrawRect(offsetY, 0.0, bw, bh, 8, 12, 18, 180)

    DrawText(line1, -0.012 * scale, -0.0125 * scale, 0.22 * scale, 255, 255, 255, 255, 4, false)
    if line2 and line2 ~= "" then
        DrawText(line2, 0.024 * scale, -0.0105 * scale, 0.145 * scale, 220, 226, 232, 220, 4, false)
    end

    ClearDrawOrigin()
end

-- ----------------------------------------------------------------------------
-- Waypoint DUI (HTML overlay)
-- ----------------------------------------------------------------------------
function GetWaypointDuiConfig()
    local cfg = FRKN.WaypointDui
    if type(cfg) ~= "table" then cfg = {} end
    return cfg
end

function InitWaypointDui()
    if waypointDui and waypointDuiReady then return true end

    local cfg = GetWaypointDuiConfig()
    local width = tonumber(cfg.Width) or DEFAULT_WAYPOINT_DUI_WIDTH
    local height = tonumber(cfg.Height) or DEFAULT_WAYPOINT_DUI_HEIGHT

    local url = string.format("https://cfx-nui-%s/html/waypoint_dui.html", GetCurrentResourceName())
    local dui = CreateDui(url, width, height)
    if not dui then return false end

    local handle = GetDuiHandle(dui)
    if not handle then
        DestroyDui(dui)
        waypointDui = nil
        waypointDuiReady = false
        return false
    end

    waypointDui = dui
    local txd = CreateRuntimeTxd(TEX_WAYPOINT_TXD)
    waypointTxd = txd
    CreateRuntimeTextureFromDuiHandle(txd, TEX_WAYPOINT_TEXTURE, handle)

    waypointDuiReady = true
    waypointDuiLastMessage = nil
    waypointDuiLastMessageTime = 0
    waypointDuiWarmupEnd = GetGameTimer() + 1500
    return true
end

function GetWaypointDuiStyle(styleId)
    local cfg = GetWaypointDuiConfig()
    if type(cfg.Styles) == "table" and type(cfg.Styles[styleId]) == "table" then
        return cfg.Styles[styleId]
    end
    return {}
end

function SendWaypointDuiMessage(distance, eta, color, style)
    if not color then color = CurrentColor end
    local msg = string.format("%s|%s|%s|%s|%s|%s",
        distance or "",
        eta or "",
        color.r or 0,
        color.g or 180,
        color.b or 255,
        style or 2
    )

    local now = GetGameTimer()
    if waypointDuiLastMessage == msg then
        local rate = GetTickRate("DuiWarmupUpdate", 250)
        if now > waypointDuiWarmupEnd or now - waypointDuiLastMessageTime < rate then
            return
        end
    end

    waypointDuiLastMessage = msg
    waypointDuiLastMessageTime = now

    SendDuiMessage(waypointDui, json.encode({
        type = "UPDATE_WAYPOINT_DUI",
        distance = distance,
        eta = eta,
        color = color,
        style = style or 2
    }))
end

function DrawWaypointDui(position, distance, eta, color, scale, style)
    if not position or not InitWaypointDui() then return end

    SendWaypointDuiMessage(distance, eta, color, style)

    local styleCfg = GetWaypointDuiStyle(style or 2)
    scale = scale or 1.0

    local drawWidth = (tonumber(styleCfg.DrawWidth) or 0.215) * scale
    local drawHeight = (tonumber(styleCfg.DrawHeight) or 0.06) * scale
    local originX = (tonumber(styleCfg.OriginX) or 0.052) * scale

    SetDrawOrigin(position.x, position.y, position.z, 0)
    DrawSprite(TEX_WAYPOINT_TXD, TEX_WAYPOINT_TEXTURE, originX, 0.0, drawWidth, drawHeight, 0.0, 255, 255, 255, 255)
    ClearDrawOrigin()
end

function DestroyWaypointDui()
    if waypointDui then
        DestroyDui(waypointDui)
        waypointDui = nil
        waypointDuiReady = false
        waypointTxd = nil
        waypointDuiLastMessage = nil
        waypointDuiLastMessageTime = 0
        waypointDuiWarmupEnd = 0
    end
end

-- ----------------------------------------------------------------------------
-- Turn Sign DUI
-- ----------------------------------------------------------------------------
function GetTurnSignDuiConfig()
    local cfg = FRKN.TurnSignDui
    if type(cfg) ~= "table" then cfg = {} end
    return cfg
end

function InitTurnSignDui()
    if turnSignDui and turnSignDuiReady then return true end

    local cfg = GetTurnSignDuiConfig()
    local width = tonumber(cfg.Width) or DEFAULT_TURNSIGN_DUI_WIDTH
    local height = tonumber(cfg.Height) or DEFAULT_TURNSIGN_DUI_HEIGHT

    local url = string.format("https://cfx-nui-%s/html/turnsign_dui.html", GetCurrentResourceName())
    local dui = CreateDui(url, width, height)
    if not dui then return false end

    local handle = GetDuiHandle(dui)
    if not handle then
        DestroyDui(dui)
        turnSignDui = nil
        turnSignDuiReady = false
        return false
    end

    turnSignDui = dui
    local txd = CreateRuntimeTxd(TEX_TURNSIGN_TXD)
    turnSignTxd = txd
    CreateRuntimeTextureFromDuiHandle(txd, TEX_TURNSIGN_TEXTURE, handle)

    turnSignDuiReady = true
    turnSignDuiLastMessage = nil
    turnSignDuiLastMessageTime = 0
    turnSignDuiWarmupEnd = GetGameTimer() + 1500
    return true
end

function SendTurnSignDuiMessage(street, direction, curveLevel, color, style)
    if not color then color = CurrentColor end
    local msg = string.format("%s|%s|%s|%s|%s|%s|%s",
        street or "",
        direction or "straight",
        curveLevel or "",
        color.r or 0,
        color.g or 180,
        color.b or 255,
        style or 1
    )

    local now = GetGameTimer()
    if turnSignDuiLastMessage == msg then
        local rate = GetTickRate("DuiWarmupUpdate", 250)
        if now > turnSignDuiWarmupEnd or now - turnSignDuiLastMessageTime < rate then
            return
        end
    end

    turnSignDuiLastMessage = msg
    turnSignDuiLastMessageTime = now

    SendDuiMessage(turnSignDui, json.encode({
        type = "UPDATE_TURN_SIGN_DUI",
        street = street or "",
        direction = direction or "straight",
        curveLevel = curveLevel or "",
        color = color,
        style = style or 1
    }))
end

function GetTurnSignDuiStyle(styleId)
    local cfg = GetTurnSignDuiConfig()
    if type(cfg.Styles) == "table" and type(cfg.Styles[styleId]) == "table" then
        return cfg.Styles[styleId]
    end
    return {
        DrawWidth = cfg.DrawWidth,
        DrawHeight = cfg.DrawHeight,
        OriginX = cfg.OriginX,
        OriginY = cfg.OriginY
    }
end

function DrawTurnSignDui(position, turnInfo, color, scale, style)
    if not position or not turnInfo then return false end
    if not InitTurnSignDui() then return false end

    SendTurnSignDuiMessage(turnInfo.street, turnInfo.direction, turnInfo.curveLevel, color, style)

    local styleCfg = GetTurnSignDuiStyle(style or 1)
    scale = scale or 1.0

    local drawWidth = (tonumber(styleCfg.DrawWidth) or 0.27) * scale
    local drawHeight = (tonumber(styleCfg.DrawHeight) or 0.078) * scale
    local originX = (tonumber(styleCfg.OriginX) or 0.0) * scale
    local originY = (tonumber(styleCfg.OriginY) or 0.0) * scale

    SetDrawOrigin(position.x, position.y, position.z, 0)
    DrawSprite(TEX_TURNSIGN_TXD, TEX_TURNSIGN_TEXTURE, originX, originY, drawWidth, drawHeight, 0.0, 255, 255, 255, 255)
    ClearDrawOrigin()
    return true
end

function DestroyTurnSignDui()
    if turnSignDui then
        DestroyDui(turnSignDui)
        turnSignDui = nil
        turnSignDuiReady = false
        turnSignTxd = nil
        turnSignDuiLastMessage = nil
        turnSignDuiLastMessageTime = 0
        turnSignDuiWarmupEnd = 0
    end
end

-- ----------------------------------------------------------------------------
-- Ground Z with Caching
-- ----------------------------------------------------------------------------
function GetGroundZWithCache(x, y, z)
    local gridX = math.floor(x / nodeSpacing)
    local gridY = math.floor(y / nodeSpacing)
    local key = gridX * 100000 + gridY

    if groundZCache[key] then
        return groundZCache[key]
    end

    local success, groundZ = GetGroundZFor_3dCoord(x, y, z + 50.0, 0)
    if not success then
        success, groundZ = GetGroundZFor_3dCoord(x, y, 1000.0, 0)
    end

    if success then
        groundZCache[key] = groundZ
        return groundZ
    end

    return z
end

-- ----------------------------------------------------------------------------
-- Angle Utilities
-- ----------------------------------------------------------------------------
function NormalizeAngle(angle)
    angle = angle % 360.0
    if angle > 180.0 then angle = angle - 360.0 end
    if angle < -180.0 then angle = angle + 360.0 end
    return angle
end

function GetHeadingBetweenPoints(from, to)
    local dx = to.x - from.x
    local dy = to.y - from.y
    return math.deg(math.atan2(dx, dy))
end

function LerpAngle(from, to, alpha)
    local diff = NormalizeAngle(to - from)
    return from + diff * alpha
end

-- ----------------------------------------------------------------------------
-- Route Calculation Thread
-- ----------------------------------------------------------------------------
Citizen.CreateThread(function()
    while true do
        local tick = GetTickRate("TurnCalculation", 500)
        local visible = IsARVisible()
        local waypointActive = IsWaypointActive()
        local customTarget = nil

        for _, v in pairs(customRoutes) do
            if type(v) == "vector3" then
                customTarget = v
                break
            end
        end

        if not (waypointActive or customTarget) or not visible then
            if routeActive then
                routeActive = false
                routeTargetCoords = nil
                isTurning = false
                currentTurnInfo = nil
                turnMarkers = {}
                routeNodes = {}
                lastPosition = vector3(0, 0, 0)
                currentDistance = 0
                currentEtaText = ""
                DeleteAllAnchors()
                HideAR(true)
            end
            Citizen.Wait(GetTickRate("NoWaypoint", 1000))
        else
            local targetPos = nil
            local blip = GetFirstBlipInfoId(8)
            if waypointActive and DoesBlipExist(blip) then
                targetPos = GetBlipInfoIdCoord(blip)
            elseif customTarget then
                targetPos = customTarget
            end

            if targetPos then
                local ped = PlayerPedId()
                local pedPos = GetEntityCoords(ped)
                local inVehicle = IsPedInAnyVehicle(ped, false)
                local speed = 0.0
                if inVehicle then
                    speed = GetEntitySpeed(GetVehiclePedIsIn(ped, false))
                end

                local recalcRoute = false
                if not routeActive or not routeTargetCoords or #(routeTargetCoords - targetPos) > 10.0 then
                    recalcRoute = true
                end

                if recalcRoute then
                    local groundZ = GetGroundZWithCache(targetPos.x, targetPos.y, targetPos.z)
                    local newTarget = vector3(targetPos.x, targetPos.y, groundZ)
                    routeTargetCoords = newTarget
                    routeActive = true
                    isTurning = false
                    currentTurnInfo = nil
                    turnMarkers = {}
                    routeNodes = {}
                    previousCheckpoints = {}
                    DeleteAnchorEntity("turnSign")
                    lastPosition = vector3(0, 0, 0)
                    currentDistance = 0
                    currentEtaText = ""
                    lastCachedDistance = nil
                end

                local now = GetGameTimer()

                if FRKN.RequireVehicle and not inVehicle then
                    if isTurning or currentTurnInfo or #turnMarkers > 0 then
                        isTurning = false
                        currentTurnInfo = nil
                        turnMarkers = {}
                        routeNodes = {}
                        previousCheckpoints = {}
                        DeleteAnchorEntity("turnSign")
                    end
                    HideAR(false)
                    tick = GetTickRate("VehicleCheck", 200)
                else
                    if ARCategoryStates.metre.show then
                        local directDistance = #(pedPos - routeTargetCoords)
                        local routeDistance = directDistance
                        local rate = GetTickRate("RouteDistanceCalc", 2000)
                        if now - lastDistanceCalcTime > rate then
                            local travelDist = CalculateTravelDistanceBetweenPoints(pedPos.x, pedPos.y, pedPos.z,
                                routeTargetCoords.x, routeTargetCoords.y, routeTargetCoords.z)
                            if travelDist >= 100000.0 or travelDist < 5.0 then
                                routeDistance = directDistance
                            else
                                routeDistance = travelDist
                            end
                            currentDistance = routeDistance
                            lastDistanceCalcTime = now
                            lastDistanceCalcTime2 = now
                            lastCachedDistance = directDistance
                        else
                            if lastCachedDistance then
                                local delta = directDistance - lastCachedDistance
                                currentDistance = math.max(0.0, currentDistance + delta)
                            end
                            lastCachedDistance = directDistance
                        end

                        currentEtaText = CalculateETA(currentDistance, speed)
                    end

                    if now - lastGroundZCacheClear > 30000 then
                        groundZCache = {}
                        lastGroundZCacheClear = now
                    end

                    -- Route scanning for turn detection
                    local needTurnDetection = ARCategoryStates.marker.show or ARCategoryStates.adres.show or ARCategoryStates.ok.show
                    local distanceFromLastNode = #(pedPos - lastPosition)
                    local refreshDistance = GetTickRate("RouteRefreshDistance", 25.0)
                    local scanRate = GetTickRate("RouteScan", GetTickRate("TurnCalculation", 500))

                    if needTurnDetection then
                        if recalcRoute or (distanceFromLastNode > refreshDistance and now - lastRouteScanTime >= scanRate) then
                            local nodes = {}
                            local nodeCount = math.floor(GetTickRate("RouteNodeCount", 40))
                            local spacing = GetTickRate("RouteNodeSpacing", 10.0)

                            -- Sample points along the player's active GPS route
                            for i = 0, nodeCount, 1 do
                                local ok, retval, pos = pcall(GetPosAlongGpsTypeRoute, true, i * spacing, 0)
                                if ok and retval and type(pos) == "vector3" and pos.x ~= 0.0 and pos.y ~= 0.0 and pos.z ~= 0.0 then
                                    nodes[#nodes + 1] = pos
                                else
                                    break
                                end
                            end

                            routeNodes = nodes
                            lastPosition = pedPos
                            lastRouteScanTime = now

                            -- Compare this scan's nodes at fixed lookahead indices against the
                            -- PREVIOUS scan's checkpoints (before we overwrite them below). A large
                            -- shift at 2+ checkpoints means the road ahead changed shape (the turn
                            -- we were tracking is behind us now) -- it does not by itself mean a
                            -- turn is coming up; the geometry scan below is what finds those.
                            if #nodes >= 15 and #previousCheckpoints >= 3 then
                                local turnCount = 0
                                for i, idx in ipairs({10, 15, 20}) do
                                    if idx <= #nodes and previousCheckpoints[i] then
                                        local dist = #(nodes[idx] - previousCheckpoints[i])
                                        if dist > 25.0 then
                                            turnCount = turnCount + 1
                                        end
                                    end
                                end
                                if turnCount >= 2 and isTurning then
                                    isTurning = false
                                    currentTurnInfo = nil
                                    turnMarkers = {}
                                    DeleteAnchorEntity("turnSign")
                                end
                            end

                            local checkpoints = {}
                            for _, idx in ipairs({10, 15, 20}) do
                                if idx <= #nodes then
                                    checkpoints[#checkpoints + 1] = nodes[idx]
                                end
                            end
                            previousCheckpoints = checkpoints

                            -- Expire the active turn once we've passed it (too close) or it's gone
                            -- stale (too far, e.g. after a route recalculation elsewhere)
                            if isTurning and currentTurnInfo then
                                local turnDist = #(pedPos - currentTurnInfo.pos)
                                if turnDist < 25.0 or turnDist > 900.0 then
                                    isTurning = false
                                    currentTurnInfo = nil
                                    turnMarkers = {}
                                    DeleteAnchorEntity("turnSign")
                                end
                            end
                        end
                    end

                    -- Find precise turn location if not already tracking one
                    if not isTurning and inVehicle and #routeNodes >= 9 then
                        for i = 6, #routeNodes - 4, 1 do
                            local node = routeNodes[i]
                            local dist = #(pedPos - node)
                            if dist > 40.0 and dist < 800.0 then
                                local headingPrev = GetHeadingBetweenPoints(routeNodes[i - 2], node)
                                local headingNext = GetHeadingBetweenPoints(node, routeNodes[i + 2])
                                local delta = NormalizeAngle(headingNext - headingPrev)
                                local absDelta = math.abs(delta)

                                if absDelta > 20.0 then
                                    local validTurn = true
                                    local delta3 = 0.0
                                    local delta4 = 0.0

                                    if i - 3 >= 1 and i + 3 <= #routeNodes then
                                        local h1 = GetHeadingBetweenPoints(routeNodes[i - 3], node)
                                        local h2 = GetHeadingBetweenPoints(node, routeNodes[i + 3])
                                        delta3 = NormalizeAngle(h2 - h1)
                                        if math.abs(delta3) < 15.0 or delta3 * delta < 0 then
                                            validTurn = false
                                        end
                                    end

                                    if i - 4 >= 1 and i + 4 <= #routeNodes then
                                        local h1 = GetHeadingBetweenPoints(routeNodes[i - 4], node)
                                        local h2 = GetHeadingBetweenPoints(node, routeNodes[i + 4])
                                        delta4 = NormalizeAngle(h2 - h1)
                                        if math.abs(delta4) < 10.0 or delta4 * delta < 0 then
                                            validTurn = false
                                        end
                                    end

                                    if validTurn then
                                        local maxAngle = math.max(math.abs(delta), math.abs(delta3), math.abs(delta4))
                                        if maxAngle < 50.0 then
                                            validTurn = false
                                        end

                                        if validTurn and routeActive and routeTargetCoords then
                                            if #(node - routeTargetCoords) < 35.0 then
                                                validTurn = false
                                            end
                                        end

                                        local streetStart, streetEnd = 0, 0
                                        if validTurn and maxAngle < 75.0 then
                                            local startIdx = math.max(1, i - 4)
                                            local endIdx = math.min(#routeNodes, i + 4)
                                            streetStart = GetStreetNameAtCoord(routeNodes[startIdx].x, routeNodes[startIdx].y, routeNodes[startIdx].z)
                                            streetEnd = GetStreetNameAtCoord(routeNodes[endIdx].x, routeNodes[endIdx].y, routeNodes[endIdx].z)
                                            if streetStart == streetEnd and streetStart ~= 0 then
                                                validTurn = false
                                            end
                                        end

                                        if validTurn then
                                            local direction = (delta > 0) and "right" or "left"
                                            local groundZ = GetGroundZWithCache(node.x, node.y, node.z)
                                            local prevNode = routeNodes[i - 1]
                                            local dx = node.x - prevNode.x
                                            local dy = node.y - prevNode.y
                                            local len = math.sqrt(dx * dx + dy * dy)
                                            if len > 0.01 then
                                                dx = dx / len
                                                dy = dy / len
                                            end
                                            local nx = -dy
                                            local ny = dx

                                            local streetsDiffer = streetStart ~= streetEnd and streetStart ~= 0 and streetEnd ~= 0
                                            local curveLevel = (maxAngle > 50.0 or streetsDiffer) and "sharp" or "slight"

                                            local streetName = GetStreetNameFromHashKey(GetStreetNameAtCoord(node.x, node.y, groundZ))

                                            currentTurnInfo = {
                                                pos = vector3(node.x, node.y, groundZ + 2.0),
                                                street = streetName,
                                                direction = direction,
                                                curveLevel = curveLevel
                                            }

                                            turnMarkers = {}
                                            if direction == "right" then
                                                for j = -2, 2, 1 do
                                                    local offsetX = node.x + nx * (j * 2.0)
                                                    local offsetY = node.y + ny * (j * 2.0)
                                                    local z = GetGroundZWithCache(offsetX, offsetY, groundZ)
                                                    turnMarkers[#turnMarkers + 1] = {
                                                        pos = vector3(offsetX, offsetY, z),
                                                        isRight = true,
                                                        heading = headingPrev
                                                    }
                                                end
                                            else
                                                for j = 0, 4, 1 do
                                                    local offsetDist = j * 3.5
                                                    local offsetX = node.x - dx * offsetDist
                                                    local offsetY = node.y - dy * offsetDist
                                                    local z = GetGroundZWithCache(offsetX, offsetY, groundZ)
                                                    turnMarkers[#turnMarkers + 1] = {
                                                        pos = vector3(offsetX, offsetY, z),
                                                        isRight = false,
                                                        heading = headingPrev
                                                    }
                                                end
                                            end
                                            isTurning = true
                                            break
                                        end
                                    end
                                end
                            end
                        end
                    end

                    -- Fallback: if no turn detected but adres is enabled, show current street with straight direction
                    if ARCategoryStates.adres.show and not currentTurnInfo and routeActive then
                        local pedPos = GetEntityCoords(ped)
                        local streetHash = GetStreetNameAtCoord(pedPos.x, pedPos.y, pedPos.z)
                        local streetName = GetStreetNameFromHashKey(streetHash) or ""
                        if streetName ~= "" then
                            currentTurnInfo = {
                                pos = vector3(pedPos.x, pedPos.y, pedPos.z + 2.0),
                                street = streetName,
                                direction = "straight",
                                curveLevel = "normal"
                            }
                            turnMarkers = {}
                            isTurning = false
                        end
                    end

                    if not isTurning then
                        -- Keep fallback turnInfo if it exists, but clear markers
                        if not (ARCategoryStates.adres.show and currentTurnInfo and currentTurnInfo.direction == "straight") then
                            currentTurnInfo = nil
                        end
                        turnMarkers = {}
                        DeleteAnchorEntity("turnSign")
                    end
                end
            else
                if routeActive then
                    routeActive = false
                    routeTargetCoords = nil
                    isTurning = false
                    currentTurnInfo = nil
                    turnMarkers = {}
                    routeNodes = {}
                    DeleteAllAnchors()
                    HideAR(true)
                end
                Citizen.Wait(GetTickRate("NoWaypoint", 1000))
            end
        end
        Citizen.Wait(tick)
    end
end)

-- ----------------------------------------------------------------------------
-- Render Thread
-- ----------------------------------------------------------------------------
Citizen.CreateThread(function()
    while true do
        local renderIdle = GetTickRate("RenderIdle", 250)
        if IsARVisible() and routeActive and routeTargetCoords then
            local ped = PlayerPedId()
            local vehicle = GetVehiclePedIsIn(ped, false)
            local now = GetGameTimer()

            if FRKN.RequireVehicle and vehicle == 0 then
                HideAR(false)
                Citizen.Wait(GetTickRate("VehicleCheck", 200))
            else
                local pedPos = GetEntityCoords(ped)
                local distToTarget = #(pedPos - routeTargetCoords)
                local canSendNui = ShouldSendNuiUpdate(now)

                local camPos = nil
                local camFov = nil
                local nuiData = nil
                local hasNuiContent = false
                local hasWorldContent = false

                local function GetCamPos()
                    if not camPos then
                        camPos = GetGameplayCamCoords()
                    end
                    return camPos
                end

                local function GetCamFovFactor()
                    if not camFov then
                        camFov = 1 / GetGameplayCamFov() * 100
                    end
                    return camFov
                end

                local function GetNuiData()
                    if not nuiData then
                        nuiData = BuildNuiUpdateData(pedPos, vehicle)
                    end
                    return nuiData
                end

                -- Compass
                if ShowCompass and ARCategoryStates.ok.show then
                    hasNuiContent = true
                    if canSendNui then
                        GetNuiData()
                    end
                end

                -- Turn markers (world)
                if #turnMarkers > 0 and vehicle ~= 0 and ARCategoryStates.marker.show then
                    local markerColor = ARCategoryStates.marker.color
                    local markerScale = tonumber(FRKN.MarkerScale) or 2.25
                    markerScale = markerScale * GetCategoryScaled("marker", 1.0)

                    for idx, marker in ipairs(turnMarkers) do
                        local pos = marker.pos
                        local dist = #(pedPos - pos)
                        if dist > 3.0 and dist < 100.0 then
                            local alpha = 200
                            if dist < 15.0 then
                                alpha = math.floor(200 * ((dist - 3.0) / 12.0))
                            end
                            local sinOffset = math.sin(now / 300.0 - idx * 0.7) * 45
                            alpha = math.max(0, math.min(255, alpha + math.floor(sinOffset)))

                            local heading = marker.isRight and 90.0 or -90.0
                            DrawMarker(20,
                                pos.x, pos.y, pos.z + 1.2,
                                0.0, 0.0, 0.0,
                                0.0, heading, 0.0,
                                markerScale, markerScale, markerScale,
                                markerColor.r, markerColor.g, markerColor.b, alpha,
                                false, true, 2, false, nil, nil, false)
                            hasWorldContent = true
                        end
                    end
                end

                -- Turn sign (world or NUI)
                if currentTurnInfo and ShowAddressBar and ARCategoryStates.adres.show then
                    local offset = GetAnchorPropValue("TurnSignZOffset", 1.0)
                    local anchorPos = vector3(currentTurnInfo.pos.x, currentTurnInfo.pos.y, currentTurnInfo.pos.z + offset)
                    local updatedPos = UpdateAnchorEntity("turnSign", anchorPos, true)

                    local camDistance = #(GetCamPos() - updatedPos)
                    if camDistance < 90.0 then
                        local onScreen, screenX, screenY = World3dToScreen2d(updatedPos.x, updatedPos.y, updatedPos.z)
                        if onScreen then
                            local scaleFactor = (1 / camDistance) * 18.0 * GetCamFovFactor()
                            scaleFactor = scaleFactor * GetCategoryScaled("adres", 1.0)
                            scaleFactor = math.min(1.15, math.max(0.25, scaleFactor))

                            if FRKN.NativeWorldWidgets ~= false then
                                local drawn = DrawTurnSignDui(updatedPos, currentTurnInfo,
                                    ARCategoryStates.adres.color,
                                    scaleFactor,
                                    ARCategoryStates.adres.style)
                                if drawn then
                                    hasWorldContent = true
                                end
                            else
                                hasNuiContent = true
                                if canSendNui then
                                    local data = GetNuiData()
                                    data.turnSign = {
                                        visible = true,
                                        x = screenX,
                                        y = screenY,
                                        scale = scaleFactor,
                                        street = currentTurnInfo.street,
                                        direction = currentTurnInfo.direction,
                                        curveLevel = currentTurnInfo.curveLevel,
                                        style = ARCategoryStates.adres.style,
                                        color = ARCategoryStates.adres.color
                                    }
                                end
                            end
                        end
                    end
                else
                    DeleteAnchorEntity("turnSign")
                end

                -- Waypoint marker
                local drawDist = FRKN.DrawDistance * 50
                if distToTarget < drawDist and ARCategoryStates.metre.show then
                    local offset = GetAnchorPropValue("WaypointZOffset", FRKN.MarkerZOffset or 2.5)
                    local waypointPos = vector3(routeTargetCoords.x, routeTargetCoords.y, routeTargetCoords.z + offset)
                    local updatedWaypoint = UpdateAnchorEntity("waypoint", waypointPos, true)

                    local useNative = (FRKN.NativeWorldWaypoint ~= false)
                    local onScreen, screenX, screenY = true, 0.5, 0.5
                    local edgeIndicator = false

                    if EdgeIndicatorEnabled or not useNative then
                        onScreen, screenX, screenY = World3dToScreen2d(updatedWaypoint.x, updatedWaypoint.y, updatedWaypoint.z)
                        edgeIndicator = not onScreen
                    end

                    local camDist = #(GetCamPos() - updatedWaypoint)
                    local distFactor = math.sqrt(math.max(camDist, 1.0))
                    local scale = 18.0 / distFactor
                    scale = math.min(1.0, math.max(0.48, scale))

                    local distText = FormatDistance(currentDistance)
                    local categoryScale = GetCategoryScaled("metre", 1.0)

                    if useNative and not edgeIndicator then
                        DrawWaypointDui(updatedWaypoint, distText, currentEtaText,
                            ARCategoryStates.metre.color,
                            categoryScale * scale,
                            ARCategoryStates.metre.style)
                        hasWorldContent = true
                    else
                        hasNuiContent = true
                        if canSendNui then
                            local data = GetNuiData()
                            local edgeAngle = 0.0
                            if edgeIndicator then
                                local camRot = GetGameplayCamRot(2)
                                local camHeading = camRot.z
                                local dx = updatedWaypoint.x - GetCamPos().x
                                local dy = updatedWaypoint.y - GetCamPos().y
                                local heading = GetHeadingFromVector_2d(dx, dy)
                                local diff = NormalizeAngle(heading - camHeading)
                                edgeAngle = -diff

                                local rad = math.rad(-diff)
                                local sinA = math.sin(rad)
                                local cosA = -math.cos(rad)
                                local hw = 0.42
                                local hh = 0.39
                                local absSin = math.abs(sinA)
                                local absCos = math.abs(cosA)

                                if absSin < 0.001 and absCos < 0.001 then
                                    screenX = 0.5
                                    screenY = 0.11
                                else
                                    local ratioX = absSin / hw
                                    local ratioY = absCos / hh
                                    if ratioX > ratioY then
                                        screenX = 0.5 + hw * (sinA >= 0 and 1.0 or -1.0)
                                        screenY = 0.5 + (cosA / math.max(absSin, 0.001)) * hw
                                    else
                                        screenY = 0.5 + hh * (cosA >= 0 and 1.0 or -1.0)
                                        screenX = 0.5 + (sinA / math.max(absCos, 0.001)) * hh
                                    end
                                end
                                screenX = math.max(0.08, math.min(0.92, screenX))
                                screenY = math.max(0.1, math.min(0.9, screenY))
                            end

                            data.waypoint = {
                                onScreen = true,
                                edge = edgeIndicator,
                                x = screenX,
                                y = screenY,
                                scale = (not edgeIndicator and categoryScale * scale) or categoryScale,
                                edgeAngle = edgeAngle,
                                distance = distText,
                                eta = currentEtaText,
                                opacity = 1.0,
                                style = ARCategoryStates.metre.style,
                                color = ARCategoryStates.metre.color
                            }
                        end
                    end
                else
                    DeleteAnchorEntity("waypoint")
                end

                -- Update compass direction if close to turn
                if currentTurnInfo and canSendNui and nuiData then
                    local distToTurn = #(pedPos - currentTurnInfo.pos)
                    if distToTurn < 150.0 then
                        nuiData.hudNav.direction = currentTurnInfo.direction
                    end
                end

                -- Send NUI update if we have content and can send
                if canSendNui then
                    local data = GetNuiData()
                    if HasNuiContent(data) then
                        SendNUIMessage(data)
                        lastNuiUpdateTime = now
                        arKnownVisible = true
                    else
                        if arKnownVisible ~= false then
                            HideAR(true)
                        else
                            lastNuiUpdateTime = now
                        end
                    end
                end

                -- Determine wait
                if hasWorldContent then
                    renderIdle = 0
                elseif hasNuiContent or canSendNui then
                    renderIdle = math.min(GetTickRate("NuiUpdate", 100), 100)
                else
                    renderIdle = GetTickRate("RenderIdle", 250)
                end
            end
        else
            HideAR(false)
            renderIdle = GetTickRate("SystemDisabled", 1000)
        end

        Citizen.Wait(renderIdle)
    end
end)

-- ----------------------------------------------------------------------------
-- NUI Update Data Builder (FIXED COMPASS ANGLE)
-- ----------------------------------------------------------------------------
function BuildNuiUpdateData(playerPos, vehicle)
    local showCompass = ShowCompass and ARCategoryStates.ok.show
    local angle = 0.0

    if showCompass then
        local headingToTarget = GetHeadingBetweenPoints(playerPos, routeTargetCoords)
        local camHeading = GetGameplayCamRot(2).z

        -- Original logic from obfuscated script:
        -- 1. Negate the heading-to-target
        -- 2. Smooth interpolate the negated value (using global compassAngle)
        -- 3. Final angle = -(smoothed_neg - camHeading) = camHeading - smoothed_neg
        -- Since smoothed_neg ≈ -headingToTarget, final ≈ camHeading + headingToTarget
        local targetNeg = -headingToTarget
        compassAngle = LerpAngle(compassAngle, targetNeg, 0.24)
        angle = -(compassAngle - camHeading)
    end

    return {
        type = "UPDATE_AR",
        visible = true,
        waypoint = nil,
        turn = currentTurnInfo,
        markers = {},
        color = CurrentColor,
        hudNav = {
            visible = showCompass,
            compassAngle = angle,
            direction = "straight",
            style = ARCategoryStates.ok.style,
            color = ARCategoryStates.ok.color
        }
    }
end

function HasNuiContent(data)
    return data.waypoint or data.turnSign or (data.hudNav and data.hudNav.visible)
end

-- ----------------------------------------------------------------------------
-- Config Init
-- ----------------------------------------------------------------------------
Citizen.CreateThread(function()
    Citizen.Wait(1000)
    SendConfigDefaults()
end)

-- ----------------------------------------------------------------------------
-- Command to Open Settings Menu
-- ----------------------------------------------------------------------------
RegisterCommand(FRKN.MenuCommand, function()
    SetNuiFocus(true, true)
    menuOpen = true

    local hours = GetClockHours()
    local minutes = GetClockMinutes()
    local weather = GetPrevWeatherTypeHashName()
    local ampm = "AM"
    if hours >= 12 then
        ampm = "PM"
        if hours > 12 then hours = hours - 12 end
    end
    if hours == 0 then hours = 12 end

    local timeStr = string.format("%d:%02d %s", hours, minutes, ampm)

    SendNUIMessage({
        type = "SET_LOCALES",
        locales = Locales[FRKN.Locale] or Locales.en
    })

    SendConfigDefaults()

    SendNUIMessage({
        type = "OPEN_SETTINGS_MENU",
        timeText = timeStr,
        weatherId = weather,
        isNight = GetClockHours() > 19
    })
end, false)

-- ----------------------------------------------------------------------------
-- NUI Callbacks
-- ----------------------------------------------------------------------------
RegisterNUICallback("closeMenu", function(_, cb)
    SetNuiFocus(false, false)
    menuOpen = false
    if cb then cb("ok") end
end)

RegisterNUICallback("resetDefaults", function(_, cb)
    RefreshGlobalState()
    SendConfigDefaults()
    if cb then cb("ok") end
end)

RegisterNUICallback("toggleGlobal", function(data, cb)
    ARGlobalState = data.state
    for _, state in pairs(ARCategoryStates) do
        state.show = ARGlobalState
    end
    ShowAddressBar = ARGlobalState
    ShowCompass = ARGlobalState
    if cb then cb("ok") end
end)

RegisterNUICallback("toggleEdgeIndicator", function(data, cb)
    EdgeIndicatorEnabled = (data.state == true)
    if cb then cb("ok") end
end)

RegisterNUICallback("toggleCategory", function(data, cb)
    local cat = data.category
    local state = data.state
    if ARCategoryStates[cat] then
        ARCategoryStates[cat].show = state
    end
    if cat == "adres" then ShowAddressBar = state end
    if cat == "ok" then ShowCompass = state end
    if cb then cb("ok") end
end)

RegisterNUICallback("setGlobalColor", function(data, cb)
    if data.r and data.g and data.b then
        CurrentColor = { r = data.r, g = data.g, b = data.b }
        for _, state in pairs(ARCategoryStates) do
            state.color = { r = data.r, g = data.g, b = data.b }
        end
    end
    if cb then cb("ok") end
end)

RegisterNUICallback("setCategoryColor", function(data, cb)
    local cat = data.category
    if ARCategoryStates[cat] and data.r and data.g and data.b then
        ARCategoryStates[cat].color = { r = data.r, g = data.g, b = data.b }
    end
    if cb then cb("ok") end
end)

RegisterNUICallback("setCategoryStyle", function(data, cb)
    local cat = data.category
    if ARCategoryStates[cat] then
        ARCategoryStates[cat].style = data.style
    end
    if cb then cb("ok") end
end)

RegisterNUICallback("setCategoryScale", function(data, cb)
    local cat = data.category
    local scale = tonumber(data.scale) or 1.0
    if scale < 0.5 then scale = 0.5 elseif scale > 1.5 then scale = 1.5 end
    if ARCategoryStates[cat] then
        ARCategoryStates[cat].scale = scale
    end
    if cb then cb("ok") end
end)

-- ----------------------------------------------------------------------------
-- Exported Functions (for other resources)
-- ----------------------------------------------------------------------------
exports("CreateRoute", function(id, coords)
    if type(id) ~= "string" or not coords or not coords.x or not coords.y or not coords.z then
        return false
    end

    local groundZ = GetGroundZWithCache(coords.x, coords.y, coords.z)
    local target = vector3(coords.x, coords.y, groundZ)
    customRoutes[id] = target

    routeTargetCoords = target
    routeActive = true
    isTurning = false
    currentTurnInfo = nil
    turnMarkers = {}
    DeleteAnchorEntity("turnSign")
    lastPosition = vector3(0, 0, 0)

    local blip = AddBlipForCoord(coords.x, coords.y, groundZ)
    SetBlipRoute(blip, true)
    SetBlipRouteColour(blip, 18)
    customRoutes[id .. "_blip"] = blip

    return true
end)

exports("DeleteRoute", function(id)
    if type(id) ~= "string" then return false end

    local target = customRoutes[id]
    if not target then return false end

    local blipKey = id .. "_blip"
    local blip = customRoutes[blipKey]
    if blip and DoesBlipExist(blip) then
        SetBlipRoute(blip, false)
        RemoveBlip(blip)
    end

    customRoutes[id] = nil
    customRoutes[blipKey] = nil

    routeActive = false
    routeTargetCoords = nil
    isTurning = false
    currentTurnInfo = nil
    turnMarkers = {}
    routeNodes = {}
    DeleteAllAnchors()
    SendNUIMessage({ type = "UPDATE_AR", visible = false })

    return true
end)

exports("PurgeRoutes", function()
    for key, val in pairs(customRoutes) do
        if type(val) ~= "vector3" then
            if DoesBlipExist(val) then
                SetBlipRoute(val, false)
                RemoveBlip(val)
            end
        end
    end

    customRoutes = {}
    routeActive = false
    routeTargetCoords = nil
    isTurning = false
    currentTurnInfo = nil
    turnMarkers = {}
    routeNodes = {}
    DeleteAllAnchors()
    SendNUIMessage({ type = "UPDATE_AR", visible = false })

    return true
end)

-- ----------------------------------------------------------------------------
-- Resource Stop Cleanup
-- ----------------------------------------------------------------------------
AddEventHandler("onResourceStop", function(resourceName)
    if resourceName == GetCurrentResourceName() then
        DeleteAllAnchors()
        DestroyWaypointDui()
        DestroyTurnSignDui()
    end
end)