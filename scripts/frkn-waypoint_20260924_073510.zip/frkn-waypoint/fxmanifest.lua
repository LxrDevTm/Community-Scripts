fx_version 'cerulean'
game 'gta5'


version 'v1.0.1'

escrow_ignore {
	'shared/*.lua',
}

ui_page 'html/index.html'

files {
    'html/index.html',
    'html/waypoint_dui.html',
    'html/turnsign_dui.html',
    'html/style.css',
    'html/script.js',
    'html/three.min.js',
}

client_scripts {
    'client/client.lua'
}

shared_scripts {
    "shared/config.lua",
    "shared/locale.lua"
}

dependency '/assetpacks'