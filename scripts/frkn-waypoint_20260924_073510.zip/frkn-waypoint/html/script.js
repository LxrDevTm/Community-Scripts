const getResName = () => (typeof GetParentResourceName !== 'undefined') ? GetParentResourceName() : 'frkn-waypoint';
let chevronScene, chevronCamera, chevronRenderer, chevronGroup;
let chevronMesh, chevronEdges, chevronGlowMesh;
let chevronActive = true;
let chevronTargetRotZ = 0;
let chevronCurrentRotZ = 0;
let chevronColor = { r: 0, g: 180, b: 255 };
function initChevron3D() {
    const canvas = $('#hud-arrow-underground')[0];
    if (!canvas || typeof THREE === 'undefined') return;
    chevronScene = new THREE.Scene();
    chevronCamera = new THREE.PerspectiveCamera(30, 1, 0.1, 100);
    chevronCamera.position.set(0, 7.2, 0.0);
    chevronCamera.lookAt(0, 0, 0);
    chevronRenderer = new THREE.WebGLRenderer({ canvas: canvas, alpha: true, antialias: true });
    chevronRenderer.setSize(170, 170);
    chevronRenderer.setPixelRatio(2);
    chevronScene.add(new THREE.AmbientLight(0x4466aa, 0.6));
    const keyLight = new THREE.DirectionalLight(0xffffff, 1.3);
    keyLight.position.set(0, 5, 3);
    chevronScene.add(keyLight);
    const fillLight = new THREE.DirectionalLight(0x0088ff, 0.5);
    fillLight.position.set(-3, 1, -1);
    chevronScene.add(fillLight);
    const rimLight = new THREE.DirectionalLight(0x00ccff, 0.7);
    rimLight.position.set(0, -2, 2);
    chevronScene.add(rimLight);
    const backLight = new THREE.DirectionalLight(0x0044aa, 0.3);
    backLight.position.set(0, 2, -3);
    chevronScene.add(backLight);
    const shape = new THREE.Shape();
    shape.moveTo(-0.45, 1.3);
    shape.lineTo(0.45, 1.3);
    shape.lineTo(0.45, 0.1);
    shape.lineTo(1.25, 0.25);
    shape.lineTo(0.0, -1.1);
    shape.lineTo(-1.25, 0.25);
    shape.lineTo(-0.45, 0.1);
    shape.lineTo(-0.45, 1.3);
    const extrudeSettings = {
        steps: 1,
        depth: 0.5,
        bevelEnabled: true,
        bevelThickness: 0.07,
        bevelSize: 0.07,
        bevelSegments: 4
    };
    const geometry = new THREE.ExtrudeGeometry(shape, extrudeSettings);
    geometry.center();
    const material = new THREE.MeshPhongMaterial({
        color: new THREE.Color(chevronColor.r / 255, chevronColor.g / 255, chevronColor.b / 255),
        emissive: new THREE.Color(chevronColor.r / 255 * 0.15, chevronColor.g / 255 * 0.15, chevronColor.b / 255 * 0.15),
        shininess: 120,
        specular: new THREE.Color(0x66ddff),
        transparent: true,
        opacity: 0.95
    });
    chevronMesh = new THREE.Mesh(geometry, material);
    const edgesGeo = new THREE.EdgesGeometry(geometry, 15);
    const edgesMat = new THREE.LineBasicMaterial({ color: 0x00ddff, linewidth: 1, transparent: true, opacity: 0.9 });
    chevronEdges = new THREE.LineSegments(edgesGeo, edgesMat);
    chevronGroup = new THREE.Group();
    chevronGroup.add(chevronMesh);
    chevronGroup.add(chevronEdges);
    chevronScene.add(chevronGroup);
    animateChevron();
}
function scheduleChevronFrame(delay = 0) {
    if (delay > 0) setTimeout(() => requestAnimationFrame(animateChevron), delay);
    else requestAnimationFrame(animateChevron);
}
function animateChevron() {
    if (!chevronGroup || !chevronRenderer) return;
    const canvas = $('#hud-arrow-underground')[0];
    if (!canvas || canvas.style.display === 'none' || canvas.offsetParent === null) {
        scheduleChevronFrame(250);
        return;
    }
    const t = performance.now() * 0.001;
    chevronGroup.position.y = Math.sin(t * 1.8) * 0.035;
    let diff = chevronTargetRotZ - chevronCurrentRotZ;
    while (diff > Math.PI) diff -= 2 * Math.PI;
    while (diff < -Math.PI) diff += 2 * Math.PI;
    chevronCurrentRotZ += diff * 0.05;
    chevronGroup.rotation.z = chevronCurrentRotZ;
    chevronGroup.rotation.x = -0.55;
    chevronRenderer.render(chevronScene, chevronCamera);
    scheduleChevronFrame();
}
function updateChevronPerspective() {
    if (!chevronCamera) return;
    const hudNav = $('#hud-navigation')[0];
    if (!hudNav) return;
    const rect = hudNav.getBoundingClientRect();
    const isBottom = (rect.top + rect.height / 2) > (window.innerHeight / 2);
    if (isBottom) {
        chevronCamera.position.set(0, 7.2, -1.0);
    } else {
        chevronCamera.position.set(0, 7.2, 0.0);
    }
    chevronCamera.lookAt(0, 0, 0);
    chevronCamera.updateProjectionMatrix();
}
function updateChevronColor(r, g, b) {
    chevronColor = { r, g, b };
    if (!chevronMesh || !chevronEdges) return;
    const cR = r / 255;
    const cG = g / 255;
    const cB = b / 255;
    chevronMesh.material.color.setRGB(cR, cG, cB);
    chevronMesh.material.emissive.setRGB(cR * 0.15, cG * 0.15, cB * 0.15);
    chevronMesh.material.specular.setRGB(Math.min(1.0, cR + 0.3), Math.min(1.0, cG + 0.3), Math.min(1.0, cB + 0.3));
    chevronEdges.material.color.setRGB(Math.min(1.0, cR * 1.5), Math.min(1.0, cG * 1.5), Math.min(1.0, cB * 1.5));
}
function updateChevronRotation(angleDeg) {
    chevronTargetRotZ = angleDeg * Math.PI / 180;
}

let ConfigDefaults = null;
let ConfigDefaultsApplied = false;
const CATEGORY_PREVIEW_BASE_SCALE = {
    adres: 0.7,
    metre: 0.8,
    marker: 1.3,
    ok: 1.2
};
const CATEGORY_PREVIEW_IDS = {
    adres: 'preview-adres-wrapper',
    metre: 'preview-metre-wrapper',
    marker: 'preview-marker-wrapper',
    ok: 'preview-ok-wrapper'
};

function normalizeColor(color, fallback = { r: 0, g: 180, b: 255 }) {
    color = color || {};
    return {
        r: parseInt(color.r ?? fallback.r, 10),
        g: parseInt(color.g ?? fallback.g, 10),
        b: parseInt(color.b ?? fallback.b, 10)
    };
}

function rgbToHex(color) {
    const c = normalizeColor(color);
    return '#' + [c.r, c.g, c.b].map(v => Math.max(0, Math.min(255, v)).toString(16).padStart(2, '0')).join('');
}

function getDefaultCompassScale() {
    return parseFloat(ConfigDefaults?.compassScale) || 0.75;
}

function setToggleVisual(target, enabled) {
    const id = target === 'global' ? 'toggle-global' : `toggle-${target}`;
    const toggle = document.getElementById(id);
    if (toggle) toggle.classList.toggle('active', !!enabled);
}

function setEdgeIndicatorVisual(enabled) {
    const toggle = document.getElementById('toggle-edge-indicator');
    if (toggle) toggle.classList.toggle('active', !!enabled);
}

function setStyleVisual(category, style) {
    const group = document.querySelector(`.style-pill-group[data-category="${category}"]`);
    if (!group) return;
    group.querySelectorAll('.style-btn').forEach(btn => btn.classList.remove('active'));
    const selected = group.querySelector(`.style-btn[data-style="${style}"]`) || group.querySelector('.style-btn');
    if (selected) selected.classList.add('active');
    if (window.updatePreviewStyleExt) window.updatePreviewStyleExt(category, style);
}

function clampScale(scale) {
    const value = parseFloat(scale);
    if (!Number.isFinite(value)) return 1;
    return Math.max(0.5, Math.min(1.5, value));
}

function applyPreviewScale(category, scale) {
    const preview = document.getElementById(CATEGORY_PREVIEW_IDS[category]);
    if (!preview) return;
    const base = CATEGORY_PREVIEW_BASE_SCALE[category] || 1;
    preview.style.transform = `scale(${(base * clampScale(scale)).toFixed(3)})`;
}

function setScaleVisual(category, scale) {
    const normalized = clampScale(scale);
    const input = document.querySelector(`.size-range[data-category="${category}"]`);
    const value = document.querySelector(`.range-value[data-scale-value="${category}"]`);
    if (input) input.value = normalized.toString();
    if (value) value.textContent = `${Math.round(normalized * 100)}%`;
    applyPreviewScale(category, normalized);
}

function applyColorVisual(category, color) {
    const c = normalizeColor(color);
    const grid = category === 'global'
        ? document.querySelector('.global-colors')
        : document.querySelector(`.sidebar-color-grid[data-category="${category}"]`);

    if (grid) {
        grid.querySelectorAll('.color-swatch, .color-picker-input').forEach(el => el.classList.remove('selected'));
        const swatch = grid.querySelector(`.color-swatch[data-r="${c.r}"][data-g="${c.g}"][data-b="${c.b}"]`);
        if (swatch) {
            swatch.classList.add('selected');
        } else {
            const picker = grid.querySelector('.color-picker-input');
            if (picker) {
                picker.value = rgbToHex(c);
                picker.classList.add('selected');
            }
        }
    }

    const rgb = `rgb(${c.r}, ${c.g}, ${c.b})`;
    const readable = ((c.r * 0.299 + c.g * 0.587 + c.b * 0.114) < 130) ? 'white' : '#111';

    if (category === 'global') {
        document.documentElement.style.setProperty('--ar-stroke-color', rgb);
        document.documentElement.style.setProperty('--ar-fill-color', rgb);
        document.documentElement.style.setProperty('--ar-bg-color', `rgba(${c.r}, ${c.g}, ${c.b}, 0.9)`);
        document.documentElement.style.setProperty('--sidebar-accent', rgb);
        updateChevronColor(c.r, c.g, c.b);
        return;
    }

    const previewIds = {
        adres: 'preview-adres-wrapper',
        metre: 'preview-metre-wrapper',
        marker: 'preview-marker-wrapper',
        ok: 'preview-ok-visual'
    };
    const preview = document.getElementById(previewIds[category]);
    if (preview) {
        preview.style.setProperty('--cat-color', rgb);
        preview.style.setProperty('--theme-color', rgb);
        preview.style.setProperty('--icon-col', readable);
    }
    if (category === 'ok') {
        document.documentElement.style.setProperty('--compass-color', rgb);
        updateChevronColor(c.r, c.g, c.b);
    }
}

function applyConfigDefaults(force = false) {
    if (!ConfigDefaults) return;
    const settingsMenu = document.getElementById('settings-menu');
    if (!settingsMenu) {
        setTimeout(() => applyConfigDefaults(force), 50);
        return;
    }
    if (!force && ConfigDefaults.useSavedPreferences !== false && localStorage.getItem('frkn_waypoint_prefs')) {
        ConfigDefaultsApplied = true;
        return;
    }

    setToggleVisual('global', ConfigDefaults.global !== false);
    setEdgeIndicatorVisual(ConfigDefaults.edgeIndicator !== false);
    applyColorVisual('global', ConfigDefaults.globalColor);

    const cats = ConfigDefaults.categories || {};
    Object.keys(cats).forEach(cat => {
        const cfg = cats[cat] || {};
        setToggleVisual(cat, cfg.show !== false);
        setStyleVisual(cat, cfg.style || 1);
        setScaleVisual(cat, cfg.scale || 1);
        applyColorVisual(cat, cfg.color || ConfigDefaults.globalColor);
    });

    if (window.applyCompassDefaultScale) {
        window.applyCompassDefaultScale(getDefaultCompassScale(), force);
    }
    ConfigDefaultsApplied = true;
}

function resetToConfigDefaults() {
    localStorage.removeItem('frkn_waypoint_prefs');
    localStorage.removeItem('frkn_waypoint_prefs_picker');
    applyConfigDefaults(true);
    $.post(`https://${getResName()}/resetDefaults`, JSON.stringify({}));
}

$(function () {
    window.saveAllSettings = function() {
        let settings = { toggles: {}, colors: {}, styles: {}, scales: {}, edgeIndicator: true };
        $('.nui-toggle').get().forEach(t => {
            if (t.id === 'toggle-global') {
                settings.toggles.global = t.classList.contains('active');
            } else if (t.id === 'toggle-edge-indicator') {
                settings.edgeIndicator = t.classList.contains('active');
            } else if (t.dataset.target) {
                settings.toggles[t.dataset.target] = t.classList.contains('active');
            }
        });
        $('.style-pill-group').get().forEach(group => {
            let cat = group.dataset.category;
            let act = group.querySelector('.style-btn.active');
            if (cat && act) settings.styles[cat] = act.dataset.style;
        });
        $('.sidebar-color-grid').get().forEach(grid => {
            let cat = grid.dataset.category || 'global';
            let selSW = grid.querySelector('.color-swatch.selected');
            let selPK = grid.querySelector('.color-picker-input.selected');
            if (selSW) settings.colors[cat] = { type: 'swatch', r: selSW.dataset.r, g: selSW.dataset.g, b: selSW.dataset.b };
            else if (selPK) settings.colors[cat] = { type: 'picker', hex: selPK.value };
        });
        $('.size-range').get().forEach(range => {
            const cat = range.dataset.category;
            if (cat) settings.scales[cat] = clampScale(range.value);
        });
        localStorage.setItem('frkn_waypoint_prefs', JSON.stringify(settings));
    };

    const flushPendingSave = () => {
        if (window.saveTimer) {
            clearTimeout(window.saveTimer);
            window.saveTimer = null;
        }
        if (typeof window.saveAllSettings === 'function') window.saveAllSettings();
    };
    window.addEventListener('pagehide', flushPendingSave);
    window.addEventListener('beforeunload', flushPendingSave);

    initChevron3D();
    const settingsMenu = $('#settings-menu')[0];
    const appEl = $('#app')[0];
    function closeMenu() {
        settingsMenu.style.display = 'none';
        settingsMenu.classList.remove('slide-in-left');
        const hudNav = $('#hud-navigation')[0];
        if (hudNav) hudNav.classList.remove('draggable-mode');
        StateCache.appVis = null;
        StateCache.hnDis = null;
        $.post(`https://${getResName()}/closeMenu`, JSON.stringify({}));
    }
    const closeBtn = $('#close-menu-btn')[0];
    if (closeBtn) $(closeBtn).on('click', closeMenu);
    
    const factoryResetBtn = $('#factory-reset-btn')[0];
    const hudNav = $('#hud-navigation')[0];
    
    if (factoryResetBtn) {
        $(factoryResetBtn).on('click', () => {
            localStorage.removeItem('frkn_compass_pos');
            localStorage.removeItem('frkn_compass_scale');
            localStorage.removeItem('frkn_waypoint_prefs');
            localStorage.removeItem('frkn_waypoint_prefs_picker');

            currentCompassScale = getDefaultCompassScale();
            if (hudNav) {
                hudNav.style.transformOrigin = 'center';
                hudNav.style.transform = `translate(-50%, -50%) scale(${currentCompassScale})`;
                hudNav.style.left = '50%';
                hudNav.style.top = '3%';
            }
            if (typeof updateChevronPerspective === 'function') updateChevronPerspective();
            resetToConfigDefaults();
        });
    }

    const resizeHandle = $('#compass-resize-handle')[0];

    let isDraggingCompass = false;
    let compassDragOffset = { x: 0, y: 0 };

    let isResizingCompass = false;
    let resizeStartY = 0;
    let currentCompassScale = getDefaultCompassScale();
    let initialCompassScale = currentCompassScale;

    const savedScale = localStorage.getItem('frkn_compass_scale');
    if (savedScale) currentCompassScale = parseFloat(savedScale) || getDefaultCompassScale();

    window.applyCompassDefaultScale = function(scale, force = false) {
        if (!hudNav || (!force && localStorage.getItem('frkn_compass_scale'))) return;
        currentCompassScale = parseFloat(scale) || getDefaultCompassScale();
        hudNav.style.transformOrigin = 'center';
        hudNav.style.transform = `translate(-50%, -50%) scale(${currentCompassScale})`;
        if (typeof updateChevronPerspective === 'function') updateChevronPerspective();
    };

    window.applyCompassScaleFromCategory = function(scale, persist = false) {
        if (!hudNav) return;
        currentCompassScale = clampScale(scale);
        hudNav.style.transformOrigin = 'center';
        hudNav.style.transform = `translate(-50%, -50%) scale(${currentCompassScale})`;
        if (persist) localStorage.setItem('frkn_compass_scale', currentCompassScale.toString());
        if (typeof updateChevronPerspective === 'function') updateChevronPerspective();
    };

    const savedPos = localStorage.getItem('frkn_compass_pos');
    if (savedPos) {
        try {
            const pos = JSON.parse(savedPos);
            hudNav.style.transformOrigin = 'center';
            hudNav.style.transform = `translate(-50%, -50%) scale(${currentCompassScale})`;
            hudNav.style.left = pos.left;
            hudNav.style.top = pos.top;
            setTimeout(() => { updateChevronPerspective(); }, 50);
        } catch (e) { }
    } else {
        hudNav.style.transformOrigin = 'center';
        hudNav.style.transform = `translate(-50%, -50%) scale(${currentCompassScale})`;
        setTimeout(() => { updateChevronPerspective(); }, 50);
    }

    if (resizeHandle) {
        $(resizeHandle).on('mousedown', (e) => {
            if (!hudNav.classList.contains('draggable-mode')) return;
            e.stopPropagation();
            isResizingCompass = true;
            resizeStartY = e.clientY;
            initialCompassScale = currentCompassScale;
        });
    }

    $(hudNav).on('mousedown', (e) => {
        if (!hudNav.classList.contains('draggable-mode')) return;
        if (resizeHandle && (e.target === resizeHandle || resizeHandle.contains(e.target))) return;
        isDraggingCompass = true;

        let currentLeft = parseFloat(getComputedStyle(hudNav).left) || 0;
        let currentTop = parseFloat(getComputedStyle(hudNav).top) || 0;

        compassDragOffset.x = e.clientX - currentLeft;
        compassDragOffset.y = e.clientY - currentTop;
    });

    let compassRafId = null;
    let mouseEvData = { clientX: 0, clientY: 0 };

    $(window).on('mousemove', (e) => {
        if (!isResizingCompass && !isDraggingCompass) return;

        mouseEvData.clientX = e.clientX;
        mouseEvData.clientY = e.clientY;

        if (compassRafId === null) {
            compassRafId = requestAnimationFrame(() => {
                if (isResizingCompass) {
                    const deltaY = mouseEvData.clientY - resizeStartY;
                    currentCompassScale = Math.max(0.3, Math.min(3.0, initialCompassScale + (deltaY * 0.01)));
                    hudNav.style.transform = `translate(-50%, -50%) scale(${currentCompassScale})`;
                }

                if (isDraggingCompass) {
                    let targetX = mouseEvData.clientX - compassDragOffset.x;
                    let targetY = mouseEvData.clientY - compassDragOffset.y;
                    hudNav.style.left = targetX + 'px';
                    hudNav.style.top = targetY + 'px';
                    updateChevronPerspective();
                }
                compassRafId = null;
            });
        }
    });

    $(window).on('mouseup', () => {
        if (isResizingCompass) {
            isResizingCompass = false;
            localStorage.setItem('frkn_compass_scale', currentCompassScale.toString());
        }
        if (isDraggingCompass) {
            isDraggingCompass = false;
            localStorage.setItem('frkn_compass_pos', JSON.stringify({
                left: hudNav.style.left,
                top: hudNav.style.top
            }));
        }
    });
    const uiWrapper = document.querySelector('.ui-kit-wrapper');
    $('.nav-tab').get().forEach(tab => {
        $(tab).on('click', (e) => {
            let oldHeight = uiWrapper.offsetHeight;
            $('.nav-tab').get().forEach(t => t.classList.remove('active'));
            $('.tab-pane').get().forEach(p => p.classList.remove('active'));
            e.currentTarget.classList.add('active');
            let t = e.currentTarget.dataset.tab;
            document.getElementById('tab-' + t).classList.add('active');
            uiWrapper.style.height = 'auto';
            let newHeight = uiWrapper.offsetHeight;
            uiWrapper.style.height = oldHeight + 'px';
            uiWrapper.style.transition = 'none';
            void uiWrapper.offsetHeight;
            uiWrapper.style.transition = 'height 0.35s cubic-bezier(0.25, 1, 0.5, 1)';
            uiWrapper.style.height = newHeight + 'px';
            if (uiWrapper.resizeTimeout) clearTimeout(uiWrapper.resizeTimeout);
            uiWrapper.resizeTimeout = setTimeout(() => {
                uiWrapper.style.height = 'auto';
                uiWrapper.style.transition = 'none';
            }, 350);
            let selectedSwatch = document.querySelector(`.sidebar-color-grid[data-category="${t}"] .cat-swatch.selected`);
            if (selectedSwatch) {
                let r = selectedSwatch.dataset.r;
                let g = selectedSwatch.dataset.g;
                let b = selectedSwatch.dataset.b;
                document.documentElement.style.setProperty('--sidebar-accent', `rgb(${r}, ${g}, ${b})`);
            } else if (t === 'genel') {
                let globalSwatch = document.querySelector('.global-colors .global-swatch.selected');
                if (globalSwatch) {
                    let r = globalSwatch.dataset.r;
                    let g = globalSwatch.dataset.g;
                    let b = globalSwatch.dataset.b;
                    document.documentElement.style.setProperty('--sidebar-accent', `rgb(${r}, ${g}, ${b})`);
                }
            }
            const activeStyleBtn = document.querySelector(`.style-options[data-category="${t}"] .style-btn.active`);
            if (activeStyleBtn && window.updatePreviewStyleExt) {
                window.updatePreviewStyleExt(t, activeStyleBtn.dataset.style);
            }
        });
    });
    $('.global-swatch').get().forEach(swatch => {
        $(swatch).on('click', (e) => {
            let r = parseInt(e.currentTarget.dataset.r);
            let g = parseInt(e.currentTarget.dataset.g);
            let b = parseInt(e.currentTarget.dataset.b);
            $('.global-swatch, .global-picker').get().forEach(s => s.classList.remove('selected'));
            e.currentTarget.classList.add('selected');
            $('.cat-swatch').get().forEach(s => {
                s.classList.remove('selected');
                if (s.dataset.r == r && s.dataset.g == g && s.dataset.b == b) s.classList.add('selected');
            });
            $.post(`https://${getResName()}/setGlobalColor`, JSON.stringify({ r: r, g: g, b: b }));
            document.documentElement.style.setProperty('--ar-stroke-color', `rgb(${r}, ${g}, ${b})`);
            document.documentElement.style.setProperty('--ar-fill-color', `rgb(${r}, ${g}, ${b})`);
            document.documentElement.style.setProperty('--ar-bg-color', `rgba(${r}, ${g}, ${b}, 0.9)`);
            document.documentElement.style.setProperty('--sidebar-accent', `rgb(${r}, ${g}, ${b})`);
            updateChevronColor(r, g, b);
            window.saveAllSettings();
        });
    });
    $('.size-range').get().forEach(range => {
        $(range).on('input', (e) => {
            const cat = e.currentTarget.dataset.category;
            const scale = clampScale(e.currentTarget.value);
            setScaleVisual(cat, scale);
            if (cat === 'ok' && typeof window.applyCompassScaleFromCategory === 'function') {
                window.applyCompassScaleFromCategory(scale, true);
            }
            $.post(`https://${getResName()}/setCategoryScale`, JSON.stringify({ category: cat, scale: scale }));
            if (window.saveTimer) clearTimeout(window.saveTimer);
            window.saveTimer = setTimeout(window.saveAllSettings, 120);
        });
    });
    $('.cat-swatch').get().forEach(swatch => {
        $(swatch).on('click', (e) => {
            let r = parseInt(e.currentTarget.dataset.r);
            let g = parseInt(e.currentTarget.dataset.g);
            let b = parseInt(e.currentTarget.dataset.b);
            let cat = e.currentTarget.parentElement.dataset.category;
            document.documentElement.style.setProperty('--sidebar-accent', `rgb(${r}, ${g}, ${b})`);
            if (cat === 'adres') {
                const el = $('#preview-adres-wrapper')[0];
                if (el) { el.style.setProperty('--cat-color', `rgb(${r}, ${g}, ${b})`); el.style.setProperty('--icon-col', ((r * 0.299 + g * 0.587 + b * 0.114) < 130) ? 'white' : '#111'); }
            }
            if (cat === 'metre') {
                const el = $('#preview-metre-wrapper')[0];
                if (el) { el.style.setProperty('--cat-color', `rgb(${r}, ${g}, ${b})`); el.style.setProperty('--icon-col', ((r * 0.299 + g * 0.587 + b * 0.114) < 130) ? 'white' : '#111'); }
            }
            if (cat === 'marker') {
                const el = $('#preview-marker-wrapper')[0];
                if (el) { el.style.setProperty('--cat-color', `rgb(${r}, ${g}, ${b})`); el.style.setProperty('--icon-col', ((r * 0.299 + g * 0.587 + b * 0.114) < 130) ? 'white' : '#111'); }
            }
            if (cat === 'ok') {
                const visualWrapper = $('#preview-ok-visual')[0];
                if (visualWrapper) visualWrapper.style.setProperty('--cat-color', `rgb(${r}, ${g}, ${b})`);
                const grad = $('#arrowGrad')[0];
                const edge = $('#arrowEdge')[0];
                const glows = $('#nfs-hud-arrow .arrow-glow-outer path, #preview-ok-visual .arrow-glow-outer path');
                if (grad) {
                    grad.children[1].setAttribute('stop-color', `rgb(${r}, ${g}, ${b})`);
                    grad.children[2].setAttribute('stop-color', `rgb(${Math.max(0, r - 50)}, ${Math.max(0, g - 50)}, ${Math.max(0, b - 50)})`);
                }
                if (edge) edge.children[1].setAttribute('stop-color', `rgb(${r}, ${g}, ${b})`);
                glows.get().forEach(glow => {
                    glow.setAttribute('stroke', `rgba(${r}, ${g}, ${b}, 0.5)`);
                });
                if (window.miniPreviewMesh) {
                    window.miniPreviewMesh.material.color.setRGB(r / 255, g / 255, b / 255);
                    window.miniPreviewMesh.material.emissive.setRGB(r / 255 * 0.15, g / 255 * 0.15, b / 255 * 0.15);
                }
                if (window.miniEdgesMesh) {
                    window.miniEdgesMesh.material.color.setRGB(Math.min(1.0, r / 255 * 1.5), Math.min(1.0, g / 255 * 1.5), Math.min(1.0, b / 255 * 1.5));
                }
            }
            $(`.sidebar-color-grid[data-category="${cat}"] .cat-swatch, .sidebar-color-grid[data-category="${cat}"] .color-picker-input`).get().forEach(s => {
                s.classList.remove('selected');
            });
            e.currentTarget.classList.add('selected');
            $.post(`https://${getResName()}/setCategoryColor`, JSON.stringify({ category: cat, r: r, g: g, b: b }));
            if (cat === 'ok') {
                updateChevronColor(r, g, b);
                document.documentElement.style.setProperty('--compass-color', `rgb(${r}, ${g}, ${b})`);
            }
            window.saveAllSettings();
        });
    });
    $('.style-btn').get().forEach(btn => {
        $(btn).on('click', (e) => {
            let cat = e.currentTarget.parentElement.dataset.category;
            let styleId = e.currentTarget.dataset.style;
            $(`.style-options[data-category="${cat}"] .style-btn`).get().forEach(b => {
                b.classList.remove('active');
            });
            e.currentTarget.classList.add('active');
            if (window.updatePreviewStyleExt) {
                window.updatePreviewStyleExt(cat, styleId);
            }
            if (cat === 'ok') {
                if (styleId === "1") {
                    $('#nfs-hud-arrow')[0].style.display = 'none';
                    $('#hud-arrow-underground')[0].style.display = 'block';
                    chevronActive = true;
                    if (!chevronScene) initChevron3D();
                } else {
                    $('#nfs-hud-arrow')[0].style.display = 'block';
                    $('#hud-arrow-underground')[0].style.display = 'none';
                    chevronActive = false;
                }
            }
            if (cat === 'metre') {
                const wpCard = $('#waypoint-card')[0];
                const mThemes = { '1': 'theme-default', '2': 'theme-minimal', '3': 'theme-icon' };
                if (wpCard) {
                    wpCard.className = `ar-card pin-card ${mThemes[styleId] || 'theme-default'}`;
                }
            }
            $.post(`https://${getResName()}/setCategoryStyle`, JSON.stringify({ category: cat, style: parseInt(styleId) }));
            window.saveAllSettings();
        });
    });

    $('.pill-btn.arrow').on('click', function(e) {
        if (this.classList.contains('disabled')) return;
        let isNext = this.classList.contains('next');
        let group = $(this).closest('.style-pill-group');
        let btns = group.find('.style-btn');
        if (btns.length === 0) return;
        let activeIndex = btns.index(group.find('.style-btn.active'));
        let newIndex = isNext ? activeIndex + 1 : activeIndex - 1;
        if (newIndex >= btns.length) newIndex = 0;
        if (newIndex < 0) newIndex = btns.length - 1;
        btns.eq(newIndex).click();
    });
    $('.nui-toggle').get().forEach(toggle => {
        $(toggle).on('click', (e) => {
            toggle.classList.toggle('active');
            let isActive = toggle.classList.contains('active');
            let id = toggle.id;
            if (id === 'toggle-global') {
                $.post(`https://${getResName()}/toggleGlobal`, JSON.stringify({ state: isActive }));
                $('.nui-toggle').get().forEach(t => {
                    if (t.id === 'toggle-edge-indicator') return;
                    if (isActive) t.classList.add('active');
                    else t.classList.remove('active');
                });
            } else if (id === 'toggle-edge-indicator') {
                $.post(`https://${getResName()}/toggleEdgeIndicator`, JSON.stringify({ state: isActive }));
            } else {
                let cat = toggle.dataset.target;
                $.post(`https://${getResName()}/toggleCategory`, JSON.stringify({ category: cat, state: isActive }));
            }
            window.saveAllSettings();
        });
    });
    $(document).on('keydown', (e) => {
        if (e.key === "Escape" || e.key === "Esc" || e.keyCode === 27) {
            if (settingsMenu.style.display !== 'none') {
                closeMenu();
            }
        }
    });
    
    initMiniPreview();

    function loadAllSettings() {
        if (!ConfigDefaults) {
            setTimeout(loadAllSettings, 100);
            return;
        }
        if (ConfigDefaults && ConfigDefaults.useSavedPreferences === false) {
            applyConfigDefaults(false);
            return;
        }
        let saved = localStorage.getItem('frkn_waypoint_prefs');
        if (!saved) {
            applyConfigDefaults(false);
            return;
        }
        try {
            let s = JSON.parse(saved);
            if (typeof s.edgeIndicator === 'boolean') {
                const edgeToggle = document.getElementById('toggle-edge-indicator');
                if (edgeToggle) {
                    if (s.edgeIndicator && !edgeToggle.classList.contains('active')) edgeToggle.click();
                    else if (!s.edgeIndicator && edgeToggle.classList.contains('active')) edgeToggle.click();
                }
            } else {
                setEdgeIndicatorVisual(ConfigDefaults.edgeIndicator !== false);
                $.post(`https://${getResName()}/toggleEdgeIndicator`, JSON.stringify({ state: ConfigDefaults.edgeIndicator !== false }));
            }
            if (s.toggles) {
                $('.nui-toggle').get().forEach(t => {
                    let tgt = t.id === 'toggle-global' ? 'global' : t.dataset.target;
                    if (!tgt) return;
                    if (s.toggles[tgt] !== undefined) {
                        if (s.toggles[tgt] && !t.classList.contains('active')) t.click();
                        else if (!s.toggles[tgt] && t.classList.contains('active')) t.click();
                    }
                });
            }
            if (s.styles) {
                Object.keys(s.styles).forEach(cat => {
                    let group = document.querySelector(`.style-pill-group[data-category="${cat}"]`);
                    if (group) {
                        let btn = group.querySelector(`.style-btn[data-style="${s.styles[cat]}"]`);
                        if (btn && !btn.classList.contains('active')) btn.click();
                    }
                });
            }
            if (s.colors) {
                Object.keys(s.colors).forEach(cat => {
                    let cd = s.colors[cat];
                    let grid = cat === 'global' ? document.querySelector('.global-colors') : document.querySelector(`.sidebar-color-grid[data-category="${cat}"]`);
                    if (grid) {
                        if (cd.type === 'swatch') {
                            let sw = grid.querySelector(`.color-swatch[data-r="${cd.r}"][data-g="${cd.g}"][data-b="${cd.b}"]`);
                            if (sw && !sw.classList.contains('selected')) sw.click();
                        } else if (cd.type === 'picker') {
                            let pk = grid.querySelector('.color-picker-input');
                            if (pk) {
                                pk.value = cd.hex;
                                pk.dispatchEvent(new Event('input'));
                            }
                        }
                    }
                });
            }
            if (s.scales) {
                Object.keys(s.scales).forEach(cat => {
                    const scale = clampScale(s.scales[cat]);
                    setScaleVisual(cat, scale);
                    if (cat === 'ok' && typeof window.applyCompassScaleFromCategory === 'function') {
                        window.applyCompassScaleFromCategory(scale, false);
                    }
                    $.post(`https://${getResName()}/setCategoryScale`, JSON.stringify({ category: cat, scale: scale }));
                });
            }
        } catch(e) {}
    }
    window.loadAllSettings = loadAllSettings;
    setTimeout(loadAllSettings, 300);
});
let currentARData = null;
let lastARData = null;
let lastMsgTime = 0;
let uiColorApplied = null;
window.addEventListener('message', function (event) {
    if (event.data.type === "SET_CONFIG_DEFAULTS") {
        const shouldApplyDefaults = !ConfigDefaultsApplied;
        ConfigDefaults = event.data.defaults || null;
        if (shouldApplyDefaults) applyConfigDefaults(false);
        return;
    }
    if (event.data.type === "OPEN_SETTINGS_MENU") {
        const menu = $('#settings-menu')[0];
        menu.style.display = 'flex';
        menu.classList.remove('slide-in-left');
        void menu.offsetWidth;
        menu.classList.add('slide-in-left');
        $('#app')[0].style.display = 'block';
        const hudNav = $('#hud-navigation')[0];
        if (hudNav) hudNav.classList.add('draggable-mode');
        if (typeof window.loadAllSettings === 'function') {
            window.loadAllSettings();
        }
        return;
    }
    if (event.data.type === "SET_LOCALES") {
        const trData = event.data.locales;
        if (trData) {
            $('[data-i18n]').get().forEach(el => {
                const key = el.getAttribute('data-i18n');
                if (trData[key]) {
                    el.innerHTML = trData[key];
                }
            });
        }
        return;
    }
    if (event.data.type === "UPDATE_AR") {
        lastARData = currentARData;
        currentARData = event.data;
        if (currentARData.color && (!uiColorApplied || uiColorApplied.r !== currentARData.color.r || uiColorApplied.g !== currentARData.color.g || uiColorApplied.b !== currentARData.color.b)) {
            uiColorApplied = currentARData.color;
            let r = uiColorApplied.r || 0;
            let g = uiColorApplied.g || 160;
            let b = uiColorApplied.b || 255;
            document.documentElement.style.setProperty('--ar-stroke-color', `rgb(${r}, ${g}, ${b})`);
            document.documentElement.style.setProperty('--ar-fill-color', `rgb(${r}, ${g}, ${b})`);
            document.documentElement.style.setProperty('--ar-bg-color', `rgba(${r}, ${g}, ${b}, 0.9)`);
            document.documentElement.style.setProperty('--ar-bg-color-light', `rgba(${r}, ${g}, ${b}, 0.5)`);
        }
        let now = performance.now();
        let dt = now - lastMsgTime;
        if (lastARData && dt > 0 && dt < 100) {
            if (currentARData.turnSign && lastARData.turnSign && currentARData.turnSign.visible && lastARData.turnSign.visible) {
                currentARData.turnSign.vx = (currentARData.turnSign.x - lastARData.turnSign.x) / dt;
                currentARData.turnSign.vy = (currentARData.turnSign.y - lastARData.turnSign.y) / dt;
            }
            if (currentARData.markers && lastARData.markers) {
                for (let i = 0; i < Math.min(currentARData.markers.length, lastARData.markers.length); i++) {
                    let cM = currentARData.markers[i];
                    let lM = lastARData.markers[i];
                    if (cM && lM && cM.onScreen && lM.onScreen) {
                        cM.vx = (cM.x - lM.x) / dt;
                        cM.vy = (cM.y - lM.y) / dt;
                    }
                }
            }
            if (currentARData.waypoint && lastARData.waypoint && currentARData.waypoint.onScreen && lastARData.waypoint.onScreen) {
                currentARData.waypoint.vx = (currentARData.waypoint.x - lastARData.waypoint.x) / dt;
                currentARData.waypoint.vy = (currentARData.waypoint.y - lastARData.waypoint.y) / dt;
            }
        }
        lastMsgTime = now;
    }
});
const DOMCache = {};
function getEl(id) {
    if (!DOMCache[id]) DOMCache[id] = document.getElementById(id);
    return DOMCache[id];
}
const StateCache = {};

let smoothedCompassAngle = 0;
function lerpAngleDeg(current, target, factor) {
    let diff = target - current;
    while (diff > 180) diff -= 360;
    while (diff < -180) diff += 360;
    if (Math.abs(diff) < 0.1) return target;
    return current + diff * factor;
}

const SmoothingState = {
    wpX: null, wpY: null, wpS: null,
    wpMode: null,
    tsX: null, tsY: null, tsS: null
};

function lerpPos(current, target, factor) {
    if (current === null) return target;
    const diff = target - current;
    if (Math.abs(diff) > 0.12) return target;
    return current + diff * factor;
}

function lerpPosSoft(current, target, factor) {
    if (current === null) return target;
    return current + (target - current) * factor;
}

function scheduleARLoop(delay = 0) {
    if (delay > 0) setTimeout(() => requestAnimationFrame(renderARLoop), delay);
    else requestAnimationFrame(renderARLoop);
}
function renderARLoop() {
    if (!currentARData) {
        scheduleARLoop(250);
        return;
    }
    const data = currentARData;
    const app = getEl('app');
    if (!app) {
        scheduleARLoop(250);
        return;
    }
    const settingsMenu = getEl('settings-menu');
    const settingsOpen = settingsMenu ? settingsMenu.style.display === 'flex' : false;
    
    let shouldVisible = (data.visible !== false) || settingsOpen;

    if (StateCache.appVis !== shouldVisible) {
        StateCache.appVis = shouldVisible;
        app.style.display = shouldVisible ? 'block' : 'none';
    }

    if (!shouldVisible) {
        getEl('waypoint-card').style.display = 'none';
        getEl('hud-navigation').style.display = 'none';
        getEl('ar-sign-container').style.display = 'none';
        StateCache.wpDis = 'none';
        StateCache.hnDis = 'none';
        StateCache.tsDis = 'none';
        scheduleARLoop(250);
        return;
    }
    let now = performance.now();
    let timeSinceMsg = now - lastMsgTime;
    if (timeSinceMsg > 60 || timeSinceMsg < 0) timeSinceMsg = 0;
    const wpCard = getEl('waypoint-card');
    if (data.waypoint && data.waypoint.onScreen) {
        if (StateCache.wpDis !== 'flex') {
            StateCache.wpDis = 'flex';
            wpCard.style.display = 'flex';
        }
        const isEdge = data.waypoint.edge === true;
        const wpMode = isEdge ? 'edge' : 'world';
        if (SmoothingState.wpMode !== wpMode) {
            SmoothingState.wpX = null;
            SmoothingState.wpY = null;
            SmoothingState.wpS = null;
            SmoothingState.wpMode = wpMode;
        }
        let predX = data.waypoint.x;
        let predY = data.waypoint.y;
        let sc = data.waypoint.scale || 1.0;
        if (sc > 1.2) sc = 1.2;
        if (sc < 0.4) sc = 0.4;
        if (isEdge) {
            SmoothingState.wpX = lerpPosSoft(SmoothingState.wpX, predX, 0.18);
            SmoothingState.wpY = lerpPosSoft(SmoothingState.wpY, predY, 0.18);
            SmoothingState.wpS = lerpPosSoft(SmoothingState.wpS, sc, 0.16);
        } else {
            SmoothingState.wpX = predX;
            SmoothingState.wpY = predY;
            SmoothingState.wpS = sc;
        }
        const screenX = isEdge ? Math.round(SmoothingState.wpX * window.innerWidth) : (SmoothingState.wpX * window.innerWidth);
        const screenY = isEdge ? Math.round(SmoothingState.wpY * window.innerHeight) : (SmoothingState.wpY * window.innerHeight);
        wpCard.style.transform = `translate3d(${screenX}px, ${screenY}px, 0) translate(-50%, -50%) scale(${SmoothingState.wpS})`;
        wpCard.style.opacity = data.waypoint.opacity || 1.0;
        const metreThemes = { 1: 'theme-default', 2: 'theme-minimal', 3: 'theme-icon' };
        let newClass = 'ar-card pin-card ' + (metreThemes[data.waypoint.style] || 'theme-default');
        if (StateCache.wpDistText !== data.waypoint.distance) {
            StateCache.wpDistText = data.waypoint.distance;
            getEl('wp-dist').innerText = data.waypoint.distance;
        }
        if (StateCache.wpEtaText !== data.waypoint.eta) {
            StateCache.wpEtaText = data.waypoint.eta;
            getEl('wp-eta').innerText = data.waypoint.eta;
        }
        let distStr = (data.waypoint.distance || '').toString().toUpperCase().trim();
        let distMeters = 999999;
        if (distStr.includes('KM')) {
            distMeters = parseFloat(distStr) * 1000;
        } else if (distStr.includes('MI')) {
            distMeters = parseFloat(distStr) * 1609.34;
        } else if (distStr.includes('FT')) {
            distMeters = parseFloat(distStr) * 0.3048;
        } else {
            distMeters = parseFloat(distStr) || 999999;
        }
        const pinIcon = wpCard.querySelector('.pin-icon');
        const wc = data.waypoint.color;
        const cr = wc ? wc.r : 0, cg = wc ? wc.g : 180, cb = wc ? wc.b : 255;
        const colorKey = `${cr},${cg},${cb}`;
        if (!isEdge && distMeters < 80) {
            newClass = 'ar-card pin-card theme-default near-destination';
            if (pinIcon && pinIcon.dataset.flagColor !== colorKey) {
                pinIcon.dataset.flagMode = '1';
                pinIcon.dataset.flagColor = colorKey;
                pinIcon.innerHTML = `<svg viewBox="0 0 64 88" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M32 86 C32 86 60 50 60 30 C60 14.5 47.5 2 32 2 C16.5 2 4 14.5 4 30 C4 50 32 86 32 86Z"
                          stroke="rgb(${cr},${cg},${cb})" stroke-width="3" fill="none"/>
                    <line x1="25" y1="15" x2="25" y2="46" stroke="white" stroke-width="2.5" stroke-linecap="round"/>
                    <rect x="25" y="15" width="20" height="14" rx="1" fill="white"/>
                    <rect x="25" y="15" width="10" height="7" fill="rgba(30,30,40,0.85)"/>
                    <rect x="35" y="22" width="10" height="7" fill="rgba(30,30,40,0.85)"/>
                    <circle cx="25" cy="14" r="2" fill="white"/>
                </svg>`;
            }
        } else {
            if (pinIcon && pinIcon.dataset.flagMode) {
                delete pinIcon.dataset.flagMode;
                delete pinIcon.dataset.flagColor;
                pinIcon.innerHTML = `<svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M12 2C8.13 2 5 5.13 5 9C5 14.25 12 22 12 22C12 22 19 14.25 19 9C19 5.13 15.87 2 12 2ZM12 11.5C10.62 11.5 9.5 10.38 9.5 9C9.5 7.62 10.62 6.5 12 6.5C13.38 6.5 14.5 7.62 14.5 9C14.5 10.38 13.38 11.5 12 11.5Z" fill="white"/>
                </svg>`;
            }
        }
        if (StateCache.wpClass !== newClass) {
            StateCache.wpClass = newClass;
            wpCard.className = newClass;
        }
        if (data.waypoint.color && StateCache.wpColorKey !== colorKey) {
            StateCache.wpColorKey = colorKey;
            wpCard.style.setProperty('--cat-color', `rgb(${cr}, ${cg}, ${cb})`);
            wpCard.style.setProperty('--icon-col', ((cr * 0.299 + cg * 0.587 + cb * 0.114) < 130) ? 'white' : '#111');
        }
    } else {
        if (StateCache.wpDis !== 'none') {
            StateCache.wpDis = 'none';
            wpCard.style.display = 'none';
        }
        SmoothingState.wpX = null;
        SmoothingState.wpY = null;
        SmoothingState.wpS = null;
        SmoothingState.wpMode = null;
    }
    const hudNav = getEl('hud-navigation');
    const compass = getEl('nfs-hud-arrow');
    const okToggle = getEl('toggle-ok');
    const globalToggle = getEl('toggle-global');
    const okEnabled = (!okToggle || okToggle.classList.contains('active')) && (!globalToggle || globalToggle.classList.contains('active'));
    
    let isArrowTabActive = false;
    if (typeof settingsOpen !== 'undefined' && settingsOpen) {
        let at = document.querySelector('.nav-tab.active');
        if (at && at.dataset.tab === 'ok') isArrowTabActive = true;
    }

    let hasValidRoute = data.waypoint || data.turn || data.turnSign || (data.markers && data.markers.length > 0);
    if (((data.hudNav && data.hudNav.visible && hasValidRoute) || isArrowTabActive) && okEnabled) {
        if (StateCache.hnDis !== 'flex') { StateCache.hnDis = 'flex'; hudNav.style.display = 'flex'; }
        let cRot = data.hudNav?.compassAngle || 0;
        smoothedCompassAngle = lerpAngleDeg(smoothedCompassAngle, cRot, 0.08);
        compass.style.setProperty('--compass-rot', `${smoothedCompassAngle}deg`);
        if (data.hudNav && data.hudNav.color) {
            let rC = data.hudNav.color.r, gC = data.hudNav.color.g, bC = data.hudNav.color.b;
            let cKey = `${rC},${gC},${bC}`;
            if (StateCache.hnColor !== cKey) {
                StateCache.hnColor = cKey;
                document.documentElement.style.setProperty('--compass-color', `rgb(${rC}, ${gC}, ${bC})`);
                const grad = getEl('arrowGrad');
                const edge = getEl('arrowEdge');
                const glow = document.querySelector('#nfs-hud-arrow .arrow-glow-outer path');
                if (grad) {
                    grad.children[1].setAttribute('stop-color', `rgb(${rC}, ${gC}, ${bC})`);
                    grad.children[2].setAttribute('stop-color', `rgb(${Math.max(0, rC - 50)}, ${Math.max(0, gC - 50)}, ${Math.max(0, bC - 50)})`);
                }
                if (edge) {
                    edge.children[1].setAttribute('stop-color', `rgb(${rC}, ${gC}, ${bC})`);
                }
                if (glow) {
                    glow.setAttribute('stroke', `rgba(${rC}, ${gC}, ${bC}, 0.5)`);
                }
                if (typeof chevronMesh !== 'undefined' && chevronMesh) {
                    chevronMesh.material.color.setRGB(rC / 255, gC / 255, bC / 255);
                    chevronMesh.material.emissive.setRGB(rC / 255 * 0.15, gC / 255 * 0.15, bC / 255 * 0.15);
                }
            }
        }
        if (data.hudNav && data.hudNav.style) {
            if (StateCache.hnStyle !== data.hudNav.style) {
                StateCache.hnStyle = data.hudNav.style;
                if (data.hudNav.style === 1) {
                    getEl('nfs-hud-arrow').style.display = 'none';
                    getEl('hud-arrow-underground').style.display = 'block';
                    chevronActive = true;
                    if (getEl('hud-arrow-neon')) getEl('hud-arrow-neon').style.display = 'none';
                } else if (data.hudNav.style === 2) {
                    getEl('nfs-hud-arrow').style.display = 'none';
                    getEl('hud-arrow-underground').style.display = 'none';
                    chevronActive = false;
                    let neonMode = getEl('hud-arrow-neon');
                    if (!neonMode) {
                        neonMode = document.createElement('div');
                        neonMode.id = 'hud-arrow-neon';
                        neonMode.className = 'nfs-arrow-3d';
                        neonMode.innerHTML = `<svg viewBox="0 0 80 80" fill="currentColor" style="color: var(--compass-color, #00b4ff); filter: drop-shadow(0 0 10px currentColor);"><path d="M40 0 L15 70 L40 50 L65 70 Z"/></svg>`;
                        getEl('hud-navigation').appendChild(neonMode);
                    }
                    neonMode.style.display = 'block';
                } else {
                    getEl('nfs-hud-arrow').style.display = 'block';
                    getEl('hud-arrow-underground').style.display = 'none';
                    chevronActive = false;
                    if (getEl('hud-arrow-neon')) getEl('hud-arrow-neon').style.display = 'none';
                }
            }
        }
        if (chevronActive && typeof updateChevronRotation === "function") updateChevronRotation(data.hudNav?.compassAngle || 0);
    } else {
        if (StateCache.hnDis !== 'none') { StateCache.hnDis = 'none'; hudNav.style.display = 'none'; }
        if (chevronActive && typeof chevronGroup !== "undefined" && chevronGroup) chevronGroup.rotation.z = 0;
    }
    const signContainer = getEl('ar-sign-container');
    if (data.turnSign && data.turnSign.visible) {
        if (StateCache.tsDis !== 'block') { StateCache.tsDis = 'block'; signContainer.style.display = 'block'; }
        let predX = data.turnSign.x;
        let predY = data.turnSign.y;
        SmoothingState.tsX = predX;
        SmoothingState.tsY = predY;
        SmoothingState.tsS = data.turnSign.scale;
        const sX = SmoothingState.tsX * window.innerWidth;
        const sY = SmoothingState.tsY * window.innerHeight;
        if (StateCache.tsText !== data.turnSign.street) {
            StateCache.tsText = data.turnSign.street;
            getEl('ar-sign-text').innerText = data.turnSign.street;
        }
        let styleClass = 'style-default';
        if (data.turnSign.style === 2) styleClass = 'style-sharp';
        else if (data.turnSign.style === 3) styleClass = 'style-minimal';
        let newTsClass = 'ar-sign-wrapper ' + data.turnSign.direction + ' ' + styleClass;
        if (StateCache.tsClass !== newTsClass) {
            StateCache.tsClass = newTsClass;
            signContainer.className = newTsClass;
        }
        if (data.turnSign.color) {
            const tc = data.turnSign.color;
            let cKey = `${tc.r},${tc.g},${tc.b}`;
            if (StateCache.tsColor !== cKey) {
                StateCache.tsColor = cKey;
                signContainer.style.setProperty('--cat-color', `rgb(${tc.r}, ${tc.g}, ${tc.b})`);
            }
        }
        const iconDiv = getEl('ar-sign-icon');
        let cacheKey = `${data.turnSign.direction}_${data.turnSign.curveLevel}`;
        if (StateCache.tsSvg !== cacheKey) {
            StateCache.tsSvg = cacheKey;
            let iconSvg = '';
            if (data.turnSign.direction === 'right') {
                if (data.turnSign.curveLevel === 'slight') {
                    iconSvg = `<svg viewBox="0 0 24 24"><path d="M5 20 V 16 C 5 12 9 8 16 5 L 20 5 M 20 5 L 15 2 M 20 5 L 15 8" /></svg>`;
                } else {
                    iconSvg = `<svg viewBox="0 0 24 24"><path d="M5 20 V 12 C 5 8 8 5 12 5 H 20 M 20 5 L 15 2 M 20 5 L 15 8" /></svg>`;
                }
            } else if (data.turnSign.direction === 'left') {
                if (data.turnSign.curveLevel === 'slight') {
                    iconSvg = `<svg viewBox="0 0 24 24"><path d="M19 20 V 16 C 19 12 15 8 8 5 L 4 5 M 4 5 L 9 2 M 4 5 L 9 8" /></svg>`;
                } else {
                    iconSvg = `<svg viewBox="0 0 24 24"><path d="M19 20 V 12 C 19 8 16 5 12 5 H 4 M 4 5 L 9 2 M 4 5 L 9 8" /></svg>`;
                }
            } else if (data.turnSign.direction === 'uturn') {
                iconSvg = `<svg viewBox="0 0 24 24"><path d="M9 20 L 9 10 C 9 6 15 6 15 10 L 15 20 M 15 20 L 12 16 M 15 20 L 18 16" /></svg>`;
            }
            iconDiv.innerHTML = iconSvg;
        }
        signContainer.style.transform = `translate3d(${sX}px, ${sY}px, 0) translate(-50%, -100%) scale(${SmoothingState.tsS})`;
    } else {
        if (StateCache.tsDis !== 'none') { StateCache.tsDis = 'none'; signContainer.style.display = 'none'; }
        SmoothingState.tsX = null;
        SmoothingState.tsY = null;
        SmoothingState.tsS = null;
    }
    if (typeof syncPreviews === "function") {
        syncPreviews(data);
    }
    scheduleARLoop();
}
scheduleARLoop();
let miniPreviewScene, miniPreviewCamera, miniPreviewRenderer;
window.miniPreviewMesh = null;
function initMiniPreview() {
    const canvas = $('#preview-canvas-underground')[0];
    if (!canvas) return;
    miniPreviewScene = new THREE.Scene();
    miniPreviewCamera = new THREE.PerspectiveCamera(50, 1.0, 0.1, 100);
    miniPreviewCamera.position.set(0, 2, 6);
    miniPreviewCamera.lookAt(0, 0, 0);
    miniPreviewRenderer = new THREE.WebGLRenderer({ canvas: canvas, alpha: true, antialias: true });
    miniPreviewRenderer.setSize(100, 100);
    const ambient = new THREE.AmbientLight(0xffffff, 0.8);
    miniPreviewScene.add(ambient);
    const dir = new THREE.DirectionalLight(0xffffff, 1.0);
    dir.position.set(5, 10, 7);
    miniPreviewScene.add(dir);
    const shape = new THREE.Shape();
    shape.moveTo(-0.45, 1.3);
    shape.lineTo(0.45, 1.3);
    shape.lineTo(0.45, 0.1);
    shape.lineTo(1.25, 0.25);
    shape.lineTo(0.0, -1.1);
    shape.lineTo(-1.25, 0.25);
    shape.lineTo(-0.45, 0.1);
    shape.lineTo(-0.45, 1.3);
    const extrudeSettings = { steps: 1, depth: 0.5, bevelEnabled: true, bevelThickness: 0.07, bevelSize: 0.07, bevelSegments: 4 };
    const geo = new THREE.ExtrudeGeometry(shape, extrudeSettings);
    geo.center();
    const mat = new THREE.MeshPhongMaterial({ color: 0x0090ff, emissive: 0x002050, shininess: 100, transparent: true, opacity: 0.95 });
    window.miniPreviewMesh = new THREE.Mesh(geo, mat);
    const edgesGeo = new THREE.EdgesGeometry(geo, 15);
    const edgesMat = new THREE.LineBasicMaterial({ color: 0x00ddff, linewidth: 1, transparent: true, opacity: 0.9 });
    const miniEdges = new THREE.LineSegments(edgesGeo, edgesMat);
    window.miniEdgesMesh = miniEdges;
    const group = new THREE.Group();
    group.add(window.miniPreviewMesh);
    group.add(window.miniEdgesMesh);
    group.rotation.x = -0.55;
    group.position.y = -0.5;
    miniPreviewScene.add(group);
    function animateMini() {
        const menu = document.getElementById('settings-menu');
        if (!menu || menu.style.display !== 'flex') {
            setTimeout(() => requestAnimationFrame(animateMini), 500);
            return;
        }
        if (group) {
            group.rotation.z += 0.01;
            miniPreviewRenderer.render(miniPreviewScene, miniPreviewCamera);
        }
        requestAnimationFrame(animateMini);
    }
    animateMini();
}
document.addEventListener("DOMContentLoaded", () => {
    const menuEl = $('#settings-menu')[0];
    const dragHandle = $('#menu-drag-handle')[0];
    let isDragging = false;
    let initialX = 0;
    let initialY = 0;
    let xOffset = 50;
    let yOffset = window.innerHeight / 2 - 350;
    menuEl.style.left = `${xOffset}px`;
    menuEl.style.top = `${yOffset}px`;
    menuEl.style.transform = "none";
    menuEl.style.bottom = "auto";
    menuEl.style.right = "auto";
    menuEl.style.margin = "0";
    dragHandle.addEventListener("mousedown", dragStart);
    document.addEventListener("mouseup", dragEnd);
    document.addEventListener("mousemove", drag);
    function dragStart(e) {
        initialX = e.clientX - xOffset;
        initialY = e.clientY - yOffset;
        if (e.target === dragHandle || dragHandle.contains(e.target)) {
            isDragging = true;
        }
    }
    function dragEnd(e) {
        initialX = xOffset;
        initialY = yOffset;
        isDragging = false;
    }
    function drag(e) {
        if (isDragging) {
            e.preventDefault();
            xOffset = e.clientX - initialX;
            yOffset = e.clientY - initialY;
            if (xOffset < 0) xOffset = 0;
            if (yOffset < 0) yOffset = 0;
            if (xOffset + menuEl.offsetWidth > window.innerWidth) xOffset = window.innerWidth - menuEl.offsetWidth;
            if (yOffset + menuEl.offsetHeight > window.innerHeight) yOffset = window.innerHeight - menuEl.offsetHeight;
            menuEl.style.left = xOffset + "px";
            menuEl.style.top = yOffset + "px";
        }
    }
    $('.color-picker-input').get().forEach(picker => {
        $(picker).on('input', (e) => {
            let hex = e.target.value;
            let result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
            if (result) {
                let r = parseInt(result[1], 16);
                let g = parseInt(result[2], 16);
                let b = parseInt(result[3], 16);
                let isGlobal = e.target.classList.contains('global-picker');

                if (isGlobal) {
                    $('.global-swatch, .global-picker').get().forEach(s => s.classList.remove('selected'));
                    e.target.classList.add('selected');
                } else {
                    let cat = e.target.dataset.category;
                    $(`.sidebar-color-grid[data-category="${cat}"] .cat-swatch, .sidebar-color-grid[data-category="${cat}"] .color-picker-input`).get().forEach(s => s.classList.remove('selected'));
                    e.target.classList.add('selected');
                }

                document.documentElement.style.setProperty('--sidebar-accent', `rgb(${r}, ${g}, ${b})`);
                if (isGlobal || e.target.dataset.category === 'adres') {
                    const el = $('#preview-adres-wrapper')[0];
                    if (el) { el.style.setProperty('--cat-color', `rgb(${r}, ${g}, ${b})`); el.style.setProperty('--icon-col', ((r * 0.299 + g * 0.587 + b * 0.114) < 130) ? 'white' : '#111'); }
                }
                if (isGlobal || e.target.dataset.category === 'metre') {
                    const el = $('#preview-metre-wrapper')[0];
                    if (el) { el.style.setProperty('--cat-color', `rgb(${r}, ${g}, ${b})`); el.style.setProperty('--icon-col', ((r * 0.299 + g * 0.587 + b * 0.114) < 130) ? 'white' : '#111'); }
                }
                if (isGlobal || e.target.dataset.category === 'marker') {
                    const el = $('#preview-marker-wrapper')[0];
                    if (el && el.children[0]) {
                        el.children[0].setAttribute('stroke', `rgb(${r}, ${g}, ${b})`);
                        el.children[0].style.filter = `drop-shadow(0 0 5px rgb(${r}, ${g}, ${b}))`;
                    }
                }
                if (isGlobal || e.target.dataset.category === 'ok') {
                    document.documentElement.style.setProperty('--compass-color', `rgb(${r}, ${g}, ${b})`);
                    if (typeof updateChevronColor === 'function') updateChevronColor(r, g, b);
                    const grad = $('#arrowGrad')[0];
                    const edge = $('#arrowEdge')[0];
                    const glows = $('#nfs-hud-arrow .arrow-glow-outer path, #preview-ok-visual .arrow-glow-outer path');
                    if (grad) {
                        grad.children[1].setAttribute('stop-color', `rgb(${r}, ${g}, ${b})`);
                        grad.children[2].setAttribute('stop-color', `rgb(${Math.max(0, r - 50)}, ${Math.max(0, g - 50)}, ${Math.max(0, b - 50)})`);
                    }
                    if (edge) edge.children[1].setAttribute('stop-color', `rgb(${r}, ${g}, ${b})`);
                    glows.get().forEach(glow => {
                        glow.setAttribute('stroke', `rgba(${r}, ${g}, ${b}, 0.5)`);
                    });
                }
                if (isGlobal) {
                    $.post(`https://${getResName()}/setGlobalColor`, JSON.stringify({ r: r, g: g, b: b }));
                } else {
                    let cat = e.target.dataset.category;
                    $.post(`https://${getResName()}/setCategoryColor`, JSON.stringify({ category: cat, r: r, g: g, b: b }));
                }
                if(window.saveTimer) clearTimeout(window.saveTimer);
                window.saveTimer = setTimeout(window.saveAllSettings || (()=>localStorage.setItem('frkn_waypoint_prefs_picker', hex)), 300);
            }
        });
    });
});
function updatePreviewStyleExt(category, styleId) {
    if (category === 'adres') {
        const wrap = $('#preview-adres-wrapper')[0];
        if (wrap) {
            wrap.className = 'ar-sign-wrapper ' + (styleId == 1 ? 'style-default' : styleId == 2 ? 'style-sharp' : styleId == 3 ? 'style-minimal' : 'style-default');
        }
    }
    if (category === 'metre') {
        const wrap = $('#preview-metre-wrapper')[0];
        if (wrap) {
            wrap.className = 'ar-card pin-card ' + (styleId == 1 ? 'theme-default' : styleId == 2 ? 'theme-minimal' : styleId == 3 ? 'theme-icon' : 'theme-default');
        }
    }
    if (category === 'ok') {
        const c3d = $('#preview-canvas-underground')[0];
        const visualElem = $('#preview-ok-visual')[0];
        if (c3d) c3d.style.display = 'none';
        if (styleId == 1) {
            if (c3d) c3d.style.display = 'block';
            if (visualElem) visualElem.style.display = 'none';
        } else {
            if (visualElem) visualElem.style.display = 'flex';
            if (styleId == 2) {
                if (visualElem) visualElem.innerHTML = '<svg width="50" height="50" viewBox="0 0 80 80" fill="currentColor" style="color: var(--cat-color, var(--sidebar-accent, #00b4ff)); filter: drop-shadow(0 0 10px currentColor);"><path d="M40 0 L15 70 L40 50 L65 70 Z"/></svg>';
            } else {
                const classicArrowHTML = $('#nfs-hud-arrow')[0] ? $('#nfs-hud-arrow')[0].innerHTML : '';
                if (visualElem) visualElem.innerHTML = '<div style="transform: scale(0.6); position: relative; width: 80px; height: 64px;">' + classicArrowHTML + '</div>';
            }
        }
    }
}
window.updatePreviewStyleExt = updatePreviewStyleExt;
function syncPreviews(data) {
    if (!data) return;
    if (data.turnSign && data.turnSign.visible && $('#preview-adres-text')[0]) {
        $('#preview-adres-text')[0].innerText = data.turnSign.street || "...";
        $('#preview-adres-icon')[0].innerHTML = $('#ar-sign-icon')[0].innerHTML;
        if (data.turnSign.color) {
            $('#preview-adres-wrapper')[0].style.setProperty('--cat-color', `rgb(${data.turnSign.color.r}, ${data.turnSign.color.g}, ${data.turnSign.color.b})`);
        }
    }
    if (data.waypoint && data.waypoint.onScreen && $('#preview-metre-dist')[0]) {
        $('#preview-metre-dist')[0].innerText = data.waypoint.distance || '...';
        if (data.waypoint.eta) {
            $('#preview-metre-eta')[0].innerText = data.waypoint.eta;
        }
        if (data.waypoint.color) {
            $('#preview-metre-wrapper')[0].style.setProperty('--cat-color', `rgb(${data.waypoint.color.r}, ${data.waypoint.color.g}, ${data.waypoint.color.b})`);
            $('#preview-metre-wrapper')[0].style.setProperty('--theme-color', `rgb(${data.waypoint.color.r}, ${data.waypoint.color.g}, ${data.waypoint.color.b})`);
            $('#preview-metre-wrapper')[0].style.setProperty('--icon-col', ((data.waypoint.color.r * 0.299 + data.waypoint.color.g * 0.587 + data.waypoint.color.b * 0.114) < 130) ? 'white' : '#111');
            $('#preview-metre-wrapper')[0].classList.add('custom-color-active');
        }
    }
}
