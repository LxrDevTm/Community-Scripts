FRKN = {
    -- Selected Language ('tr', 'en', 'de', 'ru')
    Locale = 'en',
    
    -- AR navigation system activates only when the player is inside a vehicle (true/false)
    RequireVehicle = true,
    
    -- Command to open the setting menu
    MenuCommand = 'waypoint',
    
    -- Distance unit system ('km' or 'mil')
    UnitSystem = 'km',

    -- Default UI state, styles, colors and scale.
    -- Categories: adres = turn street sign, metre = destination meter,
    -- marker = world turn markers, ok = screen-top navigation arrow.
    UI = {
        GlobalEnabled = true,
        GlobalColor = { r = 0, g = 180, b = 255 },
        UseSavedPreferences = true,
        GlobalScale = 0.85,
        CompassDefaultScale = 0.75,
        EdgeIndicatorEnabled = true,
        Categories = {
            adres = { Enabled = true, Style = 1, Scale = 1.0, Color = { r = 0, g = 180, b = 255 } },
            metre = { Enabled = true, Style = 2, Scale = 1.0, Color = { r = 0, g = 180, b = 255 } },
            marker = { Enabled = true, Style = 1, Scale = 1.0, Color = { r = 0, g = 180, b = 255 } },
            ok = { Enabled = true, Style = 1, Scale = 1.0, Color = { r = 0, g = 180, b = 255 } }
        }
    },

    -- AR Marker Visibility Distance Limit
    DrawDistance = 150.0,
    
    -- Z-Axis Height Offset for Destination Marker
    MarkerZOffset = 0.0,

    -- 3D turn marker size
    MarkerScale = 2.25,

    -- Draw the visible destination meter as a DUI texture in the world
    -- so the old HTML design stays locked like an in-game marker.
    NativeWorldWaypoint = true,

    WaypointDui = {
        Width = 1024,
        Height = 256,
        Styles = {
            [1] = { DrawWidth = 0.140, DrawHeight = 0.065, OriginX = 0.0 },
            [2] = { DrawWidth = 0.110, DrawHeight = 0.056, OriginX = 0.070 },
            [3] = { DrawWidth = 0.090, DrawHeight = 0.032, OriginX = 0.0 }
        }
    },

    -- Draw address and mini meter widgets as DUI textures in the world too,
    -- avoiding screen-space projection jitter while preserving the NUI designs.
    NativeWorldWidgets = true,

    TurnSignDui = {
        Width = 1024,
        Height = 256,
        Styles = {
            [1] = { DrawWidth = 0.200, DrawHeight = 0.078, OriginX = 0.0, OriginY = -0.02 },
            [2] = { DrawWidth = 0.200, DrawHeight = 0.072, OriginX = 0.0, OriginY = -0.02 },
            [3] = { DrawWidth = 0.200, DrawHeight = 0.065, OriginX = 0.0, OriginY = -0.02 }
        }
    },


    -- Invisible fixed props used as stable world anchors for NUI overlays.
    AnchorProps = {
        Enabled = true,
        Model = 'prop_ld_dummy_rope',
        WaypointZOffset = 2.5,
        TurnSignZOffset = 1.0
    },

    -- System Optimization (Tick Rates in ms)
    -- Increase these values to reduce CPU usage / Decrease for faster responsiveness
    TickRates = {
        RouteDistanceCalc = 2000, -- Check interval for GPS distance text updates (Increases CPU performance)
        VehicleCheck = 200,     -- Sleep time when 'RequireVehicle' is true and player is on foot
        NoWaypoint = 1000,      -- Sleep time when the player has no active GPS destination
        SystemDisabled = 1000,  -- Sleep time when the entire AR system is toggled off from the menu
        TurnCalculation = 650,  -- Frequency of lightweight route maintenance
        RouteScan = 900,        -- Minimum delay between expensive GPS route node scans
        RouteRefreshDistance = 25.0, -- Re-scan route after the player moves this many meters
        RouteNodeCount = 36,    -- Number of route look-ahead samples
        RouteNodeSpacing = 10.0,-- Distance between route look-ahead samples
        NuiUpdate = 100,        -- Screen-space NUI refresh rate; world DUI is still drawn every frame when visible
        DuiWarmupUpdate = 250,  -- DUI message throttle while its texture is warming up
        RenderIdle = 250        -- Sleep when no per-frame world draw is needed
    }
}
