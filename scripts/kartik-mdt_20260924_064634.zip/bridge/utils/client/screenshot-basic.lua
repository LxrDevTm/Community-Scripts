if Config.CameraMethod == 'discord' then

function TakeScreenPhoto(api, cb)
    exports['screenshot-basic']:requestScreenshotUpload(api, 'files[]', function(data)
        local image = json.decode(data)
        if not data or not image then return cb('') end
        cb(image.attachments[1] and image.attachments[1]?.proxy_url or 'Invalid Url')
    end)
end

elseif Config.CameraMethod == 'fivemanage' then

function TakeScreenPhoto(api, cb)
    exports['screenshot-basic']:requestScreenshotUpload('https://api.fivemanage.com/api/image', 'image', {
        headers = { Authorization = api },
        encoding = 'png'
    }, function(data)
        local resp = json.decode(data)
        cb(resp and resp.url or 'invalid url')
    end)
end

elseif Config.CameraMethod == 'fivemerr' then

    function TakeScreenPhoto(api, cb)
        exports['screenshot-basic']:requestScreenshotUpload('https://api.fivemerr.com/v1/media/images', 'file', {
            headers = { Authorization = api },
            encoding = 'png'
        }, function(data)
            local resp = json.decode(data)
            cb(resp and resp.url or 'invalid url')
        end)
    end

end