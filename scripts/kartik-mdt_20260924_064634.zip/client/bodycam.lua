local camera, useBodycamByCommand, bodycamConfig
camera = nil
targetPed = nil
PlyInCam = false
carCam = false
inRoomBodycam = false
savedCoords = nil
useBodycamByCommand = Config.Utils.bodycam.useByCommand
if useBodycamByCommand then
  local registerCommand = RegisterCommand
  local bodycamCommand = Config.Utils.bodycam.command
  local function toggleBodycamCommand()
    local isBodycamAllowed = isActionAllowed("bodycam")
    if not isBodycamAllowed then
      return
    end
    local toggleBodycam = ToggleBodycam
    toggleBodycam()
  end
  registerCommand(bodycamCommand, toggleBodycamCommand)
end

local function notifyPlayer(message, type, duration)
  local lib = lib
  local notify = lib.notify
  local notification = {}
  notification.title = "Bodycam"
  notification.description = message
  notification.duration = duration
  notification.type = type
  notify(notification)
end
NotifyPlayer = notifyPlayer

local function bodyOverlay(visible, data)
  local sendNUIMessage = SendNUIMessage
  local message = {}
  message.action = "toggleBodycamUI"
  local overlayData = {}
  overlayData.visible = visible
  overlayData.data = data
  message.data = overlayData
  sendNUIMessage(message)
end
BodyOverlay = bodyOverlay

local function toggleBodycam()
  local bodycamItemRequired = Config.Utils.bodycam.itemRequired
  if bodycamItemRequired then
    local hasItem = HasItem
    local bodycamItem = Config.Utils.bodycam.item
    local hasBodycamItem = hasItem(bodycamItem)
    if not hasBodycamItem then
      return
    end
  end
  local playerData = PlayerData
  if playerData then
    local citizenId = playerData.citizenid
  end
  if not citizenId then
    local notifyPlayer = NotifyPlayer
    local message = "Citizen ID not found!"
    local type = "error"
    notifyPlayer(message, type)
    return
  end
  local globalState = GlobalState
  local playerOnBodycam = globalState.PlayerOnBodycam
  if playerOnBodycam then
    local playerBodycamStatus = playerOnBodycam[citizenId]
    if playerBodycamStatus then
      local status = playerBodycamStatus.status
      local isBodycamActive = status == "on"
    end
  end
  if isBodycamActive then
    local action = "Deactivating"
  else
    local action = "Activating"
  end
  local lib = lib
  local progressBar = lib.progressBar
  local progressBarConfig = {}
  progressBarConfig.duration = 2500
  progressBarConfig.label = action .. " Bodycam"
  progressBarConfig.useWhileDead = false
  progressBarConfig.canCancel = true
  local disableConfig = {}
  disableConfig.combat = true
  progressBarConfig.disable = disableConfig
  local animConfig = {}
  animConfig.dict = "clothingtie"
  animConfig.clip = "try_tie_positive_a"
  progressBarConfig.anim = animConfig
  local startedProgressBar = progressBar(progressBarConfig)
  if startedProgressBar then
    local callback = lib.callback
    local await = callback.await
    local toggleBodycamEvent = "kartik-mdt:server:toggleBodycam"
    local isToggleBodycam = not isBodycamActive
    local result = await(toggleBodycamEvent, false, isToggleBodycam, citizenId)
    if result then
      local bodyOverlay = BodyOverlay
      local isVisible = not isBodycamActive
      local data = result
      bodyOverlay(isVisible, data)
    else
      local notifyPlayer = NotifyPlayer
      local message = "Failed to toggle bodycam!"
      local type = "error"
      notifyPlayer(message, type)
    end
  else
    local notifyPlayer = NotifyPlayer
    local message = "Cancelled!"
    local type = "error"
    notifyPlayer(message, type)
  end
end
ToggleBodycam = toggleBodycam

exports("ToggleBodycam", ToggleBodycam)

RegisterNUICallback("fetchBodycams", function(data, cb)
  if data then
    local lib = lib
    local callback = lib.callback
    local await = callback.await
    local fetchBodycamsEvent = "kartik-mdt:server:fetchBodycams"
    local result = await(fetchBodycamsEvent, false, data)
    if result then
      cb(result)
    end
  end
end)

RegisterNUICallback("fetchBodycamDataById", function(data, cb)
  if data then
    local lib = lib
    local callback = lib.callback
    local await = callback.await
    local fetchBodycamDataByIdEvent = "kartik-mdt:server:fetchBodycamDataById"
    local result = await(fetchBodycamDataByIdEvent, false, data)
    if result then
      cb(result)
    end
  end
end)

RegisterNUICallback("getPaginatedCameraVideos", function(data, cb)
  if data then
    local lib = lib
    local callback = lib.callback
    local await = callback.await
    local getPaginatedCameraVideosEvent = "kartik-mdt:server:getPaginatedCameraVideos"
    local result = await(getPaginatedCameraVideosEvent, false, data)
    if result then
      cb(result)
    end
  end
end)

local function setCamRotation()
  while PlyInCam do
    local setCamRot = SetCamRot
    local cam = camera
    local x = 0
    local y = 0
    local z = GetEntityHeading(targetPed)
    local flags = 2
    setCamRot(cam, x, y, z, flags)
    Wait(1)
  end
end
SetCamRotation = setCamRotation

local function setCarCam()
  while PlyInCam do
    local isPedInAnyVehicle = IsPedInAnyVehicle
    local ped = targetPed
    local ignoreHelicopters = false
    local isInVehicle = isPedInAnyVehicle(ped, ignoreHelicopters)
    if isInVehicle then
      if not carCam then
        local attachCamToPedBone = AttachCamToPedBone
        local cam = camera
        local boneIndex = 46240
        local xOffset = 0.1
        local yOffset = 0.25
        local zOffset = -0.1
        local p6 = true
        attachCamToPedBone(cam, ped, boneIndex, xOffset, yOffset, zOffset, p6)
        carCam = true
      end
    else
      if carCam then
        local attachCamToPedBone = AttachCamToPedBone
        local cam = camera
        local boneIndex = 46240
        local xOffset = 0.1
        local yOffset = 0.025
        local zOffset = 0.1
        local p6 = true
        attachCamToPedBone(cam, ped, boneIndex, xOffset, yOffset, zOffset, p6)
        carCam = false
      end
    end
    Wait(2000)
  end
end
SetCarCam = setCarCam

RegisterNUICallback("openBodycam", function(data, cb)
  if data then
    local cameraData = data.camera
    if cameraData then
      local citizenId = cameraData.citizenId
      local lib = lib
      local callback = lib.callback
      local await = callback.await
      local getSourceEvent = "kartik-mdt:server:getSource"
      local result, source = await(getSourceEvent, false, citizenId)
      if result then
        if inRoomBodycam then
          local coords = GetEntityCoords(cache.ped)
          savedCoords = coords
          local setEntityCoords = SetEntityCoords
          local ped = cache.ped
          local x = source.x
          local y = source.y
          local z = source.z - 100.0
          setEntityCoords(ped, x, y, z)
          local freezeEntityPosition = FreezeEntityPosition
          freezeEntityPosition(ped, true)
          local setEntityVisible = SetEntityVisible
          setEntityVisible(ped, false, false)
          local setEntityCollision = SetEntityCollision
          setEntityCollision(ped, false, false)
          local setEntityInvincible = SetEntityInvincible
          setEntityInvincible(ped, true)
          local networkSetEntityInvisibleToNetwork = NetworkSetEntityInvisibleToNetwork
          networkSetEntityInvisibleToNetwork(ped, true)
        end
        Wait(1000)
        local getPlayerFromServerId = GetPlayerFromServerId
        local player = getPlayerFromServerId(source)
        if player < 1 then
          cb({ success = false, message = "Target player not found." })
          return
        end
        local getPed = GetPlayerPed
        local ped = getPed(player)
        targetPed = ped
        if not inRoomBodycam then
          if ped then
            if DoesEntityExist(ped) then
              local createCam = CreateCam
              local cam = createCam("DEFAULT_SCRIPTED_FLY_CAMERA", true)
              camera = cam
              local attachCamToPedBone = AttachCamToPedBone
              local boneIndex = Config.Bodycam.boneIndex
              local xOffset = Config.Bodycam.xOffset
              local yOffset = Config.Bodycam.yOffset
              local zOffset = Config.Bodycam.zOffset
              local p6 = true
              attachCamToPedBone(cam, ped, boneIndex, xOffset, yOffset, zOffset, p6)
              local setCamFov = SetCamFov
              local fov = Config.Bodycam.fov
              setCamFov(cam, fov)
              local getEntityHeading = GetEntityHeading
              local heading = getEntityHeading(ped)
              PlyInCam = true
              if not inRoomBodycam then
                local networkSetInSpectatorMode = NetworkSetInSpectatorMode
                networkSetInSpectatorMode(true, ped)
              end
              local setCamRot = SetCamRot
              local x = 0.0
              local y = 0.0
              local z = heading
              local flags = 2
              setCamRot(cam, x, y, z, flags)
              local renderScriptCams = RenderScriptCams
              renderScriptCams(true, false, 0, true, false)
              local shakeCam = ShakeCam
              local camShake = "HAND_SHAKE"
              local amplitude = 1.0
              shakeCam(cam, camShake, amplitude)
              local setCamShakeAmplitude = SetCamShakeAmplitude
              setCamShakeAmplitude(cam, 2.0)
              local doScreenFadeIn = DoScreenFadeIn
              doScreenFadeIn(1000)
              CreateThread(SetCarCam)
              CreateThread(SetCamRotation)
              cb({ success = true, recTime = Config.BodycamRecordTime })
            else
              cb({ success = false, message = "Target not available." })
            end
          else
            cb({ success = false, message = "Target not available." })
          end
        end
      else
        cb({ success = false, message = "Cannot Establish Connection." })
      end
    else
      cb({ success = false, message = "Invalid bodycam data." })
    end
  end
end)

RegisterNUICallback("closeCamera", function(data, cb)
  if inRoomBodycam then
    if savedCoords then
      local setEntityCoords = SetEntityCoords
      local ped = cache.ped
      local x = savedCoords.x
      local y = savedCoords.y
      local z = savedCoords.z
      setEntityCoords(ped, x, y, z)
    end
    local freezeEntityPosition = FreezeEntityPosition
    local ped = cache.ped
    freezeEntityPosition(ped, false)
    local setEntityVisible = SetEntityVisible
    setEntityVisible(ped, true, false)
    local setEntityCollision = SetEntityCollision
    setEntityCollision(ped, true, true)
    local setEntityInvincible = SetEntityInvincible
    setEntityInvincible(ped, false)
    local networkSetEntityInvisibleToNetwork = NetworkSetEntityInvisibleToNetwork
    networkSetEntityInvisibleToNetwork(ped, false)
  end
  savedCoords = nil
  local cam = camera
  if cam then
    local renderScriptCams = RenderScriptCams
    renderScriptCams(false, false, 0, 1, 0)
    local destroyCam = DestroyCam
    destroyCam(cam, false)
    camera = nil
    PlyInCam = false
    carCam = false
    local networkSetInSpectatorMode = NetworkSetInSpectatorMode
    networkSetInSpectatorMode(false, targetPed)
    targetPed = nil
  end
  cb("ok")
end)

RegisterNetEvent("kartik-mdt:client:removeBodycam", function()
  local bodyOverlay = BodyOverlay
  bodyOverlay(false, false)
end)

local function checkBodycam()
  local uiOpen = uiOpen
  if uiOpen then
    return
  end
  inRoomBodycam = true
  local playerData = PlayerData
  if not playerData then
    return
  end
  local isBodycamAllowed = isActionAllowed("bodycam")
  if not isBodycamAllowed then
    return
  end

local sendNuiMessage = SendNUIMessage
local setVisibleData = {}
setVisibleData.action = "setVisible"
setVisibleData.data = true
sendNuiMessage(setVisibleData)
local showBodycamPageData = {}
showBodycamPageData.action = "showBodycamPage"
showBodycamPageData.data = true
sendNuiMessage(showBodycamPageData)
local setData = {}
setData.action = "setData"
setData.data = true
sendNuiMessage(setData)
uiOpen = true
SetNuiFocus(true, true)
SetNuiFocusKeepInput(false)
doAnimation()
openBodycamList = ESCROWSHX1_1