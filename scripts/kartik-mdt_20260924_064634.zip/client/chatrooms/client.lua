local registerNUICallback, callbackEvent
registerNUICallback = RegisterNUICallback
callbackEvent = "chatrooms:fetchUsers"
local function fetchUsers(data, cb)
  local libCallback = lib.callback.await
  local result = libCallback("kartik-mdt:server:fetchOfficers", false, data)
  cb(result)
end
registerNUICallback(callbackEvent, fetchUsers)

registerNUICallback = RegisterNUICallback
callbackEvent = "chatrooms:createChannel"
local function createChannel(data, cb)
  local libCallback = lib.callback.await
  local result = libCallback("kartik-mdt:server:createChannel", false, data)
  cb(result)
end
registerNUICallback(callbackEvent, createChannel)

registerNUICallback = RegisterNUICallback
callbackEvent = "chatrooms:fetchMessages"
local function fetchMessages(data, cb)
  local libCallback = lib.callback.await
  local result = libCallback("kartik-mdt:server:fetchMessages", false, data)
  cb(result)
end
registerNUICallback(callbackEvent, fetchMessages)

registerNUICallback = RegisterNUICallback
callbackEvent = "chatrooms:sendMessage"
local function sendMessage(data, cb)
  local libCallback = lib.callback.await
  local result = libCallback("kartik-mdt:server:sendMessage", false, data)
  cb(result)
end
registerNUICallback(callbackEvent, sendMessage)

registerNUICallback = RegisterNUICallback
callbackEvent = "chatrooms:fetchChannels"
local function fetchChannels(data, cb)
  local libCallback = lib.callback.await
  local result = libCallback("kartik-mdt:server:fetchChannels", false, data)
  cb(result)
end
registerNUICallback(callbackEvent, fetchChannels)

registerNUICallback = RegisterNUICallback
callbackEvent = "chatrooms:inviteMember"
local function inviteMember(data, cb)
  local libCallback = lib.callback.await
  local result = libCallback("kartik-mdt:server:inviteMember", false, data)
  cb(result)
end
registerNUICallback(callbackEvent, inviteMember)

registerNUICallback = RegisterNUICallback
callbackEvent = "chatrooms:kickMember"
local function kickMember(data, cb)
  local libCallback = lib.callback.await
  local result = libCallback("kartik-mdt:server:kickMember", false, data)
  cb(result)
end
registerNUICallback(callbackEvent, kickMember)