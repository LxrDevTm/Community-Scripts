local openCivilianMDT, closeCivilianMDT, registerNuiCallback
function openCivilianMDT()
  local uiOpen = uiOpen
  if uiOpen then
    return
  end
  local sendMessage = SendNUIMessage
  local message = {}
  message.action = "openCivMDT"
  message.data = true
  sendMessage(message)
  uiOpen = true
  local setNuiFocus = SetNuiFocus
  setNuiFocus(true, true)
  local setNuiFocusKeepInput = SetNuiFocusKeepInput
  setNuiFocusKeepInput(false)
end

function closeCivilianMDT()
  local uiOpen = uiOpen
  if not uiOpen then
    return
  end
  local sendMessage = SendNUIMessage
  local message = {}
  message.action = "openCivMDT"
  message.data = false
  sendMessage(message)
  local setNuiFocus = SetNuiFocus
  setNuiFocus(false, false)
end

registerNuiCallback = RegisterNUICallback
local callbackName = "closeCivMDT"
function callback(data, cb)
  closeCivilianMDT()
  cb("ok")
end
registerNuiCallback(callbackName, callback)