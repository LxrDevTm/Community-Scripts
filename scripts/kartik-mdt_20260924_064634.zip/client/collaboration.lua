local currentReportId, currentPage, currentDepartment, reportEditors, changeQueue, lastChangeTime, isProcessingChanges
currentReportId = nil
currentPage = nil
currentDepartment = nil
reportEditors = {}
changeQueue = {}
lastChangeTime = 0
isProcessingChanges = false

function startEditingReport(reportId, page, department)
  if currentReportId then
    stopEditingReport()
  end
  currentReportId = reportId
  currentPage = page
  currentDepartment = department
  local editorData = {}
  editorData.id = PlayerData.citizenid
  editorData.name = PlayerData.name
  editorData.department = PlayerData.jobData.label
  TriggerServerEvent("kartik-mdt:reports:startEditing", reportId, editorData, page, department)
  TriggerServerEvent("kartik-mdt:reports:getActiveEditors", reportId, page, department)
  sendReactMessage({ type = "startCollabEditing", reportId = reportId })
end

function stopEditingReport()
  if currentReportId then
    TriggerServerEvent("kartik-mdt:reports:stopEditing", currentReportId, currentPage, currentDepartment)
    currentReportId = nil
    currentPage = nil
    currentDepartment = nil
    reportEditors = {}
    sendReactMessage({ type = "stopCollabEditing" })
  end
end

function sendReportChanges(reportId, changes, changeType, page, department)
  if currentReportId == reportId and currentPage == page and currentDepartment == department then
    table.insert(changeQueue, { reportId = reportId, changes = changes, changeType = changeType, page = page, department = department, time = GetGameTimer() })
    if not isProcessingChanges then
      processChangeQueue()
    end
  end
end

function processChangeQueue()
  isProcessingChanges = true
  CreateThread(function()
    while #changeQueue > 0 do
      local currentTime = GetGameTimer()
      local change = changeQueue[1]
      if currentTime - lastChangeTime > 500 then
        table.remove(changeQueue, 1)
        TriggerServerEvent("kartik-mdt:reports:updateReport", change.reportId, change.changes, change.changeType, change.page, change.department)
        lastChangeTime = currentTime
      end
      Wait(100)
    end
    isProcessingChanges = false
  end)
end

RegisterNetEvent("kartik-mdt:reports:receiveUpdate")
AddEventHandler("kartik-mdt:reports:receiveUpdate", function(reportId, changes, changeType, timestamp, sourceId, editors)
  if currentReportId == reportId and currentPage == editors.page and currentDepartment == editors.department then
    if sourceId ~= GetPlayerServerId(PlayerId()) then
      sendReactMessage({ type = "collabUpdate", reportId = reportId, changes = changes, changeType = changeType, sourceId = sourceId, timestamp = timestamp, editors = editors })
    end
  end
end)

RegisterNetEvent("kartik-mdt:reports:currentEditors")
AddEventHandler("kartik-mdt:reports:currentEditors", function(reportId, editors)
  reportEditors = editors
  sendReactMessage({ type = "collabEditors", reportId = reportId, editors = editors })
end)

RegisterNetEvent("kartik-mdt:reports:editorJoined")
AddEventHandler("kartik-mdt:reports:editorJoined", function(reportId, editors)
  if currentReportId == reportId then
    reportEditors = editors
    sendReactMessage({ type = "collabEditorJoined", reportId = reportId, editors = editors })
  end
end)

RegisterNetEvent("kartik-mdt:reports:editorLeft")
AddEventHandler("kartik-mdt:reports:editorLeft", function(reportId, editors)
  if currentReportId == reportId then
    reportEditors = editors
    sendReactMessage({ type = "collabEditorLeft", reportId = reportId, editors = editors })
  end
end)

RegisterNUICallback("startEditingReport", function(data, cb)
  startEditingReport(data.reportId, data.page, data.department)
  cb({ success = true })
end)

RegisterNUICallback("stopEditingReport", function(data, cb)
  stopEditingReport()
  cb({ success = true })
end)

RegisterNUICallback("sendReportChanges", function(data, cb)
  sendReportChanges(data.reportId, data.changes, data.changeType, data.page, data.department)
  cb({ success = true })
end)

AddEventHandler("onResourceStop", function(resource)
  if resource == GetCurrentResourceName() then
    stopEditingReport()
  end
end)