local registerNUICallback, callbackName
registerNUICallback = RegisterNUICallback
callbackName = "getCourtCases"
function handleGetCourtCases(data, cb)
  if data then
    local libCallback = lib.callback.await
    local result = libCallback("kartik-mdt:server:getCourtCases", false, data)
    if result then
      cb(result)
    else
      cb(false)
    end
  end
end
registerNUICallback(callbackName, handleGetCourtCases)

registerNUICallback = RegisterNUICallback
callbackName = "createCourtCase"
function handleCreateCourtCase(data, cb)
  if data then
    local libCallback = lib.callback.await
    local result = libCallback("kartik-mdt:server:createCourtCase", false, data)
    if result then
      cb(result)
    else
      cb(false)
    end
  end
end
registerNUICallback(callbackName, handleCreateCourtCase)

registerNUICallback = RegisterNUICallback
callbackName = "updateCourtCaseStatus"
function handleUpdateCourtCaseStatus(data, cb)
  if data then
    local libCallback = lib.callback.await
    local result = libCallback("kartik-mdt:server:updateCourtCaseStatus", false, data)
    if result then
      cb(result)
    else
      cb(false)
    end
  end
end
registerNUICallback(callbackName, handleUpdateCourtCaseStatus)

registerNUICallback = RegisterNUICallback
callbackName = "addCourtCaseNote"
function handleAddCourtCaseNote(data, cb)
  if data then
    local libCallback = lib.callback.await
    local result = libCallback("kartik-mdt:server:addCourtCaseNote", false, data)
    if result then
      cb(result)
    else
      cb(false)
    end
  end
end
registerNUICallback(callbackName, handleAddCourtCaseNote)

registerNUICallback = RegisterNUICallback
callbackName = "deleteCourtCase"
function handleDeleteCourtCase(data, cb)
  if data and data.caseId then
    local libCallback = lib.callback.await
    local result = libCallback("kartik-mdt:server:deleteCourtCase", false, data)
    if result then
      cb(result)
    else
      cb(false)
    end
  end
end
registerNUICallback(callbackName, handleDeleteCourtCase)

registerNUICallback = RegisterNUICallback
callbackName = "getAvailableCourtrooms"
function handleGetAvailableCourtrooms(data, cb)
  local courtrooms = Config.Courtrooms or {}
  local response = { success = true, courtrooms = courtrooms }
  cb(response)
end
registerNUICallback(callbackName, handleGetAvailableCourtrooms)

registerNUICallback = RegisterNUICallback
callbackName = "getCourtCasesForDateRange"
function handleGetCourtCasesForDateRange(data, cb)
  if data then
    local libCallback = lib.callback.await
    local result = libCallback("kartik-mdt:server:getCourtCasesForDateRange", false, data)
    if result then
      cb(result)
    end
  end
end
registerNUICallback(callbackName, handleGetCourtCasesForDateRange)