local trackerBlips = {}
isTrackerOn = false

function createBlip(playerData)
  if not playerData then
    return
  end

  local pid = playerData.pid
  local label = playerData.label
  local job = playerData.job
  local coords = playerData.coords
  local sprite = playerData.sprite
  local callsign = playerData.callsign

  local ped = GetPlayerPed(pid)
  local blip = GetBlipFromEntity(ped)

  if not DoesBlipExist(blip) then
    if NetworkIsPlayerActive(pid) then
      blip = AddBlipForEntity(ped)
    else
      blip = AddBlipForCoord(coords.x, coords.y, coords.z)
    end

    SetBlipSprite(blip, sprite)
    SetBlipShowCone(blip, true)
    SetBlipRotation(blip, math.ceil(coords.w))
    SetBlipScale(blip, Config.BlipScale or 1.0)
    SetBlipColour(blip, Config.Sprites.Job[job] or 2)
    SetBlipAsShortRange(blip, false)

    BeginTextCommandSetBlipName("STRING")
    AddTextComponentString(callsign .. " - " .. label)
    EndTextCommandSetBlipName(blip)

    table.insert(trackerBlips, blip)
  end

  local playerBlip = GetBlipFromEntity(PlayerPedId())
  if playerBlip == blip then
    RemoveBlip(blip)
  end
end

function removeBlips()
  for _, blip in pairs(trackerBlips) do
    RemoveBlip(blip)
  end
  trackerBlips = {}
end

RegisterNetEvent("kartik-mdt:client:changeTrackerStatus", function(status)
  if status then
    isTrackerOn = true
  else
    isTrackerOn = false
    removeBlips()
  end
end)

RegisterNetEvent("kartik-mdt:client:updateBlips", function(players)
  removeBlips()
  if not isTrackerOn then
    return
  end
  if not players then
    return
  end

  for _, player in pairs(players) do
    local pid = GetPlayerFromServerId(player.src)
    local playerData = {
      pid = pid,
      label = player.label,
      job = player.job,
      coords = player.coords,
      sprite = player.sprite,
      callsign = player.callsign,
    }
    createBlip(playerData)
  end
end)