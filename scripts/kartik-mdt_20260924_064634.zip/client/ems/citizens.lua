local registerNUICallback, callbackName, callbackFunction
registerNUICallback = RegisterNUICallback
callbackName = "fetchCitizenEMSReports"
function callbackFunction(data, cb)
  if data then
    local libCallback = lib.callback.await
    local result = libCallback("kartik-mdt:server:fetchCitizenEMSReports", false, data)
    if result then
      cb(result)
    end
  end
end
registerNUICallback(callbackName, callbackFunction)

registerNUICallback = RegisterNUICallback
callbackName = "fetchCitizenEMSIncidentReports"
function callbackFunction(data, cb)
  if data then
    local libCallback = lib.callback.await
    local result = libCallback("kartik-mdt:server:fetchCitizenEMSIncidentReports", false, data)
    if result then
      cb(result)
    end
  end
end
registerNUICallback(callbackName, callbackFunction)