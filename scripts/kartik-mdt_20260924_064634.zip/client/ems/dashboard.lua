local registerNUICallback, callbackEvent
registerNUICallback = RegisterNUICallback
callbackEvent = "fetchEMSAnnouncements"
function handleFetchEMSAnnouncements(data, cb)
  if data then
    local lib = lib
    local awaitCallback = lib.callback.await
    local result = awaitCallback("kartik-mdt:server:fetchEMSAnnouncements", false, data)
    if result then
      cb(result)
    end
  end
end
registerNUICallback(callbackEvent, handleFetchEMSAnnouncements)

registerNUICallback = RegisterNUICallback
callbackEvent = "deleteEMSAnnouncement"
function handleDeleteEMSAnnouncement(data, cb)
  if data then
    local lib = lib
    local awaitCallback = lib.callback.await
    local result = awaitCallback("kartik-mdt:server:deleteEMSAnnouncement", false, data)
    if result then
      cb(result)
    end
  end
end
registerNUICallback(callbackEvent, handleDeleteEMSAnnouncement)

registerNUICallback = RegisterNUICallback
callbackEvent = "editEMSAnnouncement"
function handleEditEMSAnnouncement(data, cb)
  if data then
    local lib = lib
    local awaitCallback = lib.callback.await
    local result = awaitCallback("kartik-mdt:server:editEMSAnnouncement", false, data)
    if result then
      cb(result)
    end
  end
end
registerNUICallback(callbackEvent, handleEditEMSAnnouncement)

registerNUICallback = RegisterNUICallback
callbackEvent = "addEMSAnnouncement"
function handleAddEMSAnnouncement(data, cb)
  if data then
    local lib = lib
    local awaitCallback = lib.callback.await
    local result = awaitCallback("kartik-mdt:server:addEMSAnnouncement", false, data)
    if result then
      cb(result)
    end
  end
end
registerNUICallback(callbackEvent, handleAddEMSAnnouncement)

registerNUICallback = RegisterNUICallback
callbackEvent = "initEMSDashboard"
function handleInitEMSDashboard(data, cb)
  if data then
    local lib = lib
    local awaitCallback = lib.callback.await
    local result = awaitCallback("kartik-mdt:server:initEMSDashboard", false, data)
    if result then
      local configLogo = Config.Logo
      if not configLogo then
        configLogo = {}
      end
      result.jobLogo = configLogo
      cb(result)
    end
  end
end
registerNUICallback(callbackEvent, handleInitEMSDashboard)