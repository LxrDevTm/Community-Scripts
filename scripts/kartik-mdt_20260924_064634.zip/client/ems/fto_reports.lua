local registerNUICallback, callbackName
registerNUICallback = RegisterNUICallback
callbackName = "fetchEMSFTOReports"
function handleFetchReports(data, cb)
  if data then
    local lib = lib
    local result = lib.callback.await("kartik-mdt:server:fetchEMSFTOReports", false, data)
    if result then
      cb(result)
    else
      cb(false)
    end
  end
end
registerNUICallback(callbackName, handleFetchReports)

registerNUICallback = RegisterNUICallback
callbackName = "fetchEMSFTOReportDataByReportId"
function handleFetchReportData(data, cb)
  if data then
    local lib = lib
    local result = lib.callback.await("kartik-mdt:server:fetchEMSFTOReportDataByReportId", false, data)
    if result then
      cb(result)
    else
      cb(false)
    end
  end
end
registerNUICallback(callbackName, handleFetchReportData)

registerNUICallback = RegisterNUICallback
callbackName = "createEMSFTOReport"
function handleCreateReport(data, cb)
  if data then
    local lib = lib
    local result = lib.callback.await("kartik-mdt:server:createEMSFTOReport", false, data)
    if result then
      cb(result)
    else
      cb(false)
    end
  end
end
registerNUICallback(callbackName, handleCreateReport)

registerNUICallback = RegisterNUICallback
callbackName = "saveEMSFTOReport"
function handleSaveReport(data, cb)
  if data then
    local lib = lib
    local result = lib.callback.await("kartik-mdt:server:saveEMSFTOReport", false, data)
    if result then
      cb(result)
    else
      cb(false)
    end
  else
    cb(false)
  end
end
registerNUICallback(callbackName, handleSaveReport)

registerNUICallback = RegisterNUICallback
callbackName = "rejectEMSFTOReport"
function handleRejectReport(data, cb)
  if data then
    local lib = lib
    local result = lib.callback.await("kartik-mdt:server:rejectEMSFTOReport", false, data)
    if result then
      cb(result)
    else
      cb(false)
    end
  else
    cb(false)
  end
end
registerNUICallback(callbackName, handleRejectReport)

registerNUICallback = RegisterNUICallback
callbackName = "approveEMSFTOReport"
function handleApproveReport(data, cb)
  if data then
    local lib = lib
    local result = lib.callback.await("kartik-mdt:server:approveEMSFTOReport", false, data)
    if result then
      cb(result)
    else
      cb(false)
    end
  else
    cb(false)
  end
end
registerNUICallback(callbackName, handleApproveReport)