local registerNUICallback, fetchEMSIncidentsCallback
registerNUICallback = RegisterNUICallback
fetchEMSIncidentsCallback = "fetchEMSIncidents"
function handleFetchEMSIncidents(data, cb)
  if data then
    local lib = lib
    local await = lib.callback.await
    local result = await("kartik-mdt:server:fetchEMSIncidents", false, data)
    if result then
      cb(result)
    else
      cb(false)
    end
  end
end
registerNUICallback(fetchEMSIncidentsCallback, handleFetchEMSIncidents)

local registerNUICallback, fetchEMSIncidentDataByIncidentIdCallback
registerNUICallback = RegisterNUICallback
fetchEMSIncidentDataByIncidentIdCallback = "fetchEMSIncidentDataByIncidentId"
function handleFetchEMSIncidentDataByIncidentId(data, cb)
  if data then
    local lib = lib
    local await = lib.callback.await
    local result = await("kartik-mdt:server:fetchEMSIncidentDataByIncidentId", false, data)
    if result then
      cb(result)
    else
      cb(false)
    end
  end
end
registerNUICallback(fetchEMSIncidentDataByIncidentIdCallback, handleFetchEMSIncidentDataByIncidentId)

local registerNUICallback, addNewEMSIncidentCallback
registerNUICallback = RegisterNUICallback
addNewEMSIncidentCallback = "addNewEMSIncident"
function handleAddNewEMSIncident(data, cb)
  if data then
    local lib = lib
    local await = lib.callback.await
    local result = await("kartik-mdt:server:addNewEMSIncident", false, data)
    if result then
      cb(result)
    else
      cb(false)
    end
  end
end
registerNUICallback(addNewEMSIncidentCallback, handleAddNewEMSIncident)

local registerNUICallback, saveEMSIncidentCallback
registerNUICallback = RegisterNUICallback
saveEMSIncidentCallback = "saveEMSIncident"
function handleSaveEMSIncident(data, cb)
  if data then
    local lib = lib
    local await = lib.callback.await
    local result = await("kartik-mdt:server:saveEMSIncident", false, data)
    if result then
      cb(result)
    else
      cb(false)
    end
  else
    cb(false)
  end
end
registerNUICallback(saveEMSIncidentCallback, handleSaveEMSIncident)

local registerNUICallback, deleteEMSIncidentCallback
registerNUICallback = RegisterNUICallback
deleteEMSIncidentCallback = "deleteEMSIncident"
function handleDeleteEMSIncident(data, cb)
  if data then
    local hasPermission = hasManagePermission()
    if hasPermission then
      local lib = lib
      local await = lib.callback.await
      local result = await("kartik-mdt:server:deleteEMSIncident", false, data)
      if result then
        cb(result)
      else
        local response = {}
        response.success = false
        response.message = "Failed to delete incident."
        cb(response)
      end
    else
      local response = {}
      response.success = false
      response.message = "You do not have permission to delete incidents."
      cb(response)
    end
  end
end
registerNUICallback(deleteEMSIncidentCallback, handleDeleteEMSIncident)