local registerNUICallback, callbackName
registerNUICallback = RegisterNUICallback
callbackName = "fetchMedics"
function handleFetchMedics(data, cb)
  if data then
    local lib = lib
    local result = lib.callback.await("kartik-mdt:server:fetchMedics", false, data)
    if result then
      cb(result)
    end
  end
end
registerNUICallback(callbackName, handleFetchMedics)

registerNUICallback = RegisterNUICallback
callbackName = "fetchMedicDataByMedicId"
function handleFetchMedicDataByMedicId(data, cb)
  if data then
    local lib = lib
    local result = lib.callback.await("kartik-mdt:server:fetchMedicDataByMedicId", false, data)
    if result then
      cb(result)
    else
      cb(false)
    end
  end
end
registerNUICallback(callbackName, handleFetchMedicDataByMedicId)

registerNUICallback = RegisterNUICallback
callbackName = "updateMedicRank"
function handleUpdateMedicRank(data, cb)
  if data then
    local lib = lib
    local result = lib.callback.await("kartik-mdt:server:updateMedicRank", false, data)
    if result then
      cb(result)
    end
  end
end
registerNUICallback(callbackName, handleUpdateMedicRank)

registerNUICallback = RegisterNUICallback
callbackName = "updateMedictags"
function handleUpdateMedictags(data, cb)
  if data then
    local lib = lib
    local result = lib.callback.await("kartik-mdt:server:updateMedictags", false, data)
    if result then
      cb(result)
    end
  end
end
registerNUICallback(callbackName, handleUpdateMedictags)

registerNUICallback = RegisterNUICallback
callbackName = "addNewMedics"
function handleAddNewMedics(data, cb)
  if data then
    local lib = lib
    local result = lib.callback.await("kartik-mdt:server:addNewMedics", false, data)
    if result then
      cb(result)
    end
  end
end
registerNUICallback(callbackName, handleAddNewMedics)

registerNUICallback = RegisterNUICallback
callbackName = "addMedicAssignment"
function handleAddMedicAssignment(data, cb)
  if data then
    local lib = lib
    local result = lib.callback.await("kartik-mdt:server:addOfficerAssignment", false, data)
    if result then
      cb(result)
    end
  end
end
registerNUICallback(callbackName, handleAddMedicAssignment)

registerNUICallback = RegisterNUICallback
callbackName = "fireMedic"
function handleFireMedic(data, cb)
  if data then
    local lib = lib
    local result = lib.callback.await("kartik-mdt:server:fireMedic", false, data)
    if result then
      cb(result)
    end
  end
end
registerNUICallback(callbackName, handleFireMedic)