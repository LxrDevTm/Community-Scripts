local registerNUICallback, callbackName
registerNUICallback = RegisterNUICallback
callbackName = "fetchEMSReports"
function handleFetchEMSReports(data, cb)
  if data then
    local lib = lib
    local result = lib.callback.await("kartik-mdt:server:fetchEMSReports", false, data)
    if result then
      cb(result)
    else
      cb(false)
    end
  end
end
registerNUICallback(callbackName, handleFetchEMSReports)

registerNUICallback = RegisterNUICallback
callbackName = "fetchEMSReportDataByReportId"
function handleFetchEMSReportDataByReportId(data, cb)
  if data then
    local lib = lib
    local result = lib.callback.await("kartik-mdt:server:fetchEMSReportDataByReportId", false, data)
    if result then
      cb(result)
    end
  end
end
registerNUICallback(callbackName, handleFetchEMSReportDataByReportId)

registerNUICallback = RegisterNUICallback
callbackName = "addNewEMSReport"
function handleAddNewEMSReport(data, cb)
  if data then
    local lib = lib
    local result = lib.callback.await("kartik-mdt:server:addNewEMSReport", false, data)
    if result then
      cb(result)
    else
      cb(false)
    end
  end
end
registerNUICallback(callbackName, handleAddNewEMSReport)

registerNUICallback = RegisterNUICallback
callbackName = "saveCurrentEMSReport"
function handleSaveCurrentEMSReport(data, cb)
  if data then
    local lib = lib
    local result = lib.callback.await("kartik-mdt:server:saveCurrentEMSReport", false, data)
    if result then
      cb(result)
    else
      cb(false)
    end
  else
    cb(false)
  end
end
registerNUICallback(callbackName, handleSaveCurrentEMSReport)

registerNUICallback = RegisterNUICallback
callbackName = "deleteEMSReport"
function handleDeleteEMSReport(data, cb)
  if data then
    local lib = lib
    local result = lib.callback.await("kartik-mdt:server:deleteEMSReport", false, data)
    if result then
      cb(result)
    end
  end
end
registerNUICallback(callbackName, handleDeleteEMSReport)

registerNUICallback = RegisterNUICallback
callbackName = "getRecentEMSReports"
function handleGetRecentEMSReports(data, cb)
  if data then
    local lib = lib
    local result = lib.callback.await("kartik-mdt:server:getRecentEMSReports", false, data)
    if result then
      cb(result)
    end
  end
end
registerNUICallback(callbackName, handleGetRecentEMSReports)