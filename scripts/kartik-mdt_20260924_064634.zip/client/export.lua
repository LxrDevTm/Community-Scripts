local registerNUICallback, callbackName
registerNUICallback = RegisterNUICallback
callbackName = "saveImage"
function saveImageCallback(data, cb)
  if data then
    local lib = lib
    local awaitCallback = lib.callback.await
    local result = awaitCallback("kartik-mdt:server:saveImage", false, data)
    if result then
      cb(result)
    end
  end
end
registerNUICallback(callbackName, saveImageCallback)

registerNUICallback = RegisterNUICallback
callbackName = "getExportDepartments"
function getExportDepartmentsCallback(data, cb)
  if data then
    local lib = lib
    local awaitCallback = lib.callback.await
    local result = awaitCallback("kartik-mdt:server:getWebhook", false, data)
    if result then
      local exportData = Config.Exports
      local webhook = result.webhook
      cb({exportData = exportData, webhook = webhook})
    end
  end
end
registerNUICallback(callbackName, getExportDepartmentsCallback)

registerNUICallback = RegisterNUICallback
callbackName = "getServerWebhook"
function getServerWebhookCallback(data, cb)
  if data then
    local lib = lib
    local awaitCallback = lib.callback.await
    local result = awaitCallback("kartik-mdt:server:getWebhook", false, data)
    if result then
      local webhook = result.webhook
      cb({success = true, webhook = webhook})
    end
  end
end
registerNUICallback(callbackName, getServerWebhookCallback)

registerNUICallback = RegisterNUICallback
callbackName = "downloadDutyRecords"
function downloadDutyRecordsCallback(data, cb)
  if data then
    local lib = lib
    local awaitCallback = lib.callback.await
    local result = awaitCallback("kartik-mdt:server:downloadDutyRecords", false, data)
    if result then
      cb(result)
    end
  end
end
registerNUICallback(callbackName, downloadDutyRecordsCallback)

registerNUICallback = RegisterNUICallback
callbackName = "receivePDF"
function receivePDFCallback(data, cb)
  if data then
    local lib = lib
    local awaitCallback = lib.callback.await
    local result = awaitCallback("kartik-mdt:server:receivePDF", false, data)
    if result then
      cb(result)
    end
  end
end
registerNUICallback(callbackName, receivePDFCallback)