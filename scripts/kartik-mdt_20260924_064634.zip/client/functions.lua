local activeBlips, blipData
activeBlips = {}
blipData = {}

function isCoreDetected(core)
  local numResources, resourceIndex, maxIndex, increment
  numResources = GetNumResources()
  numResources = numResources()
  resourceIndex = 0
  maxIndex = numResources - 1
  increment = 1
  for i = resourceIndex, maxIndex, increment do
    local resource = GetResourceByFindIndex(i)
    resource = resource(i)
    if resource == core then
      local resourceState = GetResourceState(resource)
      resourceState = resourceState(resource)
      if "started" == resourceState then
        return true
      end
    end
  end
  return false
end
detectCore = isCoreDetected

function getDepartmentCategory(department)
  local jobCategories, job, category
  jobCategories = Config.Jobs
  for jobName, job in pairs(jobCategories) do
    for _, category in ipairs(job) do
      if department == category then
        return jobName
      end
    end
  end
  return false
end
getDepartmentCategory = getDepartmentCategory

function getPlayerHeading()
  local heading, cache
  heading = GetEntityHeading(cache.ped)
  if heading >= 315 or heading < 45 then
    return "North Bound"
  elseif heading >= 45 and heading < 135 then
    return "West Bound"
  elseif heading >= 135 and heading < 225 then
    return "South Bound"
  elseif heading >= 225 and heading < 315 then
    return "East Bound"
  end
end
GetPlayerHeading = getPlayerHeading

function shouldTriggerNotification()
  local config, currentJob, job
  config = Config
  if config.Debug then
    return true
  end
  currentJob = getCurrentJob()
  currentJob = currentJob.job
  job = config.NoDispatchNotificationJobs[currentJob]
  if job then
    return false
  end
  return true
end
shouldTriggerNotification = shouldTriggerNotification

function getVehicleColor(vehicle)
  local colors, primaryColor, secondaryColor
  colors = GetVehicleColours(vehicle)
  primaryColor, secondaryColor = colors(vehicle)
  local colorConfig = Config.Colors
  primaryColor = tostring(primaryColor)
  secondaryColor = tostring(secondaryColor)
  local primaryColorName = colorConfig[primaryColor]
  local secondaryColorName = colorConfig[secondaryColor]
  if primaryColorName and secondaryColorName then
    return secondaryColorName .. " on " .. primaryColorName
  elseif primaryColorName then
    return primaryColorName
  elseif secondaryColorName then
    return secondaryColorName
  else
    return "Unknown"
  end
end
getVehicleColor = getVehicleColor

function getVehicleDoors(vehicle)
  local doorCount, boneIndex
  doorCount = 0
  local bones = {
    "door_pside_f",
    "door_pside_r",
    "door_dside_f",
    "door_dside_r"
  }
  for _, bone in ipairs(bones) do
    boneIndex = GetEntityBoneIndexByName(vehicle, bone)
    if boneIndex ~= -1 then
      doorCount = doorCount + 1
    end
  end
  if doorCount == 2 then
    return "Two door"
  elseif doorCount == 3 then
    return "Three door"
  elseif doorCount == 4 then
    return "Four door"
  else
    return "unknown"
  end
end
getVehicleDoors = getVehicleDoors

function getVehicleData(vehicle)
  local vehicleData, vehicleClass, vehicleName, vehiclePlate
  vehicleData = {}
  vehicleClass = GetVehicleClass(vehicle)
  local vehicleClasses = {
    [0] = "Compact",
    [1] = "Sedan",
    [2] = "SUVs",
    [3] = "Coupes",
    [4] = "Muscle",
    [5] = "Sport Classic",
    [6] = "Sports",
    [7] = "Super",
    [8] = "Motorcycle",
    [9] = "Offroad",
    [10] = "Industrial",
    [11] = "Utility",
    [12] = "Van",
    [17] = "Service",
    [19] = "Military",
    [20] = "Truck"
  }
  vehicleClass = vehicleClasses[vehicleClass]
  if not vehicleClass then
    vehicleClass = "Unknown"
  end
  vehicleData.class = vehicleClass
  vehicleName = getVehicleDisplayName(GetEntityModel(vehicle))
  vehicleData.name = vehicleName
  vehiclePlate = GetVehicleNumberPlateText(vehicle)
  vehicleData.plate = vehiclePlate
  vehicleData.doors = getVehicleDoors(vehicle)
  vehicleData.color = getVehicleColor(vehicle)
  vehicleData.id = NetworkGetNetworkIdFromEntity(vehicle)
  vehicleData.heading = GetPlayerHeading()
  return vehicleData
end
GetVehicleData = getVehicleData

function getWeaponName()
  local currentWeapon, weaponName
  currentWeapon = GetSelectedPedWeapon(cache.ped)
  local weaponTable = Config.weaponTable
  weaponName = weaponTable[currentWeapon]
  if not weaponName then
    weaponName = getWeaponDisplayName(currentWeapon)
    if not weaponName then
      weaponName = GetLabelText(currentWeapon)
      if not weaponName then
        weaponName = "Unknown"
      end
    end
  end
  return weaponName
end
GetWeaponName = getWeaponName

function isActionAllowed(page)
  local currentJob, jobRank, permissions
  currentJob = getCurrentJob()
  currentJob = currentJob.job
  jobRank = getCurrentJobRank()
  jobRank = jobRank.rank
  if not currentJob then
    return false
  end
  permissions = GetSanitizedPermissions(currentJob, jobRank)
  if permissions then
    local pages = permissions.Pages
    return pages[page]
  end
  return false
end
isActionAllowed = isActionAllowed

function openEvidenceLocker()
  local input, serialNumber
  input = lib.inputDialog("Police Evidence", {"Serial No"})
  if not input then
    return
  end
  serialNumber = input[1]
  if not serialNumber then
    return
  end
  serialNumber = string.lower(tostring(serialNumber))
  local evidenceId = GetEvidenceStashId(serialNumber)
  if evidenceId then
    OpenStash(evidenceId)
  else
    OpenStash("evidence_" .. serialNumber)
  end
end
openEvidenceLocker = openEvidenceLocker

function hasJobAuth(job)
  local currentJob, jobConfig
  currentJob = getCurrentJob()
  currentJob = currentJob.job
  jobConfig = Config.Jobs[job]
  if not jobConfig then
    return false
  end
  for _, authorizedJob in ipairs(jobConfig) do
    if currentJob == authorizedJob then
      return true
    end
  end
  return false
end
HasJobAuth = hasJobAuth

function createBlipData(position, radius, sprite, color, scale)
  local blip, blipRadius
  blip = AddBlipForCoord(position.x, position.y, position.z)
  blipRadius = AddBlipForRadius(position.x, position.y, position.z, radius)
  SetBlipSprite(blip, sprite or 161)
  SetBlipHighDetail(blip, true)
  SetBlipScale(blip, scale or 1.0)
  SetBlipColour(blip, color or 84)
  SetBlipAlpha(blip, 255)
  SetBlipAsShortRange(blip, false)
  SetBlipCategory(blip, 2)
  SetBlipColour(blipRadius, color or 84)
  SetBlipAlpha(blipRadius, 128)
  return blip, blipRadius
end
createBlipData = createBlipData

function createBlip(data)
  local blip, blipRadius, sprite, color, scale
  blip = data.blip
  if not blip then
    return
  end
  sprite = blip.sprite or 161
  color = blip.color or 84
  scale = blip.scale or 1.0
  blip, blipRadius = createBlipData(vector3(data.x, data.y, data.z), blip.radius, sprite, color, scale)
  local length = blip.length * 60000 / 128
  while 128 > 0 do
    Wait(length)
    local alpha = math.max(0, 128 - 1)
    SetBlipAlpha(blipRadius, alpha)
    SetBlipAlpha(blip, alpha)
    alpha = alpha - 1
  end
  RemoveBlip(blipRadius)
  RemoveBlip(blip)
end
createBlip = createBlip

function toggleDuty(onDuty)
  local playerData, citizenId, job
  playerData = {}
  citizenId = PlayerData.citizenid
  playerData.citizenId = citizenId
  playerData.duty = onDuty
  local result = lib.callback.await("kartik-mdt:server:toggleDuty", false, playerData)
  if result then
    local status
    if onDuty then
      status = "on-duty"
    else
      status = "off-duty"
    end
    MDTData.status = status
    if onDuty and Config.SmallDispatch and Config.SmallDispatch.autoToggle then
      ToggleSmallDispatch()
    end
    sendReactMessage({action = "updateDuty", data = result})
  end
end
ToggleDuty = toggleDuty