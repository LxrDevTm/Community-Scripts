local registerNUICallback, fetchLicenseTypesCallback
registerNUICallback = RegisterNUICallback
fetchLicenseTypesCallback = "fetchLicenseTypes"
function fetchLicenseTypes(data, cb)
  if data then
    local licenses = Config.Licenses
    if licenses then
      cb(licenses)
    end
  end
end
registerNUICallback(fetchLicenseTypesCallback, fetchLicenseTypes)

local registerNUICallback, updateCitizenLicenseCallback
registerNUICallback = RegisterNUICallback
updateCitizenLicenseCallback = "updateCitizenLicense"
function updateCitizenLicense(data, cb)
  if data then
    local libCallback = lib.callback.await
    local result = libCallback("kartik-mdt:server:updateCitizenLicense", false, data)
    if result then
      cb(result)
    end
  end
end
registerNUICallback(updateCitizenLicenseCallback, updateCitizenLicense)