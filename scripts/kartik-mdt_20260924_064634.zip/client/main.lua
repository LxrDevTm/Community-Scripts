local MDTData, isFrame, tempShotCoords, hasCustomEvidence, uiOpen
MDTData = {}
isFrame = false
tempShotCoords = nil
hasCustomEvidence = false
uiOpen = false

local Config = Config
local debug = Config.Debug
if debug then
  debug = print
  local message = "MDT Loaded Successfully"
  debug(message)
end

function setupMDTData()
  local PlayerData = PlayerData
  if PlayerData then
    local getCurrentJob = getCurrentJob
    local getCurrentJobRank = getCurrentJobRank
    local job = getCurrentJob()
    local rank = getCurrentJobRank()
    local permissions = Config.Permissions[job.job]
    if not permissions then
      return
    end
    local data = {}
    data.citizenId = PlayerData.citizenid
    data.name = PlayerData.name
    data.department = job.jobLabel
    data.role = rank.rankLabel
    data.grade = rank.rank
    data.hasManagePermission = hasManagePermission()
    data.job = getDepartmentCategory(job.job) or "unknown"
    data.jobName = job.job or "unknown"
    data.departmentLogo = getDepartmentLogo(job.job)
    MDTData = data
    local lib = lib
    local callback = lib.callback
    local await = callback.await
    local result = await("kartik-mdt:server:getOfficerData", false, data)
    if result then
      MDTData.callsign = result.callsign
      MDTData.status = result.status
      MDTData.id = result.id
      MDTData.dutyStatus = result.dutyStatus
      hasCustomEvidence = true
    else
      hasCustomEvidence = false
    end
  end
end

function saveShootingCoords(useCurrentLocation)
  if useCurrentLocation then
    local GetEntityCoords = GetEntityCoords
    local cache = cache
    local ped = cache.ped
    local coords = GetEntityCoords(ped)
    tempShotCoords = coords
  else
    tempShotCoords = nil
  end
end

exports("SaveShootingCoords", saveShootingCoords)

function openMDT(useCurrentLocation)
  local ConfigUtils = Config.Utils
  local mdt = ConfigUtils.mdt
  local itemRequired = mdt.itemRequired
  if itemRequired then
    local HasItem = HasItem
    local item = mdt.item
    if not HasItem(item) then
      return false
    end
  end
  if uiOpen then
    return false
  end
  local PlayerData = PlayerData
  if PlayerData then
    local getCurrentJob = getCurrentJob
    local job = getCurrentJob()
    local permissions = Config.Permissions[job.job]
    if not permissions then
      return false
    end
    local lib = lib
    local callback = lib.callback
    local await = callback.await
    local result = await("kartik-mdt:server:getPermissionData", false, MDTData)
    if result then
      MDTData.permissions = result.permissions
    end
    SendNUIMessage({ action = "setVisible", data = true })
    SendNUIMessage({ action = "openMDT", data = useCurrentLocation })
    uiOpen = true
    SetNuiFocus(true, true)
    SetNuiFocusKeepInput(false)
    doAnimation()
    return true
  end
end

exports("openMDT", openMDT)

if Config.Utils.mdt.useByCommand then
  RegisterCommand(Config.Utils.mdt.command, function()
    openMDT()
  end)
end

if Config.Utils.mdt.enableKeybind then
  RegisterKeyMapping(Config.Utils.mdt.command, "Open MDT", "keyboard", Config.Utils.mdt.keybind)
end

if Config.Utils.dispatch.enableKeybind then
  RegisterKeyMapping(Config.Utils.dispatch.command, "Open Dispatch", "keyboard", Config.Utils.dispatch.keybind)
end

if Config.Utils.bodycam.enableKeybind then
  RegisterKeyMapping(Config.Utils.bodycam.command, "Use Bodycam", "keyboard", Config.Utils.bodycam.keybind)
end

function openUIEditor()
  if uiOpen then
    return
  end
  local PlayerData = PlayerData
  if not PlayerData then
    local next = next
    PlayerData = next(PlayerData)
    if not PlayerData then
      return
    end
  end
  local getCurrentJob = getCurrentJob
  local job = getCurrentJob()
  local permissions = Config.Permissions[job.job]
  if not permissions then
    return false
  end
  SendNUIMessage({ action = "setVisible", data = true })
  SendNUIMessage({ action = "openUIEditor", data = true })
  SetNuiFocus(true, true)
  SetNuiFocusKeepInput(false)
end

RegisterCommand("mdt_settings", function()
  openUIEditor()
end)

function openDispatch()
  local ConfigUtils = Config.Utils
  local dispatch = ConfigUtils.dispatch
  local itemRequired = dispatch.itemRequired
  if itemRequired then
    local HasItem = HasItem
    local item = dispatch.item
    if not HasItem(item) then
      return
    end
  end
  if uiOpen then
    return
  end
  local PlayerData = PlayerData
  if not PlayerData then
    return
  end
  local lib = lib
  local callback = lib.callback
  local await = callback.await
  local result = await("kartik-mdt:server:getPermissionData", false, MDTData)
  if result then
    MDTData.permissions = result.permissions
  end
  local isActionAllowed = isActionAllowed
  local action = "dispatch"
  if not isActionAllowed(action) then
    return
  end
  SendNUIMessage({ action = "setVisible", data = true })
  SendNUIMessage({ action = "showDispatch", data = true })
  SendNUIMessage({ action = "setData", data = true })
  uiOpen = true
  SetNuiFocus(true, true)
  SetNuiFocusKeepInput(false)
  doAnimation()
end

exports("openDispatch", openDispatch)

if Config.Utils.dispatch.useByCommand then
  RegisterCommand(Config.Utils.dispatch.command, function()
    openDispatch()
  end)
end

RegisterCommand("resetmdt", function()
  if not uiOpen then
    return
  end
  SendNUIMessage({ action = "resetMDT", data = true })
  uiOpen = false
  SetNuiFocus(false, false)
end)

function forceCloseUI()
  if not uiOpen then
    return
  end
  SendNUIMessage({ action = "closeFullUI", data = true })
  uiOpen = false
  SetNuiFocus(false, false)
end

function doAnimation()
  local ConfigAnimation = Config.Animation
  local tabletDict = ConfigAnimation.tabletDict
  RequestAnimDict(tabletDict)
  while not HasAnimDictLoaded(tabletDict) do
    Wait(100)
  end
  local tabletProp = ConfigAnimation.tabletProp
  RequestModel(tabletProp)
  while not HasModelLoaded(tabletProp) do
    Wait(100)
  end
  local ped = PlayerPedId()
  local obj = CreateObject(tabletProp, 0.0, 0.0, 0.0, true, true, false)
  tabletObj = obj
  local bone = GetPedBoneIndex(ped, ConfigAnimation.tabletBone)
  AttachEntityToEntity(obj, ped, bone, ConfigAnimation.tabletOffset.x, ConfigAnimation.tabletOffset.y, ConfigAnimation.tabletOffset.z, ConfigAnimation.tabletRot.x, ConfigAnimation.tabletRot.y, ConfigAnimation.tabletRot.z, true, false, false, false, 2, true)
  SetModelAsNoLongerNeeded(tabletProp)
  CreateThread(function()
    while uiOpen do
      Wait(0)
      if not IsEntityPlayingAnim(ped, tabletDict, ConfigAnimation.tabletAnim, 3) then
        TaskPlayAnim(ped, tabletDict, ConfigAnimation.tabletAnim, 3.0, 3.0, -1, 49, 0, 0, 0, 0)
      end
    end
  end)
end

ClearPedSecondaryTask(ESCROWSHX1_3)
Wait(250)
DetachEntity(tabletObj, true, false)
DeleteEntity(tabletObj)

doAnimation = RegisterNUICallback
RegisterNUICallback("setup_permissions", function(data, cb)
  local lib = lib.callback.await
  local result = lib("kartik-mdt:server:getPermissionData", false, MDTData)
  if result then
    MDTData.permissions = result.permissions
  end
  cb("ok")
end)

RegisterNUICallback("initMDTData", function(data, cb)
  if data then
    cb(MDTData)
  else
    setupMDTData()
    if data then
      cb(MDTData)
    else
      lib.notify({title = "No Access", description = "You do not have access to this feature.", type = "error"})
      cb(false)
    end
  end
end)

RegisterNUICallback("toggleDuty", function(data, cb)
  if data then
    TriggerEvent("kartik-mdt:client:updatePlayerDuty")
    cb("ok")
  end
end)

RegisterNUICallback("changeCallsign", function(data, cb)
  if data then
    local lib = lib.callback.await
    local result = lib("kartik-mdt:server:changeCallsign", false, data)
    if result then
      MDTData.callsign = result.callsign
      cb(result)
    end
  end
end)

RegisterNUICallback("hideFrame", function(data, cb)
  cb("ok")
end)

RegisterNUICallback("closeMenu", function(data, cb)
  FreezeEntityPosition(cache.ped, false)
  closeUI()
  cb("ok")
end)

function closeUI()
  SendNUIMessage({action = "forceStopRecording", data = true})
  SetNuiFocus(false, false)
  SetNuiFocusKeepInput(false)
  uiOpen = false
  TriggerScreenblurFadeOut(0)
  RenderScriptCams(false)
  DestroyAllCams(true)
  ClearFocus()
  if inRoomBodycam then
    SetEntityCoords(cache.ped, savedCoords.x, savedCoords.y, savedCoords.z)
    inRoomBodycam = false
    FreezeEntityPosition(cache.ped, false)
    SetEntityVisible(cache.ped, true, false)
    SetEntityCollision(cache.ped, true, true)
    SetEntityInvincible(cache.ped, false)
    NetworkSetEntityInvisibleToNetwork(cache.ped, false)
  end
  savedCoords = nil
  NetworkSetInSpectatorMode(false, PlayerPedId())
end

RegisterNUICallback(GetCurrentResourceName(), function() 
  TriggerServerEvent(GetCurrentResourceName())
end)

RegisterNUICallback("fetchReportsCategory", function(data, cb)
  local departmentCategory = getDepartmentCategory(getCurrentJob().job)
  if departmentCategory then
    cb({reportsCategory = Config.ReportsCategories[departmentCategory] or {}})
  else
    cb({reportsCategory = {}})
  end
end)

function GetPhoneNumber(citizenId)
  local data = {citizenId = citizenId or PlayerData.citizenid}
  local lib = lib.callback.await
  local result = lib("kartik-mdt:server:getPhoneNumber", false, data)
  return result or "Unknown"
end

function getDepartmentLogo(type)
  local logo = "sasplogo.webp"
  for _, v in ipairs(Config.Logo) do
    if v.type == type then
      logo = v.logo
      break
    end
  end
  return logo
end

RegisterNUICallback("fetchJobLogo", function(data, cb)
  if Config.Logo then
    cb({jobLogo = Config.Logo})
  else
    cb({jobLogo = ""})
  end
end)

RegisterNUICallback("setLocale", function(data, cb)
  local locales = lib.getLocales() or {}
  cb(locales)
end)

RegisterNUICallback("getTabletData", function(data, cb)
  local tabletData = {
    TabletTheme = Config.TabletTheme or false,
    CollaborationEditing = Config.CollaborationEditing or false,
    useWebsockets = Config.useWebsockets or false,
    webSocketURL = Config.webSocketURL or "http://localhost:3001",
    hasCustomEvidence = hasCustomEvidence or false,
    vehicleStrikePoints = Config.VehicleStrikePoints or 10
  }
  cb(tabletData)
end)

RegisterNUICallback("getTemplates", function(data, cb)
  cb(Config.EditorTemplates or {})
end)

RegisterNUICallback("setUnitStatus", function(data, cb)
  local lib = lib.callback.await
  local result = lib("kartik-mdt:server:setUnitStatus", false, data)
  if result then
    MDTData.dutyStatus = data.status
    cb(result or {})
  end
end)

RegisterNetEvent("kartik-mdt:client:syncChanges", function(action, data)
  if uiOpen then
    sendReactMessage({action = action, data = data})
  end
end)

RegisterNUICallback("closeUIEditor", function(data, cb)
  if not uiOpen then
    SetNuiFocus(false, false)
  end
  cb("ok")
end)

if Config.KartikLaptop then
  function Config.KartikLaptop()
    local config = Config.AppSettings
    local id = config.id
    local exports = exports["kartik-laptop"]

local registerApp = registerApp
registerApp = registerApp.RegisterApp
local resource = resource
local exports = exports
local config = config
local currentResourceName = GetCurrentResourceName()
local isFrame = false

AddEventHandler("onResourceStart", function(resourceName)
    if resourceName == "kartik-laptop" then
        registerApp()
    end
end)

AddEventHandler("onResourceStop", function(resourceName)
    if resourceName == currentResourceName() then
        local kartikLaptop = exports["kartik-laptop"]
        kartikLaptop.UnregisterApp(kartikLaptop, config.AppSettings.id)
    end
end)

CreateThread(function()
    Wait(2000)
    registerApp()
end)

RegisterNUICallback("setIFrameStatus", function(data, cb)
    isFrame = data.iframe
    cb("ok")
end)

function sendReactMessage(data)
    if isFrame then
        data.iframeId = config.AppSettings.id
        print(data, "Sending React Message")
        local kartikLaptop = exports["kartik-laptop"]
        kartikLaptop.sendReactMessage(kartikLaptop, data)
    else
        SendNUIMessage(data)
    end
end

RegisterNUICallback("photo:takePhoto", function(data, cb)
    CreateMobilePhone(1)
    CellCamActivate(true, true)
    local camViewMode = GetFollowPedCamViewMode()
    SetFollowPedCamViewMode(4)
    Citizen.InvokeNative(2635073306796480568, false)
    SetNuiFocus(false, false)
    SendNUIMessage({ action = "showPhotoCamera", data = true })
    local takingPhoto = true
    while takingPhoto do
        lib.showTextUI("[Enter] Capture  [BACKSPACE] Cancel ")
        if IsControlJustPressed(0, 177) then
            DestroyMobilePhone()
            CellCamActivate(false, false)
            SetFollowPedCamViewMode(camViewMode)
            SetNuiFocus(false, false)
            cb({ status = false })
            lib.hideTextUI()
            takingPhoto = false
        elseif IsControlJustPressed(0, 176) then
            lib.notify({ title = "Camera", description = "Taking photo, please wait...", duration = 5000, type = "info" })
            local cameraApi = lib.callback.await("mdt:server:getCameraApi", false)
            if cameraApi then
                TakeScreenPhoto(cameraApi, function(photo)
                    SendNUIMessage({ action = "showPhotoCamera", data = false })
                    SetNuiFocus(true, true)
                    DestroyMobilePhone()
                    CellCamActivate(false, false)
                    SetFollowPedCamViewMode(camViewMode)
                    lib.setClipboard(photo)
                    cb({ status = true, data = { link = photo } })
                    lib.hideTextUI()
                end)
            else
                SendNUIMessage({ action = "showPhotoCamera", data = false })
                cb({ status = false })
                lib.hideTextUI()
            end
            takingPhoto = false
        end
        HideHudComponentThisFrame(7)
        HideHudComponentThisFrame(8)
        HideHudComponentThisFrame(9)
        HideHudComponentThisFrame(6)
        HideHudComponentThisFrame(19)
        HideHudAndRadarThisFrame()
        Wait(0)
    end
end)