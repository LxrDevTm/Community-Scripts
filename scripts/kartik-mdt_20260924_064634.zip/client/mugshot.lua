local takeMugshot, registerMugshotEvent, loadModel
function takeMugshot(playerId)
  local lib = lib
  local inputDialog = lib.inputDialog
  local mugshotTitle = "Mugshot"
  local inputTable = {}
  local playerIdLabel = "Player ID"
  inputTable[1] = playerIdLabel
  inputDialog = inputDialog(mugshotTitle, inputTable)
  if inputDialog then
    local selectedId = inputDialog[1]
    if selectedId then
      local finalId = playerId or selectedId
      if not playerId then
        finalId = 1
      end
      local triggerServerEvent = TriggerServerEvent
      local takeMugshotEvent = "kartik-mdt:server:takemugshot"
      local playerIdToTake = inputDialog[1]
      local mugshotId = finalId
      triggerServerEvent(takeMugshotEvent, playerIdToTake, mugshotId)
    end
  end
end
openMugshot = takeMugshot
takeMugshot = RegisterNetEvent
registerMugshotEvent = "kartik-mdt:client:takemugshot"
function loadModel(playerId, location)
  local config = Config
  local mugshotConfig = config.Mugshot
  local locations = mugshotConfig.Locations
  local locationIndex = location or 1
  if not location then
    locationIndex = 1
  end
  local locationData = locations[locationIndex]
  local playerPed = PlayerPedId()
  playerPed = playerPed()
  local playerCoords = GetEntityCoords
  playerCoords = playerCoords(playerPed)
  local playerData = PlayerData
  local citizenId = playerData.citizenid
  local playerName = playerData.name
  local attachments = {}
  local loadScaleform = LoadScale
  local scaleform = loadScaleform("mugshot_board_01")
  local createRenderModel = CreateRenderModel
  local renderModel = createRenderModel("ID_Text", "prop_police_id_text")
  local createThread = CreateThread
  function renderMugshot()
    while true do
      local hideHudAndRadar = HideHudAndRadarThisFrame
      hideHudAndRadar()
      local setTextRenderId = SetTextRenderId
      setTextRenderId(renderModel)
      local set2dLayer = Set_2dLayer
      set2dLayer(4)
      local setScriptGfxDrawBehindPausemenu = SetScriptGfxDrawBehindPausemenu
      setScriptGfxDrawBehindPausemenu(1)
      local drawScaleformMovie = DrawScaleformMovie
      drawScaleformMovie(scaleform, 0.405, 0.37, 0.81, 0.74, 255, 255, 255, 255, 0)
      setScriptGfxDrawBehindPausemenu(0)
      local setTextRenderId = SetTextRenderId
      local getDefaultScriptRendertargetRenderId = GetDefaultScriptRendertargetRenderId
      local renderId = getDefaultScriptRendertargetRenderId()
      setTextRenderId(renderId)
      local wait = Wait
      wait(0)
    end
  end
  createThread(renderMugshot)
  local loadModel = loadModel
  loadModel("prop_police_id_board")
  loadModel("prop_police_id_text")
  local loadAnimDict = loadAnimDict
  loadAnimDict("mp_character_creation@lineup@male_a")
  local createObject = CreateObject
  local object = createObject("prop_police_id_board", playerCoords, true, true, false)
  local object2 = createObject("prop_police_id_text", playerCoords, true, true, false)
  local attachEntityToEntity = AttachEntityToEntity
  attachEntityToEntity(object2, object, -1, 4103, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, false, false, false, false, 2, true)
  attachEntityToEntity(object, playerPed, GetPedBoneIndex(playerPed, 28422), 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0, 0, 0, 0, 2, 1)
  local setEntityCoords = SetEntityCoords
  setEntityCoords(playerPed, locationData.MugShotCoords)
  local setEntityHeading = SetEntityHeading
  setEntityHeading(playerPed, locationData.MugShotHeading)
  local setCurrentPedWeapon = SetCurrentPedWeapon
  setCurrentPedWeapon(playerPed, "weapon_unarmed", true)
  local clearPedTasksImmediately = ClearPedTasksImmediately
  clearPedTasksImmediately(playerPed)
  local clearPedWetness = ClearPedWetness
  clearPedWetness(playerPed)
  local clearPedBloodDamage = ClearPedBloodDamage
  clearPedBloodDamage(playerPed)
  local taskPlayAnim = TaskPlayAnim
  taskPlayAnim(playerPed, "mp_character_creation@lineup@male_a", "loop_raised", 8.0, 8.0, -1, 49, 0, false, false, false)
  local freezeEntityPosition = FreezeEntityPosition
  freezeEntityPosition(playerPed, true)
  local setPauseMenuActive = SetPauseMenuActive
  setPauseMenuActive(false)
  local cameraAngles = {}
  cameraAngles[1] = {heading = locationData.MugShotHeading}
  cameraAngles[2] = {heading = locationData.MugShotHeading + 90.0}
  cameraAngles[3] = {heading = locationData.MugShotHeading - 90.0}
  local createCam = CreateCam
  local cam = createCam("DEFAULT_SCRIPTED_CAMERA", 1)
  local setCamCoord = SetCamCoord
  setCamCoord(cam, locationData.CameraPos.pos)
  local setCamRot = SetCamRot
  setCamRot(cam, locationData.CameraPos.rotation, 2)
  local renderScriptCams = RenderScriptCams
  renderScriptCams(1, 0, 0, 1, 1)
  local cameraIndex = 1
  local cameraCount = 3
  local cameraStep = 1
  for cameraIndex = cameraIndex, cameraCount, cameraStep do
    local currentAngle = cameraAngles[cameraIndex]
    local setEntityHeading = SetEntityHeading
    setEntityHeading(playerPed, currentAngle.heading)
    local beginScaleformMovieMethod = BeginScaleformMovieMethod
    beginScaleformMovieMethod(scaleform, "SET_BOARD")
    local pushScaleformMovieMethodParameterString = PushScaleformMovieMethodParameterString
    pushScaleformMovieMethodParameterString("POLICE")
    pushScaleformMovieMethodParameterString(playerName)
    pushScaleformMovieMethodParameterString(citizenId)
    pushScaleformMovieMethodParameterString("Criminal")
    local pushScaleformMovieFunctionParameterInt = PushScaleformMovieFunctionParameterInt
    pushScaleformMovieFunctionParameterInt(0)
    pushScaleformMovieFunctionParameterInt(math.random(100, 999))
    pushScaleformMovieFunctionParameterInt(116)
    local endScaleformMovieMethod = EndScaleformMovieMethod
    endScaleformMovieMethod()
    local wait = Wait
    wait(250)
    local lib = lib
    local callback = lib.callback
    local await = callback.await
    local getMugshotWebhook = "kartik-mdt:server:GetMugshotWebhook"
    local useWebhook = await(getMugshotWebhook, false)
    if useWebhook then
      local promise = promise
      local newPromise = promise.new
      local screenshotPromise = newPromise()
      local screenshotBasic = exports["screenshot-basic"]
      local requestScreenshotUpload = screenshotBasic.requestScreenshotUpload
      local screenshotUrl = tostring(useWebhook)
      local files = {}
      files["files[]"] = { encoding = "jpg" }
      local function uploadScreenshot(data)
        local jsonData = json.decode(data)
        if jsonData then
          local attachments = jsonData.attachments
          if attachments then
            local attachment = attachments[1]
            if attachment then
              table.insert(attachments, attachment.url)
            end
          end
        end
        screenshotPromise:resolve(true)
      end
      requestScreenshotUpload(screenshotUrl, "files[]", files, uploadScreenshot)
      local citizen = Citizen
      local awaitPromise = citizen.Await
      awaitPromise(screenshotPromise)
    end
    wait(100)
  end
  local destroyCam = DestroyCam
  destroyCam(cam, 0)
  renderScriptCams(0, 0, 1, 1, 1)
  clearPedTasksImmediately(playerPed)
  freezeEntityPosition(playerPed, false)
  local deleteObject = DeleteObject
  deleteObject(object)
  deleteObject(object2)
  renderModel = nil
  local triggerServerEvent = TriggerServerEvent
  local mugLogEvent = "kartik-mdt:server:MugLog"
  local playerIdToLog = playerId
  triggerServerEvent(mugLogEvent, playerIdToLog, attachments)
end
takeMugshot(registerMugshotEvent, loadModel)
function loadModel(modelName)
  local requestModel = RequestModel
  local getHashKey = GetHashKey
  local modelHash = getHashKey(modelName)
  requestModel(modelHash)
  while true do
    local hasModelLoaded = HasModelLoaded
    hasModelLoaded = hasModelLoaded(modelHash)
    if hasModelLoaded then
      break
    end
    local wait = Wait
    wait(0)
  end
end
loadModel = loadModel
function loadAnimDict(animDict)
  while true do
    local hasAnimDictLoaded = HasAnimDictLoaded
    hasAnimDictLoaded = hasAnimDictLoaded(animDict)
    if hasAnimDictLoaded then
      break
    end
    local requestAnimDict = RequestAnimDict
    requestAnimDict(animDict)
    local wait = Wait
    wait(0)
  end
end
loadAnimDict = loadAnimDict
function loadScaleform(scaleformName)
  local requestScaleformMovie = RequestScaleformMovie
  local scaleform = requestScaleformMovie(scaleformName)
  while true do
    local hasScaleformMovieLoaded = HasScaleformMovieLoaded
    hasScaleformMovieLoaded = hasScaleformMovieLoaded(scaleform)
    if hasScaleformMovieLoaded then
      break
    end
    local wait = Wait
    wait(0)
  end
  return scaleform
end
loadScaleform = loadScaleform
function createRenderModel(renderModelName, modelName)
  local registerNamedRendertarget = RegisterNamedRendertarget
  local isNamedRendertargetRegistered = IsNamedRendertargetRegistered
  local isNamedRendertargetLinked = IsNamedRendertargetLinked
  local linkNamedRendertarget = LinkNamedRendertarget
  local getNamedRendertargetRenderId = GetNamedRendertargetRenderId
  local renderId = 0
  if not isNamedRendertargetRegistered(renderModelName) then
    registerNamedRendertarget(renderModelName, 0)
  end
  if not isNamedRendertargetLinked(renderModelName) then
    linkNamedRendertarget(renderModelName)
  end
  if isNamedRendertargetRegistered(renderModelName) then
    renderId = getNamedRendertargetRenderId(renderModelName)
  end
  return renderId
end
createRenderModel = createRenderModel