local deepCopy, getSanitizedPermissions, checkPermission

function deepCopy(object)
  local copiedObject = {}
  local pairsIterator = pairs
  local objectType = type
  local objectPairs = pairsIterator(object)
  for key, value in objectPairs do
    local valueType = objectType(value)
    if "table" == valueType then
      copiedObject[key] = deepCopy(value)
    else
      copiedObject[key] = value
    end
  end
  return copiedObject
end

function checkPermission(permission, requiredRank, userPermissions)
  if false == permission then
    return false
  end
  if true == permission then
    return true
  end
  local permissionType = type(permission)
  if "table" ~= permissionType then
    return false
  end
  local permissionRank = permission.rank
  local permissionTags = permission.tags
  local permissionRequire = permission.require
  if not permissionRequire then
    permissionRequire = "any"
  end
  local hasRequiredRank = nil ~= permissionRank and false ~= permissionRank and requiredRank >= permissionRank
  local hasRequiredTags = deepCopy(userPermissions, permissionTags)
  if "all" == permissionRequire then
    return hasRequiredRank or hasRequiredTags
  else
    return hasRequiredRank or not hasRequiredTags
  end
end

function getSanitizedPermissions(permissionName, requiredRank, userPermissions)
  local config = Config
  local permissions = config.Permissions
  local permissionConfig = permissions[permissionName]
  if permissionConfig then
    local pages = permissionConfig.Pages
    if pages then
      if not userPermissions then
        userPermissions = {}
      end
      local copiedPages = deepCopy(pages)
      local pagesIterator = pairs
      local pagesPairs = pagesIterator(pages)
      for pageName, pageConfig in pagesPairs do
        local canView = false
        local canEdit = false
        local viewPermission = pageConfig.view
        if false ~= viewPermission then
          canView = checkPermission(viewPermission, requiredRank, userPermissions)
        end
        local editPermission = pageConfig.edit
        if false ~= editPermission then
          canEdit = checkPermission(editPermission, requiredRank, userPermissions)
        end
        local sanitizedPage = {}
        sanitizedPage.view = canView
        sanitizedPage.edit = canEdit
        copiedPages[pageName] = sanitizedPage
      end
      return { Pages = copiedPages }
    end
  end
  return {}
end

GetSanitizedPermissions = getSanitizedPermissions