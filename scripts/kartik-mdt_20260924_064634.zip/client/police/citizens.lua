local registerNUICallback, fetchCallback, callbackData
registerNUICallback = RegisterNUICallback
fetchCallback = "fetchCitizens"
function handleFetchCitizens(data, cb)
  if data then
    local libCallback = lib.callback.await
    local result = libCallback("kartik-mdt:server:fetchCitizens", false, data)
    if result then
      cb(result)
    else
      cb(false)
    end
  end
end
registerNUICallback(fetchCallback, handleFetchCitizens)

registerNUICallback = RegisterNUICallback
fetchCallback = "fetchCitizenDataByCitizenId"
function handleFetchCitizenDataByCitizenId(data, cb)
  if data then
    local libCallback = lib.callback.await
    local result = libCallback("kartik-mdt:server:fetchCitizenDataByCitizenId", false, data)
    if result then
      cb(result)
    else
      cb(false)
    end
  end
end
registerNUICallback(fetchCallback, handleFetchCitizenDataByCitizenId)

registerNUICallback = RegisterNUICallback
fetchCallback = "addCitizenNote"
function handleAddCitizenNote(data, cb)
  if data then
    local libCallback = lib.callback.await
    local result = libCallback("kartik-mdt:server:addCitizenNote", false, data)
    if result then
      cb(result)
    else
      cb(false)
    end
  end
end
registerNUICallback(fetchCallback, handleAddCitizenNote)

registerNUICallback = RegisterNUICallback
fetchCallback = "deleteNote"
function handleDeleteNote(data, cb)
  if data then
    local libCallback = lib.callback.await
    local result = libCallback("kartik-mdt:server:deleteNote", false, data)
    if result then
      cb(result)
    else
      cb(false)
    end
  end
end
registerNUICallback(fetchCallback, handleDeleteNote)

registerNUICallback = RegisterNUICallback
fetchCallback = "updateCitizenPhoto"
function handleUpdateCitizenPhoto(data, cb)
  if data then
    local libCallback = lib.callback.await
    local result = libCallback("kartik-mdt:server:updateCitizenPhoto", false, data)
    if result then
      cb(result)
    else
      cb(false)
    end
  end
end
registerNUICallback(fetchCallback, handleUpdateCitizenPhoto)

registerNUICallback = RegisterNUICallback
fetchCallback = "fetchCitizenReports"
function handleFetchCitizenReports(data, cb)
  if data then
    local libCallback = lib.callback.await
    local result = libCallback("kartik-mdt:server:fetchCitizenReports", false, data)
    if result then
      cb(result)
    end
  end
end
registerNUICallback(fetchCallback, handleFetchCitizenReports)

registerNUICallback = RegisterNUICallback
fetchCallback = "fetchCitizenIncidentReports"
function handleFetchCitizenIncidentReports(data, cb)
  if data then
    local libCallback = lib.callback.await
    local result = libCallback("kartik-mdt:server:fetchCitizenIncidentReports", false, data)
    if result then
      cb(result)
    end
  end
end
registerNUICallback(fetchCallback, handleFetchCitizenIncidentReports)

registerNUICallback = RegisterNUICallback
fetchCallback = "setHouseWaypoint"
function handleSetHouseWaypoint(data, cb)
  if data then
    local coords = data.coords
    if coords then
      SetNewWaypoint(coords.x, coords.y)
      lib.notify({
        title = "Waypoint Set",
        description = response.message,
        type = "success"
      })
    end
  end
end
registerNUICallback(fetchCallback, handleSetHouseWaypoint)

registerNUICallback = RegisterNUICallback
fetchCallback = "fetchCitizenAssets"
function handleFetchCitizenAssets(data, cb)
  if data then
    local libCallback = lib.callback.await
    local result = libCallback("kartik-mdt:server:fetchCitizenAssets", false, data)
    if result then
      for _, vehicle in pairs(result.vehicles) do
        vehicle.model = getVehicleDisplayName(vehicle.model)
      end
      for _, property in pairs(result.properties) do
        if property.coords then
          local streetName = GetStreetNameAtCoord(property.coords.x, property.coords.y, property.coords.z)
          property.address = GetStreetNameFromHashKey(streetName)
        end
      end
      cb(result)
    end
  end
end
registerNUICallback(fetchCallback, handleFetchCitizenAssets)

registerNUICallback = RegisterNUICallback
fetchCallback = "fetchCitizenInsurances"
function handleFetchCitizenInsurances(data, cb)
  if data then
    local libCallback = lib.callback.await
    local result = libCallback("kartik-mdt:server:fetchCitizenInsurances", false, data)
    if result then
      cb(result)
    end
  end
end
registerNUICallback(fetchCallback, handleFetchCitizenInsurances)

registerNUICallback = RegisterNUICallback
fetchCallback = "fetchCitizenCitations"
function handleFetchCitizenCitations(data, cb)
  if data then
    local libCallback = lib.callback.await
    local result = libCallback("kartik-mdt:server:fetchCitizenCitations", false, data)
    if result then
      cb(result)
    end
  end
end
registerNUICallback(fetchCallback, handleFetchCitizenCitations)

registerNUICallback = RegisterNUICallback
fetchCallback = "fetchCitizenWarrants"
function handleFetchCitizenWarrants(data, cb)
  if data then
    local libCallback = lib.callback.await
    local result = libCallback("kartik-mdt:server:fetchCitizenWarrants", false, data)
    if result then
      cb(result)
    end
  end
end
registerNUICallback(fetchCallback, handleFetchCitizenWarrants)

registerNUICallback = RegisterNUICallback
fetchCallback = "updateCitizenDangerStatus"
function handleUpdateCitizenDangerStatus(data, cb)
  if data then
    local libCallback = lib.callback.await
    local result = libCallback("kartik-mdt:server:updateCitizenDangerStatus", false, data)
    if result then
      cb(result)
    end
  end
end
registerNUICallback(fetchCallback, handleUpdateCitizenDangerStatus)

registerNUICallback = RegisterNUICallback
fetchCallback = "updateCitizenBiometric"
function handleUpdateCitizenBiometric(data, cb)
  if data then
    local libCallback = lib.callback.await
    local result = libCallback("kartik-mdt:server:updateCitizenBiometric", false, data)
    if result then
      cb(result)
    end
  end
end
registerNUICallback(fetchCallback, handleUpdateCitizenBiometric)

registerNUICallback = RegisterNUICallback
fetchCallback = "updateCitizenName"
function handleUpdateCitizenName(data, cb)
  if data then
    local libCallback = lib.callback.await
    local result = libCallback("kartik-mdt:server:updateCitizenName", false, data)
    if result then
      cb(result)
    end
  end
end
registerNUICallback(fetchCallback, handleUpdateCitizenName)