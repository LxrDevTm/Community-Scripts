local registerNUICallback, fetchCriminalCodesCallback
registerNUICallback = RegisterNUICallback
fetchCriminalCodesCallback = function(data, cb)
  local libCallback, result
  if data then
    libCallback = lib.callback.await
    result = libCallback("kartik-mdt:server:fetchCriminalCodes", false, data)
    if result then
      result.category = Config.CriminalCodeCategory
      cb(result)
    end
  end
end
registerNUICallback("fetchCriminalCodes", fetchCriminalCodesCallback)

local registerNUICallback, fetchAllCriminalCodesCallback
registerNUICallback = RegisterNUICallback
fetchAllCriminalCodesCallback = function(data, cb)
  local libCallback, result
  if data then
    libCallback = lib.callback.await
    result = libCallback("kartik-mdt:server:fetchAllCriminalCodes", false, data)
    if result then
      cb(result)
    end
  end
end
registerNUICallback("fetchAllCriminalCodes", fetchAllCriminalCodesCallback)

local registerNUICallback, fetchCriminalCodeByIdCallback
registerNUICallback = RegisterNUICallback
fetchCriminalCodeByIdCallback = function(data, cb)
  local libCallback, result
  if data then
    libCallback = lib.callback.await
    result = libCallback("kartik-mdt:server:fetchCriminalCodeById", false, data)
    if result then
      cb(result)
    else
      cb(false)
    end
  end
end
registerNUICallback("fetchCriminalCodeById", fetchCriminalCodeByIdCallback)

local registerNUICallback, addCriminalCodeCallback
registerNUICallback = RegisterNUICallback
addCriminalCodeCallback = function(data, cb)
  local libCallback, result
  if data then
    libCallback = lib.callback.await
    result = libCallback("kartik-mdt:server:addCriminalCode", false, data)
    if result then
      cb(result)
    else
      cb(false)
    end
  end
end
registerNUICallback("addCriminalCode", addCriminalCodeCallback)

local registerNUICallback, updateCriminalCodeCallback
registerNUICallback = RegisterNUICallback
updateCriminalCodeCallback = function(data, cb)
  local libCallback, result
  if data then
    libCallback = lib.callback.await
    result = libCallback("kartik-mdt:server:updateCriminalCode", false, data)
    if result then
      cb(result)
    else
      cb(false)
    end
  end
end
registerNUICallback("updateCriminalCode", updateCriminalCodeCallback)

local registerNUICallback, deleteCriminalCodeCallback
registerNUICallback = RegisterNUICallback
deleteCriminalCodeCallback = function(data, cb)
  local libCallback, result
  if data then
    libCallback = lib.callback.await
    result = libCallback("kartik-mdt:server:deleteCriminalCode", false, data)
    if result then
      cb(result)
    end
  end
end
registerNUICallback("deleteCriminalCode", deleteCriminalCodeCallback)