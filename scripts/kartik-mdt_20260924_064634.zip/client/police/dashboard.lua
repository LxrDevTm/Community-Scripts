local registerNUICallback, callbackName
registerNUICallback = RegisterNUICallback
callbackName = "fetchAnnouncements"
function fetchAnnouncements(data, cb)
  if data then
    local lib = lib
    local result = lib.callback.await("kartik-mdt:server:fetchAnnouncements", false, data)
    if result then
      cb(result)
    end
  end
end
registerNUICallback(callbackName, fetchAnnouncements)

registerNUICallback = RegisterNUICallback
callbackName = "initPoliceDashboard"
function initPoliceDashboard(data, cb)
  if data then
    local lib = lib
    local result = lib.callback.await("kartik-mdt:server:initPoliceDashboard", false, data)
    if result then
      local config = Config
      local logo = config.Logo
      if not logo then
        logo = {}
      end
      result.jobLogo = logo
      cb(result)
    end
  end
end
registerNUICallback(callbackName, initPoliceDashboard)

registerNUICallback = RegisterNUICallback
callbackName = "deleteAnnouncement"
function deleteAnnouncement(data, cb)
  if data then
    local lib = lib
    local result = lib.callback.await("kartik-mdt:server:deleteAnnouncement", false, data)
    if result then
      cb(result)
    end
  end
end
registerNUICallback(callbackName, deleteAnnouncement)

registerNUICallback = RegisterNUICallback
callbackName = "editAnnouncement"
function editAnnouncement(data, cb)
  if data then
    local lib = lib
    local result = lib.callback.await("kartik-mdt:server:editAnnouncement", false, data)
    if result then
      cb(result)
    end
  end
end
registerNUICallback(callbackName, editAnnouncement)

registerNUICallback = RegisterNUICallback
callbackName = "addAnnouncement"
function addAnnouncement(data, cb)
  if data then
    local lib = lib
    local result = lib.callback.await("kartik-mdt:server:addAnnouncement", false, data)
    if result then
      cb(result)
    end
  end
end
registerNUICallback(callbackName, addAnnouncement)

registerNUICallback = RegisterNUICallback
callbackName = "fetchActiveWarrants"
function fetchActiveWarrants(data, cb)
  if data then
    local lib = lib
    local result = lib.callback.await("kartik-mdt:server:fetchActiveWarrants", false, data)
    if result then
      cb(result)
    end
  end
end
registerNUICallback(callbackName, fetchActiveWarrants)

registerNUICallback = RegisterNUICallback
callbackName = "fetchWantedVehicles"
function fetchWantedVehicles(data, cb)
  if data then
    local lib = lib
    local result = lib.callback.await("kartik-mdt:server:fetchWantedVehicles", false, data)
    if result then
      for _, vehicle in pairs(result.vehiclesData) do
        vehicle.model = getVehicleDisplayName(vehicle.model)
      end
      cb(result)
    end
  end
end
registerNUICallback(callbackName, fetchWantedVehicles)

registerNUICallback = RegisterNUICallback
callbackName = "getRecentReports"
function getRecentReports(data, cb)
  if data then
    local lib = lib
    local result = lib.callback.await("kartik-mdt:server:getRecentReports", false, data)
    if result then
      cb(result)
    end
  end
end
registerNUICallback(callbackName, getRecentReports)