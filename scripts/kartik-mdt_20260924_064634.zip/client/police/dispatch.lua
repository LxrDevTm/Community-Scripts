local registerNUICallback, registerNetEvent
dispatchSilent = false

registerNUICallback = RegisterNUICallback
local fetchActiveUnitsCallback = function(data, cb)
  local lib = lib
  local callback = lib.callback
  local await = callback.await
  local result = await("kartik-mdt:server:fetchActiveUnitsHere", false, data)
  if result then
    cb(result)
  end
end
registerNUICallback("fetchActiveUnits", fetchActiveUnitsCallback)

registerNUICallback = RegisterNUICallback
local getRadioChannelsCallback = function(data, cb)
  local lib = lib
  local callback = lib.callback
  local await = callback.await
  local result = await("kartik-mdt:server:getRadioChannels", false, data)
  if result then
    cb(result)
  end
end
registerNUICallback("getRadioChannels", getRadioChannelsCallback)

registerNUICallback = RegisterNUICallback
local createRadioChannelsCallback = function(data, cb)
  local lib = lib
  local callback = lib.callback
  local await = callback.await
  local result = await("kartik-mdt:server:createRadioChannels", false, data)
  if result then
    cb(result)
  end
end
registerNUICallback("createRadioChannels", createRadioChannelsCallback)

registerNUICallback = RegisterNUICallback
local joinLeaveRadioCallback = function(data, cb)
  local lib = lib
  local callback = lib.callback
  local await = callback.await
  local result = await("kartik-mdt:server:joinLeaveRadio", false, data)
  if result then
    cb(result)
  end
end
registerNUICallback("joinLeaveRadio", joinLeaveRadioCallback)

registerNUICallback = RegisterNUICallback
local assignRadioNumberCallback = function(data, cb)
  local lib = lib
  local callback = lib.callback
  local await = callback.await
  local result = await("kartik-mdt:server:assignRadioNumber", false, data)
  if result then
    cb(result)
  end
end
registerNUICallback("assignRadioNumber", assignRadioNumberCallback)

registerNUICallback = RegisterNUICallback
local renameChannelNameCallback = function(data, cb)
  local lib = lib
  local callback = lib.callback
  local await = callback.await
  local result = await("kartik-mdt:server:renameChannelName", false, data)
  if result then
    cb(result)
  end
end
registerNUICallback("renameChannelName", renameChannelNameCallback)

registerNUICallback = RegisterNUICallback
local deleteRadioChannelCallback = function(data, cb)
  local lib = lib
  local callback = lib.callback
  local await = callback.await
  local result = await("kartik-mdt:server:deleteRadioChannel", false, data)
  if result then
    cb(result)
  end
end
registerNUICallback("deleteRadioChannel", deleteRadioChannelCallback)

registerNUICallback = RegisterNUICallback
local getActiveIncidentsCallback = function(data, cb)
  local lib = lib
  local callback = lib.callback
  local await = callback.await
  local result = await("kartik-mdt:server:getActiveIncidents", false, data)
  if result then
    for _, incident in pairs(result.incidents) do
      if not incident.location then
        local streetName = GetStreetNameAtCoord(incident.x, incident.y, incident.z)
        local streetNameFromHashKey = GetStreetNameFromHashKey(streetName)
        incident.location = streetNameFromHashKey
      end
    end
    cb(result)
  end
end
registerNUICallback("getActiveIncidents", getActiveIncidentsCallback)

registerNUICallback = RegisterNUICallback
local attachUnitToIncidentCallback = function(data, cb)
  local lib = lib
  local callback = lib.callback
  local await = callback.await
  local result = await("kartik-mdt:server:attachUnitToIncident", false, data)
  if result then
    cb(result)
  end
end
registerNUICallback("attachUnitToIncident", attachUnitToIncidentCallback)

registerNUICallback = RegisterNUICallback
local detachUnitCallback = function(data, cb)
  local lib = lib
  local callback = lib.callback
  local await = callback.await
  local result = await("kartik-mdt:server:detachUnit", false, data)
  if result then
    cb(result)
  end
end
registerNUICallback("detachUnit", detachUnitCallback)

registerNUICallback = RegisterNUICallback
local deleteDispatchIncidentCallback = function(data, cb)
  local lib = lib
  local callback = lib.callback
  local await = callback.await
  local result = await("kartik-mdt:server:deleteDispatchIncident", false, data)
  if result then
    cb(result)
  end
end
registerNUICallback("deleteDispatchIncident", deleteDispatchIncidentCallback)

registerNUICallback = RegisterNUICallback
local setWaypointCallback = function(data, cb)
  if data.x and data.y then
    SetNewWaypoint(data.x, data.y)
    cb({ success = true })
  end
end
registerNUICallback("setWaypoint", setWaypointCallback)

registerNetEvent = RegisterNetEvent
local sendDispatchNotificationEvent = function(data)
  if IsPauseMenuActive() then return end
  if dispatchSilent then return end
  if data then
    SendNUIMessage({ action = "addDispatchCall", data = data })
    if data.sound then
      PlaySound(data.sound)
    end
    if data.blip then
      createBlip(data)
    end
  end
end
registerNetEvent("kartik-mdt:client:sendDispatchNotification", sendDispatchNotificationEvent)

registerNetEvent = RegisterNetEvent
local sendReplyDispatchNotificationEvent = function(data)
  if data then
    SendNUIMessage({ action = "showDispatchCall", data = data })
  end
end
registerNetEvent("kartik-mdt:client:sendReplyDispatchNotification", sendReplyDispatchNotificationEvent)

registerNUICallback = RegisterNUICallback
local attachUnitToUnitCallback = function(data, cb)
  local lib = lib
  local callback = lib.callback
  local await = callback.await
  local result = await("kartik-mdt:server:attachUnitToUnit", false, data)
  if result then
    cb(result)
  end
end
registerNUICallback("attachUnitToUnit", attachUnitToUnitCallback)

registerNUICallback = RegisterNUICallback
local detachUnitFromUnitCallback = function(data, cb)
  local lib = lib
  local callback = lib.callback
  local await = callback.await
  local result = await("kartik-mdt:server:detachUnitFromUnit", false, data)
  if result then
    cb(result)
  end
end
registerNUICallback("detachUnitFromUnit", detachUnitFromUnitCallback)

registerNUICallback = RegisterNUICallback
local getUnitAttachmentsCallback = function(data, cb)
  local lib = lib
  local callback = lib.callback
  local await = callback.await
  local result = await("kartik-mdt:server:GetUnitAttachments", false, data)
  if result then
    cb(result)
  end
end
registerNUICallback("getUnitAttachments", getUnitAttachmentsCallback)

registerNUICallback = RegisterNUICallback
local fetchDispatchSilentModeCallback = function(data, cb)
  cb(dispatchSilent)
end
registerNUICallback("fetchDispatchSilentMode", fetchDispatchSilentModeCallback)

registerNUICallback = RegisterNUICallback
local setDispatchSilentModeCallback = function(data, cb)
  if data then
    dispatchSilent = data.isSilent
    cb("ok")
  end
end
registerNUICallback("setDispatchSilentMode", setDispatchSilentModeCallback)