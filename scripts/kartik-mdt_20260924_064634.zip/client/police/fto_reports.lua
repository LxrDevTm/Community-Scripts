local registerNUICallback, fetchFTOCategoriesCallback
registerNUICallback = RegisterNUICallback
fetchFTOCategoriesCallback = function(data, cb)
  local departmentCategory = getDepartmentCategory
  local currentJob = getCurrentJob()
  currentJob = currentJob.job
  departmentCategory = departmentCategory(currentJob)
  if departmentCategory then
    local categories = Config.FTOReportsCategories
    categories = categories[departmentCategory]
    if not categories then
      categories = {}
    end
    cb(categories)
  else
    cb({})
  end
end
registerNUICallback("fetchFTOCategories", fetchFTOCategoriesCallback)

local registerNUICallback, fetchFTOReportsCallback
registerNUICallback = RegisterNUICallback
fetchFTOReportsCallback = function(data, cb)
  if data then
    local lib = lib
    local callback = lib.callback
    local await = callback.await
    local result = await("kartik-mdt:server:fetchFTOReports", false, data)
    if result then
      cb(result)
    else
      cb(false)
    end
  end
end
registerNUICallback("fetchFTOReports", fetchFTOReportsCallback)

local registerNUICallback, fetchFTOReportDataByReportIdCallback
registerNUICallback = RegisterNUICallback
fetchFTOReportDataByReportIdCallback = function(data, cb)
  if data then
    local lib = lib
    local callback = lib.callback
    local await = callback.await
    local result = await("kartik-mdt:server:fetchFTOReportDataByReportId", false, data)
    if result then
      cb(result)
    else
      cb(false)
    end
  end
end
registerNUICallback("fetchFTOReportDataByReportId", fetchFTOReportDataByReportIdCallback)

local registerNUICallback, createFTOReportCallback
registerNUICallback = RegisterNUICallback
createFTOReportCallback = function(data, cb)
  if data then
    local lib = lib
    local callback = lib.callback
    local await = callback.await
    local result = await("kartik-mdt:server:createFTOReport", false, data)
    if result then
      cb(result)
    else
      cb(false)
    end
  end
end
registerNUICallback("createFTOReport", createFTOReportCallback)

local registerNUICallback, saveFTOReportCallback
registerNUICallback = RegisterNUICallback
saveFTOReportCallback = function(data, cb)
  if data then
    local lib = lib
    local callback = lib.callback
    local await = callback.await
    local result = await("kartik-mdt:server:saveFTOReport", false, data)
    if result then
      cb(result)
    else
      cb(false)
    end
  else
    cb(false)
  end
end
registerNUICallback("saveFTOReport", saveFTOReportCallback)

local registerNUICallback, rejectFTOReportCallback
registerNUICallback = RegisterNUICallback
rejectFTOReportCallback = function(data, cb)
  if data then
    local lib = lib
    local callback = lib.callback
    local await = callback.await
    local result = await("kartik-mdt:server:rejectFTOReport", false, data)
    if result then
      cb(result)
    else
      cb(false)
    end
  else
    cb(false)
  end
end
registerNUICallback("rejectFTOReport", rejectFTOReportCallback)

local registerNUICallback, approveFTOReportCallback
registerNUICallback = RegisterNUICallback
approveFTOReportCallback = function(data, cb)
  if data then
    local lib = lib
    local callback = lib.callback
    local await = callback.await
    local result = await("kartik-mdt:server:approveFTOReport", false, data)
    if result then
      cb(result)
    else
      cb(false)
    end
  else
    cb(false)
  end
end
registerNUICallback("approveFTOReport", approveFTOReportCallback)