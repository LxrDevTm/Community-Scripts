local registerNUICallback, callbackName
registerNUICallback = RegisterNUICallback
callbackName = "fetchIncidents"
function handleFetchIncidents(data, cb)
  if data then
    local lib = lib
    local await = lib.callback.await
    local result = await("kartik-mdt:server:fetchIncidents", false, data)
    if result then
      cb(result)
    else
      cb(false)
    end
  end
end
registerNUICallback(callbackName, handleFetchIncidents)

registerNUICallback = RegisterNUICallback
callbackName = "fetchIncidentDataByIncidentId"
function handleFetchIncidentDataByIncidentId(data, cb)
  if data then
    local lib = lib
    local await = lib.callback.await
    local result = await("kartik-mdt:server:fetchIncidentDataByIncidentId", false, data)
    if result then
      cb(result)
    else
      cb(false)
    end
  end
end
registerNUICallback(callbackName, handleFetchIncidentDataByIncidentId)

registerNUICallback = RegisterNUICallback
callbackName = "addNewIncident"
function handleAddNewIncident(data, cb)
  if data then
    local lib = lib
    local await = lib.callback.await
    local result = await("kartik-mdt:server:addNewIncident", false, data)
    if result then
      cb(result)
    else
      cb(false)
    end
  end
end
registerNUICallback(callbackName, handleAddNewIncident)

registerNUICallback = RegisterNUICallback
callbackName = "saveIncident"
function handleSaveIncident(data, cb)
  if data then
    local lib = lib
    local await = lib.callback.await
    local result = await("kartik-mdt:server:saveIncident", false, data)
    if result then
      cb(result)
    else
      cb(false)
    end
  else
    cb(false)
  end
end
registerNUICallback(callbackName, handleSaveIncident)

registerNUICallback = RegisterNUICallback
callbackName = "deleteIncident"
function handleDeleteIncident(data, cb)
  if data then
    local hasPermission = hasManagePermission()
    if hasPermission then
      local lib = lib
      local await = lib.callback.await
      local result = await("kartik-mdt:server:deleteIncident", false, data)
      if result then
        cb(result)
      else
        local response = {}
        response.success = false
        response.message = "Failed to delete incident."
        cb(response)
      end
    else
      local response = {}
      response.success = false
      response.message = "You do not have permission to delete incidents."
      cb(response)
    end
  end
end
registerNUICallback(callbackName, handleDeleteIncident)