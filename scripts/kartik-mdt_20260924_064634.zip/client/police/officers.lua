local registerNUICallback, fetchOfficersCallback
registerNUICallback = RegisterNUICallback
fetchOfficersCallback = function(data, cb)
  local libCallback, result
  if data then
    libCallback = lib.callback.await
    result = libCallback("kartik-mdt:server:fetchOfficers", false, data)
    if result then
      cb(result)
    end
  end
end
registerNUICallback("fetchOfficers", fetchOfficersCallback)

local registerNUICallback, fetchOfficerDataByOfficerIdCallback
registerNUICallback = RegisterNUICallback
fetchOfficerDataByOfficerIdCallback = function(data, cb)
  local libCallback, result
  if data then
    libCallback = lib.callback.await
    result = libCallback("kartik-mdt:server:fetchOfficerDataByOfficerId", false, data)
    if result then
      cb(result)
    else
      cb(false)
    end
  end
end
registerNUICallback("fetchOfficerDataByOfficerId", fetchOfficerDataByOfficerIdCallback)

local registerNUICallback, updateOfficerRankCallback
registerNUICallback = RegisterNUICallback
updateOfficerRankCallback = function(data, cb)
  local hasPermission, libCallback, result
  if data then
    hasPermission = hasManagePermission()
    if hasPermission then
      libCallback = lib.callback.await
      result = libCallback("kartik-mdt:server:updateOfficerRank", false, data)
      if result then
        cb(result)
      end
    else
      cb({ success = false, message = "You do not have permission to update officer ranks." })
    end
  end
end
registerNUICallback("updateOfficerRank", updateOfficerRankCallback)

local registerNUICallback, addNewOfficersCallback
registerNUICallback = RegisterNUICallback
addNewOfficersCallback = function(data, cb)
  local hasPermission, libCallback, result
  if data then
    hasPermission = hasManagePermission()
    if hasPermission then
      libCallback = lib.callback.await
      result = libCallback("kartik-mdt:server:addNewOfficers", false, data)
      if result then
        cb(result)
      end
    else
      cb({ success = false, message = "You do not have permission to add new officers." })
    end
  end
end
registerNUICallback("addNewOfficers", addNewOfficersCallback)

local registerNUICallback, addOfficerAssignmentCallback
registerNUICallback = RegisterNUICallback
addOfficerAssignmentCallback = function(data, cb)
  local libCallback, result
  if data then
    libCallback = lib.callback.await
    result = libCallback("kartik-mdt:server:addOfficerAssignment", false, data)
    if result then
      cb(result)
    end
  end
end
registerNUICallback("addOfficerAssignment", addOfficerAssignmentCallback)

local registerNUICallback, updateOfficerTagsCallback
registerNUICallback = RegisterNUICallback
updateOfficerTagsCallback = function(data, cb)
  local libCallback, result
  if data then
    libCallback = lib.callback.await
    result = libCallback("kartik-mdt:server:updateOfficertags", false, data)
    if result then
      cb(result)
    end
  end
end
registerNUICallback("updateOfficertags", updateOfficerTagsCallback)

local registerNUICallback, fireOfficerCallback
registerNUICallback = RegisterNUICallback
fireOfficerCallback = function(data, cb)
  local hasPermission, libCallback, result
  if data then
    hasPermission = hasManagePermission()
    if hasPermission then
      libCallback = lib.callback.await
      result = libCallback("kartik-mdt:server:fireOfficer", false, data)
      if result then
        cb(result)
      end
    else
      cb({ success = false, message = "You do not have permission to fire officers." })
    end
  end
end
registerNUICallback("fireOfficer", fireOfficerCallback)

local registerNUICallback, getDepartmentsCallback
registerNUICallback = RegisterNUICallback
getDepartmentsCallback = function(data, cb)
  local jobs, currentJob, departmentCategory, departments
  if data then
    jobs = Jobs
    if jobs then
      currentJob = getCurrentJob()
      currentJob = currentJob.job
      departmentCategory = getDepartmentCategory(currentJob)
      departments = {}
      for _, job in pairs(Config.Jobs[departmentCategory]) do
        table.insert(departments, Jobs[job])
      end
      cb(departments)
    else
      cb(nil)
    end
  else
    cb(nil)
  end
end
registerNUICallback("getDepartments", getDepartmentsCallback)

local registerNUICallback, fetchTagsCallback
registerNUICallback = RegisterNUICallback
fetchTagsCallback = function(data, cb)
  local departmentCategory, tags
  if data then
    departmentCategory = getDepartmentCategory(PlayerData.jobData.name)
    tags = Config.Tags[departmentCategory]
    if tags then
      cb(tags)
    else
      cb({})
    end
  else
    cb({})
  end
end
registerNUICallback("fetchTags", fetchTagsCallback)