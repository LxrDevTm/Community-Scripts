local registerNUICallback = RegisterNUICallback
local fetchReportsCallback = "fetchReports"
local function handleFetchReports(data, cb)
  if data then
    local lib = lib
    local callback = lib.callback.await
    local result = callback("kartik-mdt:server:fetchReports", false, data)
    if result then
      cb(result)
    else
      cb(false)
    end
  end
end
registerNUICallback(fetchReportsCallback, handleFetchReports)

local fetchReportDataByReportIdCallback = "fetchReportDataByReportId"
local function handleFetchReportDataByReportId(data, cb)
  if data then
    local lib = lib
    local callback = lib.callback.await
    local result = callback("kartik-mdt:server:fetchReportDataByReportId", false, data)
    if result then
      cb(result)
    else
      cb(false)
    end
  end
end
registerNUICallback(fetchReportDataByReportIdCallback, handleFetchReportDataByReportId)

local fetchLockerItemsCallback = "fetchLockerItems"
local function handleFetchLockerItems(data, cb)
  if data then
    local lib = lib
    local callback = lib.callback.await
    local result = callback("kartik-mdt:server:fetchLockerItems", false, data)
    if result then
      for _, item in pairs(result.lockerItems) do
        item.id = _
        item.imageUrl = GetItemImage(item.name)
      end
      cb(result)
    else
      cb(false)
    end
  end
end
registerNUICallback(fetchLockerItemsCallback, handleFetchLockerItems)

local addNewReportCallback = "addNewReport"
local function handleAddNewReport(data, cb)
  if data then
    local lib = lib
    local callback = lib.callback.await
    local result = callback("kartik-mdt:server:addNewReport", false, data)
    if result then
      cb(result)
    else
      cb(false)
    end
  end
end
registerNUICallback(addNewReportCallback, handleAddNewReport)

local saveCurrentReportCallback = "saveCurrentReport"
local function handleSaveCurrentReport(data, cb)
  if data then
    local lib = lib
    local callback = lib.callback.await
    local result = callback("kartik-mdt:server:saveCurrentReport", false, data)
    if result then
      cb(result)
    else
      cb(false)
    end
  else
    cb(false)
  end
end
registerNUICallback(saveCurrentReportCallback, handleSaveCurrentReport)

local deleteReportCallback = "deleteReport"
local function handleDeleteReport(data, cb)
  if data then
    if hasManagePermission() then
      local lib = lib
      local callback = lib.callback.await
      local result = callback("kartik-mdt:server:deleteReport", false, data)
      if result then
        cb(result)
      else
        cb({ success = false, message = "Failed to delete report." })
      end
    else
      cb({ success = false, message = "You do not have permission to delete reports." })
    end
  end
end
registerNUICallback(deleteReportCallback, handleDeleteReport)

local jailPersonCallback = "jailPerson"
local function handleJailPerson(data, cb)
  if data then
    local lib = lib
    local callback = lib.callback.await
    local result = callback("kartik-mdt:server:jailPerson", false, data)
    if result then
      cb(result)
    end
  end
end
registerNUICallback(jailPersonCallback, handleJailPerson)

local finePersonCallback = "finePerson"
local function handleFinePerson(data, cb)
  if data then
    local lib = lib
    local callback = lib.callback.await
    local result = callback("kartik-mdt:server:finePerson", false, data)
    if result then
      cb(result)
    end
  end
end
registerNUICallback(finePersonCallback, handleFinePerson)

local fetchEvidenceCasesCallback = "fetchEvidenceCases"
local function handleFetchEvidenceCases(data, cb)
  if data then
    local lib = lib
    local callback = lib.callback.await
    local result = callback("kartik-mdt:server:fetchEvidenceCases", false, data)
    if result then
      cb(result)
    end
  end
end
registerNUICallback(fetchEvidenceCasesCallback, handleFetchEvidenceCases)

local unlockReportCallback = "unlockReport"
local function handleUnlockReport(data, cb)
  if data then
    local lib = lib
    local callback = lib.callback.await
    local result = callback("kartik-mdt:server:unlockReport", false, data)
    if result then
      cb(result)
    end
  end
end
registerNUICallback(unlockReportCallback, handleUnlockReport)

local lockReportCallback = "lockReport"
local function handleLockReport(data, cb)
  if data then
    local lib = lib
    local callback = lib.callback.await
    local result = callback("kartik-mdt:server:lockReport", false, data)
    if result then
      cb(result)
    end
  end
end
registerNUICallback(lockReportCallback, handleLockReport)

local grantReportAccessCallback = "grantReportAccess"
local function handleGrantReportAccess(data, cb)
  if data then
    local lib = lib
    local callback = lib.callback.await
    local result = callback("kartik-mdt:server:grantReportAccess", false, data)
    if result then
      cb(result)
    end
  end
end
registerNUICallback(grantReportAccessCallback, handleGrantReportAccess)

local revokeReportAccessCallback = "revokeReportAccess"
local function handleRevokeReportAccess(data, cb)
  if data then
    local lib = lib
    local callback = lib.callback.await
    local result = callback("kartik-mdt:server:revokeReportAccess", false, data)
    if result then
      cb(result)
    end
  end
end
registerNUICallback(revokeReportAccessCallback, handleRevokeReportAccess)