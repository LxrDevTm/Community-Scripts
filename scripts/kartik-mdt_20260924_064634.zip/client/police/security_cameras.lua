local registerNUICallback, getCameraListCallback, openCameraCallback, closeCameraCallback, getPaginatedSecurityCameraVideosCallback
cam = nil

registerNUICallback = RegisterNUICallback
getCameraListCallback = function(data, cb)
  local cameras = Config.Cameras
  if cameras then
    local pageNumber = tonumber(data.page) or 1
    local query = data.query or ""
    local filteredCameras = {}
    local totalCameras = #cameras
    for index, camera in pairs(cameras) do
      local location = camera.location
      if location then
        local locationLower = location:lower()
        local queryLower = query:lower()
        if locationLower:find(queryLower) then
          table.insert(filteredCameras, camera)
        end
      end
      local id = tostring(camera.id)
      if id:find(query:lower()) then
        table.insert(filteredCameras, camera)
      end
    end
    table.sort(filteredCameras, function(a, b)
      return a.id < b.id
    end)
    local paginatedCameras = {}
    local start = (pageNumber - 1) * 10 + 1
    local finish = math.min(pageNumber * 10, totalCameras)
    if totalCameras >= start then
      for i = start, finish, 1 do
        table.insert(paginatedCameras, filteredCameras[i])
      end
    end
    cb({
      cameras = paginatedCameras,
      totalCount = totalCameras
    })
  end
end
registerNUICallback("getCameraList", getCameraListCallback)

openCameraCallback = function(data, cb)
  local cameraId = data.id
  local camera = Config.Cameras[cameraId]
  local recordTime = Config.RecordTime
  if camera then
    local type = data.type
    if type == "view" then
      local rotation = camera.rotation or {x = -7.5, y = 0, z = 0, order = 2}
      local createdCam = CreateCam("DEFAULT_SCRIPTED_CAMERA", true)
      cam = createdCam
      SetCamCoord(cam, camera.coords.x, camera.coords.y, camera.coords.z)
      SetCamRot(cam, rotation.x, rotation.y, rotation.z, rotation.order)
      SetFocusPosAndVel(camera.coords.x, camera.coords.y, camera.coords.z, 0.0, 0.0, 0.0)
      SetCamActive(cam, true)
      RenderScriptCams(true, false, 0, true, true)
    end
    cb({
      success = true,
      recTime = recordTime
    })
  end
end
registerNUICallback("openCamera", openCameraCallback)

closeCameraCallback = function(data, cb)
  local currentCam = cam
  if currentCam then
    RenderScriptCams(false, false, 0, true, true)
    DestroyCam(currentCam, false)
    cam = nil
    PlyInCam = false
    cb("ok")
  end
end
registerNUICallback("closeCamera", closeCameraCallback)

getPaginatedSecurityCameraVideosCallback = function(data, cb)
  local lib = lib
  local result = lib.callback.await("kartik-mdt:server:getPaginatedSecurityCameraVideos", false, data)
  if result then
    cb(result)
  end
end
registerNUICallback("getPaginatedSecurityCameraVideos", getPaginatedSecurityCameraVideosCallback)