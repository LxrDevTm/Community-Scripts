local registerNUICallback, fetchVehiclesCallback
registerNUICallback = RegisterNUICallback
fetchVehiclesCallback = function(data, cb)
  local lib, result, vehiclesData, vehicle, vehicleModel, vehicleDisplayName
  if data then
    lib = lib
    lib = lib.callback
    lib = lib.await
    result = lib("kartik-mdt:server:fetchVehicles", false, data)
    if result then
      for vehicle, vehicleData in pairs(result.vehiclesData) do
        vehicleModel = vehicleData.model
        vehicleDisplayName = getVehicleDisplayName(vehicleModel)
        vehicleData.model = vehicleDisplayName
      end
      cb(result)
    end
  end
end
registerNUICallback("fetchVehicles", fetchVehiclesCallback)

local registerNUICallback, fetchVehicleDataByPlateCallback
registerNUICallback = RegisterNUICallback
fetchVehicleDataByPlateCallback = function(data, cb)
  local lib, result
  if data then
    lib = lib
    lib = lib.callback
    lib = lib.await
    result = lib("kartik-mdt:server:fetchVehicleDataByPlate", false, data)
    if result then
      cb(result)
    end
  end
end
registerNUICallback("fetchVehicleDataByPlate", fetchVehicleDataByPlateCallback)

local registerNUICallback, getVehicleDataByPlateCallback
registerNUICallback = RegisterNUICallback
getVehicleDataByPlateCallback = function(data, cb)
  local lib, result, vehicleData, vehicleModel, vehicleDisplayName
  if data then
    lib = lib
    lib = lib.callback
    lib = lib.await
    result = lib("kartik-mdt:server:getVehicleDataByPlate", false, data)
    if result then
      vehicleData = result.data
      vehicleModel = vehicleData.model
      vehicleDisplayName = getVehicleDisplayName(vehicleModel)
      vehicleData.model = vehicleDisplayName
      print(json.encode(result))
      cb(result)
    end
  end
end
registerNUICallback("getVehicleDataByPlate", getVehicleDataByPlateCallback)

local registerNUICallback, updateVehicleStatusCallback
registerNUICallback = RegisterNUICallback
updateVehicleStatusCallback = function(data, cb)
  local lib, result
  if data then
    lib = lib
    lib = lib.callback
    lib = lib.await
    result = lib("kartik-mdt:server:updateVehicleStatus", false, data)
    if result then
      cb(result)
    end
  end
end
registerNUICallback("updateVehicleStatus", updateVehicleStatusCallback)

local registerNUICallback, addVehicleReportSightingsCallback
registerNUICallback = RegisterNUICallback
addVehicleReportSightingsCallback = function(data, cb)
  local lib, result
  if data then
    lib = lib
    lib = lib.callback
    lib = lib.await
    result = lib("kartik-mdt:server:addVehicleReportSightings", false, data)
    if result then
      cb(result)
    end
  end
end
registerNUICallback("addVehicleReportSightings", addVehicleReportSightingsCallback)

local registerNUICallback, fetchVehiclesReportsCallback
registerNUICallback = RegisterNUICallback
fetchVehiclesReportsCallback = function(data, cb)
  local lib, result
  if data then
    lib = lib
    lib = lib.callback
    lib = lib.await
    result = lib("kartik-mdt:server:fetchVehiclesReports", false, data)
    if result then
      cb(result)
    else
      cb(false)
    end
  end
end
registerNUICallback("fetchVehiclesReports", fetchVehiclesReportsCallback)

local registerNUICallback, updateVehiclePhotoCallback
registerNUICallback = RegisterNUICallback
updateVehiclePhotoCallback = function(data, cb)
  local lib, result
  if data then
    lib = lib
    lib = lib.callback
    lib = lib.await
    result = lib("kartik-mdt:server:updateVehiclePhoto", false, data)
    if result then
      cb(result)
    else
      cb(false)
    end
  end
end
registerNUICallback("updateVehiclePhoto", updateVehiclePhotoCallback)

local registerNUICallback, fetchVehiclesStrikesCallback
registerNUICallback = RegisterNUICallback
fetchVehiclesStrikesCallback = function(data, cb)
  local lib, result
  if data then
    lib = lib
    lib = lib.callback
    lib = lib.await
    result = lib("kartik-mdt:server:fetchVehiclesStrikes", false, data)
    if result then
      cb(result)
    end
  end
end
registerNUICallback("fetchVehiclesStrikes", fetchVehiclesStrikesCallback)

local registerNUICallback, addVehicleStrikeCallback
registerNUICallback = RegisterNUICallback
addVehicleStrikeCallback = function(data, cb)
  local lib, result
  if data then
    lib = lib
    lib = lib.callback
    lib = lib.await
    result = lib("kartik-mdt:server:addVehicleStrike", false, data)
    if result then
      cb(result)
    end
  end
end
registerNUICallback("addVehicleStrike", addVehicleStrikeCallback)

local registerNUICallback, updateVehicleStrikeCallback
registerNUICallback = RegisterNUICallback
updateVehicleStrikeCallback = function(data, cb)
  local lib, result
  if data then
    lib = lib
    lib = lib.callback
    lib = lib.await
    result = lib("kartik-mdt:server:updateVehicleStrike", false, data)
    if result then
      cb(result)
    end
  end
end
registerNUICallback("updateVehicleStrike", updateVehicleStrikeCallback)