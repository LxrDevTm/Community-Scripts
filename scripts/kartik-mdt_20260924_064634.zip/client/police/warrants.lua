local registerNUICallback, callbackName
registerNUICallback = RegisterNUICallback
callbackName = "fetchWarrants"
function handleFetchWarrants(data, cb)
  if data then
    local lib = lib
    local await = lib.callback.await
    local result = await("kartik-mdt:server:fetchWarrants", false, data)
    if result then
      cb(result)
    end
  end
end
registerNUICallback(callbackName, handleFetchWarrants)

registerNUICallback = RegisterNUICallback
callbackName = "fetchWarrantDataByWarrantId"
function handleFetchWarrantDataByWarrantId(data, cb)
  if data then
    local lib = lib
    local await = lib.callback.await
    local result = await("kartik-mdt:server:fetchWarrantDataByWarrantId", false, data)
    if result then
      cb(result)
    end
  end
end
registerNUICallback(callbackName, handleFetchWarrantDataByWarrantId)

registerNUICallback = RegisterNUICallback
callbackName = "updateWarrant"
function handleUpdateWarrant(data, cb)
  if data then
    local lib = lib
    local await = lib.callback.await
    local result = await("kartik-mdt:server:updateWarrant", false, data)
    if result then
      cb(result)
    end
  end
end
registerNUICallback(callbackName, handleUpdateWarrant)

registerNUICallback = RegisterNUICallback
callbackName = "addNewWarrant"
function handleAddNewWarrant(data, cb)
  if data then
    local lib = lib
    local await = lib.callback.await
    local result = await("kartik-mdt:server:addNewWarrant", false, data)
    if result then
      cb(result)
    end
  end
end
registerNUICallback(callbackName, handleAddNewWarrant)

registerNUICallback = RegisterNUICallback
callbackName = "addReportSightings"
function handleAddReportSightings(data, cb)
  if data then
    local lib = lib
    local await = lib.callback.await
    local result = await("kartik-mdt:server:addReportSightings", false, data)
    if result then
      cb(result)
    end
  end
end
registerNUICallback(callbackName, handleAddReportSightings)

registerNUICallback = RegisterNUICallback
callbackName = "updateCaseNotes"
function handleUpdateCaseNotes(data, cb)
  if data then
    local lib = lib
    local await = lib.callback.await
    local result = await("kartik-mdt:server:updateCaseNotes", false, data)
    if result then
      cb(result)
    end
  end
end
registerNUICallback(callbackName, handleUpdateCaseNotes)

registerNUICallback = RegisterNUICallback
callbackName = "warrants:deleteWarrant"
function handleDeleteWarrant(data, cb)
  if data then
    local lib = lib
    local await = lib.callback.await
    local result = await("kartik-mdt:server:deleteWarrant", false, data)
    if result then
      cb(result)
    end
  end
end
registerNUICallback(callbackName, handleDeleteWarrant)