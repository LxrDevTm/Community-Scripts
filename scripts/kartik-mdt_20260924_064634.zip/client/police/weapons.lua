local registerNUICallback, callbackName
registerNUICallback = RegisterNUICallback
callbackName = "fetchWeapons"
function handleFetchWeapons(data, cb)
  if data then
    local lib = lib
    local result = lib.callback.await("kartik-mdt:server:fetchWeapons", false, data)
    if result then
      cb(result)
    else
      cb(false)
    end
  end
end
registerNUICallback(callbackName, handleFetchWeapons)

registerNUICallback = RegisterNUICallback
callbackName = "fetchWeaponDataBySerialNumber"
function handleFetchWeaponDataBySerialNumber(data, cb)
  if data then
    local lib = lib
    local result = lib.callback.await("kartik-mdt:server:fetchWeaponDataBySerialNumber", false, data)
    if result then
      cb(result)
    end
  end
end
registerNUICallback(callbackName, handleFetchWeaponDataBySerialNumber)

registerNUICallback = RegisterNUICallback
callbackName = "updateWeapon"
function handleUpdateWeapon(data, cb)
  if data then
    local lib = lib
    local result = lib.callback.await("kartik-mdt:server:updateWeapon", false, data)
    if result then
      cb(result)
    end
  end
end
registerNUICallback(callbackName, handleUpdateWeapon)

registerNUICallback = RegisterNUICallback
callbackName = "deleteWeapon"
function handleDeleteWeapon(data, cb)
  if data then
    local lib = lib
    local result = lib.callback.await("kartik-mdt:server:deleteWeapon", false, data)
    if result then
      cb(result)
    end
  end
end
registerNUICallback(callbackName, handleDeleteWeapon)

registerNUICallback = RegisterNUICallback
callbackName = "addWeapon"
function handleAddWeapon(data, cb)
  if data then
    local lib = lib
    local result = lib.callback.await("kartik-mdt:server:addWeapon", false, data)
    if result then
      cb(result)
    end
  end
end
registerNUICallback(callbackName, handleAddWeapon)

registerNUICallback = RegisterNUICallback
callbackName = "updateWeaponImage"
function handleUpdateWeaponImage(data, cb)
  if data then
    local lib = lib
    local result = lib.callback.await("kartik-mdt:server:updateWeaponImage", false, data)
    if result then
      cb(result)
    end
  end
end
registerNUICallback(callbackName, handleUpdateWeaponImage)