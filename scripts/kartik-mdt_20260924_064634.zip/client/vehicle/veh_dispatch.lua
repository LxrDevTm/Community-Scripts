vehicleDispatch = false
onFootDispatch = false
dispatchMode = "closed"

function startVehicleDispatchThread()
  CreateThread(function()
    while true do
      local cache = cache
      local vehicle = cache.vehicle
      if not vehicle then
        break
      end
      if not vehicleDispatch then
        break
      end
      local ped = cache.ped
      local vehicleIn = GetVehiclePedIsIn(ped, false)
      local frontOffset = GetOffsetFromEntityInWorldCoords(vehicleIn, 0.0, 1.0, 1.0)
      local rearOffset = GetOffsetFromEntityInWorldCoords(vehicleIn, 0.0, 105.0, 0.0)
      local frontResult = StartShapeTestCapsule(frontOffset, rearOffset, 6.0, 10, vehicleIn, 7)
      local frontHit, frontEntity, frontCoords, frontNormal, frontMaterial = GetShapeTestResult(frontResult)
      if IsEntityAVehicle(frontEntity) then
        local plate = GetVehicleNumberPlateText(frontEntity)
        local wanted = GlobalState.wanted_vehicles[plate] or false
        SendNUIMessage({
          action = "updateFrontCar",
          data = {
            plate = plate,
            wanted = wanted
          }
        })
      end
      local rearOffset = GetOffsetFromEntityInWorldCoords(vehicleIn, 0.0, -105.0, 0.0)
      local rearResult = StartShapeTestCapsule(frontOffset, rearOffset, 3.0, 10, vehicleIn, 7)
      local rearHit, rearEntity, rearCoords, rearNormal, rearMaterial = GetShapeTestResult(rearResult)
      if IsEntityAVehicle(rearEntity) then
        local plate = GetVehicleNumberPlateText(rearEntity)
        local wanted = GlobalState.wanted_vehicles[plate] or false
        SendNUIMessage({
          action = "updateRearCar",
          data = {
            plate = plate,
            wanted = wanted
          }
        })
      end
      Wait(500)
    end
  end)
end

function onCacheUpdate(key, value)
  if not value then
    if dispatchMode == "vehicle" then
      dispatchMode = "foot"
      onFootDispatch = true
      vehicleDispatch = false
      SendNUIMessage({
        action = "carMDT",
        data = {
          open = true,
          mode = "foot"
        }
      })
    end
  else
    if isActionAllowed("dispatch") then
      local vehicleClass = GetVehicleClass(value)
      if vehicleClass == 18 then
        if dispatchMode == "foot" then
          dispatchMode = "vehicle"
          vehicleDispatch = true
          onFootDispatch = false
          startVehicleDispatchThread()
          SendNUIMessage({
            action = "carMDT",
            data = {
              open = true,
              mode = "vehicle"
            }
          })
        end
      end
    end
  end
end

lib.onCache("vehicle", onCacheUpdate)

function openVehicleDispatch()
  dispatchMode = "closed"
  vehicleDispatch = false
  onFootDispatch = false
  SendNUIMessage({
    action = "carMDT",
    data = {
      open = false,
      mode = "closed"
    }
  })
end

function closeVehicleDispatch()
  if dispatchMode == "closed" then
    openVehicleDispatch()
  else
    closeVehicleDispatch()
  end
end

function toggleDispatchMode()
  if dispatchMode == "closed" then
    openVehicleDispatch()
  else
    closeVehicleDispatch()
  end
end

lib.addKeybind({
  name = "vehicle_dispatch_nui",
  description = "press F10 to focus on Vehicle Dispatch",
  defaultKey = Config.Keybinds.vehicle_dispatch_focus or "F10",
  onPressed = function()
    if not vehicleDispatch and not onFootDispatch then
      return
    end
    SetNuiFocus(true, true)
    SetNuiFocusKeepInput(false)
  end
})

lib.addKeybind({
  name = "vehicle_dispatch",
  description = "press F11 to toggle Vehicle Dispatch",
  defaultKey = Config.Keybinds.open_vehicle_dispatch or "F11",
  onPressed = function()
    toggleDispatchMode()
  end
})

lib.addKeybind({
  name = "next_incident",
  description = "Go to Next Incident",
  defaultKey = "RIGHT",
  onPressed = function()
    if vehicleDispatch or onFootDispatch then
      SendNUIMessage({
        action = "nextIncident"
      })
    end
  end
})

lib.addKeybind({
  name = "previous_incident",
  description = "Go to Previous Incident",
  defaultKey = "LEFT",
  onPressed = function()
    if vehicleDispatch or onFootDispatch then
      SendNUIMessage({
        action = "previousIncident"
      })
    end
  end
})

lib.addKeybind({
  name = "emergency_set_waypoint",
  description = "Last Waypoint ( EMERGENCY )",
  defaultKey = Config.Keybinds.set_last_waypoint or "O",
  onPressed = function()
    if vehicleDispatch or onFootDispatch then
      SendNUIMessage({
        action = "respondAttachment"
      })
    end
  end
})

function toggleSmallDispatch()
  if Config.SmallDispatch and Config.SmallDispatch.enabled then
    toggleDispatchMode()
    if not vehicleDispatch and not onFootDispatch then
      if not uiOpen then
        SetNuiFocus(false, false)
      end
    end
  end
end