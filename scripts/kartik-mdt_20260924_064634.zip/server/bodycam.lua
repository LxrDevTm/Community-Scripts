local resourceName = GetCurrentResourceName()
if resourceName ~= "kartik-mdt" then
  return
end

local PlayerOnBodycam = {}
GlobalState.PlayerOnBodycam = PlayerOnBodycam

local function handleBodycamToggle(player, autoStart, citizenId)
  if not citizenId then
    return false
  end

  local query = "SELECT * FROM mdt_units WHERE citizenid = ?"
  local result = MySQL.query.await(query, {citizenId})
  if not result then
    return false
  end

  if #result == 0 then
    return false
  end

  local unit = result[1]
  if unit.isFired == 1 then
    return false
  end

  if autoStart then
    local playerData = PlayerOnBodycam[citizenId]
    if playerData then
      if playerData.status == "off" then
        updateBodycamStatus(citizenId, "on")
        local player = GetPlayerByCitizenId(citizenId)
        if player then
          local jobData = player.jobData
          if not jobData then
            jobData = {label = "Unknown", grade = {name = "Unknown"}}
          end
          local department = jobData.label
          local rank = jobData.grade.name
          PlayerOnBodycam[citizenId].department = department
          PlayerOnBodycam[citizenId].rank = rank
          GlobalState.PlayerOnBodycam = PlayerOnBodycam
        end
        return PlayerOnBodycam[citizenId]
      end
    else
      local player = GetPlayerByCitizenId(citizenId)
      if player then
        createBodycamEntry(player, citizenId, "on")
        return PlayerOnBodycam[citizenId]
      end
    end
  else
    local playerData = PlayerOnBodycam[citizenId]
    if playerData then
      updateBodycamStatus(citizenId, "off")
      return PlayerOnBodycam[citizenId]
    else
      return false
    end
  end
end

RegisterNetEvent("kartik-mdt:server:removeBodycam", function()
  local source = source
  local config = Config.Utils.bodycam
  if not config.itemRequired then
    return
  end
  local playerData = GetPlayerData(source)
  if not playerData then
    return
  end
  local citizenId = playerData.citizenId
  local result = handleBodycamToggle(source, false, citizenId)
  if result then
    TriggerClientEvent("kartik-mdt:client:removeBodycam", source)
  end
end)

local function updateBodycamStatus(citizenId, status)
  local query = "UPDATE mdt_units SET bodycam = ? WHERE citizenid = ?"
  MySQL.query.await(query, {status, citizenId})
  PlayerOnBodycam[citizenId].status = status
  GlobalState.PlayerOnBodycam = PlayerOnBodycam
end

local function createBodycamEntry(player, citizenId, status)
  local name = player.name or "Unknown"
  local jobData = player.jobData or {label = "Unknown", grade = {name = "Unknown"}}
  local department = jobData.label
  local rank = jobData.grade.name
  PlayerOnBodycam[citizenId] = {
    citizenId = citizenId,
    name = name,
    department = department,
    rank = rank,
    status = status,
    videoURLs = ""
  }
  GlobalState.PlayerOnBodycam = PlayerOnBodycam
  local query = "UPDATE mdt_units SET bodycam = ? WHERE citizenid = ?"
  MySQL.query.await(query, {status, citizenId})
end

lib.callback.register("kartik-mdt:server:toggleBodycam", function(source, autoStart, citizenId)
  return handleBodycamToggle(source, autoStart, citizenId)
end)

lib.callback.register("kartik-mdt:server:fetchBodycams", function(source, data)
  if not data then
    return
  end
  local page = data.page or 1
  local query = data.query or ""
  local offset = (page - 1) * 10
  local result, totalCount = fetchBodycamPlayersWithPagination(query, offset)
  return {bodycams = result, totalCount = totalCount}
end)

lib.callback.register("kartik-mdt:server:getSource", function(source, citizenId)
  if citizenId then
    local player = GetPlayerByCitizenId(citizenId)
    if player then
      local ped = GetPlayerPed(player.source)
      local coords = GetEntityCoords(ped)
      return player.source, coords
    else
      return false
    end
  end
end)

lib.callback.register("kartik-mdt:server:fetchBodycamDataById", function(source, data)
  if data then
    local id = data.id
    local query = "SELECT COUNT(*) AS count FROM mdt_bodycams WHERE citizenid = ?"
    local result = MySQL.query.await(query, {id})
    local count = result[1].count
    if count > 0 then
      return {success = true}
    else
      return {success = false}
    end
  else
    return nil
  end
end)

lib.callback.register("kartik-mdt:server:getPaginatedCameraVideos", function(source, data)
  if data then
    local id = data.id
    local page = data.page or 1
    local perPage = data.perPage or 10
    local offset = (page - 1) * perPage
    local query = "SELECT * FROM mdt_bodycams WHERE citizenid = ? LIMIT ? OFFSET ?"
    local result = MySQL.query.await(query, {id, perPage, offset})
    local countQuery = "SELECT COUNT(*) AS count FROM mdt_bodycams WHERE citizenid = ?"
    local countResult = MySQL.query.await(countQuery, {id})
    local count = countResult[1].count
    if result then
      return {success = true, videos = result, totalCount = count}
    else
      return {success = false, totalCount = count}
    end
  else
    return nil
  end
end)