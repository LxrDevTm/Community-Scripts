local registerCallback, createChannel, fetchChannels, fetchMessages, sendMessage, inviteMember
registerCallback = lib.callback
registerCallback = registerCallback.register
createChannel = "kartik-mdt:server:createChannel"
function createChannel(player, data)
    local playerData = GetPlayerData(player)
    if not playerData then
        return { success = false, error = "Invalid player" }
    end
    local groupData = data.groupData or {}
    local invitedUsers = data.invitedUsers or {}
    local type = groupData.type or "group"
    local name = data.name
    local members = {}
    local owner = { citizenId = playerData.citizenId, name = playerData.name }
    table.insert(members, owner)
    for _, user in ipairs(invitedUsers) do
        if user.citizenId then
            local offlinePlayer = GetOfflinePlayerByCitizenId(user.citizenId)
            if offlinePlayer then
                table.insert(members, { citizenId = user.citizenId, name = offlinePlayer.name })
            end
        end
    end
    if type == "dm" then
        if not owner then
            return { success = false, error = "Cannot create DM without another user" }
        end
        local existingDm = MySQL.query.await([[ SELECT id, name, members FROM mdt_channels WHERE type = 'dm' ]])
        for _, channel in ipairs(existingDm or {}) do
            local membersJson = json.decode(channel.members)
            if membersJson then
                local user1 = membersJson[1]
                local user2 = membersJson[2]
                if (user1.citizenId == playerData.citizenId and user2.citizenId == owner.citizenId) or (user1.citizenId == owner.citizenId and user2.citizenId == playerData.citizenId) then
                    return { success = true, alreadyCreated = channel.id }
                end
            end
        end
    elseif not name or name == "" then
        return { success = false, error = "Missing channel name" }
    end
    local membersJson = json.encode(members)
    local channelId = MySQL.insert.await([[ INSERT INTO mdt_channels (owner, name, type, members) VALUES (?, ?, ?, ?) ]], { playerData.citizenId, name, type, membersJson })
    if not channelId then
        return { success = false, error = "Failed to create channel" }
    end
    MySQL.insert.await([[ INSERT INTO mdt_messages (channelId, authorId, authorName, content) VALUES (?, ?, ?, ?) ]], { channelId, playerData.citizenId, playerData.name, "Created the " .. type })
    return { success = true, channel = { id = channelId, name = name, type = type, members = members, owner = playerData.citizenId, createdAt = os.time() } }
end
registerCallback(createChannel, "kartik-mdt:server:createChannel")
fetchChannels = "kartik-mdt:server:fetchChannels"
function fetchChannels(player, data)
    local playerData = GetPlayerData(player)
    if not playerData then
        return { success = false, error = "Invalid player" }
    end
    local query = [[ SELECT id, owner, name, type, members, createdAt FROM mdt_channels WHERE JSON_SEARCH(members, 'one', ?) IS NOT NULL OR owner = ? ORDER BY createdAt DESC ]]
    local channels = MySQL.query.await(query, { playerData.citizenId, playerData.citizenId })
    if not channels then
        return { success = false, error = "Failed to fetch channels" }
    end
    local result = {}
    for _, channel in ipairs(channels) do
        local membersJson = json.decode(channel.members)
        if membersJson then
            for _, member in ipairs(membersJson) do
                local player = GetPlayerByCitizenId(member.citizenId)
                if player then
                    local playerData = GetPlayerData(player)
                    if playerData then
                        member.name = playerData.name
                    end
                    member.status = "online"
                else
                    local offlinePlayer = GetOfflinePlayerByCitizenId(member.citizenId)
                    if offlinePlayer then
                        member.name = offlinePlayer.name
                    end
                    member.status = "offline"
                end
            end
        end
        if channel.type == "dm" then
            local member = membersJson and membersJson[1]
            if member and member.citizenId ~= playerData.citizenId then
                channel.name = member.name or "Unknown"
            end
        end
        table.insert(result, { id = channel.id, owner = channel.owner, name = channel.name, type = channel.type, members = membersJson, createdAt = channel.createdAt })
    end
    return { success = true, channels = result }
end
registerCallback(fetchChannels, "kartik-mdt:server:fetchChannels")
fetchMessages = "kartik-mdt:server:fetchMessages"
function fetchMessages(player, data)
    local playerData = GetPlayerData(player)
    if not playerData then
        return { success = false, error = "Invalid player" }
    end
    local channelId = data.channelId
    local limit = data.limit or 50
    local offset = data.offset or 0
    if not channelId then
        return { success = false, error = "Missing channelId" }
    end
    local query = [[ SELECT members FROM mdt_channels WHERE id = ? ]]
    local channel = MySQL.query.await(query, { channelId })
    if not channel then
        return { success = false, error = "Channel not found" }
    end
    local membersJson = json.decode(channel[1].members)
    if not membersJson then
        membersJson = {}
    end
    local isMember = false
    for _, member in ipairs(membersJson) do
        if member.citizenId == playerData.citizenId then
            isMember = true
            break
        end
    end
    if not isMember then
        return { success = false, error = "Not a member of this channel" }
    end
    local query = [[ SELECT id, channelId, authorId, authorName, content, UNIX_TIMESTAMP(timestamp) as timestamp, edited FROM mdt_messages WHERE channelId = ? ORDER BY timestamp ASC LIMIT ? OFFSET ? ]]
    local messages = MySQL.query.await(query, { channelId, limit, offset })
    local totalCount = MySQL.query.await([[ SELECT COUNT(*) as total FROM mdt_messages WHERE channelId = ? ]], { channelId })[1].total
    return { success = true, messages = messages or {}, totalCount = totalCount }
end
registerCallback(fetchMessages, "kartik-mdt:server:fetchMessages")
sendMessage = "kartik-mdt:server:sendMessage"
function sendMessage(player, data)
    local playerData = GetPlayerData(player)
    if not playerData then
        return { success = false, error = "Invalid player" }
    end
    local channelId = data.channelId
    local content = data.content
    if not (channelId and content) or content == "" then
        return { success = false, error = "Missing required fields" }
    end
    local query = [[ SELECT members FROM mdt_channels WHERE id = ? ]]
    local channel = MySQL.query.await(query, { channelId })
    if not channel then
        return { success = false, error = "Channel not found" }
    end
    local membersJson = json.decode(channel[1].members)
    if not membersJson then
        membersJson = {}
    end
    local isMember = false
    for _, member in ipairs(membersJson) do
        if member.citizenId == playerData.citizenId then
            isMember = true
            break
        end
    end
    if not isMember then
        return { success = false, error = "Not a member of this channel" }
    end
    local messageId = MySQL.insert.await([[ INSERT INTO mdt_messages (channelId, authorId, authorName, content) VALUES (?, ?, ?, ?) ]], { channelId, playerData.citizenId, playerData.name, content })
    if not messageId then
        return { success = false, error = "Failed to send message" }
    end
    return { success = true, message = { id = messageId, channelId = channelId, authorId = playerData.citizenId, authorName = playerData.name, content = content, timestamp = os.time(), edited = false } }
end
registerCallback(sendMessage, "kartik-mdt:server:sendMessage")
inviteMember = "kartik-mdt:server:inviteMember"
function inviteMember(player, data)
    local playerData = GetPlayerData(player)
    if not playerData then
        return { success = false, error = "Invalid player" }
    end
    local channelId = data.channelId
    local invitedUsers = data.invitedUsers or {}
    if not channelId or #invitedUsers == 0 then
        return { success = false, error = "Missing channelId or invited users" }
    end
    local query = [[ SELECT id, members, owner, type, name FROM mdt_channels WHERE id = ? ]]
    local channel = MySQL.query.await(query, { channelId })
    if not channel then
        return { success = false, error = "Channel not found" }
    end
    local membersJson = json.decode(channel[1].members)
    if not membersJson then
        membersJson = {}
    end
    for _, user in ipairs(invitedUsers) do
        local existingMember = false
        for _, member in ipairs(membersJson) do
            if member.citizenId == user.citizenId then
                existingMember = true
                break
            end
        end
        if not existingMember then
            table.insert(membersJson, user)
        end
    end
    local membersJsonString = json.encode(membersJson)
    MySQL.update.await([[ UPDATE mdt_channels SET members = ? WHERE id = ? ]], { membersJsonString, channelId })
    return { success = true }
end
registerCallback(inviteMember, "kartik-mdt:server:inviteMember")

local function removeMember(player, data)
  local playerData = GetPlayerData(player)
  if not playerData then
    return { success = false, error = "Invalid player" }
  end

  local channelId = data.channelId
  local citizenId = data.citizenId
  if not channelId or not citizenId then
    return { success = false, error = "Missing data" }
  end

  local result = MySQL.query.await("SELECT * FROM mdt_channels WHERE id = ?", { channelId })
  if not result or #result == 0 then
    return { success = false, error = "Channel not found" }
  end

  local channel = result[1]
  local members = json.decode(channel.members)
  if not members then
    members = {}
  end

  if channel.owner ~= playerData.citizenId then
    return { success = false, error = "No permission to remove members" }
  end

  local updatedMembers = {}
  for _, member in ipairs(members) do
    if member.citizenId ~= citizenId then
      table.insert(updatedMembers, member)
    end
  end

  local updateResult = MySQL.update.await("UPDATE mdt_channels SET members = ? WHERE id = ?", { json.encode(updatedMembers), channelId })
  if not updateResult or updateResult == 0 then
    return { success = false, error = "Database update failed" }
  end

  return { success = true, updatedMembers = updatedMembers }
end

lib.callback.register("kartik-mdt:server:kickMember", removeMember)

local function addMember(player, data)
  local playerData = GetPlayerData(player)
  if not playerData then
    return { success = false, error = "Invalid player" }
  end

  local channelId = data.channelId
  local citizenId = data.citizenId
  if not channelId or not citizenId then
    return { success = false, error = "Missing data" }
  end

  local result = MySQL.query.await("SELECT * FROM mdt_channels WHERE id = ?", { channelId })
  if not result or #result == 0 then
    return { success = false, error = "Channel not found" }
  end

  local channel = result[1]
  local members = json.decode(channel.members)
  if not members then
    members = {}
  end

  if channel.owner ~= playerData.citizenId then
    return { success = false, error = "No permission to add members" }
  end

  local newMember = {}
  newMember.citizenId = citizenId
  newMember.name = ""

  local player = GetPlayerByCitizenId(citizenId)
  if player then
    local playerData = GetPlayerData(player)
    if playerData then
      newMember.name = playerData.name
    end
  else
    local offlinePlayer = GetOfflinePlayerByCitizenId(citizenId)
    if offlinePlayer then
      newMember.name = offlinePlayer.name
    end
  end

  table.insert(members, newMember)

  local updateResult = MySQL.update.await("UPDATE mdt_channels SET members = ? WHERE id = ?", { json.encode(members), channelId })
  if not updateResult or updateResult == 0 then
    return { success = false, error = "Database update failed" }
  end

  local message = "Invited " .. table.concat(map(function(v) return v.name end, members), ", ") .. " to the channel."
  MySQL.insert.await([[INSERT INTO mdt_messages (channelId, authorId, authorName, content) VALUES (?, ?, ?, ?)]], { channelId, playerData.citizenId, playerData.name, message })

  return { success = true, newMembers = members }
end

lib.callback.register("kartik-mdt:server:addMember", addMember)