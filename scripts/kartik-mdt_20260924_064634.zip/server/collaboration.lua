local resourceName, collaborationEditing, useWebsockets, editors, reports, lastActive
resourceName = GetCurrentResourceName()
resourceName = resourceName()
if "kartik-mdt" ~= resourceName then
  return
end
collaborationEditing = Config
collaborationEditing = collaborationEditing.CollaborationEditing
if collaborationEditing then
  collaborationEditing = Config
  collaborationEditing = collaborationEditing.CollaborationEditing
  if not collaborationEditing then
    goto label20
  end
  collaborationEditing = Config
  collaborationEditing = collaborationEditing.useWebsockets
  if not collaborationEditing then
    goto label20
  end
end
return

::label20::
editors = {}
reports = {}
lastActive = {}
function initializeEditor(department, reportType, editorId)
  local editor, report, lastActiveEditor
  editor = editors
  report = editor[department]
  if not report then
    report = {}
  end
  editor[department] = report
  editor = editors
  editor = editor[department]
  report = editor[reportType]
  if not report then
    report = {}
  end
  editor[reportType] = report
  editor = editors
  editor = editor[department]
  editor = editor[reportType]
  lastActiveEditor = editor[editorId]
  if not lastActiveEditor then
    lastActiveEditor = {}
  end
  editor[editorId] = lastActiveEditor
  editor = reports
  report = editor[department]
  if not report then
    report = {}
  end
  editor[department] = report
  editor = reports
  editor = editor[department]
  report = editor[reportType]
  if not report then
    report = {}
  end
  editor[reportType] = report
  editor = reports
  editor = editor[department]
  editor = editor[reportType]
  lastActiveEditor = editor[editorId]
  if not lastActiveEditor then
    lastActiveEditor = {}
  end
  editor[editorId] = lastActiveEditor
  editor = lastActive
  report = editor[department]
  if not report then
    report = {}
  end
  editor[department] = report
  editor = lastActive
  editor = editor[department]
  report = editor[reportType]
  if not report then
    report = {}
  end
  editor[reportType] = report
  editor = lastActive
  editor = editor[department]
  editor = editor[reportType]
  lastActiveEditor = editor[editorId]
  if not lastActiveEditor then
    lastActiveEditor = os.time()
  end
  editor[editorId] = lastActiveEditor
end
local registerNetEvent = RegisterNetEvent
local event = "kartik-mdt:reports:startEditing"
function startEditing(source, data, reportType, editorId)
  local editor, report, lastActiveEditor
  editor = source
  initializeEditor(data.department, reportType, editorId)
  editor = editors
  report = editor[data.department]
  report = report[reportType]
  report = report[editorId]
  report.id = data.id
  report.name = data.name
  report.department = data.department
  report.lastActive = os.time()
  editor = reports
  report = editor[data.department]
  report = report[reportType]
  report = report[editorId]
  if report then
    for editorId, editorData in pairs(report) do
      TriggerClientEvent("kartik-mdt:reports:editorJoined", tonumber(editorId), editorId, editorData)
    end
  end
end
registerNetEvent(event, startEditing)
registerNetEvent = RegisterNetEvent
event = "kartik-mdt:reports:stopEditing"
function stopEditing(source, data, reportType, editorId)
  local editor, report, lastActiveEditor
  editor = source
  report = editors
  report = report[data.department]
  if report then
    report = report[reportType]
    if report then
      report = report[editorId]
      if report then
        report = editors
        report = report[data.department]
        report = report[reportType]
        report = report[editorId]
        local editorIdStr = tostring(editor)
        report[editorIdStr] = nil
        report = pairs
        editor = editors
        editor = editor[data.department]
        editor = editor[reportType]
        editor = editor[editorId]
        if not editor then
          editor = {}
        end
        for editorId, editorData in report(editor) do
          TriggerClientEvent("kartik-mdt:reports:editorLeft", tonumber(editorId), editorId, editorData)
        end
      end
    end
  end
end
registerNetEvent(event, stopEditing)
registerNetEvent = RegisterNetEvent
event = "kartik-mdt:reports:updateReport"
function updateReport(source, data, reportType, editorId, changes)
  local editor, report, lastActiveEditor
  editor = source
  initializeEditor(data.department, reportType, editorId)
  editor = editors
  report = editor[data.department]
  report = report[reportType]
  report = report[editorId]
  if report then
    report.lastActive = os.time()
  end
  local timestamp = os.time()
  local change = {}
  change.source = editor
  change.changes = changes
  change.changeType = data.changeType
  change.page = data.page
  change.department = data.department
  change.timestamp = timestamp
  table.insert(reports[data.department][reportType][editorId], change)
  editor = lastActive
  editor = editor[data.department]
  editor = editor[reportType]
  editor[editorId] = timestamp
  for editorId, editorData in pairs(editors[data.department][reportType][editorId]) do
    if tonumber(editorId) ~= editor then
      TriggerClientEvent("kartik-mdt:reports:receiveUpdate", tonumber(editorId), editorId, changes, data.changeType, editor, timestamp, data.page, data.department)
    end
  end
end
registerNetEvent(event, updateReport)
registerNetEvent = RegisterNetEvent
event = "kartik-mdt:reports:getActiveEditors"
function getActiveEditors(source, data, reportType, editorId)
  local editor, report, lastActiveEditor
  editor = source
  report = editors
  report = report[data.department]
  if not report then
    report = {}
  end
  report = report[reportType]
  if not report then
    report = {}
  end
  report = report[editorId]
  if not report then
    report = {}
  end
  TriggerClientEvent("kartik-mdt:reports:currentEditors", editor, editorId, report)
end
registerNetEvent(event, getActiveEditors)
local createThread = CreateThread
function cleanup()
  while true do
    Wait(60000)
    local currentTime = os.time()
    for department, reports in pairs(editors) do
      for reportType, report in pairs(reports) do
        for editorId, editorData in pairs(report) do
          local inactiveTime = {}
          for editor, data in pairs(editorData) do
            local lastActive = data.lastActive
            if not lastActive then
              lastActive = currentTime
            end
            local timeDiff = currentTime - lastActive
            if timeDiff > 300 then
              table.insert(inactiveTime, editor)
            end
          end
          for i, editor in ipairs(inactiveTime) do
            editorData[editor] = nil
          end
          if next(editorData) == nil then
            report[editorId] = nil
            if next(report) == nil then
              reports[reportType] = nil
              if next(reports) == nil then
                editors[department] = nil
              end
            end
          end
        end
      end
    end
  end
end
createThread(cleanup)
local addEventHandler = AddEventHandler
local event = "playerDropped"
function onPlayerDropped()
  local source = tostring(source)
  for department, reports in pairs(editors) do
    for reportType, report in pairs(reports) do
      for editorId, editorData in pairs(report) do
        if editorData[source] then
          editorData[source] = nil
          TriggerClientEvent("kartik-mdt:reports:editorLeft", -1, editorId, editorData)
          if next(editorData) == nil then
            report[editorId] = nil
            if next(report) == nil then
              reports[reportType] = nil
              if next(reports) == nil then
                editors[department] = nil
              end
            end
          end
        end
      end
    end
  end
end
addEventHandler(event, onPlayerDropped)