local courtCaseFormatter, lib, MySQL, json, os, string, GetPlayerData, FormatPlayer, SendDiscordLog

courtCaseFormatter = function(caseId)
  local currentDate = os.date("%Y")
  return string.format("CC-%s-%03d", currentDate, caseId)
end

lib = lib or {}
lib.callback = lib.callback or {}
lib.callback.register = lib.callback.register or function(event, callback) end

MySQL = MySQL or {}
MySQL.query = MySQL.query or function(query, params) end
MySQL.query.await = MySQL.query.await or function(query, params) end

json = json or {}
json.decode = json.decode or function(jsonString) end
json.encode = json.encode or function(data) end

os = os or {}
os.date = os.date or function(format) end

string = string or {}
string.format = string.format or function(format, ...) end

GetPlayerData = GetPlayerData or function(player) end
FormatPlayer = FormatPlayer or function(player) end
SendDiscordLog = SendDiscordLog or function(channel, message, color, fields) end

local function getCourtCases(player, data)
  local page = data.page or 1
  local query = data.query or ""
  local limit = 10
  local offset = (page - 1) * limit

  local courtCasesQuery = [[
    SELECT c.*
    FROM mdt_court_cases c
    WHERE ? = '' OR 
          LOWER(c.title) LIKE LOWER(?) OR 
          LOWER(c.defendant) LIKE LOWER(?) OR 
          LOWER(c.id) LIKE LOWER(?)
    ORDER BY c.date DESC
    LIMIT ? OFFSET ?
  ]]

  local courtCasesParams = {
    query,
    "%" .. query .. "%",
    "%" .. query .. "%",
    "%" .. query .. "%",
    limit,
    offset
  }

  local courtCases = MySQL.query.await(courtCasesQuery, courtCasesParams)

  local totalCountQuery = [[
    SELECT COUNT(*) as count FROM mdt_court_cases 
    WHERE ? = '' OR 
          LOWER(title) LIKE LOWER(?) OR 
          LOWER(defendant) LIKE LOWER(?) OR 
          LOWER(id) LIKE LOWER(?)
  ]]

  local totalCountParams = {
    query,
    "%" .. query .. "%",
    "%" .. query .. "%",
    "%" .. query .. "%"
  }

  local totalCount = MySQL.query.await(totalCountQuery, totalCountParams)[1].count

  local caseIds = {}
  for _, case in ipairs(courtCases) do
    table.insert(caseIds, case.id)
  end

  local notesQuery = [[
    SELECT * FROM mdt_court_case_notes 
    WHERE caseId IN (?)
    ORDER BY timestamp DESC
  ]]

  local notesParams = {table.concat(caseIds, ",")}

  local notes = MySQL.query.await(notesQuery, notesParams)

  local notesByCaseId = {}
  for _, note in ipairs(notes) do
    local caseId = note.caseId
    if not notesByCaseId[caseId] then
      notesByCaseId[caseId] = {}
    end
    table.insert(notesByCaseId[caseId], note)
  end

  for _, case in ipairs(courtCases) do
    local caseId = case.id
    case.notes = notesByCaseId[caseId] or {}
    case.formattedId = courtCaseFormatter(caseId)
  end

  return {
    success = true,
    cases = courtCases,
    totalCount = totalCount
  }
end

lib.callback.register("kartik-mdt:server:getCourtCases", getCourtCases)

local function createCourtCase(player, data)
  local caseData = data.caseData
  if not caseData then
    return {
      success = false,
      error = "No case data provided"
    }
  end

  local playerData = GetPlayerData(player)

  local title = caseData.title
  if not title or #title < 3 then
    return {
      success = false,
      error = "Case title is required and must be at least 3 characters"
    }
  end

  local defendant = caseData.defendant
  if not defendant or #defendant < 3 then
    return {
      success = false,
      error = "Defendant name is required and must be at least 3 characters"
    }
  end

  local date = caseData.date
  if not date then
    return {
      success = false,
      error = "Case date is required"
    }
  end

  local query = [[
    INSERT INTO mdt_court_cases (
      title, date, status, defendant, judge, defense, 
      prosecution, courtroom, relatedReports
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  ]]

  local params = {
    title,
    date,
    caseData.status,
    defendant,
    caseData.judge or "",
    caseData.defense or "",
    caseData.prosecution or "",
    caseData.courtroom or "",
    json.encode(caseData.relatedReports or {})
  }

  local result, err = pcall(MySQL.query.await, query, params)
  if not result then
    return {
      success = false,
      error = "Database error: " .. tostring(err)
    }
  end

  local caseId = MySQL.query.await.insertId

  local noteQuery = [[
    INSERT INTO mdt_court_case_notes (caseId, timestamp, author, content)
    VALUES (?, ?, ?, ?)
  ]]

  local noteParams = {
    caseId,
    os.date("%Y-%m-%dT%H:%M:%S"),
    playerData.name,
    "Case created by " .. playerData.name
  }

  local noteResult, noteErr = pcall(MySQL.query.await, noteQuery, noteParams)
  if not noteResult then
    print("Failed to add initial note:", tostring(noteErr))
  end

  SendDiscordLog("court_cases", "\240\159\147\129 New Court Case Created", nil, 3447003, {
    {name = "Case ID", value = tostring(caseId), inline = true},
    {name = "Title", value = title, inline = true},
    {name = "Defendant", value = defendant, inline = true},
    {name = "Filed By", value = FormatPlayer(player), inline = false}
  })

  return {
    success = true,
    caseId = caseId,
    message = "Court case created successfully"
  }
end

lib.callback.register("kartik-mdt:server:createCourtCase", createCourtCase)

local function updateCourtCaseStatus(player, data)
  local caseData = data.caseData
  if not caseData then
    return {
      success = false,
      error = "Invalid case data"
    }
  end

  local caseId = caseData.caseId
  if not caseId then
    return {
      success = false,
      error = "Invalid case data"
    }
  end

  local playerData = GetPlayerData(player)

  local query = [[
    UPDATE mdt_court_cases 
    SET status = ?, verdict = ?, sentence = ?, 
        postponedReason = ?, newDate = ?
    WHERE id = ?
  ]]

  local params = {
    caseData.status,
    caseData.verdict,
    caseData.sentence,
    caseData.postponedReason,
    caseData.newDate,
    caseId
  }

  local result = MySQL.query.await(query, params)

  if result.affectedRows > 0 then
    local noteQuery = [[
      INSERT INTO mdt_court_case_notes (caseId, timestamp, author, content)
      VALUES (?, ?, ?, ?)
    ]]

    local noteParams = {
      caseId,
      os.date("%Y-%m-%dT%H:%M:%S"),
      playerData.name,
      string.format("Status updated to: %s", caseData.status)
    }

    MySQL.query.await(noteQuery, noteParams)

    local caseQuery = [[
      SELECT c.*, 
             (SELECT JSON_ARRAYAGG(
                  JSON_OBJECT(
                      'id', n.id,
                      'timestamp', n.timestamp,
                      'author', n.author,
                      'content', n.content
                  )
              ) FROM mdt_court_case_notes n WHERE n.caseId = c.id) as notes
      FROM mdt_court_cases c
      WHERE c.id = ?
    ]]

    local caseParams = {caseId}

    local caseData = MySQL.query.await(caseQuery, caseParams)[1]

    caseData.relatedReports = json.decode(caseData.relatedReports or "[]")
    caseData.notes = json.decode(caseData.notes or "[]")

    SendDiscordLog("court_cases", "\226\154\150\239\184\143 Court Case Status Updated", nil, 15105570, {
      {name = "Case ID", value = tostring(caseId), inline = true},
      {name = "New Status", value = caseData.status or "N/A", inline = true},
      {name = "Updated By", value = FormatPlayer(player), inline = false}
    })

    return {
      success = true,
      data = {case = caseData}
    }
  else
    return {
      success = false,
      error = "Case not found"
    }
  end
end

lib.callback.register("kartik-mdt:server:updateCourtCaseStatus", updateCourtCaseStatus)

local function addCourtCaseNote(player, data)
  local caseData = data.case
  if not caseData then
    return {
      success = false,
      error = "Invalid case data"
    }
  end

  local caseId = caseData.caseId
  if not caseId then
    return {
      success = false,
      error = "Invalid case data"
    }
  end

  local playerData = GetPlayerData(player)

  local query = [[
    INSERT INTO mdt_court_case_notes (caseId, timestamp, author, content)
    VALUES (?, ?, ?, ?)
  ]]

  local params = {
    caseId,
    os.date("%Y-%m-%dT%H:%M:%S"),
    playerData.name,
    caseData.content
  }

  local result = MySQL.query.await(query, params)

  if result.affectedRows > 0 then
    SendDiscordLog("court_cases", "\240\159\147\157 New Note Added to Court Case", nil, 15844367, {
      {name = "Case ID", value = tostring(caseId), inline = true},
      {name = "Author", value = playerData.name, inline = true},
      {name = "Added By", value = FormatPlayer(player), inline = false},
      {name = "Note", value = caseData.content:sub(1, 100), inline = false}
    })

    return {
      success = true
    }
  else
    return {
      success = false,
      error = "Failed to add note"
    }
  end
end

lib.callback.register("kartik-mdt:server:addCourtCaseNote", addCourtCaseNote)

local lib = lib
local registerCallback = lib.callback.register
local deleteCourtCase = function(player, data)
    local caseId = data.caseId
    if not caseId then
        return { success = false, error = "No case ID provided" }
    end
    local query = "SELECT id FROM mdt_court_cases WHERE id = ?"
    local result = MySQL.query.await(query, { caseId })
    if result and #result > 0 then
        query = "DELETE FROM mdt_court_cases WHERE id = ?"
        local result = MySQL.query.await(query, { caseId })
        if result.affectedRows > 0 then
            local logData = {
                "court_cases",
                "\226\157\140 Court Case Deleted",
                nil,
                10038562,
                {
                    { name = "Case ID", value = tostring(caseId), inline = true },
                    { name = "Deleted By", value = FormatPlayer(player), inline = false }
                }
            }
            SendDiscordLog(table.unpack(logData))
            return { success = true, data = { caseId = caseId } }
        else
            return { success = false, error = "Failed to delete case" }
        end
    else
        return { success = false, error = "Case not found" }
    end
end
registerCallback("kartik-mdt:server:deleteCourtCase", deleteCourtCase)

local formatDateTime = function(dateString)
    local year, month, day, hour, minute, second = dateString:match("(%d+)%-(%d+)%-(%d+)T(%d+):(%d+):(%d+)")
    return string.format("%04d-%02d-%02d %02d:%02d:%02d", year, month, day, hour, minute, second)
end

local getCourtCasesForDateRange = function(player, data)
    local startDate = data.startDate
    local endDate = data.endDate
    if not startDate or not endDate then
        return { success = false, error = "No date provided" }
    end
    startDate = formatDateTime(startDate)
    endDate = formatDateTime(endDate)
    local query = [[
        SELECT * FROM mdt_court_cases
        WHERE date BETWEEN ? AND ?
        ORDER BY date DESC
    ]]
    local results = MySQL.query.await(query, { startDate, endDate })
    if #results == 0 then
        return { success = false, error = "No cases found for the given date range" }
    end
    local caseIds = {}
    for _, result in ipairs(results) do
        table.insert(caseIds, result.id)
    end
    local notes = {}
    if #caseIds > 0 then
        query = [[
            SELECT * FROM mdt_court_case_notes 
            WHERE caseId IN (]] .. table.concat(caseIds, ",") .. [[)
            ORDER BY timestamp DESC
        ]]
        local noteResults = MySQL.query.await(query)
        notes = {}
        for _, note in ipairs(noteResults) do
            local caseId = note.caseId
            if not notes[caseId] then
                notes[caseId] = {}
            end
            table.insert(notes[caseId], note)
        end
    end
    for _, result in ipairs(results) do
        result.relatedReports = json.decode(result.relatedReports or "[]")
        result.notes = notes[result.id] or {}
        result.formattedId = formatDateTime(tostring(result.id))
    end
    return { success = true, cases = results }
end
registerCallback("kartik-mdt:server:getCourtCasesForDateRange", getCourtCasesForDateRange)