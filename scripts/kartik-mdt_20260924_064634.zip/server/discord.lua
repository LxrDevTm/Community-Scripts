local apiEndpoint = "https://discord.com/api"
local routes = {}
routes.activeThreads = "/channels/%s/threads/active"
routes.ban = "/guilds/%s/bans/%s"
routes.bans = "/guilds/%s/bans"
routes.bulkDelete = "/channels/%s/messages/bulk-delete"
routes.channel = "/channels/%s"
routes.channelInvites = "/channels/%s/invites"
routes.channelThreads = "/channels/%s/threads"
routes.createDm = "/users/@me/channels"
routes.crosspost = "/channels/%s/messages/%s/crosspost"
routes.currentUser = "/users/@me"
routes.followers = "/channels/%s/followers"
routes.github = "/webhooks/%s/%s/github"
routes.groupDm = "/channels/%s/recipients/%s"
routes.guild = "/guilds/%s"
routes.guildChannels = "/guilds/%s/channels"
routes.guildEmoji = "/guilds/%s/emojis/%s"
routes.guildEmojis = "/guilds/%s/emojis"
routes.guildInvites = "/guilds/%s/invites"
routes.guildMember = "/guilds/%s/members/%s"
routes.guildMembers = "/guilds/%s/members"
routes.guildPreview = "/guilds/%s/preview"
routes.guilds = "/guilds"
routes.guildThreads = "/guilds/%s/threads/active"
routes.guildWebhooks = "/guilds/%s/webhooks"
routes.integration = "/guilds/%s/integrations/%"
routes.integrations = "/guilds/%s/integrations"
routes.invite = "/invites/%s"
routes.joinedThreads = "/channels/%s/users/@me/threads/archived/private"
routes.memberRole = "/guilds/%s/members/%s/roles/%s"
routes.message = "/channels/%s/messages/%s"
routes.messages = "/channels/%s/messages"
routes.messageThreads = "/channels/%s/messages/%s/threads"
routes.myConnections = "/users/@me/connections"
routes.myGuild = "/users/@me/guilds/%s"
routes.myGuilds = "/users/@me/guilds"
routes.myVoiceState = "/guilds/%s/voice-states/@me"
routes.nick = "/guilds/%s/members/@me/nick"
routes.ownReaction = "/channels/%s/messages/%s/reactions/%s/@me"
routes.pinMessage = "/channels/%s/pins/%s"
routes.pins = "/channels/%s/pins"
routes.privateThreads = "/channels/%s/threads/archived/private"
routes.prune = "/guilds/%s/prune"
routes.publicThreads = "/channels/%s/threads/archived/public"
routes.reaction = "/channels/%s/messages/%s/reactions/%s"
routes.reactions = "/channels/%s/messages/%s/reactions"
routes.regions = "/guilds/%s/regions"
routes.role = "/guilds/%s/roles/%s"
routes.roles = "/guilds/%s/roles"
routes.searchMembers = "/guilds/%s/members/search"
routes.slack = "/webhooks/%s/%s/slack"
routes.threadMembers = "/channels/%s/thread-members"
routes.threadSelf = "/channels/%s/thread-members/@me"
routes.threadUser = "/channels/%s/thread-members/%s"
routes.typing = "/channels/%s/typing"
routes.user = "/users/%s"
routes.userReaction = "/channels/%s/messages/%s/reactions/%s/%s"
routes.userVoiceState = "/guilds/%s/voice-states/%s"
routes.vanityUrl = "/guilds/%s/vanity-url"
routes.webhook = "/webhooks/%s/%s"
routes.webhookId = "/webhooks/%s"
routes.webhookMessage = "/webhooks/%s/%s/messages/%s"
routes.webhooks = "/channels/%s/webhooks"
routes.welcomeScreen = "/guilds/%s/welcome-screen"
routes.widget = "/guilds/%s/widget"
routes.widgetImage = "/guilds/%s/widget.png"
routes.widgetJson = "/guilds/%s/widget.json"

function isRateLimited(statusCode)
  return statusCode < 200
end

function isNotRateLimited(statusCode)
  local isNotLimited = not isRateLimited(statusCode)
  return isNotLimited
end

function createSimplePromiseCallback(promise)
  return function(resolve, reject, statusCode, response)
    local object = json.decode(response)
    if object == nil then
      reject(response)
    else
      resolve(object)
    end
  end
end

function createQueryString(query)
  local queryString = {}
  if query then
    for key, value in pairs(query) do
      table.insert(queryString, string.format("%s=%s", key, value))
    end
  end
  local queryStringLength = #queryString
  if queryStringLength > 0 then
    return "?" .. table.concat(queryString, "&")
  else
    return ""
  end
end

local Queue = {}
Queue.__index = Queue

function Queue.new(route)
  local instance = setmetatable({}, Queue)
  instance.route = route
  instance.items = {}
  instance.rateLimitRemaining = 0
  instance.rateLimitReset = 0
  instance.rateLimitHits = 0
  return instance
end

function Queue:enqueue(item)
  table.insert(self.items, 1, item)
end

function Queue:dequeue()
  local item = table.remove(self.items)
  if item then
    if not item() then
      table.insert(self.items, item)
    end
  end
end

function Queue:isReady()
  return #self.items > 0
end

function Queue:processResponse(statusCode, response)
  self.rateLimitRemaining = self.rateLimitRemaining - 1
  if statusCode == 429 then
    self.rateLimitRemaining = 0
    self.rateLimitHits = self.rateLimitHits + 1
    local resetTime = os.time() + (self.rateLimitHits * 5)
    self.rateLimitReset = resetTime
    return false
  else
    if self.rateLimitHits > 0 then
      self.rateLimitHits = self.rateLimitHits - 1
    end
    if isNotRateLimited(statusCode) then
      local remaining = tonumber(response["x-ratelimit-remaining"])
      local reset = tonumber(response["x-ratelimit-reset"])
      if remaining then
        self.rateLimitRemaining = remaining
      end
      if reset then
        self.rateLimitReset = reset
      end
    end
    return true
  end
end

local DiscordRest = {}
DiscordRest.channelTypes = {
  GUILD_TEXT = 0,
  DM = 1,
  GUILD_VOICE = 2,
  GROUP_DM = 3,
  GUILD_CATEGORY = 4,
  GUILD_NEWS = 5,
  GUILD_STORE = 6,
  GUILD_NEWS_THREAD = 10,
  GUILD_PUBLIC_THREAD = 11,
  GUILD_PRIVATE_THREAD = 12,
  GUILD_STAGE_VOICE = 13
}

function DiscordRest.new(botToken)
  local instance = setmetatable({}, DiscordRest)
  instance.botToken = botToken
  instance.queues = {}
  Citizen.CreateThread(function()
    while true do
      local processed = instance:processQueues()
      if processed then
        Citizen.Wait(50)
      end
    end
  end)
  return instance
end

function DiscordRest:getQueue(route)
  local queue = self.queues[route]
  if not queue then
    queue = Queue.new(route)
    self.queues[route] = queue
  end
  return queue
end

function DiscordRest:processQueues()
  local processed = false
  for route, queue in pairs(self.queues) do
    if queue:isReady() then
      queue:dequeue()
      processed = true
      Citizen.Wait(50)
    end
  end
  return processed
end

function DiscordRest:getAuthorization(token)
  return "Bot " .. (token or self.botToken or "")
end

function DiscordRest:enqueueRequest(route, method, query, body, headers, callback)
  if not headers then
    headers = {}
  end
  if body then
    local bodyType = type(body)
    if bodyType ~= "string" then
      headers["Content-Type"] = "application/json"
      body = json.encode(body)
    end
  else
    headers["Content-Length"] = "0"
    body = ""
  end
  local queue = self:getQueue(route)
  local promise = promise.new()
  local callbackWrapper = createSimplePromiseCallback(promise)
  PerformHttpRequest(route, function(statusCode, response)
    local processed = queue:processResponse(statusCode, response)
    if processed then
      callbackWrapper(statusCode, response)
      if callback then
        callback(statusCode, response)
      end
    else
      callbackWrapper(false)
      if Config.debug then
        print(string.format("Rate limiting detected for %s, this request will be requeued after %d seconds", route, queue.rateLimitHits * 5))
      end
    end
  end, method, body, headers)
  return Citizen.Await(promise)
end

function DiscordRest:performRequest(route, method, query, body, headers, callback)
  local queue = self:getQueue(route)
  local url = createQueryString(query)
  local promise = promise.new()
  local callbackWrapper = createSimplePromiseCallback(promise)
  self:enqueueRequest(route .. url, method, query, body, headers, callbackWrapper)
  return promise
end

DiscordRest.performRequestToWebhook = function(rest, endpoint, method, headers, body, query, options)
    local request = rest.performRequest
    local authorization = rest.getAuthorization(endpoint, options)
    local headers = headers or {}
    headers.Authorization = authorization
    return request(rest, endpoint, method, headers, body, query, options)
end

DiscordRest.addThreadMember = function(rest, threadId, userId, options)
    local request = rest.performAuthorizedRequest
    local endpoint = rest.threadUser
    local params = {threadId, userId}
    local method = "PUT"
    local body = nil
    return request(rest, endpoint, params, body, method, nil, options)
end

DiscordRest.bulkDeleteMessages = function(rest, channelId, messages, options)
    local request = rest.performAuthorizedRequest
    local endpoint = rest.bulkDelete
    local params = {channelId}
    local method = "POST"
    local body = {messages = messages}
    return request(rest, endpoint, params, nil, method, body, options)
end

DiscordRest.createChannelInvite = function(rest, channelId, options, data)
    local request = rest.performAuthorizedRequest
    local endpoint = rest.channelInvites
    local params = {channelId}
    local method = "POST"
    local body = data or {}
    return request(rest, endpoint, params, nil, method, body, options)
end

DiscordRest.createMessage = function(rest, channelId, data, options)
    local request = rest.performAuthorizedRequest
    local endpoint = rest.messages
    local params = {channelId}
    local method = "POST"
    local body = data
    return request(rest, endpoint, params, nil, method, body, options)
end

DiscordRest.createReaction = function(rest, channelId, messageId, emoji, options)
    local request = rest.performAuthorizedRequest
    local endpoint = rest.ownReaction
    local params = {channelId, messageId, emoji}
    local method = "PUT"
    local body = nil
    return request(rest, endpoint, params, nil, method, body, options)
end

DiscordRest.crosspostMessage = function(rest, channelId, messageId, options)
    local request = rest.performAuthorizedRequest
    local endpoint = rest.crosspost
    local params = {channelId, messageId}
    local method = "POST"
    local body = nil
    return request(rest, endpoint, params, nil, method, body, options)
end

DiscordRest.deleteAllReactions = function(rest, channelId, messageId, options)
    local request = rest.performAuthorizedRequest
    local endpoint = rest.reactions
    local params = {channelId, messageId}
    local method = "DELETE"
    local body = nil
    return request(rest, endpoint, params, nil, method, body, options)
end

DiscordRest.deleteAllReactionsForEmoji = function(rest, channelId, messageId, emoji, options)
    local request = rest.performAuthorizedRequest
    local endpoint = rest.reaction
    local params = {channelId, messageId, emoji}
    local method = "DELETE"
    local body = nil
    return request(rest, endpoint, params, nil, method, body, options)
end

DiscordRest.deleteChannel = function(rest, channelId, options)
    local request = rest.performAuthorizedRequest
    local endpoint = rest.channel
    local params = {channelId}
    local method = "DELETE"
    local body = nil
    return request(rest, endpoint, params, nil, method, body, options)
end

DiscordRest.deleteChannelPermission = function(rest, channelId, overwriteId, options)
    local request = rest.performAuthorizedRequest
    local endpoint = rest.editChannelPermissions
    local params = {channelId, overwriteId}
    local method = "DELETE"
    local body = nil
    return request(rest, endpoint, params, nil, method, body, options)
end

DiscordRest.deleteMessage = function(rest, channelId, messageId, options)
    local request = rest.performAuthorizedRequest
    local endpoint = rest.message
    local params = {channelId, messageId}
    local method = "DELETE"
    local body = nil
    return request(rest, endpoint, params, nil, method, body, options)
end

DiscordRest.deleteOwnReaction = function(rest, channelId, messageId, emoji, options)
    local request = rest.performAuthorizedRequest
    local endpoint = rest.ownReaction
    local params = {channelId, messageId, emoji}
    local method = "DELETE"
    local body = nil
    return request(rest, endpoint, params, nil, method, body, options)
end

DiscordRest.deleteUserReaction = function(rest, channelId, messageId, userId, emoji, options)
    local request = rest.performAuthorizedRequest
    local endpoint = rest.userReaction
    local params = {channelId, messageId, userId, emoji}
    local method = "DELETE"
    local body = nil
    return request(rest, endpoint, params, nil, method, body, options)
end

DiscordRest.editChannelPermissions = function(rest, channelId, overwriteId, options, data)
    local request = rest.performAuthorizedRequest
    local endpoint = rest.editChannelPermissions
    local params = {channelId, overwriteId}
    local method = "PUT"
    local body = data
    return request(rest, endpoint, params, nil, method, body, options)
end

DiscordRest.editMessage = function(rest, channelId, messageId, options, data)
    local request = rest.performAuthorizedRequest
    local endpoint = rest.message
    local params = {channelId, messageId}
    local method = "PATCH"
    local body = data
    return request(rest, endpoint, params, nil, method, body, options)
end

DiscordRest.followNewsChannel = function(rest, channelId, webhookChannelId, options)
    local request = rest.performAuthorizedRequest
    local endpoint = rest.followers
    local params = {channelId}
    local method = "POST"
    local body = {webhook_channel_id = webhookChannelId}
    return request(rest, endpoint, params, nil, method, body, options)
end

DiscordRest.getChannel = function(rest, channelId, options)
    local request = rest.performAuthorizedRequest
    local endpoint = rest.channel
    local params = {channelId}
    local method = "GET"
    local body = nil
    return request(rest, endpoint, params, nil, method, body, options)
end

DiscordRest.getChannelInvites = function(rest, channelId, options)
    local request = rest.performAuthorizedRequest
    local endpoint = rest.channelInvites
    local params = {channelId}
    local method = "GET"
    local body = nil
    return request(rest, endpoint, params, nil, method, body, options)
end

DiscordRest.getChannelMessage = function(rest, channelId, messageId, options)
    local request = rest.performAuthorizedRequest
    local endpoint = rest.message
    local params = {channelId, messageId}
    local method = "GET"
    local body = nil
    return request(rest, endpoint, params, nil, method, body, options)
end

DiscordRest.getChannelMessages = function(rest, channelId, options, limit)
    local request = rest.performAuthorizedRequest
    local endpoint = rest.messages
    local params = {channelId}
    local method = "GET"
    local body = nil
    return request(rest, endpoint, params, limit, method, body, options)
end

DiscordRest.getPinnedMessages = function(rest, channelId, options)
    local request = rest.performAuthorizedRequest
    local endpoint = rest.pins
    local params = {channelId}
    local method = "GET"
    local body = nil
    return request(rest, endpoint, params, nil, method, body, options)
end

DiscordRest.getReactions = function(rest, channelId, messageId, emoji, options, limit)
    local request = rest.performAuthorizedRequest
    local endpoint = rest.reaction
    local params = {channelId, messageId, emoji}
    local method = "GET"
    local body = nil
    return request(rest, endpoint, params, limit, method, body, options)
end

DiscordRest.groupDmAddRecipient = function(rest, channelId, userId, options, data)
    local request = rest.performAuthorizedRequest
    local endpoint = rest.groupDm
    local params = {channelId, userId}
    local method = "PUT"
    local body = data
    return request(rest, endpoint, params, nil, method, body, options)
end

DiscordRest.groupDmRemoveRecipient = function(rest, channelId, userId, options)
    local request = rest.performAuthorizedRequest
    local endpoint = rest.groupDm
    local params = {channelId, userId}
    local method = "DELETE"
    local body = nil
    return request(rest, endpoint, params, nil, method, body, options)
end

DiscordRest.joinThread = function(rest, threadId, options)
    local request = rest.performAuthorizedRequest
    local endpoint = rest.threadSelf
    local params = {threadId}
    local method = "PUT"
    local body = nil
    return request(rest, endpoint, params, nil, method, body, options)
end

DiscordRest.leaveThread = function(rest, threadId, options)
    local request = rest.performAuthorizedRequest
    local endpoint = rest.threadSelf
    local params = {threadId}
    local method = "DELETE"
    local body = nil
    return request(rest, endpoint, params, nil, method, body, options)
end

DiscordRest.listActiveThreads = function(rest, guildId, options)
    local request = rest.performAuthorizedRequest
    local endpoint = rest.activeThreads
    local params = {guildId}
    local method = "GET"
    local body = nil
    return request(rest, endpoint, params, nil, method, body, options)
end

function listJoinedPrivateArchivedThreads(rest, guildId, options)
    local request = rest.performAuthorizedRequest
    local endpoint = rest.joinedThreads
    local params = {}
    params[1] = guildId
    local body = nil
    local method = "GET"
    local auth = options
    return request(rest, endpoint, params, body, method, nil, auth)
end
DiscordRest.listJoinedPrivateArchivedThreads = listJoinedPrivateArchivedThreads

function listPrivateArchivedThreads(rest, guildId, options)
    local request = rest.performAuthorizedRequest
    local endpoint = rest.privateThreads
    local params = {}
    params[1] = guildId
    local body = nil
    local method = "GET"
    local auth = options
    return request(rest, endpoint, params, body, method, nil, auth)
end
DiscordRest.listPrivateArchivedThreads = listPrivateArchivedThreads

function listPublicArchivedThreads(rest, guildId, options)
    local request = rest.performAuthorizedRequest
    local endpoint = rest.publicThreads
    local params = {}
    params[1] = guildId
    local body = nil
    local method = "GET"
    local auth = options
    return request(rest, endpoint, params, body, method, nil, auth)
end
DiscordRest.listPublicArchivedThreads = listPublicArchivedThreads

function listThreadMembers(rest, threadId, options)
    local request = rest.performAuthorizedRequest
    local endpoint = rest.threadMembers
    local params = {}
    params[1] = threadId
    local body = nil
    local method = "GET"
    local auth = options
    return request(rest, endpoint, params, body, method, nil, auth)
end
DiscordRest.listThreadMembers = listThreadMembers

function modifyChannel(rest, channelId, options, reason)
    local request = rest.performAuthorizedRequest
    local endpoint = rest.channel
    local params = {}
    params[1] = channelId
    local body = options
    local method = "PATCH"
    local auth = reason
    return request(rest, endpoint, params, nil, method, body, auth)
end
DiscordRest.modifyChannel = modifyChannel

function pinMessage(rest, channelId, messageId, options)
    local request = rest.performAuthorizedRequest
    local endpoint = rest.pinMessage
    local params = {}
    params[1] = channelId
    params[2] = messageId
    local body = nil
    local method = "PUT"
    local auth = options
    return request(rest, endpoint, params, nil, method, nil, auth)
end
DiscordRest.pinMessage = pinMessage

function removeThreadMember(rest, threadId, userId, options)
    local request = rest.performAuthorizedRequest
    local endpoint = rest.threadUser
    local params = {}
    params[1] = threadId
    params[2] = userId
    local body = nil
    local method = "DELETE"
    local auth = options
    return request(rest, endpoint, params, nil, method, nil, auth)
end
DiscordRest.removeThreadMember = removeThreadMember

function startThreadWithMessage(rest, channelId, messageId, options)
    local request = rest.performAuthorizedRequest
    local endpoint = rest.messageThreads
    local params = {}
    params[1] = channelId
    params[2] = messageId
    local body = options
    local method = "POST"
    local auth = nil
    return request(rest, endpoint, params, nil, method, body, auth)
end
DiscordRest.startThreadWithMessage = startThreadWithMessage

function startThreadWithoutMessage(rest, channelId, options, reason)
    local autoArchiveDuration = options.auto_archive_duration
    if not autoArchiveDuration then
        options.auto_archive_duration = 1440
    end
    local type = type(options.type)
    if "string" == type then
        local channelTypes = DiscordRest.channelTypes
        options.type = channelTypes[options.type]
    end
    if not options.type then
        options.type = DiscordRest.channelTypes.GUILD_PUBLIC_THREAD
    end
    local request = rest.performAuthorizedRequest
    local endpoint = rest.channelThreads
    local params = {}
    params[1] = channelId
    local body = options
    local method = "POST"
    local auth = reason
    return request(rest, endpoint, params, nil, method, body, auth)
end
DiscordRest.startThreadWithoutMessage = startThreadWithoutMessage

function triggerTypingIndicator(rest, channelId, options)
    local request = rest.performAuthorizedRequest
    local endpoint = rest.typing
    local params = {}
    params[1] = channelId
    local body = nil
    local method = "POST"
    local auth = options
    return request(rest, endpoint, params, nil, method, nil, auth)
end
DiscordRest.triggerTypingIndicator = triggerTypingIndicator

function unpinMessage(rest, channelId, messageId, options)
    local request = rest.performAuthorizedRequest
    local endpoint = rest.pinMessage
    local params = {}
    params[1] = channelId
    params[2] = messageId
    local body = nil
    local method = "DELETE"
    local auth = options
    return request(rest, endpoint, params, nil, method, nil, auth)
end
DiscordRest.unpinMessage = unpinMessage

function createGuildEmoji(rest, guildId, emoji, options)
    local request = rest.performAuthorizedRequest
    local endpoint = rest.guildEmojis
    local params = {}
    params[1] = guildId
    local body = emoji
    local method = "POST"
    local auth = options
    return request(rest, endpoint, params, nil, method, body, auth)
end
DiscordRest.createGuildEmoji = createGuildEmoji

function deleteGuildEmoji(rest, guildId, emojiId, options)
    local request = rest.performAuthorizedRequest
    local endpoint = rest.guildEmoji
    local params = {}
    params[1] = guildId
    params[2] = emojiId
    local body = nil
    local method = "DELETE"
    local auth = options
    return request(rest, endpoint, params, nil, method, nil, auth)
end
DiscordRest.deleteGuildEmoji = deleteGuildEmoji

function getGuildEmoji(rest, guildId, emojiId, options)
    local request = rest.performAuthorizedRequest
    local endpoint = rest.guildEmoji
    local params = {}
    params[1] = guildId
    params[2] = emojiId
    local body = nil
    local method = "GET"
    local auth = options
    return request(rest, endpoint, params, nil, method, nil, auth)
end
DiscordRest.getGuildEmoji = getGuildEmoji

function listGuildEmojis(rest, guildId, options)
    local request = rest.performAuthorizedRequest
    local endpoint = rest.guildEmojis
    local params = {}
    params[1] = guildId
    local body = nil
    local method = "GET"
    local auth = options
    return request(rest, endpoint, params, nil, method, nil, auth)
end
DiscordRest.listGuildEmojis = listGuildEmojis

function modifyGuildEmoji(rest, guildId, emojiId, emoji, options)
    local request = rest.performAuthorizedRequest
    local endpoint = rest.guildEmoji
    local params = {}
    params[1] = guildId
    params[2] = emojiId
    local body = emoji
    local method = "PATCH"
    local auth = options
    return request(rest, endpoint, params, nil, method, body, auth)
end
DiscordRest.modifyGuildEmoji = modifyGuildEmoji

function addGuildMember(rest, guildId, userId, options)
    local request = rest.performAuthorizedRequest
    local endpoint = rest.guildMember
    local params = {}
    params[1] = guildId
    params[2] = userId
    local body = options
    local method = "PUT"
    local auth = nil
    return request(rest, endpoint, params, nil, method, body, auth)
end
DiscordRest.addGuildMember = addGuildMember

function addGuildMemberRole(rest, guildId, userId, roleId, options)
    local request = rest.performAuthorizedRequest
    local endpoint = rest.memberRole
    local params = {}
    params[1] = guildId
    params[2] = userId
    params[3] = roleId
    local body = nil
    local method = "PUT"
    local auth = options
    return request(rest, endpoint, params, nil, method, nil, auth)
end
DiscordRest.addGuildMemberRole = addGuildMemberRole

function beginGuildPrune(rest, guildId, options)
    local request = rest.performAuthorizedRequest
    local endpoint = rest.prune
    local params = {}
    params[1] = guildId
    local body = options
    local method = "POST"
    local auth = nil
    local response = request(rest, endpoint, params, nil, method, body, auth)
    local next = response.next
    function callback(response)
        local pruned = response.pruned
        return pruned
    end
    return next(response, callback)
end
DiscordRest.beginGuildPrune = beginGuildPrune

function createGuild(rest, name, options)
    local request = rest.performAuthorizedRequest
    local endpoint = rest.guilds
    local params = nil
    local body = name
    local method = "POST"
    local auth = options
    return request(rest, endpoint, params, nil, method, body, auth)
end
DiscordRest.createGuild = createGuild

function createGuildBan(rest, guildId, userId, options, reason)
    local request = rest.performAuthorizedRequest
    local endpoint = rest.ban
    local params = {}
    params[1] = guildId
    params[2] = userId
    local body = options
    local method = "PUT"
    local auth = reason
    return request(rest, endpoint, params, nil, method, body, auth)
end
DiscordRest.createGuildBan = createGuildBan

function createGuildChannel(rest, guildId, options, reason)
    local request = rest.performAuthorizedRequest
    local endpoint = rest.guildChannels
    local params = {}
    params[1] = guildId
    local body = options
    local method = "POST"
    local auth = reason
    return request(rest, endpoint, params, nil, method, body, auth)
end
DiscordRest.createGuildChannel = createGuildChannel

function createGuildRole(rest, guildId, options, reason)
    local request = rest.performAuthorizedRequest
    local endpoint = rest.roles
    local params = {}
    params[1] = guildId
    local body = options
    local method = "POST"
    local auth = reason
    return request(rest, endpoint, params, nil, method, body, auth)
end
DiscordRest.createGuildRole = createGuildRole

function deleteGuild(rest, guildId, options)
    local request = rest.performAuthorizedRequest
    local endpoint = rest.guild
    local params = {}
    params[1] = guildId
    local body = nil
    local method = "DELETE"
    local auth = options
    return request(rest, endpoint, params, nil, method, nil, auth)
end
DiscordRest.deleteGuild = deleteGuild

function deleteGuildIntegration(rest, guildId, integrationId, options)
    local request = rest.performAuthorizedRequest
    local endpoint = rest.integration
    local params = {}
    params[1] = guildId
    params[2] = integrationId
    local body = nil
    local method = "DELETE"
    local auth = options
    return request(rest, endpoint, params, nil, method, nil, auth)
end
DiscordRest.deleteGuildIntegration = deleteGuildIntegration

function deleteGuildRole(rest, guildId, roleId, options)
    local request = rest.performAuthorizedRequest
    local endpoint = rest.role
    local params = {}
    params[1] = guildId
    params[2] = roleId
    local body = nil
    local method = "DELETE"
    local auth = options
    return request(rest, endpoint, params, nil, method, nil, auth)
end
DiscordRest.deleteGuildRole = deleteGuildRole

function getGuild(rest, guildId, options)
    local request = rest.performAuthorizedRequest
    local endpoint = rest.guild
    local params = {}
    params[1] = guildId
    local query = {}
    query.with_counts = options
    local body = nil
    local method = "GET"
    local auth = nil
    return request(rest, endpoint, params, query, method, nil, auth)
end
DiscordRest.getGuild = getGuild

function getGuildBan(rest, guildId, userId, options)
    local request = rest.performAuthorizedRequest
    local endpoint = rest.ban
    local params = {}
    params[1] = guildId
    params[2] = userId
    local body = nil
    local method = "GET"
    local auth = options
    return request(rest, endpoint, params, nil, method, nil, auth)
end
DiscordRest.getGuildBan = getGuildBan

DiscordRest.getGuildBan = function(rest, guildId, userId, reason)
  local performRequest = rest.performAuthorizedRequest
  local endpoint = rest.bans
  local params = {guildId, userId}
  local query = nil
  local method = "GET"
  local body = nil
  local options = reason
  return performRequest(rest, endpoint, params, query, method, body, options)
end

DiscordRest.getGuildBans = function(rest, guildId, limit, before, after)
  local performRequest = rest.performAuthorizedRequest
  local endpoint = rest.bans
  local params = {guildId}
  local query = {limit = limit, before = before, after = after}
  local method = "GET"
  local body = nil
  local options = nil
  return performRequest(rest, endpoint, params, query, method, body, options)
end

DiscordRest.getGuildChannels = function(rest, guildId)
  local performRequest = rest.performAuthorizedRequest
  local endpoint = rest.guildChannels
  local params = {guildId}
  local query = nil
  local method = "GET"
  local body = nil
  local options = nil
  return performRequest(rest, endpoint, params, query, method, body, options)
end

DiscordRest.getGuildIntegrations = function(rest, guildId)
  local performRequest = rest.performAuthorizedRequest
  local endpoint = rest.integrations
  local params = {guildId}
  local query = nil
  local method = "GET"
  local body = nil
  local options = nil
  return performRequest(rest, endpoint, params, query, method, body, options)
end

DiscordRest.getGuildInvites = function(rest, guildId)
  local performRequest = rest.performAuthorizedRequest
  local endpoint = rest.guildInvites
  local params = {guildId}
  local query = nil
  local method = "GET"
  local body = nil
  local options = nil
  return performRequest(rest, endpoint, params, query, method, body, options)
end

DiscordRest.getGuildMember = function(rest, guildId, userId, params)
  local performRequest = rest.performAuthorizedRequest
  local endpoint = rest.guildMember
  local paramsList = {guildId, userId}
  local query = nil
  local method = "GET"
  local body = nil
  local options = params
  return performRequest(rest, endpoint, paramsList, query, method, body, options)
end

DiscordRest.getGuildPreview = function(rest, guildId)
  local performRequest = rest.performAuthorizedRequest
  local endpoint = rest.guildPreview
  local params = {guildId}
  local query = nil
  local method = "GET"
  local body = nil
  local options = nil
  return performRequest(rest, endpoint, params, query, method, body, options)
end

DiscordRest.getGuildPruneCount = function(rest, guildId, days, params)
  local performRequest = rest.performAuthorizedRequest
  local endpoint = rest.prune
  local paramsList = {guildId}
  local query = {days = days}
  local method = "GET"
  local body = nil
  local options = params
  local response = performRequest(rest, endpoint, paramsList, query, method, body, options)
  local function getPrunedCount(response)
    return response.pruned
  end
  return getPrunedCount(response)
end

DiscordRest.getGuildRoles = function(rest, guildId)
  local performRequest = rest.performAuthorizedRequest
  local endpoint = rest.roles
  local params = {guildId}
  local query = nil
  local method = "GET"
  local body = nil
  local options = nil
  return performRequest(rest, endpoint, params, query, method, body, options)
end

DiscordRest.getGuildVanityUrl = function(rest, guildId)
  local performRequest = rest.performAuthorizedRequest
  local endpoint = rest.vanityUrl
  local params = {guildId}
  local query = nil
  local method = "GET"
  local body = nil
  local options = nil
  return performRequest(rest, endpoint, params, query, method, body, options)
end

DiscordRest.getGuildVoiceRegions = function(rest, guildId)
  local performRequest = rest.performAuthorizedRequest
  local endpoint = rest.regions
  local params = {guildId}
  local query = nil
  local method = "GET"
  local body = nil
  local options = nil
  return performRequest(rest, endpoint, params, query, method, body, options)
end

DiscordRest.getGuildWelcomeScreen = function(rest, guildId)
  local performRequest = rest.performAuthorizedRequest
  local endpoint = rest.welcomeScreen
  local params = {guildId}
  local query = nil
  local method = "GET"
  local body = nil
  local options = nil
  return performRequest(rest, endpoint, params, query, method, body, options)
end

DiscordRest.getGuildWidget = function(rest, guildId)
  local performRequest = rest.performRequest
  local endpoint = rest.widgetJson
  local params = {guildId}
  local query = nil
  local method = "GET"
  local body = nil
  local options = nil
  return performRequest(rest, endpoint, params, query, method, body, options)
end

DiscordRest.getGuildWidgetSettings = function(rest, guildId, params)
  local performRequest = rest.performAuthorizedRequest
  local endpoint = rest.widget
  local paramsList = {guildId}
  local query = nil
  local method = "GET"
  local body = nil
  local options = params
  return performRequest(rest, endpoint, paramsList, query, method, body, options)
end

DiscordRest.listActiveGuildThreads = function(rest, guildId, params)
  local performRequest = rest.performAuthorizedRequest
  local endpoint = rest.guildThreads
  local paramsList = {guildId}
  local query = nil
  local method = "GET"
  local body = nil
  local options = params
  return performRequest(rest, endpoint, paramsList, query, method, body, options)
end

DiscordRest.listGuildMembers = function(rest, guildId, limit, after, params)
  local performRequest = rest.performAuthorizedRequest
  local endpoint = rest.guildMembers
  local paramsList = {guildId}
  local query = {limit = limit, after = after}
  local method = "GET"
  local body = nil
  local options = params
  return performRequest(rest, endpoint, paramsList, query, method, body, options)
end

DiscordRest.modifyCurrentUserNick = function(rest, guildId, nick, params)
  local performRequest = rest.performAuthorizedRequest
  local endpoint = rest.nick
  local paramsList = {guildId}
  local query = nil
  local method = "PATCH"
  local body = {nick = nick}
  local options = params
  return performRequest(rest, endpoint, paramsList, query, method, body, options)
end

DiscordRest.modifyCurrentUserVoiceState = function(rest, guildId, params, options)
  local performRequest = rest.performAuthorizedRequest
  local endpoint = rest.myVoiceState
  local paramsList = {guildId}
  local query = nil
  local method = "PATCH"
  local body = params
  local options = options
  return performRequest(rest, endpoint, paramsList, query, method, body, options)
end

DiscordRest.modifyGuild = function(rest, guildId, params, options)
  local performRequest = rest.performAuthorizedRequest
  local endpoint = rest.guild
  local paramsList = {guildId}
  local query = nil
  local method = "PATCH"
  local body = params
  local options = options
  return performRequest(rest, endpoint, paramsList, query, method, body, options)
end

DiscordRest.modifyGuildChannelPositions = function(rest, guildId, params, options)
  local performRequest = rest.performAuthorizedRequest
  local endpoint = rest.guildChannels
  local paramsList = {guildId}
  local query = nil
  local method = "PATCH"
  local body = params
  local options = options
  return performRequest(rest, endpoint, paramsList, query, method, body, options)
end

DiscordRest.modifyGuildMember = function(rest, guildId, userId, params, options)
  local performRequest = rest.performAuthorizedRequest
  local endpoint = rest.guildMember
  local paramsList = {guildId, userId}
  local query = nil
  local method = "PATCH"
  local body = params
  local options = options
  return performRequest(rest, endpoint, paramsList, query, method, body, options)
end

DiscordRest.modifyGuildRole = function(rest, guildId, roleId, params, options)
  local performRequest = rest.performAuthorizedRequest
  local endpoint = rest.role
  local paramsList = {guildId, roleId}
  local query = nil
  local method = "PATCH"
  local body = params
  local options = options
  return performRequest(rest, endpoint, paramsList, query, method, body, options)
end

DiscordRest.modifyGuildRolePositions = function(rest, guildId, params, options)
  local performRequest = rest.performAuthorizedRequest
  local endpoint = rest.roles
  local paramsList = {guildId}
  local query = nil
  local method = "PATCH"
  local body = params
  local options = options
  return performRequest(rest, endpoint, paramsList, query, method, body, options)
end

DiscordRest.modifyGuildWelcomeScreen = function(rest, guildId, params, options)
  local performRequest = rest.performAuthorizedRequest
  local endpoint = rest.welcomeScreen
  local paramsList = {guildId}
  local query = nil
  local method = "PATCH"
  local body = params
  local options = options
  return performRequest(rest, endpoint, paramsList, query, method, body, options)
end

DiscordRest.modifyGuildWidget = function(rest, guildId, params, options)
  local performRequest = rest.performAuthorizedRequest
  local endpoint = rest.widget
  local paramsList = {guildId}
  local query = nil
  local method = "PATCH"
  local body = params
  local options = options
  return performRequest(rest, endpoint, paramsList, query, method, body, options)
end

DiscordRest.modifyUserVoiceState = function(rest, guildId, userId, params, options)
  local performRequest = rest.performAuthorizedRequest
  local endpoint = rest.userVoiceState
  local paramsList = {guildId, userId}
  local query = nil
  local method = "PATCH"
  local body = params
  local options = options
  return performRequest(rest, endpoint, paramsList, query, method, body, options)
end

DiscordRest.removeGuildBan = function(rest, guildId, userId, params)
  local performRequest = rest.performAuthorizedRequest
  local endpoint = rest.ban
  local paramsList = {guildId, userId}
  local query = nil
  local method = "DELETE"
  local body = nil
  local options = params
  return performRequest(rest, endpoint, paramsList, query, method, body, options)
end

DiscordRest.removeGuildMember = function(rest, guildId, userId, params)
  local performRequest = rest.performAuthorizedRequest
  local endpoint = rest.guildMember
  local paramsList = {guildId, userId}
  local query = nil
  local method = "DELETE"
  local body = nil
  local options = params
  return performRequest(rest, endpoint, paramsList, query, method, body, options)
end

DiscordRest.removeGuildMemberRole = function(rest, guildId, userId, roleId, params)
  local performRequest = rest.performAuthorizedRequest
  local endpoint = rest.memberRole
  local paramsList = {guildId, userId, roleId}
  local query = nil
  local method = "DELETE"
  local body = nil
  local options = params
  return performRequest(rest, endpoint, paramsList, query, method, body, options)
end

DiscordRest.searchGuildMembers = function(rest, guildId, query, params)
  local performRequest = rest.performAuthorizedRequest
  local endpoint = rest.searchMembers
  local paramsList = {guildId}
  local query = {query = query}
  local method = "GET"
  local body = nil
  local options = params
  return performRequest(rest, endpoint, paramsList, query, method, body, options)
end

DiscordRest.searchGuildMembers = function(rest, query, limit)
  local performAuthorizedRequest = rest.performAuthorizedRequest
  local invite = rest.invite
  local params = {}
  params[1] = query
  local method = "GET"
  local body = nil
  local options = limit
  return performAuthorizedRequest(rest, invite, params, nil, method, body, options)
end

DiscordRest.deleteInvite = function(rest, code, options)
  local performAuthorizedRequest = rest.performAuthorizedRequest
  local invite = rest.invite
  local params = {}
  params[1] = code
  local method = "DELETE"
  local body = nil
  local options = options
  return performAuthorizedRequest(rest, invite, params, nil, method, body, options)
end

DiscordRest.getInvite = function(rest, code, options)
  local performAuthorizedRequest = rest.performAuthorizedRequest
  local invite = rest.invite
  local params = {}
  params[1] = code
  local method = "GET"
  local body = nil
  local options = options
  return performAuthorizedRequest(rest, invite, params, nil, method, body, options)
end

DiscordRest.createDm = function(rest, recipientId, options)
  local performAuthorizedRequest = rest.performAuthorizedRequest
  local createDm = rest.createDm
  local body = {}
  body.recipient_id = recipientId
  local method = "POST"
  local params = nil
  local options = options
  return performAuthorizedRequest(rest, createDm, params, nil, method, body, options)
end

DiscordRest.getCurrentUser = function(rest, options)
  local performAuthorizedRequest = rest.performAuthorizedRequest
  local currentUser = rest.currentUser
  local params = nil
  local method = "GET"
  local body = nil
  local options = options
  return performAuthorizedRequest(rest, currentUser, params, nil, method, body, options)
end

DiscordRest.getCurrentUserGuilds = function(rest, limit, options)
  local performAuthorizedRequest = rest.performAuthorizedRequest
  local myGuilds = rest.myGuilds
  local params = {}
  params[1] = limit
  local method = "GET"
  local body = nil
  local options = options
  return performAuthorizedRequest(rest, myGuilds, params, nil, method, body, options)
end

DiscordRest.getUser = function(rest, userId, options)
  local performAuthorizedRequest = rest.performAuthorizedRequest
  local user = rest.user
  local params = {}
  params[1] = userId
  local method = "GET"
  local body = nil
  local options = options
  return performAuthorizedRequest(rest, user, params, nil, method, body, options)
end

DiscordRest.getUserConnections = function(rest, options)
  local performAuthorizedRequest = rest.performAuthorizedRequest
  local myConnections = rest.myConnections
  local params = nil
  local method = "GET"
  local body = nil
  local options = options
  return performAuthorizedRequest(rest, myConnections, params, nil, method, body, options)
end

DiscordRest.leaveGuild = function(rest, guildId, options)
  local performAuthorizedRequest = rest.performAuthorizedRequest
  local myGuild = rest.myGuild
  local params = {}
  params[1] = guildId
  local method = "DELETE"
  local body = nil
  local options = options
  return performAuthorizedRequest(rest, myGuild, params, nil, method, body, options)
end

DiscordRest.modifyCurrentUser = function(rest, data, options)
  local performAuthorizedRequest = rest.performAuthorizedRequest
  local currentUser = rest.currentUser
  local params = nil
  local method = "PATCH"
  local body = data
  local options = options
  return performAuthorizedRequest(rest, currentUser, params, nil, method, body, options)
end

DiscordRest.deleteWebhook = function(rest, webhookId, options)
  local performAuthorizedRequest = rest.performAuthorizedRequest
  local webhookId = rest.webhookId
  local params = {}
  params[1] = webhookId
  local method = "DELETE"
  local body = nil
  local options = options
  return performAuthorizedRequest(rest, webhookId, params, nil, method, body, options)
end

DiscordRest.deleteWebhookMessage = function(rest, webhookId, webhookToken, messageId)
  local performRequest = rest.performRequest
  local webhookMessage = rest.webhookMessage
  local params = {}
  params[1] = webhookId
  params[2] = webhookToken
  params[3] = messageId
  local method = "DELETE"
  return performRequest(rest, webhookMessage, params, nil, method)
end

DiscordRest.deleteWebhookWithToken = function(rest, webhookId, webhookToken)
  local deleteWebhookWithUrl = rest.deleteWebhookWithUrl
  local webhook = rest.webhook
  local params = {}
  params[1] = webhookId
  params[2] = webhookToken
  local url, _, _ = webhook(params)
  return deleteWebhookWithUrl(rest, url)
end

DiscordRest.deleteWebhookWithUrl = function(rest, url)
  local performRequestToWebhook = rest.performRequestToWebhook
  local method = "DELETE"
  return performRequestToWebhook(rest, url, nil, method)
end

DiscordRest.editWebhookMessage = function(rest, webhookId, webhookToken, messageId, data)
  local performRequest = rest.performRequest
  local webhookMessage = rest.webhookMessage
  local params = {}
  params[1] = webhookId
  params[2] = webhookToken
  params[3] = messageId
  local method = "PATCH"
  local body = data
  return performRequest(rest, webhookMessage, params, nil, method, body)
end

DiscordRest.executeGitHubCompatibleWebhook = function(rest, webhookId, webhookToken, data, wait)
  local executeGitHubCompatibleWebhookUrl = rest.executeGitHubCompatibleWebhookUrl
  local github = rest.github
  local params = {}
  params[1] = webhookId
  params[2] = webhookToken
  local url, _, _ = github(params)
  return executeGitHubCompatibleWebhookUrl(rest, url, data, wait)
end

DiscordRest.executeGitHubCompatibleWebhookUrl = function(rest, url, data, wait)
  local performRequestToWebhook = rest.performRequestToWebhook
  local method = "POST"
  return performRequestToWebhook(rest, url, data, method, wait)
end

DiscordRest.executeSlackCompatibleWebhook = function(rest, webhookId, webhookToken, data, wait)
  local executeSlackCompatibleWebhookUrl = rest.executeSlackCompatibleWebhookUrl
  local slack = rest.slack
  local params = {}
  params[1] = webhookId
  params[2] = webhookToken
  local url, _, _ = slack(params)
  return executeSlackCompatibleWebhookUrl(rest, url, data, wait)
end

DiscordRest.executeSlackCompatibleWebhookUrl = function(rest, url, data, wait)
  local performRequestToWebhook = rest.performRequestToWebhook
  local method = "POST"
  return performRequestToWebhook(rest, url, data, method, wait)
end

DiscordRest.executeWebhook = function(rest, webhookId, webhookToken, data, wait)
  local executeWebhookUrl = rest.executeWebhookUrl
  local webhook = rest.webhook
  local params = {}
  params[1] = webhookId
  params[2] = webhookToken
  local url, _, _ = webhook(params)
  return executeWebhookUrl(rest, url, data, wait)
end

DiscordRest.executeWebhookUrl = function(rest, url, data, wait)
  local performRequestToWebhook = rest.performRequestToWebhook
  local method = "POST"
  return performRequestToWebhook(rest, url, data, method, wait)
end

DiscordRest.getChannelWebhooks = function(rest, channelId, options)
  local performAuthorizedRequest = rest.performAuthorizedRequest
  local webhooks = rest.webhooks
  local params = {}
  params[1] = channelId
  local method = "GET"
  local body = nil
  local options = options
  return performAuthorizedRequest(rest, webhooks, params, nil, method, body, options)
end

DiscordRest.getGuildWebhooks = function(rest, guildId, options)
  local performAuthorizedRequest = rest.performAuthorizedRequest
  local guildWebhooks = rest.guildWebhooks
  local params = {}
  params[1] = guildId
  local method = "GET"
  local body = nil
  local options = options
  return performAuthorizedRequest(rest, guildWebhooks, params, nil, method, body, options)
end

DiscordRest.getWebhook = function(rest, webhookId, options)
  local performAuthorizedRequest = rest.performAuthorizedRequest
  local webhookId = rest.webhookId
  local params = {}
  params[1] = webhookId
  local method = "GET"
  local body = nil
  local options = options
  return performAuthorizedRequest(rest, webhookId, params, nil, method, body, options)
end

DiscordRest.getWebhookMessage = function(rest, webhookId, webhookToken, messageId)
  local performRequest = rest.performRequest
  local webhookMessage = rest.webhookMessage
  local params = {}
  params[1] = webhookId
  params[2] = webhookToken
  params[3] = messageId
  local method = "GET"
  return performRequest(rest, webhookMessage, params, nil, method)
end

DiscordRest.getWebhookWithToken = function(rest, webhookId, webhookToken)
  local getWebhookWithUrl = rest.getWebhookWithUrl
  local webhook = rest.webhook
  local params = {}
  params[1] = webhookId
  params[2] = webhookToken
  local url, _, _ = webhook(params)
  return getWebhookWithUrl(rest, url)
end

DiscordRest.getWebhookWithUrl = function(rest, url)
  local performRequestToWebhook = rest.performRequestToWebhook
  local method = "GET"
  return performRequestToWebhook(rest, url, nil, method)
end

DiscordRest.modifyWebhook = function(rest, webhookId, data, options)
  local performAuthorizedRequest = rest.performAuthorizedRequest
  local webhookId = rest.webhookId
  local params = {}
  params[1] = webhookId
  local method = "PATCH"
  local body = data
  local options = options
  return performAuthorizedRequest(rest, webhookId, params, nil, method, body, options)
end

DiscordRest.modifyWebhookWithToken = function(rest, webhookId, webhookToken, data)
  local modifyWebhookWithUrl = rest.modifyWebhookWithUrl
  local webhook = rest.webhook
  local params = {}
  params[1] = webhookId
  params[2] = webhookToken
  local url, _, _ = webhook(params)
  return modifyWebhookWithUrl(rest, url, data)
end

DiscordRest.modifyWebhookWithUrl = function(rest, url, data)
  local performRequestToWebhook = rest.performRequestToWebhook
  local method = "PATCH"
  return performRequestToWebhook(rest, url, data, method)
end

DiscordRest.getUserId = function(promise, rest, player)
  local identifiers = GetPlayerIdentifiers(player)
  for _, identifier in ipairs(identifiers) do
    if identifier:find("discord:") then
      local userId = identifier:gsub("discord:", "")
      return userId
    end
  end
end

DiscordRest["addGuildMemberRoleToPlayer"] = function(rest, guildId, playerId, roleId, options)
  local userId = rest.getUserId(rest, playerId)
  local next = userId.next
  return next(userId, function()
    return rest.addGuildMemberRole(rest, guildId, userId, roleId, options)
  end)
end

DiscordRest["addPlayerToGuild"] = function(rest, guildId, playerId, options)
  local userId = rest.getUserId(rest, playerId)
  local next = userId.next
  return next(userId, function()
    return rest.addGuildMember(rest, guildId, userId, options)
  end)
end

DiscordRest["addPlayerToThread"] = function(rest, threadId, playerId)
  local userId = rest.getUserId(rest, playerId)
  local next = userId.next
  return next(userId, function()
    return rest.addThreadMember(rest, threadId, userId)
  end)
end

DiscordRest["createGuildBanForPlayer"] = function(rest, guildId, playerId, options)
  local userId = rest.getUserId(rest, playerId)
  local next = userId.next
  return next(userId, function()
    return rest.createGuildBan(rest, guildId, userId, options)
  end)
end

DiscordRest["deletePlayerReaction"] = function(rest, messageId, channelId, playerId, emoji)
  local userId = rest.getUserId(rest, playerId)
  local next = userId.next
  return next(userId, function()
    return rest.deleteUserReaction(rest, messageId, channelId, userId, emoji)
  end)
end

DiscordRest["getGuildBanForPlayer"] = function(rest, guildId, playerId)
  local userId = rest.getUserId(rest, playerId)
  local next = userId.next
  return next(userId, function()
    return rest.getGuildBan(rest, guildId, userId)
  end)
end

DiscordRest["getGuildMemberForPlayer"] = function(rest, guildId, playerId)
  local userId = rest.getUserId(rest, playerId)
  local next = userId.next
  return next(userId, function()
    return rest.getGuildMember(rest, guildId, userId)
  end)
end

DiscordRest["getUserForPlayer"] = function(rest, playerId)
  local userId = rest.getUserId(rest, playerId)
  local next = userId.next
  return next(userId, function()
    return rest.getUser(rest, userId)
  end)
end

DiscordRest["groupDmAddPlayer"] = function(rest, groupId, playerId, options)
  local userId = rest.getUserId(rest, playerId)
  local next = userId.next
  return next(userId, function()
    return rest.groupDmAddRecipient(rest, groupId, userId, options)
  end)
end

DiscordRest["groupDmRemovePlayer"] = function(rest, groupId, playerId)
  local userId = rest.getUserId(rest, playerId)
  local next = userId.next
  return next(userId, function()
    return rest.groupDmRemoveRecipient(rest, groupId, userId)
  end)
end

DiscordRest["modifyGuildMemberForPlayer"] = function(rest, guildId, playerId, options)
  local userId = rest.getUserId(rest, playerId)
  local next = userId.next
  return next(userId, function()
    return rest.modifyGuildMember(rest, guildId, userId, options)
  end)
end

DiscordRest["modifyPlayerVoiceState"] = function(rest, guildId, playerId, options)
  local userId = rest.getUserId(rest, playerId)
  local next = userId.next
  return next(userId, function()
    return rest.modifyUserVoiceState(rest, guildId, userId, options)
  end)
end

DiscordRest["removeGuildBanForPlayer"] = function(rest, guildId, playerId)
  local userId = rest.getUserId(rest, playerId)
  local next = userId.next
  return next(userId, function()
    return rest.removeGuildBan(rest, guildId, userId)
  end)
end

DiscordRest["removeGuildMemberRoleFromPlayer"] = function(rest, guildId, playerId, roleId)
  local userId = rest.getUserId(rest, playerId)
  local next = userId.next
  return next(userId, function()
    return rest.removeGuildMemberRole(rest, guildId, userId, roleId)
  end)
end

DiscordRest["removePlayerFromGuild"] = function(rest, guildId, playerId)
  local userId = rest.getUserId(rest, playerId)
  local next = userId.next
  return next(userId, function()
    return rest.removeGuildMember(rest, guildId, userId)
  end)
end

DiscordRest["removePlayerFromThread"] = function(rest, threadId, playerId)
  local userId = rest.getUserId(rest, playerId)
  local next = userId.next
  return next(userId, function()
    return rest.removeThreadMember(rest, threadId, userId)
  end)
end

local ServerConfig = _ENV.ServerConfig
local DiscordBot = ServerConfig.DiscordBot
local GuildID = ServerConfig.GuildID
local ScriptAlertChannelID = ServerConfig.ScriptAlertChannelID
if not ScriptAlertChannelID then
  ScriptAlertChannelID = nil
end

local discordRest = DiscordRest.new(DiscordRest, DiscordBot)

local function getChannelByName(channelName)
  local promise = promise.new()
  local channels = discordRest.getGuildChannels(discordRest, GuildID, ScriptAlertChannelID)
  local next = channels.next
  next(channels, function(channels)
    for _, channel in ipairs(channels) do
      if channel.name == channelName then
        promise.resolve(channel.id)
        return
      end
    end
    promise.reject("No channel named " .. channelName)
  end)
  return promise
end

local environment = _ENV
local sendVersionUpdateEmbed = "sendVersionUpdateEmbed"

function sendVersionUpdateEmbed(currentVersion, newVersion, changelogs)
  local embed = {}
  embed.title = "New Update Available"
  local description = [[
A new update is available for **kartik-mdt**.

]]
  description = description .. "Current Version: **" .. currentVersion .. "**\n"
  description = description .. "New Version: **" .. newVersion .. "**\n"
  description = description .. "Changelogs: **" .. changelogs .. "**"
  embed.description = description
  embed.color = 5814783
  embed.timestamp = os.date("!%Y-%m-%dT%H:%M:%SZ")
  local components = {}
  local actionRow = {}
  actionRow.type = 1
  local joinDiscordButton = {}
  joinDiscordButton.type = 2
  joinDiscordButton.style = 5
  joinDiscordButton.label = "Join Discord"
  joinDiscordButton.url = "https://discord.gg/Mxe4hFBNT3"
  local purchaseScriptButton = {}
  purchaseScriptButton.type = 2
  purchaseScriptButton.style = 5
  purchaseScriptButton.label = "Purchase Script"
  purchaseScriptButton.url = "https://kartik-scripts.tebex.io"
  local documentationButton = {}
  documentationButton.type = 2
  documentationButton.style = 5
  documentationButton.label = "Documentation"
  documentationButton.url = "https://kartik-scripts.gitbook.io"
  actionRow.components = {joinDiscordButton, purchaseScriptButton, documentationButton}
  components[1] = actionRow
  if client then
    local sendMessage = client.createMessage
    local messageId = nil
    local message = {}
    message.content = nil
    message.embeds = {embed}
    message.components = components
    local result = sendMessage(client, messageId, message, nil)
    local nextFunction = result.next
    function onSuccess(response)
      statusMessageId = response.id
    end
    function onFailure(error)
      print("Failed to send version update message: " .. error)
    end
    nextFunction(result, onSuccess, onFailure)
  end
end
environment[sendVersionUpdateEmbed] = sendVersionUpdateEmbed