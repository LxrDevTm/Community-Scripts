local resourceName, removePlayerBlipEvent, togglePlayerEvent
resourceName = GetCurrentResourceName()
resourceName = resourceName()
if "kartik-mdt" ~= resourceName then
  return
end
local blipPlayers = {}
function removePlayerBlip(playerId)
  local playerData = GetPlayerData(playerId)
  if not playerData then
    return
  end
  local citizenId = playerData.citizenId
  local playerBlip = blipPlayers[citizenId]
  if playerBlip then
    blipPlayers[citizenId] = nil
    local player = Player(playerId)
    local playerState = player.state
    playerState.set(playerState, "duty_blips", nil, true)
    return citizenId
  end
  return false
end
removePlayerBlip = removePlayerBlip
RegisterNetEvent("kartik-mdt:server:removePlayerBlip", function()
  local playerId = source
  removePlayerBlip(playerId)
  TriggerClientEvent("kartik-mdt:client:changeTrackerStatus", playerId, false)
end)
function togglePlayer(playerId, label, job)
  local playerBlip = blipPlayers[playerId]
  if playerBlip then
    blipPlayers[playerId] = nil
    TriggerClientEvent("ox_lib:notify", playerId, {
      title = "Tracker Deactivated",
      message = "Your tracker has been deactivated. You can no longer be tracked by your team.",
      type = "error"
    })
    TriggerClientEvent("kartik-mdt:client:changeTrackerStatus", playerId, false)
    local player = Player(playerId)
    local playerState = player.state
    playerState.set(playerState, "duty_blips", nil, true)
    return playerId
  else
    local callsign = GetCallsign(playerId)
    local playerBlip = {
      identifier = playerId,
      src = playerId,
      label = label or "Undefined",
      job = job or "unemployed",
      callsign = callsign
    }
    blipPlayers[playerId] = playerBlip
    TriggerClientEvent("ox_lib:notify", playerId, {
      title = "Tracker Activated",
      description = "Your tracker has been activated. You can now be tracked by your team.",
      type = "success"
    })
    TriggerClientEvent("kartik-mdt:client:changeTrackerStatus", playerId, true)
    return playerBlip
  end
end
togglePlayer = togglePlayer
function getBlipPerVehicle(vehicle)
  local vehicleType = GetVehicleType(vehicle)
  local sprite = Config.Sprites.Vehicle[vehicleType]
  if not sprite then
    sprite = Config.Sprites.Vehicle.other
  end
  return sprite
end
getBlipPerVehicle = getBlipPerVehicle
CreateThread(function()
  while true do
    Wait(Config.UpdateInterval)
    if blipPlayers then
      local playerBlips = {}
      for playerId, playerBlip in pairs(blipPlayers) do
        local playerPed = GetPlayerPed(playerBlip.src)
        local vehicle = GetVehiclePedIsIn(playerPed, false)
        if vehicle ~= 0 then
          local sprite = getBlipPerVehicle(vehicle)
          if sprite then
            goto continue
          end
        end
        local coords = GetEntityCoords(playerPed)
        local heading = GetEntityHeading(playerPed)
        local playerBlipData = {
          src = playerBlip.src,
          label = playerBlip.label,
          job = playerBlip.job,
          callsign = playerBlip.callsign,
          coords = vec4(coords.x, coords.y, coords.z, heading),
          sprite = 1
        }
        table.insert(playerBlips, playerBlipData)
        ::continue::
      end
      TriggerClientEvent("kartik-mdt:client:updateBlips", -1, playerBlips)
    end
  end
end)