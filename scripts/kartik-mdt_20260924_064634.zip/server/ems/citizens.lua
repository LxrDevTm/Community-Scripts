local registerCallback, fetchCitizenEMSReports
registerCallback = lib.callback.register
fetchCitizenEMSReports = function(data)
  if data then
    local citizenId = data.citizenId
    local query = [[
            SELECT * FROM mdt_ems_reports 
            WHERE JSON_CONTAINS(peopleInvolved, '{"citizenId": "]] .. citizenId .. [["
"}', '$')
        ]]
    local results = MySQL.query.await(query)
    if results then
      local count = #results
      if count > 0 then
        local reports = {}
        for _, result in ipairs(results) do
          local report = {}
          report.reportId = result.reportId
          report.reportName = result.name or "Unknown"
          report.location = result.location
          report.citizenId = result.citizenid or citizenId
          report.dateTime = result.dateTime
          report.peopleInvolved = result.peopleInvolved
          table.insert(reports, report)
        end
        return reports
      else
        return { success = false, message = "No reports found for the given citizenId" }
      end
    end
  else
    return { success = false, message = "No data received" }
  end
end
registerCallback("kartik-mdt:server:fetchCitizenEMSReports", fetchCitizenEMSReports)

local registerCallback, fetchCitizenEMSIncidentReports
registerCallback = lib.callback.register
fetchCitizenEMSIncidentReports = function(data)
  if data then
    local citizenId = data.citizenId
    local query = [[
            SELECT * FROM mdt_ems_incidents
            WHERE JSON_CONTAINS(peopleInvolved, '{"citizenId": "]] .. citizenId .. [["
"}', '$')
        ]]
    local results = MySQL.query.await(query)
    if results then
      local count = #results
      if count > 0 then
        local incidents = {}
        for _, result in ipairs(results) do
          local incident = {}
          incident.incidentId = result.incidentId
          incident.incidentName = result.title or "Unknown"
          incident.location = result.location
          incident.citizenId = result.citizenid or citizenId
          incident.dateTime = result.dateTime
          incident.peopleInvolved = result.peopleInvolved
          table.insert(incidents, incident)
        end
        return incidents
      else
        return { success = false, message = "No reports found for the given citizenId" }
      end
    end
  else
    return { success = false, message = "No data received" }
  end
end
registerCallback("kartik-mdt:server:fetchCitizenEMSIncidentReports", fetchCitizenEMSIncidentReports)