local fetchEMSAnnouncements, initEMSDashboard, fetchEMSAnnouncementsCallback, addEMSAnnouncement, deleteEMSAnnouncement, editEMSAnnouncement, fetchRecentReports, getRecentReportsCallback

function fetchEMSAnnouncements(data)
  local queryResults, mysqlQuery, offset, limit, hasMoreAnnouncements
  local query = "SELECT COUNT(*) as total FROM mdt_ems_bulletin"
  local mysql = MySQL.query.await
  local results = mysql(query, {})
  if results[1] then
    local totalAnnouncements = results[1].total
    if data then
      limit = data.limit
      offset = (data.page - 1) * limit
      query = "SELECT * FROM mdt_ems_bulletin ORDER BY dateTime DESC LIMIT ? OFFSET ?"
      local params = {limit, offset}
      results = mysql(query, params)
      hasMoreAnnouncements = totalAnnouncements > (data.page * limit)
    else
      query = "SELECT * FROM mdt_ems_bulletin"
      results = mysql(query, {})
    end
    if results then
      local response = {success = true, announcements = results, message = "", hasMore = hasMoreAnnouncements}
      return response
    else
      print("Error fetching announcements.")
      return {success = false, message = "No announcements found."}
    end
  else
    return {success = false, message = "No announcements found."}
  end
end

initEMSDashboard = function(player, data)
  local announcements, warrants, recentReports, wantedVehicles, activeUnits
  announcements = fetchEMSAnnouncements(data)
  warrants = fetchWarrants(data)
  recentReports = fetchEMSRecentReports(data)
  if not recentReports then recentReports = {} end
  wantedVehicles = fetchWantedVehicles(data)
  activeUnits = fetchActiveUnitsHere()
  local response = {
    announcements = announcements or {},
    warrantsData = warrants or {},
    reports = recentReports or {},
    vehiclesData = wantedVehicles or {},
    units = activeUnits or {}
  }
  return response
end

lib.callback.register("kartik-mdt:server:initEMSDashboard", initEMSDashboard)

lib.callback.register("kartik-mdt:server:fetchEMSAnnouncements", function(player, data)
  return fetchEMSAnnouncements(data)
end)

lib.callback.register("kartik-mdt:server:addEMSAnnouncement", function(player, data)
  if data then
    local announcementId, title, description, dateTime
    announcementId = data.announcementToAdd.announcementId
    title = data.announcementToAdd.title
    description = data.announcementToAdd.description
    dateTime = data.announcementToAdd.dateTime
    local query = "INSERT INTO mdt_ems_bulletin (announcementId, title, description, dateTime) VALUES (?, ?, ?, ?)"
    local params = {announcementId, title, description, dateTime}
    local results = MySQL.query.await(query, params)
    if results then
      SendDiscordLog("ems_announcement", "\240\159\134\149 EMS Announcement Created", nil, 5763719, {
        {name = "Title", value = title or "N/A", inline = true},
        {name = "Date", value = dateTime or "N/A", inline = true},
        {name = "Player", value = FormatPlayer(player), inline = false}
      })
      return {success = true, message = "Announcement added successfully."}
    else
      print("Error inserting announcement.")
      return {success = false, message = "Failed to add announcement."}
    end
  else
    print("No data received.")
    return {success = false, message = "No data received."}
  end
end)

lib.callback.register("kartik-mdt:server:deleteEMSAnnouncement", function(player, data)
  if data then
    local announcementId = data.announcementId
    local query = "DELETE FROM mdt_ems_bulletin WHERE announcementId = ?"
    local params = {announcementId}
    local results = MySQL.query.await(query, params)
    if results then
      SendDiscordLog("ems_announcement", "\240\159\151\145\239\184\143 EMS Announcement Deleted", nil, 15158332, {
        {name = "Announcement ID", value = announcementId or "N/A", inline = true},
        {name = "Player", value = FormatPlayer(player), inline = false}
      })
      return {success = true, message = "Announcement deleted successfully."}
    else
      print("Delete failed or no rows affected.")
      return {success = false, message = "Failed to delete the announcement."}
    end
  else
    print("No data received.")
    return {success = false, message = "No data received."}
  end
end)

lib.callback.register("kartik-mdt:server:editEMSAnnouncement", function(player, data)
  if data then
    local announcementId, title, description, dateTime
    announcementId = data.edited.announcementId
    title = data.edited.title
    description = data.edited.description
    dateTime = data.edited.dateTime
    local query = "SELECT * FROM mdt_ems_bulletin WHERE announcementId = ?"
    local params = {announcementId}
    local results = MySQL.query.await(query, params)
    if #results > 0 then
      query = "UPDATE mdt_ems_bulletin SET title = ?, description = ?, dateTime = ? WHERE announcementId = ?"
      params = {title, description, dateTime, announcementId}
      results = MySQL.query.await(query, params)
      if results then
        SendDiscordLog("ems_announcement", "\226\156\143\239\184\143 EMS Announcement Edited", nil, 3447003, {
          {name = "Title", value = title or "N/A", inline = true},
          {name = "Date", value = dateTime or "N/A", inline = true},
          {name = "Player", value = FormatPlayer(player), inline = false}
        })
        return {success = true, message = "Announcement Changed Successfully"}
      else
        print("Insertion failed or no rows affected.")
        return {success = false, message = "Failed to change."}
      end
    else
      return {success = false, message = "Failed to change the announcement."}
    end
  else
    print("No data received.")
    return nil
  end
end)

function fetchRecentReports(data)
  if data then
    local page, limit, offset, query, params, results
    page = data.page
    limit = data.limit
    offset = (page - 1) * limit
    query = "SELECT * FROM mdt_police_reports ORDER BY dateTime DESC LIMIT ? OFFSET ?;"
    params = {limit, offset}
    results = MySQL.query.await(query, params)
    if results then
      local reports = {}
      for _, report in ipairs(results) do
        local reportData = {
          reportId = report.reportId,
          reportName = report.name or "",
          dateTime = report.dateTime,
          location = report.location or ""
        }
        table.insert(reports, reportData)
      end
      return {reports = reports, success = true}
    end
  else
    print("No data received.")
    return {success = false}
  end
end

lib.callback.register("kartik-mdt:server:getRecentReports", function(player, data)
  return fetchRecentReports(data)
end)