local registerCallback, fetchReportsCallback, fetchReportDataCallback, createReportCallback, saveReportCallback, approveReportCallback, rejectReportCallback
registerCallback = lib.callback.register
fetchReportsCallback = function(source, data)
  if data then
    local page = data.page
    local query = data.query
    if not query then
      query = ""
    end
    local offset = (page - 1) * 10
    local whereClause = ""
    local params = {}
    if query ~= "" then
      whereClause = "WHERE LOWER(trainee_name) LIKE LOWER(?) OR LOWER(id) LIKE LOWER(?) OR LOWER(fto_name) LIKE LOWER(?) "
      local likePattern = "%" .. query .. "%"
      params = {likePattern, likePattern, likePattern}
    end
    local querySql = "SELECT * FROM mdt_ems_fto_reports " .. whereClause .. " ORDER BY id DESC LIMIT 10 OFFSET ?"
    table.insert(params, offset)
    local results = MySQL.query.await(querySql, params)
    local reports = {}
    for _, result in ipairs(results) do
      local report = {
        id = result.id,
        traineeName = result.trainee_name,
        ftoName = result.fto_name,
        status = result.status,
        date = result.date,
        shift = result.shift,
        phase = result.phase,
        overallPerformance = result.overall_performance
      }
      table.insert(reports, report)
    end
    if query ~= "" then
      params[3] = nil
    end
    local countQuerySql = "SELECT COUNT(*) as count FROM mdt_ems_fto_reports " .. whereClause
    local countResults = MySQL.query.await(countQuerySql, params)
    local totalCount = countResults[1].count
    return {ftoreports = reports, totalCount = totalCount}
  end
end
fetchReportDataCallback = function(source, data)
  if data then
    local reportId = data.ReportId
    if reportId then
      local querySql = "SELECT * FROM mdt_ems_fto_reports WHERE id = ?"
      local params = {reportId}
      local results = MySQL.query.await(querySql, params)
      if results[1] then
        local report = {
          id = reportId,
          categories = results[1].categories,
          strengths = results[1].strengths,
          areasForImprovement = results[1].areas_for_improvement,
          additionalComments = results[1].additional_comments or "",
          rejectionReason = results[1].rejection_reason or ""
        }
        return report
      else
        return nil
      end
    end
  end
  return nil
end
createReportCallback = function(source, data)
  if data then
    local report = data.report
    if report then
      local traineeName = report.traineeName
      local ftoName = report.ftoName
      local date = report.date
      local shift = report.shift
      local phase = report.phase
      local categories = json.encode(report.categories)
      local overallPerformance = report.overallPerformance
      local strengths = report.strengths
      local areasForImprovement = report.areasForImprovement
      local additionalComments = report.additionalComments
      local status = report.status
      local querySql = "INSERT INTO mdt_ems_fto_reports (trainee_name, fto_name, date, shift, phase, categories, overall_performance, strengths, areas_for_improvement, additional_comments, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
      local params = {traineeName, ftoName, date, shift, phase, categories, overallPerformance, strengths, areasForImprovement, additionalComments, status}
      local results = MySQL.query.await(querySql, params)
      local reportId = results.insertId
      SendDiscordLog("ems_fto_report", "\240\159\147\157 EMS FTO Report Created", nil, 5763719, {
        {name = "Trainee", value = traineeName or "N/A", inline = true},
        {name = "FTO", value = ftoName or "N/A", inline = true},
        {name = "Date", value = date or "N/A", inline = true},
        {name = "Player", value = FormatPlayer(source), inline = false}
      })
      return {success = true, message = "Report added successfully.", reportId = reportId}
    end
  end
  return {success = false, message = "No data received."}
end
saveReportCallback = function(source, data)
  if data then
    local reportId = data.reportId
    if reportId then
      local report = data.report
      local traineeName = report.traineeName
      local ftoName = report.ftoName
      local date = report.date
      local shift = report.shift
      local phase = report.phase
      local categories = json.encode(report.categories)
      local overallPerformance = report.overallPerformance
      local strengths = report.strengths
      local areasForImprovement = report.areasForImprovement
      local additionalComments = report.additionalComments
      local querySql = "UPDATE mdt_ems_fto_reports SET trainee_name = ?, fto_name = ?, date = ?, shift = ?, phase = ?, categories = ?, overall_performance = ?, strengths = ?, areas_for_improvement = ?, additional_comments = ? WHERE id = ?"
      local params = {traineeName, ftoName, date, shift, phase, categories, overallPerformance, strengths, areasForImprovement, additionalComments, reportId}
      local results = MySQL.query.await(querySql, params)
      if results.affectedRows > 0 then
        SendDiscordLog("ems_fto_report", "\226\156\143\239\184\143 EMS FTO Report Edited", nil, 3447003, {
          {name = "Trainee", value = traineeName or "N/A", inline = true},
          {name = "FTO", value = ftoName or "N/A", inline = true},
          {name = "Date", value = date or "N/A", inline = true},
          {name = "Player", value = FormatPlayer(source), inline = false}
        })
        return {success = true, message = "Report saved successfully."}
      else
        return {success = false, message = "Failed to update the report."}
      end
    end
  end
  return {success = false, message = "No data received."}
end
approveReportCallback = function(source, data)
  if data then
    local reportId = data.reportId
    if reportId then
      local querySql = "UPDATE mdt_ems_fto_reports SET status = 'approved' WHERE id = ?"
      local params = {reportId}
      local results = MySQL.query.await(querySql, params)
      if results.affectedRows > 0 then
        SendDiscordLog("ems_fto_report", "\226\156\133 EMS FTO Report Approved", nil, 3066993, {
          {name = "Report ID", value = tostring(reportId), inline = true},
          {name = "Player", value = FormatPlayer(source), inline = false}
        })
        return {success = true, message = "Report approved successfully."}
      else
        return {success = false, message = "Failed to approve the report."}
      end
    end
  end
  return {success = false, message = "No data received."}
end
rejectReportCallback = function(source, data)
  if data then
    local reportId = data.reportId
    if reportId then
      local rejectionReason = data.rejectionReason
      local querySql = "UPDATE mdt_ems_fto_reports SET status = 'rejected', rejection_reason = ? WHERE id = ?"
      local params = {rejectionReason, reportId}
      local results = MySQL.query.await(querySql, params)
      if results.affectedRows > 0 then
        SendDiscordLog("ems_fto_report", "\226\157\140 EMS FTO Report Rejected", nil, 15158332, {
          {name = "Report ID", value = tostring(reportId), inline = true},
          {name = "Reason", value = rejectionReason or "N/A", inline = false},
          {name = "Player", value = FormatPlayer(source), inline = false}
        })
        return {success = true, message = "Report rejected successfully."}
      else
        return {success = false, message = "Failed to reject the report."}
      end
    end
  end
  return {success = false, message = "No data received."}
end
registerCallback("kartik-mdt:server:fetchEMSFTOReports", fetchReportsCallback)
registerCallback("kartik-mdt:server:fetchEMSFTOReportDataByReportId", fetchReportDataCallback)
registerCallback("kartik-mdt:server:createEMSFTOReport", createReportCallback)
registerCallback("kartik-mdt:server:saveEMSFTOReport", saveReportCallback)
registerCallback("kartik-mdt:server:approveEMSFTOReport", approveReportCallback)
registerCallback("kartik-mdt:server:rejectEMSFTOReport", rejectReportCallback)