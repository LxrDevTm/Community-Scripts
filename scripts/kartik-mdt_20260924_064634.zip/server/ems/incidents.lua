local callback, eventName, fetchEMSIncidents
callback = lib.callback
callback = callback.register
eventName = "kartik-mdt:server:fetchEMSIncidents"
function fetchEMSIncidents(player, data)
  if data then
    local page = data.page
    local query = data.query
    if not query then
      query = ""
    end
    local offset = (page - 1) * 10
    local whereClause = ""
    local params = {}
    if query ~= "" then
      whereClause = "WHERE LOWER(title) LIKE LOWER(?) OR LOWER(incidentId) LIKE LOWER(?) "
      params = { "%" .. query .. "%", "%" .. query .. "%" }
    end
    local querySql = "SELECT * FROM mdt_ems_incidents " .. whereClause .. " ORDER BY incidentId DESC"
    table.insert(params, offset)
    querySql = querySql .. " LIMIT 10 OFFSET ?"
    local results = MySQL.query.await(querySql, params)
    local incidents = {}
    for _, result in ipairs(results) do
      local medicName = "Unknown"
      local medicId = result.medicId
      if medicId then
        local citizenId = getCitizenIdFromUnitId(medicId)
        if citizenId then
          local offlinePlayer = GetOfflinePlayerByCitizenId(citizenId)
          if offlinePlayer then
            medicName = offlinePlayer.name
          end
        else
          medicName = medicId
        end
      end
      local incident = {
        incidentId = result.incidentId,
        title = result.title,
        dateTime = result.dateTime,
        medicName = medicName,
        isLocked = result.isLocked,
        canAccessReport = not result.isLocked or checkReportPermission(GetPlayerData(player).citizenId, result.reportId, "incident", "ems"),
        lockReason = result.lock_reason or "No reason specified",
        priority = result.priority,
        status = result.status,
        peopleInvolved = result.peopleInvolved,
        location = result.location
      }
      table.insert(incidents, incident)
    end
    if query ~= "" then
      params[3] = nil
    end
    local countQuery = "SELECT COUNT(*) as count FROM mdt_ems_incidents " .. whereClause
    local countResults = MySQL.query.await(countQuery, params)
    local totalCount = countResults[1].count
    return { incidents = incidents, totalCount = totalCount }
  end
end
callback(eventName, fetchEMSIncidents)
callback = lib.callback
callback = callback.register
eventName = "kartik-mdt:server:fetchEMSIncidentDataByIncidentId"
function fetchEMSIncidentDataByIncidentId(player, data)
  if data then
    local incidentId = data.incidentId
    local querySql = "SELECT * FROM mdt_ems_incidents WHERE incidentId = ?"
    local params = { incidentId }
    local results = MySQL.query.await(querySql, params)
    if #results > 0 then
      local result = results[1]
      if result.isLocked then
        local playerData = GetPlayerData(player)
        if not playerData then
          return { success = false, message = "No player data found." }
        end
        local citizenId = playerData.citizenId
        local jobName = playerData.jobData.name
        local jobGrade = playerData.jobData.grade.level
        if not checkReportPermission(citizenId, incidentId, "incident", "ems", jobName, jobGrade) then
          return { success = false, message = "No permission." }
        end
      end
      local reportAccess = {}
      local members = json.decode(result.members or "[]")
      if type(members) == "table" then
        for _, member in ipairs(members) do
          local offlinePlayer = GetOfflinePlayerByCitizenId(member)
          if offlinePlayer then
            table.insert(reportAccess, { id = member, name = offlinePlayer.name })
          end
        end
      end
      local incidentData = {
        incidentId = incidentId,
        title = result.title or "",
        priority = result.priority or "",
        status = result.status or "",
        dateTime = result.dateTime,
        location = result.location or "",
        description = result.description or "",
        evidences = result.evidences or "",
        peopleInvolved = result.peopleInvolved or "",
        vehiclesInvolved = result.vehiclesInvolved or "",
        timeline = result.timeline or "",
        bodyData = result.bodyData or {},
        reportAccess = reportAccess
      }
      return { success = true, data = incidentData }
    else
      return { success = false, message = "No data found." }
    end
  end
end
callback(eventName, fetchEMSIncidentDataByIncidentId)
callback = lib.callback
callback = callback.register
eventName = "kartik-mdt:server:addNewEMSIncident"
function addNewEMSIncident(player, data)
  if data then
    local incidentToAdd = data.incidentToAdd
    if incidentToAdd then
      local title = incidentToAdd.title
      local location = incidentToAdd.location
      local medicId = incidentToAdd.medicId
      local priority = incidentToAdd.priority
      local description = incidentToAdd.description
      local dateTime = incidentToAdd.dateTime
      local evidences = json.encode(incidentToAdd.evidences)
      local peopleInvolved = json.encode(incidentToAdd.peopleInvolved)
      local vehiclesInvolved = json.encode(incidentToAdd.vehiclesInvolved)
      local status = incidentToAdd.status
      local timeline = json.encode(incidentToAdd.timeline)
      local querySql = "INSERT INTO mdt_ems_incidents (title, medicId, location, priority, description, dateTime, evidences, peopleInvolved, vehiclesInvolved, status, timeline) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
      local params = { title, medicId, location, priority, description, dateTime, evidences, peopleInvolved, vehiclesInvolved, status, timeline }
      local results = MySQL.query.await(querySql, params)
      local incidentId = results.insertId
      SendDiscordLog("ems_incidents", "\240\159\154\145 EMS Incident Created", nil, 5763719, {
        { name = "Title", value = title or "N/A", inline = true },
        { name = "Location", value = location or "Unknown", inline = true },
        { name = "Priority", value = priority or "Unspecified", inline = true },
        { name = "Player", value = FormatPlayer(player), inline = false }
      })
      return { success = true, message = "Incident added successfully.", incidentId = incidentId }
    end
  end
  return false
end
callback(eventName, addNewEMSIncident)
callback = lib.callback
callback = callback.register
eventName = "kartik-mdt:server:saveEMSIncident"
function saveEMSIncident(player, data)
  if data then
    local incidentId = data.incidentId
    if incidentId then
      local title = data.title
      local location = data.location
      local description = data.description
      local evidences = json.encode(data.evidences)
      local peopleInvolved = json.encode(data.peopleInvolved)
      local vehiclesInvolved = json.encode(data.vehiclesInvolved)
      local status = data.status
      local priority = data.priority
      local bodyData = data.bodyData or {}
      local timeline = json.encode(data.timeline)
      local querySql = "UPDATE mdt_ems_incidents SET title = ?, location = ?, description = ?, evidences = ?, peopleInvolved = ?, vehiclesInvolved = ?, status = ?, priority = ?, timeline = ?, bodyData = ? WHERE incidentId = ?"
      local params = { title, location, description, evidences, peopleInvolved, vehiclesInvolved, status, priority, timeline, json.encode(bodyData), incidentId }
      local results = MySQL.query.await(querySql, params)
      if results.affectedRows > 0 then
        SendDiscordLog("ems_incidents", "\226\156\143\239\184\143 EMS Incident Edited", nil, 3447003, {
          { name = "Title", value = title or "N/A", inline = true },
          { name = "Incident ID", value = tostring(incidentId), inline = true },
          { name = "Player", value = FormatPlayer(player), inline = false }
        })
        return { success = true, message = "Incident saved successfully." }
      else
        return { success = false, message = "Failed to update the incident." }
      end
    end
  end
  return { success = false, message = "No data received." }
end
callback(eventName, saveEMSIncident)
callback = lib.callback
callback = callback.register
eventName = "kartik-mdt:server:deleteEMSIncident"
function deleteEMSIncident(player, data)
  if data then
    local incidentId = data.incidentId
    if incidentId then
      local querySql = "DELETE FROM mdt_ems_incidents WHERE incidentId = ?"
      local params = { incidentId }
      local results = MySQL.query.await(querySql, params)
      if results.affectedRows > 0 then
        SendDiscordLog("ems_incidents", "\240\159\151\145\239\184\143 EMS Incident Deleted", nil, 15158332, {
          { name = "Incident ID", value = tostring(incidentId), inline = true },
          { name = "Player", value = FormatPlayer(player), inline = false }
        })
        return { success = true, message = "Incident deleted successfully." }
      else
        return { success = false, message = "Failed to delete the incident." }
      end
    end
  end
  return { success = false, message = "No data received." }
end
callback(eventName, deleteEMSIncident)