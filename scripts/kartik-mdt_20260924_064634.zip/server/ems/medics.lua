local registerCallback, fetchMedicsCallback, addNewMedicsCallback, fetchMedicDataByMedicIdCallback, updateMedicRankCallback, addMedicAssignmentCallback, fireMedicCallback, updateMedictagsCallback

registerCallback = lib.callback.register
fetchMedics = "kartik-mdt:server:fetchMedics"
function fetchMedicsCallback(source, data)
  if not data then
    return
  end
  local page = data.page
  if not page then
    page = 1
  end
  local query = data.query
  if not query then
    query = ""
  end
  local offset = (page - 1) * 10
  local fetchUnitDataResult, totalCount = fetchUnitData(query, offset, "ems")
  local result = {}
  result.medics = fetchUnitDataResult
  result.totalCount = totalCount
  return result
end
registerCallback(fetchMedics, fetchMedicsCallback)

addNewMedics = "kartik-mdt:server:addNewMedics"
function addNewMedicsCallback(source, data)
  if data then
    local medic = data.medic
    if medic then
      local id = medic.id
      if not id then
        id = ""
      end
      local citizenId = medic.citizenId
      if not citizenId then
        citizenId = ""
      end
      local department = medic.department
      if not department then
        department = "ems"
      end
      local rank = medic.rank
      if not rank then
        rank = ""
      end
      local status = medic.status
      if not status then
        status = ""
      end
      local dutyRecords = medic.dutyRecords
      if not dutyRecords then
        dutyRecords = {}
      end
      local serviceHistory = medic.serviceHistory
      if not serviceHistory then
        serviceHistory = {}
      end
      local currentAssignments = medic.currentAssignments
      if not currentAssignments then
        currentAssignments = {}
      end
      local type = type
      type = type(serviceHistory)
      if "string" == type then
        local json = json
        json = json.decode
        serviceHistory = json(serviceHistory) or serviceHistory
        if not serviceHistory then
          serviceHistory = {}
        end
      end
      local query = "SELECT * FROM mdt_units WHERE citizenid = ?"
      local params = {}
      params[1] = citizenId
      local result = MySQL.query.await(query, params)
      if result then
        local count = #result
        if count > 0 then
          local row = result[1]
          local isFired = row.isFired
          if 0 == isFired then
            local result = {}
            result.success = false
            result.message = "Failed to hire the Medic."
            return result
          else
            local table = table
            table.insert(serviceHistory, {date = os.date("%Y-%m-%d"), event = "Rehired to department: " .. department})
            local json = json
            json = json.encode
            serviceHistory = json(serviceHistory)
            query = [[
                    UPDATE mdt_units
                    SET id = ?, citizenid = ?, department = ?, currentAssignments = ?, 
                        dutyRecords = ?, serviceHistory = ?, status = ?, isFired = 0
                    WHERE citizenid = ?
                ]]
            params = {}
            params[1] = id
            params[2] = citizenId
            params[3] = department
            params[4] = json.encode(currentAssignments)
            params[5] = json.encode(dutyRecords)
            params[6] = serviceHistory
            params[7] = status
            params[8] = citizenId
            MySQL.query.await(query, params)
            setJob(citizenId, department, rank)
            SendDiscordLog("ems_medic", "\240\159\154\145 Medic Rehired", nil, 3447003, {
              {name = "Citizen ID", value = citizenId, inline = true},
              {name = "Department", value = department, inline = true},
              {name = "Rank", value = rank, inline = true},
              {name = "Player", value = FormatPlayer(source), inline = false}
            })
            local result = {}
            result.success = true
            result.message = "Rehired successfully."
            return result
          end
        else
          query = [[
                INSERT INTO mdt_units (id, citizenid, department, currentAssignments, dutyRecords, serviceHistory, status)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ]]
          params = {}
          params[1] = id
          params[2] = citizenId
          params[3] = department
          params[4] = json.encode(currentAssignments)
          params[5] = json.encode(dutyRecords)
          params[6] = json.encode(serviceHistory)
          params[7] = status
          MySQL.query.await(query, params)
          setJob(citizenId, department, rank)
          SendDiscordLog("ems_medic", "\226\156\133 Medic Hired", nil, 5763719, {
            {name = "Citizen ID", value = citizenId, inline = true},
            {name = "Department", value = department, inline = true},
            {name = "Rank", value = rank, inline = true},
            {name = "Player", value = FormatPlayer(source), inline = false}
          })
          local result = {}
          result.success = true
          result.message = "Hired successfully."
          return result
        end
      end
    end
  else
    local result = {}
    result.success = false
    result.message = "No data received."
    return result
  end
end
registerCallback(addNewMedics, addNewMedicsCallback)

fetchMedicDataByMedicId = "kartik-mdt:server:fetchMedicDataByMedicId"
function fetchMedicDataByMedicIdCallback(source, data)
  if data then
    local medicId = data.MedicId
    local query = "SELECT * FROM mdt_units WHERE id = ?"
    local params = {}
    params[1] = medicId
    local result = MySQL.query.await(query, params)
    local json = json
    json = json.decode
    local dutyRecords = json(result[1].dutyRecords) or {}
    if #dutyRecords > 10 then
      dutyRecords = {}
      local unpack = table.unpack
      local _, _, _, _ = unpack(dutyRecords, #dutyRecords - 9, #dutyRecords)
    end
    local medicData = {}
    medicData.currentAssignments = result[1].currentAssignments or ""
    medicData.serviceHistory = result[1].serviceHistory or ""
    medicData.dutyRecords = dutyRecords or ""
    medicData.totalHours = result[1].totalHours or 0.0
    return medicData
  else
    return nil
  end
end
registerCallback(fetchMedicDataByMedicId, fetchMedicDataByMedicIdCallback)

updateMedicRank = "kartik-mdt:server:updateMedicRank"
function updateMedicRankCallback(source, data)
  if data then
    local medicId = data.medicId
    local citizenId = data.citizenId
    local rank = data.rank
    local department = data.department
    local json = json
    json = json.encode
    local serviceHistory = json(data.serviceHistory)
    local query = "UPDATE mdt_units SET serviceHistory = ?, department = ?, callsign = NULL WHERE id = ?"
    local params = {}
    params[1] = serviceHistory
    params[2] = department
    params[3] = medicId
    MySQL.query.await(query, params)
    setJob(citizenId, department, rank)
    SendDiscordLog("ems_medic", "\240\159\169\186 Medic Rank Updated", nil, 15844367, {
      {name = "Citizen ID", value = citizenId, inline = true},
      {name = "New Rank", value = rank, inline = true},
      {name = "Player", value = FormatPlayer(source), inline = false}
    })
    local result = {}
    result.success = true
    result.message = "Updated"
    return result
  else
    return nil
  end
end
registerCallback(updateMedicRank, updateMedicRankCallback)

addMedicAssignment = "kartik-mdt:server:addMedicAssignment"
function addMedicAssignmentCallback(source, data)
  if data then
    local medicId = data.medicId
    local json = json
    json = json.encode
    local currentAssignments = json(data.currentAssignments)
    local query = "UPDATE mdt_units SET currentAssignments = ? WHERE id = ?"
    local params = {}
    params[1] = currentAssignments
    params[2] = medicId
    MySQL.query.await(query, params)
    SendDiscordLog("ems_medic", "\240\159\147\139 Medic Assignment Updated", nil, 3447003, {
      {name = "Medic ID", value = medicId, inline = true},
      {name = "Player", value = FormatPlayer(source), inline = false}
    })
    local result = {}
    result.success = true
    result.message = "Updated"
    return result
  else
    return nil
  end
end
registerCallback(addMedicAssignment, addMedicAssignmentCallback)

fireMedic = "kartik-mdt:server:fireMedic"
function fireMedicCallback(source, data)
  if data then
    local citizenId = data.citizenId
    local json = json
    json = json.encode
    local serviceHistory = json(data.serviceHistory)
    local query = "UPDATE mdt_units SET isFired = ?, status = ?, serviceHistory = ?, callsign = NULL WHERE citizenid = ?"
    local params = {}
    params[1] = 1
    params[2] = "off-duty"
    params[3] = serviceHistory
    params[4] = citizenId
    MySQL.query.await(query, params)
    setJob(citizenId, "unemployed", 0)
    SendDiscordLog("ems_medic", "\226\157\140 Medic Fired", nil, 15548997, {
      {name = "Citizen ID", value = citizenId, inline = true},
      {name = "Player", value = FormatPlayer(source), inline = false}
    })
    local result = {}
    result.success = true
    result.message = "Updated"
    return result
  else
    return nil
  end
end
registerCallback(fireMedic, fireMedicCallback)

updateMedictags = "kartik-mdt:server:updateMedictags"
function updateMedictagsCallback(source, data)
  if data then
    local tags = data.tags
    if tags then
      local citizenId = data.citizenId
      local json = json
      json = json.encode
      tags = json(tags)
      local query = "UPDATE mdt_units SET tags = ? WHERE citizenid = ?"
      local params = {}
      params[1] = tags
      params[2] = citizenId
      MySQL.query.await(query, params)
      SendDiscordLog("ems_medic", "\240\159\143\183\239\184\143 Medic Tags Updated", nil, 3447003, {
        {name = "Citizen ID", value = citizenId, inline = true},
        {name = "Player", value = FormatPlayer(source), inline = false}
      })
      local result = {}
      result.success = true
      result.message = "Updated Tags"
      return result
    end
  else
    return nil
  end
end
registerCallback(updateMedictags, updateMedictagsCallback)