local registerCallback, fetchEMSReports, fetchEMSReportDataByReportId, addNewEMSReport, saveCurrentEMSReport, deleteEMSReport

registerCallback = lib.callback.register
fetchEMSReports = function(source, data)
    local playerData = GetPlayerData(source)
    if not playerData then
        return { reports = {}, totalCount = 0 }
    end

    local page = data.page
    local query = data.query
    if not query then
        query = ""
    end

    local offset = (page - 1) * 10
    local whereClause = ""
    local params = {}

    if query ~= "" then
        whereClause = "WHERE LOWER(name) LIKE LOWER(?) OR LOWER(reportId) LIKE LOWER(?) "
        params = { "%" .. query .. "%", "%" .. query .. "%" }
    end

    local querySql = "SELECT * FROM mdt_ems_reports " .. whereClause .. " LIMIT 10 OFFSET ?"
    table.insert(params, offset)

    local results = MySQL.query.await(querySql, params)
    local reports = {}

    for _, result in ipairs(results) do
        local report = {}
        report.reportId = result.reportId
        report.reportName = result.name
        report.dateTime = result.dateTime
        report.medicName = result.medicId
        report.canAccessReport = not result.isLocked or checkReportPermission(playerData.citizenId, result.reportId, "report", "ems")
        report.lockReason = result.lock_reason or "No reason specified"
        report.category = result.category
        report.peopleInvolved = result.peopleInvolved
        report.location = result.location

        table.insert(reports, report)
    end

    local countSql = "SELECT COUNT(*) as count FROM mdt_ems_reports " .. whereClause
    local countResults = MySQL.query.await(countSql, params)
    local totalCount = countResults[1].count

    return { reports = reports, totalCount = totalCount }
end

registerCallback("kartik-mdt:server:fetchEMSReports", fetchEMSReports)

fetchEMSReportDataByReportId = function(source, data)
    if data.reportId then
        local reportId = data.reportId
        local querySql = "SELECT * FROM mdt_ems_reports WHERE reportId = ?"
        local params = { reportId }
        local results = MySQL.query.await(querySql, params)

        if #results > 0 then
            local result = results[1]
            local report = {}
            report.reportId = result.reportId
            report.reportName = result.name
            report.medicId = result.medicId
            report.dateTime = result.dateTime
            report.location = result.location
            report.description = result.description
            report.evidences = result.evidences
            report.peopleInvolved = result.peopleInvolved
            report.vehiclesInvolved = result.vehiclesInvolved
            report.bodyData = result.bodyData
            report.reportAccess = {}

            local members = json.decode(result.members or "[]")
            for _, member in ipairs(members) do
                local offlinePlayer = GetOfflinePlayerByCitizenId(member)
                if offlinePlayer then
                    table.insert(report.reportAccess, { id = member, name = offlinePlayer.name })
                end
            end

            return { success = true, data = report }
        else
            return { success = false, message = "No data found." }
        end
    else
        return { success = false, message = "No data received." }
    end
end

registerCallback("kartik-mdt:server:fetchEMSReportDataByReportId", fetchEMSReportDataByReportId)

addNewEMSReport = function(source, data)
    if data.reportToAdd then
        local reportName = data.reportToAdd.reportName
        local medicId = data.reportToAdd.medicId
        local location = data.reportToAdd.location
        local description = data.reportToAdd.description
        local evidences = json.encode(data.reportToAdd.evidences)
        local peopleInvolved = json.encode(data.reportToAdd.peopleInvolved)
        local vehiclesInvolved = json.encode(data.reportToAdd.vehiclesInvolved)

        local querySql = "INSERT INTO mdt_ems_reports (name, medicId, location, description, dateTime, evidences, peopleInvolved, vehiclesInvolved) VALUES (?, ?, ?, ?, ?, ?, ?, ?)"
        local params = { reportName, medicId, location, description, os.date("%Y-%m-%d %H:%M:%S"), evidences, peopleInvolved, vehiclesInvolved }
        local results = MySQL.query.await(querySql, params)
        local reportId = results.insertId

        SendDiscordLog("ems_reports", "\240\159\147\132 EMS Report Created", nil, 3066993, {
            { name = "Report ID", value = tostring(reportId), inline = true },
            { name = "Report Name", value = reportName, inline = true },
            { name = "Medic ID", value = medicId, inline = true },
            { name = "Player", value = FormatPlayer(source), inline = false }
        })

        return { success = true, message = "Report added successfully.", reportId = reportId }
    else
        return { success = false, message = "No data received." }
    end
end

registerCallback("kartik-mdt:server:addNewEMSReport", addNewEMSReport)

saveCurrentEMSReport = function(source, data)
    if data.reportId then
        local reportId = data.reportId
        local reportName = data.reportName
        local location = data.location
        local description = data.description
        local evidences = json.encode(data.evidences)
        local peopleInvolved = json.encode(data.peopleInvolved)
        local vehiclesInvolved = json.encode(data.vehiclesInvolved)
        local bodyData = json.encode(data.bodyData)

        local querySql = "UPDATE mdt_ems_reports SET name = ?, location = ?, description = ?, evidences = ?, peopleInvolved = ?, vehiclesInvolved = ?, bodyData = ? WHERE reportId = ?"
        local params = { reportName, location, description, evidences, peopleInvolved, vehiclesInvolved, bodyData, reportId }
        local results = MySQL.query.await(querySql, params)

        if results.affectedRows > 0 then
            SendDiscordLog("ems_reports", "\226\156\143\239\184\143 EMS Report Edited", nil, 15105570, {
                { name = "Report ID", value = tostring(reportId), inline = true },
                { name = "Updated Name", value = reportName, inline = true },
                { name = "Player", value = FormatPlayer(source), inline = false }
            })

            return { success = true, message = "Report saved successfully." }
        else
            return { success = false, message = "Failed to update the report." }
        end
    else
        return { success = false, message = "No data received." }
    end
end

registerCallback("kartik-mdt:server:saveCurrentEMSReport", saveCurrentEMSReport)

deleteEMSReport = function(source, data)
    if data.reportId then
        local reportId = data.reportId
        local querySql = "DELETE FROM mdt_ems_reports WHERE reportId = ?"
        local params = { reportId }
        local results = MySQL.query.await(querySql, params)

        if results.affectedRows > 0 then
            SendDiscordLog("ems_reports", "\240\159\151\145\239\184\143 EMS Report Deleted", nil, 10038562, {
                { name = "Report ID", value = tostring(reportId), inline = true },
                { name = "Player", value = FormatPlayer(source), inline = false }
            })

            return { success = true, message = "Report deleted successfully." }
        else
            return { success = false, message = "Failed to delete the report." }
        end
    else
        return { success = false, message = "No data received." }
    end
end

registerCallback("kartik-mdt:server:deleteEMSReport", deleteEMSReport)

fetchEMSRecentReports = function(data)
    local page = data.page
    local limit = data.limit
    local offset = (page - 1) * limit
    local querySql = "SELECT * FROM mdt_ems_reports ORDER BY dateTime DESC LIMIT ? OFFSET ?"
    local params = { limit, offset }
    local results = MySQL.query.await(querySql, params)
    local reports = {}

    for _, result in ipairs(results) do
        local report = {}
        report.reportId = result.reportId
        report.reportName = result.name
        report.dateTime = result.dateTime
        report.location = result.location

        table.insert(reports, report)
    end

    return { reports = reports, success = true }
end

local fetchRecentReports, reportModule
fetchRecentReports = fetchEMSRecentReports
reportModule = ESCROWSHX1_2
return fetchRecentReports(reportModule)
end
ESCROWSHX0_1(ESCROWSHX1_1, fetchEMSRecentReports)