local messageQueue, isProcessing, extractNumericId, sendAttachmentToDiscord, processQueue, convertUtcToLocal

messageQueue = {}
isProcessing = false

function extractNumericId(str)
    local match = str:match("%d+")
    return match
end

function sendAttachmentToDiscord(discordId, content, contentType, data)
    local headers = {}
    local discordBot = ServerConfig.DiscordBot
    headers.Authorization = "Bot " .. discordBot
    headers["Content-Type"] = "application/json"

    local embedData = {}
    local embedDescription = "Check out this attachment"

    if contentType == "image" then
        local imageData = {}
        imageData.url = content
        embedData.image = imageData
    elseif contentType == "text" then
        embedData.title = "Attachment"
        embedData.description = content
    elseif contentType == "file" then
        local boundary = "----------" .. os.time()
        headers["Content-Type"] = "multipart/form-data; boundary=" .. boundary
        local file = io.open(content, "rb")
        if not file then
            print("Error opening file: " .. content)
            return
        end
        local fileData = file:read("*all")
        file:close()
        local formData = "--" .. boundary .. "\r\n"
        formData = formData .. "Content-Disposition: form-data; name=\"content\"\r\n\r\n"
        formData = formData .. embedDescription .. "\r\n"
        formData = formData .. "--" .. boundary .. "\r\n"
        formData = formData .. "Content-Disposition: form-data; name=\"file\"; filename=" .. data.fileName .. "\r\n"
        formData = formData .. "Content-Type: application/octet-stream\r\n\r\n"
        formData = formData .. fileData .. "\r\n"
        formData = formData .. "--" .. boundary .. "--"
        embedData = formData
    end

    if contentType ~= "file" then
        embedData = json.encode({ content = embedDescription, embeds = { embedData } })
    end

    local function createDmChannel(data, response)
        if data == 200 then
            local channelId = json.decode(response).id
            local url = "https://discord.com/api/v10/channels/" .. channelId .. "/messages"
            local function sendAttachment(data, response)
                if data == 200 then
                    print("Attachment and embed sent successfully")
                else
                    print("Failed to send attachment and embed. Status code: " .. data)
                    if response then
                        print("Response: " .. response)
                    end
                end
            end
            PerformHttpRequest(url, sendAttachment, "POST", embedData, headers)
        else
            print("Failed to create DM channel. Status code: " .. data)
            if response then
                print("Response: " .. response)
            end
        end
    end

    local url = "https://discord.com/api/v10/users/@me/channels"
    local userData = json.encode({ recipient_id = discordId })
    PerformHttpRequest(url, createDmChannel, "POST", userData, headers)
end

function processQueue()
    if not isProcessing then
        isProcessing = true
        if #messageQueue > 0 then
            local data = table.remove(messageQueue, 1)
            sendAttachmentToDiscord(data.discordId, data.content, data.contentType, data)
            SetTimeout(60000, function()
                isProcessing = false
                processQueue()
            end)
        else
            isProcessing = false
        end
    end
end

function convertUtcToLocal(utcTime)
    if utcTime == "" then
        return ""
    end
    local pattern = "(%d+)%-(%d+)%-(%d+)T(%d+):(%d+):(%d+)"
    local year, month, day, hour, min, sec = utcTime:match(pattern)
    if not year then
        return utcTime
    end
    local time = os.time({ year = year, month = month, day = day, hour = hour, min = min, sec = sec })
    local diff = os.difftime(os.time(), os.time({ year = os.date("%Y"), month = os.date("%m"), day = os.date("%d"), hour = os.date("%H"), min = os.date("%M"), sec = os.date("%S") }))
    time = time + diff
    return os.date("%Y-%m-%d %H:%M:%S", time)
end

lib.callback.register("kartik-mdt:server:getWebhook", function(source, data)
    if ServerConfig.Webhook then
        return { success = true, webhook = ServerConfig.Webhook }
    else
        print("Invalid data received")
        return { success = false, message = "Invalid data" }
    end
end)

lib.callback.register("kartik-mdt:server:downloadDutyRecords", function(source, data)
    if data then
        local citizenId = extractNumericId(GetPlayerIdentifierByType(source, "discord"))
        local query = "SELECT dutyRecords FROM mdt_units WHERE citizenid = ?"
        local params = { citizenId }
        local result = MySQL.query.await(query, params)
        if result and #result > 0 then
            local dutyRecords = json.decode(result[1].dutyRecords)
            if dutyRecords and type(dutyRecords) == "table" then
                local filePath = GetResourcePath(GetCurrentResourceName()) .. "/DutyRecords.xls"
                os.remove(filePath)
                local file = io.open(filePath, "w")
                if file then
                    file:write("CitizenId\tStartTime\tEndTime\tHours\n")
                    for _, record in ipairs(dutyRecords) do
                        local startTime = convertUtcToLocal(record.startTime or "")
                        local endTime = convertUtcToLocal(record.endTime or "")
                        local hours = record.hours or ""
                        file:write(citizenId .. "\t" .. startTime .. "\t" .. endTime .. "\t" .. hours .. "\n")
                    end
                    file:close()
                    print("Duty records file written successfully.")
                    table.insert(messageQueue, {
                        discordId = citizenId,
                        content = filePath,
                        contentType = "file",
                        source = source,
                        fileName = "Duty Records_" .. citizenId .. ".xls"
                    })
                    processQueue()
                    return { success = true, message = "Added to queue, You will receive in your DM shortly." }
                else
                    print("Failed to open the file for writing.")
                end
            end
        end
    else
        print("No data received.")
    end
end)

lib.callback.register("kartik-mdt:server:receivePDF", function(source, data)
    if data then
        local discordId = GetPlayerIdentifierByType(source, "discord"):match("%d+")
        local pdfData = json.decode(data.data)
        local pdfUrl = pdfData.attachments[1].url
        local pdfName = pdfData.attachments[1].filename
        local message = "Here is the PDF file: \n" .. pdfUrl
        table.insert(messageQueue, {
            discordId = discordId,
            content = message,
            contentType = "text",
            source = source,
            fileName = pdfName
        })
        processQueue()
        return { success = true, message = "PDF URL and file name received and will be sent shortly" }
    else
        return { success = false, message = "No data received" }
    end
end)