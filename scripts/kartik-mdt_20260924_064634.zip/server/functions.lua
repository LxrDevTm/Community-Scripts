local resourceName, resourceCount
resourceName = GetCurrentResourceName
resourceName = resourceName()
if "kartik-mdt" ~= resourceName then
  return
end

function detectCore(coreName)
  local numResources, resourceIndex, maxIndex, increment
  numResources = GetNumResources
  numResources = numResources()
  resourceIndex = 0
  maxIndex = numResources - 1
  increment = 1
  for i = resourceIndex, maxIndex, increment do
    local resource = GetResourceByFindIndex
    local currentIndex = i
    resource = resource(currentIndex)
    if resource == coreName then
      local resourceState = GetResourceState
      local currentResource = resource
      resourceState = resourceState(currentResource)
      if "started" == resourceState then
        return true
      end
    end
  end
  return false
end
detectCore = detectCore

function getDepartmentCategory(departmentName)
  local pairsFunc, config, jobs, jobIndex, jobName, jobData, departmentIndex
  pairsFunc = pairs
  config = Config
  jobs = config.Jobs
  for jobIndex, jobData in pairsFunc(jobs) do
    local ipairsFunc, units, unitIndex, unitName
    ipairsFunc = ipairs
    units = jobData
    for unitIndex, unitName in ipairsFunc(units) do
      if departmentName == unitName then
        return jobIndex
      end
    end
  end
end
getDepartmentCategory = getDepartmentCategory

function getCitizenIdFromUnitId(unitId)
  if unitId then
    local query = "SELECT citizenid FROM mdt_units WHERE id = ?"
    local queryParams = {}
    queryParams[1] = unitId
    local result = MySQL.query.await(query, queryParams)
    if result then
      local citizenId = result[1]
      if citizenId then
        return citizenId.citizenid
      end
    end
    return false
  end
end
getCitizenIdFromUnitId = getCitizenIdFromUnitId

function isActionAllowed(playerId, actionName)
  local playerData = GetPlayerData(playerId)
  if not playerData then
    return false
  end
  local jobName = playerData.jobData.name
  if not jobName then
    return false
  end
  local jobGrade = playerData.jobData.grade.level
  local permissions = GetSanitizedPermissions(jobName, jobGrade)
  if permissions then
    local hasPermission = next(permissions)
    if hasPermission then
      local page = permissions.Pages[actionName]
      if page then
        return page.view
      end
    end
  end
  return false
end
isActionAllowed = isActionAllowed