local resourceName, updateCitizenLicenseFunction, fetchLicensesFunction
resourceName = GetCurrentResourceName()
resourceName = resourceName()
if "kartik-mdt" ~= resourceName then
  return
end

function validateDate(dateString)
  local pattern = "^%d%d%d%d%-%d%d%-%d%d %d%d:%d%d:%d%d$"
  local match = string.match(dateString, pattern)
  if match then
    return true
  else
    local currentTime = os.date("%H:%M:%S")
    local newDateString = dateString .. " " .. currentTime
    local match = string.match(newDateString, pattern)
    return match ~= nil
  end
end

function updateCitizenLicense(player, licenseData)
  if not licenseData then
    print("No data received.")
    return { success = false, message = "No data received." }
  end

  local playerData = GetPlayerData(player)
  local citizenId = licenseData.citizenId
  local license = licenseData.license
  local approvedBy = license.approvedBy
  if not approvedBy then
    approvedBy = playerData.name
  end
  license.approvedBy = approvedBy

  local approvedDate = license.approvedDate
  if approvedDate and approvedDate ~= "0000-00-00 00:00:00" then
    if not validateDate(approvedDate) then
      approvedDate = os.date("%Y-%m-%d %H:%M:%S")
      license.approvedDate = approvedDate
    end
  else
    approvedDate = os.date("%Y-%m-%d %H:%M:%S")
    license.approvedDate = approvedDate
  end

  local expirationDate = license.expirationDate
  if expirationDate and expirationDate ~= "0000-00-00 00:00:00" then
    if not validateDate(expirationDate) then
      expirationDate = os.date("%Y-%m-%d %H:%M:%S")
      license.expirationDate = expirationDate
    end
  else
    expirationDate = os.date("%Y-%m-%d %H:%M:%S")
    license.expirationDate = expirationDate
  end

  if license.status == "approved" then
    print(type(license.expirationDate))
    print(license.expirationDate)
    if not validateDate(license.expirationDate) then
      license.expirationDate = os.date("%Y-%m-%d %H:%M:%S")
    end
  else
    license.expirationDate = os.date("%Y-%m-%d %H:%M:%S")
  end

  if license.name and license.type and license.status then
    local existingLicenses = fetchLicenses(citizenId)
    local licenseExists = false
    if existingLicenses then
      for _, existingLicense in ipairs(existingLicenses) do
        if existingLicense.type == license.type then
          licenseExists = true
          break
        end
      end
    end

    if licenseExists then
      local query = [[
        UPDATE mdt_licenses
        SET name = ?, status = ?, approvedBy = ?, approvalDate = ?, expirationDate = ?, note = ?
        WHERE citizenId = ? AND type = ?
      ]]
      local params = {
        license.name,
        license.status,
        license.approvedBy,
        license.approvedDate,
        license.expirationDate,
        license.note,
        citizenId,
        license.type
      }
      local result = MySQL.query.await(query, params)
      if result then
        UpdateLicense(citizenId, license.type, license.status)
        SendDiscordLog("licenses", "\226\156\133 License Updated", nil, 5793266, {
          { name = "Citizen ID", value = citizenId, inline = true },
          { name = "License Type", value = license.type, inline = true },
          { name = "New Status", value = license.status, inline = true },
          { name = "Updated By", value = FormatPlayer(player), inline = false }
        })
        return { success = true, message = "License updated successfully.", licenses = json.encode(fetchLicenses(citizenId)) }
      else
        return { success = false, message = "Failed to update license." }
      end
    else
      local query = [[
        INSERT INTO mdt_licenses (citizenId, name, type, status, approvedBy, approvalDate, expirationDate, note)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
      ]]
      local params = {
        citizenId,
        license.name,
        license.type,
        license.status,
        license.approvedBy,
        license.approvedDate,
        license.expirationDate,
        license.note
      }
      local result = MySQL.query.await(query, params)
      if result then
        UpdateLicense(citizenId, license.type, license.status)
        SendDiscordLog("licenses", "\240\159\134\149 License Added", nil, 3447003, {
          { name = "Citizen ID", value = citizenId, inline = true },
          { name = "License Type", value = license.type, inline = true },
          { name = "Status", value = license.status, inline = true },
          { name = "Approved By", value = FormatPlayer(player), inline = false }
        })
        return { success = true, message = "License inserted successfully.", licenses = json.encode(fetchLicenses(citizenId)) }
      else
        return { success = false, message = "Failed to insert license." }
      end
    end
  else
    return { success = false, message = "Missing required license fields." }
  end
end

function fetchLicenses(citizenId)
  local query = [[
    SELECT * FROM mdt_licenses WHERE citizenId = ?
  ]]
  local params = { citizenId }
  local result = MySQL.query.await(query, params)
  if result then
    return result
  else
    print("Error fetching licenses for citizenId " .. citizenId .. ": " .. result)
    return {}
  end
end

CreateThread(function()
  Wait(1000)
  local result = MySQL.query.await("SHOW TABLES LIKE 'mdt_licenses'")
  if #result > 0 then
    print("^3[MDT] Checking licenses for broken data on startup...^0")
    local result = MySQL.query.await([[
      SELECT id, approvalDate, expirationDate
      FROM mdt_licenses
      WHERE approvalDate IS NULL OR approvalDate = '0000-00-00 00:00:00' 
         OR expirationDate IS NULL OR expirationDate = '0000-00-00 00:00:00'
    ]])
    local fixedCount = 0
    for _, row in ipairs(result) do
      local currentTime = os.date("%Y-%m-%d %H:%M:%S")
      local approvalDate = row.approvalDate
      if approvalDate and approvalDate ~= "0000-00-00 00:00:00" then
        if not validateDate(approvalDate) then
          approvalDate = currentTime
        end
      else
        approvalDate = currentTime
      end

      local expirationDate = row.expirationDate
      if expirationDate and expirationDate ~= "0000-00-00 00:00:00" then
        if not validateDate(expirationDate) then
          expirationDate = currentTime
        end
      else
        expirationDate = currentTime
      end

      local query = [[
        UPDATE mdt_licenses
        SET approvalDate = ?, expirationDate = ?
        WHERE id = ?
      ]]
      local params = { approvalDate, expirationDate, row.id }
      local result = MySQL.query.await(query, params)
      if result and result.affectedRows > 0 then
        fixedCount = fixedCount + 1
      end
    end
    print(string.format("^2[MDT] Fixed %d broken license record(s) on startup.^0", fixedCount))
  end
end)

CreateThread(function()
  local result = MySQL.query.await("SHOW TABLES LIKE 'mdt_licenses'")
  if #result > 0 then
    local query = "SELECT * FROM mdt_licenses WHERE expirationDate < ? AND status = ?"
    local params = { os.date("%Y-%m-%d"), "approved" }
    local result = MySQL.query.await(query, params)
    for _, row in ipairs(result) do
      local expirationDate = row.expirationDate
      if expirationDate then
        local newStatus = "expired"
        local query = "UPDATE mdt_licenses SET status = ? WHERE id = ?"
        local params = { newStatus, row.id }
        MySQL.query.await(query, params)
        UpdateLicense(row.citizenId, row.type, newStatus)
        print("[" .. row.citizenId .. "] " .. row.name .. " expired")
      end
    end
  end
end)

lib.callback.register("kartik-mdt:server:updateCitizenLicense", function(player, licenseData)
  return updateCitizenLicense(player, licenseData)
end)

exports("updateCitizenLicense", updateCitizenLicense)