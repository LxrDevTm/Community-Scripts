local resolveReportTable, resolveReportIdColumn, resolveOfficerColumn

function resolveReportTable(reportType, page)
    local reportTables = {}
    reportTables.police = {}
    reportTables.police.report = "mdt_police_reports"
    reportTables.police.incident = "mdt_police_incidents"
    reportTables.ems = {}
    reportTables.ems.report = "mdt_ems_reports"
    reportTables.ems.incident = "mdt_ems_incidents"
    local reportTable = reportTables[page]
    if not reportTable then
        return nil
    end
    return reportTable[reportType]
end

function resolveReportIdColumn(reportType)
    if reportType == "incident" then
        return "incidentId"
    else
        return "reportId"
    end
end

function resolveOfficerColumn(reportType)
    if reportType == "ems" then
        return "medicId"
    else
        return "officerId"
    end
end

function checkReportPermission(citizenId, reportId, reportType, page, permission, rank)
    local mysql = MySQL.query.await
    local query = "SELECT id FROM mdt_units WHERE citizenid = ?"
    local params = {citizenId}
    local result = mysql(query, params)
    if not result or #result == 0 then
        return false
    end
    local unitId = result[1].id
    local reportTable = resolveReportTable(reportType, page)
    if not reportTable then
        return false
    end
    local reportIdColumn = resolveReportIdColumn(reportType)
    local officerColumn = resolveOfficerColumn(reportType)
    query = [[
        SELECT %s, members
        FROM %s
        WHERE %s = ?
    ]]
    query = query:format(officerColumn, reportTable, reportIdColumn)
    params = {reportId}
    result = mysql(query, params)
    if not result or #result == 0 then
        return false
    end
    local officerId = result[1][officerColumn]
    if officerId == unitId then
        return true
    end
    local config = Config.Permissions[permission]
    if not config then
        return false
    end
    local managementRank = config.management_rank
    if rank >= managementRank then
        return true
    end
    local members = result[1].members
    if not members then
        members = "[]"
    end
    local success, membersTable = pcall(json.decode, members)
    if success and type(membersTable) == "table" then
        for _, memberId in ipairs(membersTable) do
            if memberId == citizenId then
                return true
            end
        end
    end
    return false
end

local lib = lib
lib.callback.register("kartik-mdt:server:unlockReport", function(source, data)
    if not data then
        return {success = false, message = "No data received."}
    end
    local reportId = data.reportId
    local reportType = data.reportType
    local page = data.page
    local playerData = GetPlayerData(source)
    if not playerData then
        return {success = false, message = "No player data found."}
    end
    local citizenId = playerData.citizenId
    local reportTable = resolveReportTable(reportType, page)
    if not reportTable then
        return {success = false, message = "Invalid report type or page."}
    end
    local reportIdColumn = resolveReportIdColumn(reportType)
    local mysql = MySQL.query.await
    local query = "SELECT * FROM %s WHERE %s = ?"
    query = query:format(reportTable, reportIdColumn)
    local params = {reportId}
    local result = mysql(query, params)
    if not result or #result == 0 then
        return {success = false, message = "Report not found."}
    end
    local permission = checkReportPermission(citizenId, reportId, reportType, page)
    if not permission then
        return {success = false, message = "No permission."}
    end
    query = "UPDATE %s SET isLocked = 0 WHERE %s = ?"
    query = query:format(reportTable, reportIdColumn)
    params = {reportId}
    local success = mysql(query, params) > 0
    if success then
        return {success = true, message = "Report unlocked successfully."}
    else
        return {success = false, message = "Failed to unlock report."}
    end
end)

lib.callback.register("kartik-mdt:server:lockReport", function(source, data)
    if not data then
        return {success = false, message = "No data received."}
    end
    local reportId = data.reportId
    local lockReason = data.lockReason
    local reportType = data.reportType
    local page = data.page
    local playerData = GetPlayerData(source)
    if not playerData then
        return {success = false, message = "No player data found."}
    end
    local citizenId = playerData.citizenId
    local reportTable = resolveReportTable(reportType, page)
    if not reportTable then
        return {success = false, message = "Invalid report type or page."}
    end
    local reportIdColumn = resolveReportIdColumn(reportType)
    local mysql = MySQL.query.await
    local query = "SELECT * FROM %s WHERE %s = ?"
    query = query:format(reportTable, reportIdColumn)
    local params = {reportId}
    local result = mysql(query, params)
    if not result or #result == 0 then
        return {success = false, message = "Report not found."}
    end
    local permission = checkReportPermission(citizenId, reportId, reportType, page)
    if not permission then
        return {success = false, message = "No permission."}
    end
    query = "UPDATE %s SET isLocked = 1, lock_reason = ? WHERE %s = ?"
    query = query:format(reportTable, reportIdColumn)
    params = {lockReason, reportId}
    local success = mysql(query, params) > 0
    if success then
        return {success = true, message = "Report locked successfully."}
    else
        return {success = false, message = "Failed to lock report."}
    end
end)

lib.callback.register("kartik-mdt:server:grantReportAccess", function(source, data)
    if not data then
        return {success = false, message = "Invalid data."}
    end
    local reportId = data.reportId
    local userId = data.userId
    local reportType = data.reportType
    local page = data.page
    if not reportId or not userId then
        return {success = false, message = "Invalid data."}
    end
    local reportTable = resolveReportTable(reportType, page)
    if not reportTable then
        return {success = false, message = "Invalid report type or page."}
    end
    local reportIdColumn = resolveReportIdColumn(reportType)
    local mysql = MySQL.query.await
    local query = "SELECT members FROM %s WHERE %s = ?"
    query = query:format(reportTable, reportIdColumn)
    local params = {reportId}
    local result = mysql(query, params)
    if not result or #result == 0 then
        return {success = false, message = "Report not found."}
    end
    local members = result[1].members
    if not members then
        members = "[]"
    end
    local success, membersTable = pcall(json.decode, members)
    if success and type(membersTable) == "table" then
        for _, memberId in ipairs(membersTable) do
            if memberId == userId then
                return {success = false, message = "Already has access."}
            end
        end
    end
    table.insert(membersTable or {}, userId)
    local newMembers = json.encode(membersTable or {})
    query = "UPDATE %s SET members = ? WHERE %s = ?"
    query = query:format(reportTable, reportIdColumn)
    params = {newMembers, reportId}
    mysql(query, params)
    return {success = true}
end)

lib.callback.register("kartik-mdt:server:revokeReportAccess", function(source, data)
    if not data then
        return {success = false, message = "Invalid data."}
    end
    local reportId = data.reportId
    local userId = data.userId
    local reportType = data.reportType
    local page = data.page
    if not reportId or not userId then
        return {success = false, message = "Invalid data."}
    end
    local reportTable = resolveReportTable(reportType, page)
    if not reportTable then
        return {success = false, message = "Invalid report type or page."}
    end
    local reportIdColumn = resolveReportIdColumn(reportType)
    local mysql = MySQL.query.await
    local query = "SELECT members FROM %s WHERE %s = ?"
    query = query:format(reportTable, reportIdColumn)
    local params = {reportId}
    local result = mysql(query, params)
    if not result or #result == 0 then
        return {success = false, message = "Report not found."}
    end
    local members = result[1].members
    if not members then
        members = "[]"
    end
    local success, membersTable = pcall(json.decode, members)
    if success and type(membersTable) == "table" then
        local newMembers = {}
        for _, memberId in ipairs(membersTable) do
            if memberId ~= userId then
                table.insert(newMembers, memberId)
            end
        end
        local newMembersJson = json.encode(newMembers)
        query = "UPDATE %s SET members = ? WHERE %s = ?"
        query = query:format(reportTable, reportIdColumn)
        params = {newMembersJson, reportId}
        mysql(query, params)
        return {success = true}
    end
    return {success = true}
end)