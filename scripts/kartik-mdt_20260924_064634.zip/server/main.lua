local resourceName, currentResourceName, MySQL, json, os, lib, exports
currentResourceName = GetCurrentResourceName()
if currentResourceName ~= "kartik-mdt" then
    print("^1[kartik-mdt] This resource must be started as kartik-mdt^0")
    print("^1[kartik-mdt] Please change the resource name to kartik-mdt in your server.cfg^0")
    return
end

local incidents = {}
function getOfficerData(officer)
    if officer then
        local citizenId = officer.citizenId
        local query = "SELECT * FROM mdt_units WHERE citizenid = ?"
        local result = MySQL.query.await(query, {citizenId})
        if result then
            if #result > 0 then
                local unit = result[1]
                if unit.isFired == 1 then
                    return false
                end
                local officerData = {
                    id = unit.id or "",
                    callsign = unit.callsign or "",
                    status = unit.status or "off-duty",
                    dutyStatus = unit.dutyStatus or "avl",
                    radioChannels = radioChannels or {},
                    permissions = GetSanitizedPermissions(officer.jobName, officer.grade, json.decode(unit.tags) or {})
                }
                return officerData
            end
        end
    end
end

function getPermissionData(officer)
    if officer then
        local citizenId = officer.citizenId
        local query = "SELECT * FROM mdt_units WHERE citizenid = ?"
        local result = MySQL.query.await(query, {citizenId})
        if result then
            if #result > 0 then
                local unit = result[1]
                if unit.isFired == 1 then
                    return false
                end
                local permissionData = {
                    permissions = GetSanitizedPermissions(officer.jobName, officer.grade, json.decode(unit.tags) or {})
                }
                return permissionData
            end
        end
    end
end

function GetCallsign(citizenId)
    if not citizenId then
        return false
    end
    local query = "SELECT callsign FROM mdt_units WHERE citizenid = ?"
    local result = MySQL.query.await(query, {citizenId})
    if result then
        if #result > 0 then
            local unit = result[1]
            if unit.callsign then
                return unit.callsign
            else
                return "XX-00"
            end
        else
            return "XX-00"
        end
    else
        return "XX-00"
    end
end

exports("GetCallsign", GetCallsign)

lib.callback.register("kartik-mdt:server:getOfficerData", function(source, officer)
    return getOfficerData(officer)
end)

lib.callback.register("kartik-mdt:server:getPermissionData", function(source, officer)
    return getPermissionData(officer)
end)

lib.callback.register("kartik-mdt:server:setUnitStatus", function(source, data)
    if data then
        local status = data.status
        if status then
            local player = GetPlayerData(source)
            local citizenId = player.citizenId
            local query = "UPDATE mdt_units SET dutyStatus = ? WHERE citizenid = ?"
            local result = MySQL.query.await(query, {status, citizenId})
            if result.affectedRows > 0 then
                CreateThread(function()
                    local activeUnits = fetchActiveUnitsHere()
                    syncDataBetweenUnits("setActiveOfficers", activeUnits.units or {})
                end)
                return {success = true, message = "Status Changed Successfully"}
            else
                return {success = false, message = "Failed to change."}
            end
        end
    end
end)

lib.callback.register("kartik-mdt:server:changeCallsign", function(source, data)
    if data then
        local newCallsign = data.newCallsign
        local citizenId = data.citizenId
        local query = "UPDATE mdt_units SET callsign = ? WHERE citizenid = ?"
        local result = MySQL.query.await(query, {newCallsign, citizenId})
        if result.affectedRows > 0 then
            return {success = true, callsign = newCallsign, message = "Your callsign has been successfully changed."}
        else
            return {success = false, message = "Failed to change"}
        end
    else
        return {success = false, message = "Failed to change."}
    end
end)

function parseDateTime(dateString)
    if not dateString then
        return nil
    end
    local year, month, day, hour, minute, second
    local match = dateString:match("T")
    if match then
        year, month, day, hour, minute, second = dateString:match("(%d+)-(%d+)-(%d+)T(%d+):(%d+):(%d+)")
    else
        year, month, day, hour, minute, second = dateString:match("(%d+)-(%d+)-(%d+) (%d+):(%d+):(%d+)")
    end
    if not (year and month and day and hour and minute and second) then
        return nil
    end
    year = tonumber(year)
    month = tonumber(month)
    day = tonumber(day)
    hour = tonumber(hour)
    minute = tonumber(minute)
    second = tonumber(second)
    return os.time({year = year, month = month, day = day, hour = hour, min = minute, sec = second})
end

function formatDateTime(dateString)
    if not dateString then
        return nil
    end
    local match = dateString:match("T")
    if match then
        local match2 = dateString:match("Z$")
        if match2 then
            return dateString
        end
    end
    local year, month, day, hour, minute, second
    year, month, day, hour, minute, second = dateString:match("(%d+)-(%d+)-(%d+)T?(%d+):(%d+):(%d+)")
    if not (year and month and day and hour and minute and second) then
        return nil
    end
    year = tonumber(year)
    month = tonumber(month)
    day = tonumber(day)
    hour = tonumber(hour)
    minute = tonumber(minute)
    second = tonumber(second)
    local dateTime = os.time({year = year, month = month, day = day, hour = hour, min = minute, sec = second})
    return os.date("!%Y-%m-%dT%H:%M:%S.000Z", dateTime)
end

function parseDateTime2(dateString)
    local year, month, day, hour, minute, second
    year, month, day, hour, minute, second = dateString:match("(%d+)%-(%d+)%-(%d+)T(%d+):(%d+):(%d+)")
    if not (year and month and day and hour and minute and second) then
        return dateString
    end
    year = tonumber(year)
    month = tonumber(month)
    day = tonumber(day)
    hour = tonumber(hour)
    minute = tonumber(minute)
    second = tonumber(second)
    local dateTime = os.time({year = year, month = month, day = day, hour = hour, min = minute, sec = second})
    return dateTime
end

local function formatDateTime(dateString)
    local dateTable = {}
    dateTable.year = tonumber(dateString:sub(1, 4))
    dateTable.month = tonumber(dateString:sub(6, 7))
    dateTable.day = tonumber(dateString:sub(9, 10))
    dateTable.hour = tonumber(dateString:sub(12, 13))
    dateTable.min = tonumber(dateString:sub(15, 16))
    dateTable.sec = tonumber(dateString:sub(18, 19))
    return os.time(dateTable)
end

local function calculateDuration(startTime, endTime)
    return (endTime - startTime) / 3600
end

local function processDutyRecords(dutyRecords)
    local processedRecords = {}
    for _, record in ipairs(dutyRecords) do
        if record.startTime and record.endTime and record.endTime ~= "" then
            local startTime = formatDateTime(record.startTime)
            local endTime = formatDateTime(record.endTime)
            if startTime and endTime then
                local duration = calculateDuration(startTime, endTime)
                if duration > 0 then
                    record.startTime = startTime
                    record.endTime = endTime
                    record.hours = math.floor(duration * 10) / 10
                    table.insert(processedRecords, record)
                end
            end
        end
    end
    return processedRecords
end

local function getRosterLink(department)
    if ServerConfig.Roster[department] then
        return { roster = ServerConfig.Roster[department], success = true }
    else
        return { success = false, message = "No Roster Found" }
    end
end

local function getSOP(department)
    if ServerConfig.SOP[department] then
        return { sop = ServerConfig.SOP[department], success = true }
    else
        return { success = false, message = "No SOP Found" }
    end
end

local function handlePlayerDropped(source)
    local playerData = GetPlayerData(source)
    if playerData then
        local citizenId = playerData.citizenId
        local department = playerData.jobData.name
        if citizenId and department then
            local blipPlayer = blipPlayers[citizenId]
            if blipPlayer then
                blipPlayers[citizenId] = nil
            end
            handleBodycamToggle(source, false, citizenId)
            LeaveRadio(citizenId)
            local departmentCategory = getDepartmentCategory(department)
            if departmentCategory then
                local query = MySQL.query.await("SELECT * FROM mdt_units WHERE citizenid = ?", { citizenId })
                if query then
                    local unitData = query[1]
                    if unitData then
                        local dutyRecords = unitData.dutyRecords
                        if type(dutyRecords) == "string" then
                            dutyRecords = json.decode(dutyRecords) or {}
                        end
                        if type(dutyRecords) ~= "table" then
                            dutyRecords = {}
                        end
                        for _, record in ipairs(dutyRecords) do
                            if record.endTime == "" then
                                record.endTime = os.date("!%Y-%m-%dT%H:%M:%S.000Z")
                                local startTime = record.startTime
                                local endTime = record.endTime
                                local duration = calculateDuration(formatDateTime(startTime), formatDateTime(endTime))
                                record.hours = math.floor(duration * 10) / 10
                            end
                        end
                        local updatedDutyRecords = processDutyRecords(dutyRecords)
                        local dutyRecordsJson = json.encode(updatedDutyRecords)
                        MySQL.update.await("UPDATE mdt_units SET dutyRecords = ?, status = ? WHERE citizenid = ?", { dutyRecordsJson, "off-duty", citizenId })
                    end
                end
            end
        else
            print("No citizenId or department for player:", source)
        end
    end
end

AddEventHandler("playerDropped", handlePlayerDropped)

lib.callback.register("kartik-mdt:server:toggleDuty", function(player, data)
    if not data then
        return nil
    end
    local duty = data.duty
    local citizenId = data.citizenId
    local query = MySQL.query.await("SELECT dutyRecords FROM mdt_units WHERE citizenid = ?", { citizenId })
    if query then
        local dutyRecords = query[1].dutyRecords
        if dutyRecords then
            dutyRecords = json.decode(dutyRecords) or {}
        else
            dutyRecords = {}
        end
        if duty then
            local newRecord = {
                startTime = os.date("!%Y-%m-%dT%H:%M:%S.000Z"),
                endTime = "",
                hours = 0
            }
            table.insert(dutyRecords, newRecord)
            local dutyRecordsJson = json.encode(dutyRecords)
            MySQL.update.await("UPDATE mdt_units SET dutyRecords = ?, status = ? WHERE citizenid = ?", { dutyRecordsJson, "on-duty", citizenId })
            SendDiscordLog("duty_logs", "\240\159\159\162 [" .. GetOfflinePlayerByCitizenId(citizenId).jobData.label .. "] Duty Started", GetOfflinePlayerByCitizenId(citizenId).name .. " is now **ON DUTY**", 3066993, {
                { name = "Citizen ID", value = citizenId, inline = true },
                { name = "Start Time", value = formatDateTime(newRecord.startTime), inline = true }
            })
        else
            local lastRecord = dutyRecords[#dutyRecords]
            if lastRecord and lastRecord.endTime == "" then
                lastRecord.endTime = os.date("!%Y-%m-%dT%H:%M:%S.000Z")
                local duration = calculateDuration(formatDateTime(lastRecord.startTime), formatDateTime(lastRecord.endTime))
                lastRecord.hours = math.floor(duration * 10) / 10
                local dutyRecordsJson = json.encode(dutyRecords)
                MySQL.update.await("UPDATE mdt_units SET dutyRecords = ?, status = ? WHERE citizenid = ?", { dutyRecordsJson, "off-duty", citizenId })
                SendDiscordLog("duty_logs", "\240\159\148\180 Duty Ended", GetOfflinePlayerByCitizenId(citizenId).name .. " is now **OFF DUTY**", 15158332, {
                    { name = "Citizen ID", value = citizenId, inline = true },
                    { name = "Start Time", value = formatDateTime(lastRecord.startTime), inline = true },
                    { name = "End Time", value = formatDateTime(lastRecord.endTime), inline = true },
                    { name = "Duration", value = string.format("%d hr %d min", math.floor(lastRecord.hours), math.floor((lastRecord.hours % 1) * 60)), inline = true }
                })
            end
        end
        return { success = true, status = duty and "on-duty" or "off-duty", message = "Duty records updated successfully." }
    else
        return nil
    end
end)

lib.callback.register("kartik-mdt:server:getRosterLink", getRosterLink)
lib.callback.register("kartik-mdt:server:getSOPLink", getSOP)

local query = "SELECT dutyRecords FROM mdt_units WHERE citizenid = ?"
local mysql = MySQL.query.await
local params = {}
params[1] = citizenId
local result = mysql(query, params)
if result then
    local dutyRecords = result[1]
    if dutyRecords then
        local decodedDutyRecords = json.decode(dutyRecords.dutyRecords)
        if not decodedDutyRecords then
            decodedDutyRecords = {}
        end
        local totalHours = 0
        for _, record in ipairs(decodedDutyRecords) do
            totalHours = totalHours + record.hours
        end
        local updateQuery = "UPDATE mdt_units SET dutyRecords = ?, totalHours = ? WHERE citizenid = ?"
        local updateParams = {}
        updateParams[1] = json.encode(decodedDutyRecords)
        updateParams[2] = totalHours
        updateParams[3] = citizenId
        mysql(updateQuery, updateParams)
        return 1
    end
end
return 0

local CreateThread = CreateThread
function startVersionCheck()
    Wait(6000)
    function tonumber(str)
        return tonumber(str)
    end
    local resourceName = GetCurrentResourceName()
    local version = GetResourceMetadata(resourceName, "version", 0)
    local performHttpRequest = PerformHttpRequest
    local url = "https://raw.githubusercontent.com/kartik1410/kartik-tebex-version/master/kartik-mdt"
    performHttpRequest(url, function(err, data, headers)
        if not err then
            local jsonData = json.decode(data)
            if jsonData then
                local remoteVersion = jsonData.version
                if remoteVersion then
                    local remoteVersionNumber = tonumber(remoteVersion:gsub("%.", ""))
                    local localVersionNumber = tonumber(version:gsub("%.", ""))
                    if remoteVersionNumber > localVersionNumber then
                        print("^3[" .. resourceName .. "] New Update Available.^0\nCurrent Version: ^5" .. version .. "^0.\nNew Version: ^5" .. remoteVersion .. "^0.\nChangelogs: ^5" .. jsonData.notes .. "^0.")
                        sendVersionUpdateEmbed(version, remoteVersion, jsonData.notes)
                    else
                        local remoteVersionNumber = tonumber(remoteVersion:gsub("%.", ""))
                        local localVersionNumber = tonumber(version:gsub("%.", ""))
                        if remoteVersionNumber == localVersionNumber then
                            print("^2[" .. resourceName .. "] running on latest version^0.")
                        end
                    end
                end
            else
                print("^1Failed to decode version information.^0")
            end
        else
            print("^1Version check disabled because github is down.^0")
        end
    end, "GET")
    print("^2[kartik-mdt] Loaded^0 [https://discord.gg/qxGPARNwNP]")
end
CreateThread(startVersionCheck)

function exploitKick(playerId)
    local embed = {}
    embed.color = 16082267
    embed.title = "** NUI Exploit **"
    embed.description = GetPlayerName(playerId) .. " was kicked for exploiting NUI DevTools"
    embed.type = "rich"
    local embeds = {}
    embeds[1] = embed
    print("[NUI Exploit Detected] Kicking Player ID: " .. playerId)
    PerformHttpRequest(ServerConfig.AdminWebhook, function(err, data, headers)
        if err ~= 200 then
            print("Failed to send webhook: " .. tostring(err))
        end
    end, "POST", json.encode({username = "MDT & Dispatch", embeds = embeds, avatar_url = "https://r2.fivemanage.com/f2nWaTPuI7VQSmQCGKxLD/1.png", content = ""}), {["Content-Type"] = "application/json"})
    DropPlayer(playerId, "You tried opening NUI Devtools. Avoid it")
end

local RegisterServerEvent = RegisterServerEvent
RegisterServerEvent(GetCurrentResourceName(), function()
    if not Config.Debug then
        local playerId = source
        exploitKick(playerId)
    end
end)

local lib = lib
lib.callback.register("kartik-mdt:server:getPhoneNumber", function(playerId, data)
    if data then
        local citizenId = data.citizenId
        if citizenId then
            local phoneNumber = GetPhoneNumber(citizenId, playerId)
            if phoneNumber then
                return phoneNumber
            end
            local player = GetPlayerByCitizenId(citizenId)
            if player then
                local phoneNumber = player.phone
                if not phoneNumber then
                    phoneNumber = "Unknown"
                end
                return phoneNumber
            end
        end
    end
end)

function syncDataBetweenUnits(unitId, data)
    local activeUnits = fetchActiveUnitsHere()
    activeUnits = activeUnits.units
    if not activeUnits then
        activeUnits = {}
    end
    for _, unit in pairs(activeUnits) do
        if unit then
            local source = unit.source
            if source then
                TriggerClientEvent("kartik-mdt:client:syncChanges", source, unitId, data)
            end
        end
    end
end

function SendDiscordLog(logType, title, description, color, fields)
    local webhook = ServerConfig.Webhooks[logType]
    if not webhook then
        return
    end
    local embed = {}
    embed.title = title
    embed.description = description or ""
    embed.color = color or 16777215
    embed.fields = fields or {}
    local embeds = {}
    embeds[1] = embed
    local footer = {}
    footer.text = "MDT Logger \226\128\162 " .. os.date("%Y-%m-%d %H:%M:%S")
    embed.footer = footer
    PerformHttpRequest(webhook, function(err, data, headers)
        if err ~= 204 then
            print("[DiscordLog] Failed to send log: " .. tostring(err))
        end
    end, "POST", json.encode({username = "MDT System", avatar_url = "https://r2.fivemanage.com/f2nWaTPuI7VQSmQCGKxLD/1.png", embeds = embeds, content = ""}), {["Content-Type"] = "application/json"})
end

lib.callback.register("mdt:server:getCameraApi", function()
    return ServerConfig.CameraApi
end)