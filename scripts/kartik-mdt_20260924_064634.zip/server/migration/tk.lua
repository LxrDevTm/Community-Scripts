local migrateWeapons, migrateVehicles, getEvidence, migrateReports, migrateProfiles, migrateParamedics, migrateOfficers, migrateIncidents

function migrateWeapons()
    local mysqlQuery = MySQL.query.await
    local query = "SELECT * FROM tk_mdt_weapons"
    local results = mysqlQuery(query)
    local count = 0
    for _, row in ipairs(results) do
        local owners = row.owners
        if not owners then owners = "[]" end
        local ownersTable = json.decode(owners)
        for _, owner in ipairs(ownersTable) do
            local identifier = owner.identifier
            if not identifier then identifier = "unknown" end
            local serial = row.serial
            if not serial then serial = "unknown" end
            local name = row.name
            if not name then name = "unknown" end
            local date = row.date
            if not date then date = os.time() end
            local image = row.image
            if not image then image = nil end
            local insertQuery = [[
                INSERT INTO mdt_weapons (citizenId, serialNumber, weaponName, registrationDate, image)
                VALUES (?, ?, ?, FROM_UNIXTIME(?), ?)
            ]]
            local params = {identifier, serial, name, date, image}
            mysqlQuery(insertQuery, params)
            count = count + 1
        end
    end
    print(string.format("\226\156\133 Migrated %d weapon ownership entries to mdt_weapons.", count))
end

function migrateVehicles()
    local mysqlQuery = MySQL.query.await
    local query = "SELECT * FROM tk_mdt_vehicles"
    local results = mysqlQuery(query)
    local count = 0
    for _, row in ipairs(results) do
        local plate = row.plate
        local image = row.image
        local photos = row.photos
        local photo = image
        if not photo or photo == "" then
            if photos and photos ~= "" then
                local photosTable = json.decode(photos)
                if type(photosTable) == "table" and #photosTable > 0 then
                    photo = photosTable[1]
                end
            end
        end
        local insertQuery = [[
            INSERT INTO mdt_vehicles (plate, status, sightings, photo)
            VALUES (?, 'clear', NULL, ?)
        ]]
        local params = {plate, photo}
        mysqlQuery(insertQuery, params)
        count = count + 1
    end
    print(string.format("\226\156\133 Migrated %d vehicles to mdt_vehicles.", count))
end

function getEvidence(id)
    local mysqlQuery = MySQL.query.await
    local query = "SELECT * FROM tk_mdt_evidence WHERE id = ?"
    local params = {id}
    local result = mysqlQuery(query, params)
    return result[1]
end

function migrateReports()
    local mysqlQuery = MySQL.query.await
    local query = "SELECT * FROM tk_mdt_reports"
    local results = mysqlQuery(query)
    local count = 0
    for _, row in ipairs(results) do
        local date = os.date("%Y-%m-%d %H:%M:%S", row.date)
        local evidence = row.evidence
        if not evidence then evidence = "[]" end
        local evidenceTable = json.decode(evidence)
        local evidenceList = {}
        for _, evidenceId in ipairs(evidenceTable) do
            local evidenceRow = getEvidence(evidenceId)
            if evidenceRow then
                local evidenceType = "text"
                if evidenceRow.image and evidenceRow.image ~= "" then
                    evidenceType = "image"
                end
                table.insert(evidenceList, {
                    id = tostring(evidenceRow.id),
                    type = evidenceType,
                    description = evidenceRow.notes or "Imported evidence",
                    url = evidenceRow.image or "",
                })
            end
        end
        local photos = row.photos
        if photos then
            local photosTable = json.decode(photos)
            for i, photo in ipairs(photosTable) do
                if photo and photo ~= "" then
                    table.insert(evidenceList, {
                        id = "photo_" .. i,
                        type = "image",
                        description = "Imported photo",
                        url = photo,
                    })
                end
            end
        end
        local peopleInvolved = {}
        local function addPeople(category, people)
            if people then
                for _, person in ipairs(json.decode(people)) do
                    table.insert(peopleInvolved, {
                        name = person.name,
                        citizenId = person.identifier,
                        category = category,
                        charges = {},
                    })
                end
            end
        end
        addPeople("Officer", row.officers)
        addPeople("Criminal", row.suspects)
        addPeople("Civilian", row.civilians)
        local vehiclesInvolved = {}
        if row.vehicles then
            for _, vehicle in ipairs(json.decode(row.vehicles)) do
                table.insert(vehiclesInvolved, {
                    plate = vehicle.plate,
                    model = vehicle.name,
                })
            end
        end
        local insertQuery = [[
            INSERT INTO mdt_police_reports 
            (name, officerId, category, location, evidence_locker, description, dateTime, evidences, peopleInvolved, vehiclesInvolved)
            VALUES (?, ?, ?, '', NULL, ?, ?, ?, ?, ?)
        ]]
        local params = {
            row.title,
            row.creator,
            "General",
            row.content or "",
            date,
            json.encode(evidenceList),
            json.encode(peopleInvolved),
            json.encode(vehiclesInvolved),
        }
        mysqlQuery(insertQuery, params)
        count = count + 1
    end
    print(string.format("\226\156\133 Migrated %d police reports to mdt_police_reports.", count))
end

function migrateProfiles()
    local mysqlQuery = MySQL.query.await
    local query = "SELECT * FROM tk_mdt_profiles"
    local results = mysqlQuery(query)
    local count = 0
    for _, row in ipairs(results) do
        local image = row.image
        if not image or image == "" then
            local photos = row.photos
            if photos then
                local photosTable = json.decode(photos)
                if type(photosTable) == "table" and #photosTable > 0 then
                    image = photosTable[1]
                end
            end
        end
        if image and image ~= "" then
            local updateQuery = "UPDATE players SET photo = ? WHERE citizenid = ?"
            local params = {image, row.identifier}
            mysqlQuery(updateQuery, params)
        end
        local insertQuery = [[
            INSERT INTO mdt_profiles (citizenid, warrant, isDangerous, fingerprint, dna, notes)
            VALUES (?, 0, 0, NULL, NULL, ?)
        ]]
        local params = {row.identifier, row.notes or ""}
        mysqlQuery(insertQuery, params)
        count = count + 1
    end
    print(string.format("\226\156\133 Migrated %d profiles: photo to `players`, profile to `mdt_profiles`.", count))
end

function migrateParamedics()
    local mysqlQuery = MySQL.query.await
    local query = "SELECT * FROM tk_mdt_paramedics"
    local results = mysqlQuery(query)
    local count = 0
    for _, row in ipairs(results) do
        local insertQuery = [[
            INSERT INTO mdt_units (id, callsign, citizenid, department, status, dutyStatus)
            VALUES (?, ?, ?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE
                callsign = VALUES(callsign),
                department = VALUES(department),
                status = VALUES(status),
                dutyStatus = VALUES(dutyStatus)
        ]]
        local params = {
            row.identifier,
            row.callsign,
            row.identifier,
            "ems",
            "off-duty",
            "avl",
        }
        mysqlQuery(insertQuery, params)
        count = count + 1
    end
    print(string.format("\226\156\133 Migrated %d EMS units to mdt_units.", count))
end

function migrateOfficers()
    local mysqlQuery = MySQL.query.await
    local query = "SELECT * FROM tk_mdt_officers"
    local results = mysqlQuery(query)
    local count = 0
    for _, row in ipairs(results) do
        local insertQuery = [[
            INSERT INTO mdt_units (id, callsign, citizenid, department, status, dutyStatus)
            VALUES (?, ?, ?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE
                callsign = callsign,
                department = VALUES(department),
                status = VALUES(status),
                dutyStatus = VALUES(dutyStatus)
        ]]
        local params = {
            row.identifier,
            row.callsign,
            row.identifier,
            "police",
            "off-duty",
            "avl",
        }
        mysqlQuery(insertQuery, params)
        count = count + 1
    end
    print(string.format("\226\156\133 Migrated %d Law Enforcement Officers to mdt_units.", count))
end

function migrateIncidents()
    local mysqlQuery = MySQL.query.await
    local query = "SELECT * FROM tk_mdt_incidents"
    local results = mysqlQuery(query)
    local count = 0
    for _, row in ipairs(results) do
        local date = os.date("%Y-%m-%d %H:%M:%S", row.date)
        local evidence = row.evidence
        if not evidence then evidence = "[]" end
        local evidenceTable = json.decode(evidence)
        local evidenceList = {}
        for _, evidenceId in ipairs(evidenceTable) do
            local evidenceRow = getEvidence(evidenceId)
            if evidenceRow then
                local evidenceType = "text"
                if evidenceRow.image and evidenceRow.image ~= "" then
                    evidenceType = "image"
                end
                table.insert(evidenceList, {
                    id = tostring(evidenceRow.id),
                    type = evidenceType,
                    description = evidenceRow.notes or "Imported evidence",
                    url = evidenceRow.image or "",
                })
            end
        end
        local photos = row.photos
        if photos then
            local photosTable = json.decode(photos)
            for i, photo in ipairs(photosTable) do
                if photo and photo ~= "" then
                    table.insert(evidenceList, {
                        id = "photo_" .. i,
                        type = "image",
                        description = "Imported photo",
                        url = photo,
                    })
                end
            end
        end
        -- ... (rest of the function remains the same)

local policeIncidents = {}
local function processIncident(category, data)
    local json = json.decode(data or "[]")
    for _, item in ipairs(json) do
        local person = {
            name = item.name,
            citizenId = item.identifier,
            category = category,
            charges = {}
        }
        table.insert(policeIncidents, person)
    end
end

local vehicles = {}
local function processVehicles(data)
    local json = json.decode(data or "[]")
    for _, item in ipairs(json) do
        local vehicle = {
            plate = item.plate or "",
            model = item.model or item.name or "Unknown"
        }
        table.insert(vehicles, vehicle)
    end
end

local function migratePoliceIncidents()
    local mysql = MySQL.query.await
    local query = "SELECT * FROM tk_mdt_police_reports"
    local results = mysql(query)
    local count = 0
    for _, result in ipairs(results) do
        local date = os.date("%Y-%m-%d %H:%M:%S", result.date)
        local title = result.title or ""
        local content = result.content or ""
        local officerId = result.officerId
        local evidences = json.encode({})
        local peopleInvolved = json.encode(policeIncidents)
        local vehiclesInvolved = json.encode(vehicles)
        local timeline = json.encode({})
        local evidenceLocker = json.encode({})

        query = [[
            INSERT INTO mdt_police_incidents
            (title, location, officerId, description, dateTime, status, priority, evidences, peopleInvolved, vehiclesInvolved, timeline, evidence_locker)
            VALUES (?, '', NULL, ?, ?, '', '', ?, ?, ?, '[]', NULL)
        ]]
        local params = {title, content, date, evidences, peopleInvolved, vehiclesInvolved, timeline, evidenceLocker}
        mysql(query, params)
        count = count + 1

        processIncident("Officer", result.officers)
        processIncident("Criminal", result.criminals)
        processIncident("Civilian", result.civilians)
        processVehicles(result.vehicles)
    end
    print(string.format("\226\156\133 Migrated %d police incidents to mdt_police_incidents.", count))
end

local function migrateEmsReports()
    local mysql = MySQL.query.await
    local query = "SELECT * FROM tk_mdt_ems_reports"
    local results = mysql(query)
    local count = 0
    for _, result in ipairs(results) do
        local date = os.date("%Y-%m-%d %H:%M:%S", result.date)
        local title = result.title or ""
        local content = result.content or ""
        local medicId = result.creator
        local evidences = json.encode({})
        local peopleInvolved = json.encode({})
        local vehiclesInvolved = json.encode({})
        local category = "General"

        query = [[
            INSERT INTO mdt_ems_reports
            (name, medicId, location, description, dateTime, evidences, peopleInvolved, vehiclesInvolved, category)
            VALUES (?, ?, '', ?, ?, ?, ?, ?, ?)
        ]]
        local params = {title, medicId, content, date, evidences, peopleInvolved, vehiclesInvolved, category}
        mysql(query, params)
        count = count + 1

        local function processEmsIncident(category, data)
            local json = json.decode(data or "[]")
            for _, item in ipairs(json) do
                local person = {
                    name = item.name,
                    citizenId = item.identifier,
                    category = category,
                    charges = {}
                }
                table.insert(peopleInvolved, person)
            end
        end

        processEmsIncident("Medic", result.paramedics)
        processEmsIncident("Civilian", result.patients)
    end
    print(string.format("\226\156\133 Migrated %d EMS reports to mdt_ems_reports.", count))
end

local function migrateEmsAnnouncements()
    local mysql = MySQL.query.await
    local query = "SELECT * FROM tk_mdt_ems_announcements"
    local results = mysql(query)
    local count = 0
    for _, result in ipairs(results) do
        local date = os.date("%Y-%m-%d %H:%M:%S", result.date)
        local title = result.message:match("^(.-)<br>") or "EMS Announcement"
        local description = result.message:gsub("^(.-)<br>", "")

        query = [[
            INSERT INTO mdt_ems_bulletin (announcementId, title, description, dateTime)
            VALUES (?, ?, ?, ?)
        ]]
        local params = {tostring(result.id), title, description, date}
        mysql(query, params)
        count = count + 1
    end
    print(string.format("\226\156\133 Migrated %d EMS announcements to mdt_ems_bulletin.", count))
end

local function migrateAnnouncements()
    local mysql = MySQL.query.await
    local query = "SELECT * FROM tk_mdt_announcements"
    local results = mysql(query)
    local count = 0
    for _, result in ipairs(results) do
        local date = os.date("%Y-%m-%d %H:%M:%S", result.date)
        local title = result.message:match("^(.-)<br>") or "Announcement"
        local description = result.message:gsub("^(.-)<br>", "")

        query = [[
            INSERT INTO mdt_police_bulletin (announcementId, title, description, dateTime)
            VALUES (?, ?, ?, ?)
        ]]
        local params = {tostring(result.id), title, description, date}
        mysql(query, params)
        count = count + 1
    end
    print(string.format("\226\156\133 Migrated %d announcements to mdt_police_bulletin.", count))
end

local function migrateCharges()
    local mysql = MySQL.query.await
    local query = "SELECT * FROM tk_mdt_charges"
    local results = mysql(query)
    local count = 0
    for _, result in ipairs(results) do
        local fine = json.decode(result.fine or "{}")
        local sentence = json.decode(result.sentence or "{}")
        local fineDefault = tonumber(fine.default or 0)
        local sentenceDefault = tonumber(sentence.default or 0)

        query = [[
            INSERT INTO mdt_criminal_codes (id, title, description, category, fine, sentence)
            VALUES (?, ?, ?, ?, ?, ?)
        ]]
        local params = {
            tostring(result.id),
            result.name,
            result.description or "",
            result.class or "Uncategorized",
            fineDefault,
            sentenceDefault
        }
        mysql(query, params)
        count = count + 1
    end
    print(string.format("\226\156\133 Migrated %d charges to mdt_criminal_codes.", count))
end

local function migrateData()
    print("Starting migration...")
    pcall(migrateEmsAnnouncements)
    pcall(migrateAnnouncements)
    pcall(migrateCharges)
    pcall(migrateEmsReports)
    pcall(migratePoliceIncidents)
    print("Migration complete.")
end

RegisterCommand("migrate_tk", migrateData, true)