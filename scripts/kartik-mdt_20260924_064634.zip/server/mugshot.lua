local webhookUrl = ""
local webhookUrl2 = ""
local registerFunction = lib.callback.register
local getMugshotWebhookEvent = "kartik-mdt:server:GetMugshotWebhook"

function getWebhookUrl()
  local ServerConfig = ServerConfig
  local webhookUrl = ServerConfig.Webhook
  return webhookUrl
end

registerFunction(getMugshotWebhookEvent, getWebhookUrl)

local takeMugshotEvent = "kartik-mdt:server:takemugshot"

function takeMugshot(playerId, mugshotData)
  local player1Id = tonumber(playerId)
  local player1Data = GetPlayerData(player1Id)
  local player2Data = GetPlayerData(source)
  if player1Data and player2Data then
    if player1Id ~= source then
      local player1Ped = GetPlayerPed(player1Id)
      local player1Coords = GetEntityCoords(player1Ped)
      local player2Ped = GetPlayerPed(source)
      local player2Coords = GetEntityCoords(player2Ped)
      local distance = player1Coords - player2Coords
      local distanceLength = #distance
      local maxDistance = Config.Mugshot.maxDistance
      if distanceLength <= maxDistance then
        TriggerClientEvent("kartik-mdt:client:takemugshot", player1Id, source, mugshotData)
      else
        TriggerClientEvent("ox_lib:notify", source, { description = "The Player is too far away to take a mugshot.", type = "error" })
      end
    else
      TriggerClientEvent("ox_lib:notify", source, { description = "You can't take a mugshot of yourself.", type = "error" })
    end
  else
    TriggerClientEvent("ox_lib:notify", source, { description = "Invalid Player ID.", type = "error" })
  end
end

registerFunction(takeMugshotEvent, takeMugshot)

local mugLogEvent = "kartik-mdt:server:MugLog"

function logMugshot(playerId, mugshotData)
  local player1Data = GetPlayerData(source)
  local player2Data = GetPlayerData(playerId)
  local playerName = player1Data.name
  local playerCitizenId = player1Data.citizenId
  local suspectName = player2Data.name
  local embed = {}
  embed.title = Config.LogTitle
  embed.color = 16761035
  local footer = {}
  footer.text = os.date("!%a %b %d, %H:%M", os.time() + 21600)
  embed.footer = footer
  local fields = {}
  local field1 = {}
  field1.name = "Suspect:"
  field1.value = suspectName
  field1.inline = false
  local field2 = {}
  field2.name = "Citizen ID:"
  field2.value = playerCitizenId
  field2.inline = false
  local field3 = {}
  field3.name = "Officer:"
  field3.value = playerName
  field3.inline = false
  fields[1] = field1
  fields[2] = field2
  fields[3] = field3
  embed.fields = fields
  local author = {}
  author.name = "MDT & Dispatch"
  author.icon_url = "https://r2.fivemanage.com/f2nWaTPuI7VQSmQCGKxLD/1.png"
  embed.author = author
  local image = {}
  image.url = mugshotData[1] or ""
  embed.image = image
  local embeds = {}
  embeds[1] = embed
  for i = 2, #mugshotData do
    local embed2 = {}
    embed2.title = "Mugshot Angle " .. i
    embed2.color = 16761035
    local image2 = {}
    image2.url = mugshotData[i]
    embed2.image = image2
    table.insert(embeds, embed2)
  end
  if ServerConfig.Webhooks.mugshot then
    local jsonData = json.encode({ username = Config.LogName, embeds = embeds })
    PerformHttpRequest(ServerConfig.Webhooks.mugshot, function() end, "POST", jsonData, { ["Content-Type"] = "application/json" })
  end
end

registerFunction(mugLogEvent, logMugshot)