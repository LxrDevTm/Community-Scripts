local resourceName, mysqlReady
resourceName = GetCurrentResourceName()
resourceName = resourceName()
if "kartik-mdt" ~= resourceName then
  return
end
mysqlReady = MySQL
mysqlReady = mysqlReady.ready

function createTables()
  local queryResult, collation, maxLength
  local query = [[
        SELECT CHARACTER_MAXIMUM_LENGTH AS maxLen, COLLATION_NAME AS collation
        FROM information_schema.columns
        WHERE table_schema = DATABASE() AND table_name = 'player_vehicles' AND column_name = 'plate'
    ]]
  local success, result = pcall(mysqlReady.query.await, mysqlReady, query)
  if success then
    local row = result[1]
    if row then
      collation = row.collation
      maxLength = row.maxLen
    end
  else
    collation = "utf8mb4_unicode_ci"
    maxLength = 50
  end

  local queries = {
    [[
        CREATE TABLE IF NOT EXISTS `mdt_criminal_codes` (
            `id` varchar(50) NOT NULL,
            `title` longtext NOT NULL,
            `description` longtext NOT NULL,
            `category` longtext NOT NULL,
            `fine` int(11) NOT NULL DEFAULT 0,
            `sentence` int(11) NOT NULL DEFAULT 0,
            `additonalPenalties` longtext DEFAULT NULL,
            `changeHistory` longtext DEFAULT NULL,
            PRIMARY KEY (`id`)
        )ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    ]],
    [[
        CREATE TABLE IF NOT EXISTS `mdt_ems_bulletin` (
            `announcementId` varchar(50) NOT NULL,
            `title` longtext NOT NULL,
            `description` longtext NOT NULL,
            `dateTime` varchar(50) NOT NULL,
            PRIMARY KEY (`announcementId`) USING BTREE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    ]],
    [[
        CREATE TABLE IF NOT EXISTS `mdt_ems_reports` (
            `reportId` int(11) NOT NULL AUTO_INCREMENT,
            `name` longtext NOT NULL,
            `medicId` varchar(50) NOT NULL DEFAULT '',
            `category` varchar(100) NOT NULL DEFAULT '',
            `location` varchar(255) DEFAULT '',
            `description` longtext NOT NULL,
            `dateTime` varchar(50) NOT NULL DEFAULT '',
            `evidences` longtext DEFAULT NULL,
            `peopleInvolved` longtext DEFAULT NULL,
            `vehiclesInvolved` longtext DEFAULT NULL,
            PRIMARY KEY (`reportId`) USING BTREE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    ]],
    [[
        CREATE TABLE IF NOT EXISTS `mdt_ems_incidents` (
            `incidentId` int(11) NOT NULL AUTO_INCREMENT,
            `title` longtext NOT NULL,
            `location` varchar(255) DEFAULT '',
            `description` longtext NOT NULL,
            `dateTime` varchar(50) NOT NULL DEFAULT '',
            `status` varchar(50) NOT NULL DEFAULT '',
            `priority` varchar(50) NOT NULL DEFAULT '',
            `evidences` longtext DEFAULT '[]',
            `peopleInvolved` longtext DEFAULT '[]',
            `vehiclesInvolved` longtext DEFAULT '[]',
            `timeline` longtext DEFAULT '[]',
            PRIMARY KEY (`incidentId`) USING BTREE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
    ]],
    [[
        CREATE TABLE IF NOT EXISTS `mdt_police_bulletin` (
            `announcementId` varchar(50) NOT NULL,
            `title` longtext NOT NULL,
            `description` longtext NOT NULL,
            `dateTime` varchar(50) NOT NULL,
            PRIMARY KEY (`announcementId`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    ]],
    [[
        CREATE TABLE IF NOT EXISTS `mdt_vehicles_strikes` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `plate` varchar(50) NOT NULL,
            `reason` longtext DEFAULT NULL,
            `points` int(11) NOT NULL DEFAULT 0,
            `issuingOfficer` longtext DEFAULT NULL,
            `location` longtext DEFAULT NULL,
            `status` longtext NOT NULL,
            `date` datetime DEFAULT current_timestamp(),
            `expiryDate` longtext NOT NULL,
            `dismissalReason` longtext DEFAULT NULL,
            `dismissalDate` longtext DEFAULT NULL,
            `dismissedBy` longtext DEFAULT NULL,
            PRIMARY KEY (`id`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        ]],
    [[
        CREATE TABLE IF NOT EXISTS `mdt_police_reports` (
            `reportId` int(11) NOT NULL AUTO_INCREMENT,
            `name` longtext NOT NULL,
            `category` varchar(100) NOT NULL DEFAULT '',
            `officerId` varchar(50) NOT NULL DEFAULT '',
            `location` varchar(255) DEFAULT '',
            `description` longtext NOT NULL,
            `dateTime` varchar(50) NOT NULL DEFAULT '',
            `evidences` longtext DEFAULT NULL,
            `peopleInvolved` longtext DEFAULT NULL,
            `vehiclesInvolved` longtext DEFAULT NULL,
            PRIMARY KEY (`reportId`) USING BTREE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    ]],
    [[
        CREATE TABLE IF NOT EXISTS `mdt_police_incidents` (
            `incidentId` int(11) NOT NULL AUTO_INCREMENT,
            `title` longtext NOT NULL,
            `location` varchar(255) DEFAULT '',
            `description` longtext NOT NULL,
            `dateTime` varchar(50) NOT NULL DEFAULT '',
            `status` varchar(50) NOT NULL DEFAULT '',
            `priority` varchar(50) NOT NULL DEFAULT '',
            `evidences` longtext DEFAULT '[]',
            `peopleInvolved` longtext DEFAULT '[]',
            `vehiclesInvolved` longtext DEFAULT '[]',
            `timeline` longtext DEFAULT '[]',
            PRIMARY KEY (`incidentId`) USING BTREE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
    ]],
    [[
        CREATE TABLE IF NOT EXISTS `mdt_profiles` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `citizenid` varchar(100) NOT NULL,
            `warrant` int(11) NOT NULL DEFAULT 0,
            `isDangerous` int(11) NOT NULL DEFAULT 0,
            `notes` longtext DEFAULT NULL,
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    ]],
    [[
        CREATE TABLE IF NOT EXISTS `mdt_fake_profiles` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `citizenid` varchar(100) NOT NULL,
            `firstname` varchar(50) NOT NULL,
            `lastname` varchar(50) NOT NULL,
            `gender` varchar(10) NOT NULL,
            `nationality` varchar(50) NOT NULL,
            `birthdate` varchar(50) NOT NULL,
            `photo` longtext DEFAULT NULL,
            `bankAccount` varchar(50) DEFAULT NULL,
            `phoneNumber` varchar(50) DEFAULT NULL,
            `job` varchar(50) DEFAULT NULL,
            PRIMARY KEY (`id`),
            UNIQUE KEY `citizenid` (`citizenid`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    ]],
    [[
        ALTER TABLE `mdt_profiles`
        ADD COLUMN `fingerprint` longtext DEFAULT NULL,
        ADD COLUMN `dna` longtext DEFAULT NULL;
    ]],
    [[
        CREATE TABLE IF NOT EXISTS `mdt_units` (
            `id` varchar(50) NOT NULL DEFAULT 'AUTO_INCREMENT',
            `callsign` varchar(50) DEFAULT NULL,
            `citizenid` varchar(100) DEFAULT NULL,
            `department` varchar(50) DEFAULT 'police',
            `currentAssignments` longtext DEFAULT '[]',
            `totalHours` decimal(20,6) DEFAULT 0.000000,
            `dutyRecords` longtext DEFAULT '[]',
            `serviceHistory` longtext DEFAULT '[]',
            `status` enum('off-duty','on-duty') NOT NULL DEFAULT 'off-duty',
            `isFired` int(1) DEFAULT 0,
            PRIMARY KEY (`id`),
            UNIQUE KEY `citizenid` (`citizenid`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    ]],
    [[
            CREATE TABLE IF NOT EXISTS `mdt_ems_fto_reports` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `trainee_name` varchar(255) NOT NULL DEFAULT '0',
                `fto_name` varchar(255) NOT NULL DEFAULT '0',
                `date` varchar(255) NOT NULL DEFAULT '0',
                `shift` varchar(50) NOT NULL DEFAULT '0',
                `phase` int(11) DEFAULT 1,
                `categories` longtext NOT NULL,
                `overall_performance` int(11) NOT NULL DEFAULT 0,
                `strengths` longtext NOT NULL,
                `areas_for_improvement` longtext NOT NULL,
                `additional_comments` longtext NOT NULL,
                `status` longtext NOT NULL,
                `rejection_reason` longtext DEFAULT NULL,
                PRIMARY KEY (`id`) USING BTREE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        ]],
    [[
            CREATE TABLE IF NOT EXISTS `mdt_police_fto_reports` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `trainee_name` varchar(255) NOT NULL DEFAULT '0',
                `fto_name` varchar(255) NOT NULL DEFAULT '0',
                `date` varchar(255) NOT NULL DEFAULT '0',
                `shift` varchar(50) NOT NULL DEFAULT '0',
                `phase` int(11) DEFAULT 1,
                `categories` longtext NOT NULL,
                `overall_performance` int(11) NOT NULL DEFAULT 0,
                `strengths` longtext NOT NULL,
                `areas_for_improvement` longtext NOT NULL,
                `additional_comments` longtext NOT NULL,
                `status` longtext NOT NULL,
                `rejection_reason` longtext DEFAULT NULL,
                PRIMARY KEY (`id`) USING BTREE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        ]],
    [[
        CREATE TABLE IF NOT EXISTS `mdt_vehicles` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `plate` varchar(50) NOT NULL,
            `status` varchar(50) DEFAULT 'clear',
            `sightings` longtext DEFAULT NULL,
            `photo` longtext DEFAULT NULL,
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    ]],
    [[
        CREATE TABLE IF NOT EXISTS `mdt_bodycams` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `citizenid` varchar(100) DEFAULT NULL,
              `videoURL` longtext NOT NULL DEFAULT '',
            `datetime` datetime NOT NULL DEFAULT current_timestamp(),
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    ]],
    [[
        CREATE TABLE IF NOT EXISTS `mdt_cameras` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `cameraId` int(11) NOT NULL,
            `videoURL` longtext NOT NULL DEFAULT '',
            `datetime` datetime NOT NULL DEFAULT current_timestamp(),
            PRIMARY KEY (`id`)
        )  ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    ]],
    [[
        CREATE TABLE IF NOT EXISTS `mdt_warrants` (
            `id` varchar(50) NOT NULL,
            `suspectId` varchar(100) NOT NULL,
            `issueDate` varchar(50) NOT NULL,
            `expiryDate` varchar(50) NOT NULL,
            `charges` longtext NOT NULL,
            `issuingAuthority` varchar(50) NOT NULL DEFAULT '',
            `status` varchar(50) NOT NULL DEFAULT '',
            `caseNotes` longtext NOT NULL,
            `sightings` longtext DEFAULT NULL,
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    ]],
    [[
        CREATE TABLE IF NOT EXISTS `mdt_weapons` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `citizenId` varchar(100) NOT NULL DEFAULT '0',
            `serialNumber` varchar(250) NOT NULL DEFAULT '0',
            `weaponName` varchar(100) NOT NULL DEFAULT '0',
            `registrationDate` timestamp NOT NULL DEFAULT current_timestamp(),
            `image` longtext DEFAULT NULL,
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    ]],
    [[
        CREATE TABLE IF NOT EXISTS `mdt_licenses` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `citizenid` varchar(100) DEFAULT NULL,
            `name` varchar(255) NOT NULL DEFAULT '0',
            `type` varchar(50) NOT NULL DEFAULT '',
            `status` enum('approved','rejected','expired') NOT NULL DEFAULT 'approved',
            `approvedBy` varchar(255) NOT NULL DEFAULT '',
            `approvalDate` timestamp NOT NULL DEFAULT current_timestamp(),
            `expirationDate` varchar(50) NOT NULL DEFAULT '',
            `note` varchar(50) DEFAULT NULL,
            PRIMARY KEY (`id`)
        )  ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    ]],
  }

  for _, query in pairs(queries) do
    local success, result = pcall(mysqlReady.query.await, mysqlReady, query)
    if not success then
      print("Failed to create table: " .. result)
    end
  end

  local core = detectCore("qb-core")
  if not core then
    core = detectCore("qbx_core")
    if not core then
      print("Failed to detect core")
      return
    end
  end

  local success, result = pcall(mysqlReady.query.await, mysqlReady, [[
            ALTER TABLE `players` 
            ADD COLUMN `photo` longtext DEFAULT NULL
        ]])
  if not success then
    print("Failed to add photo column to players table: " .. result)
  end

  local success, result = pcall(mysqlReady.query.await, mysqlReady, [[
        SELECT COLUMN_NAME, COLLATION_NAME FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = "players" AND column_name = "citizenid"
    ]])
  if success and result[1] then
    local row = result[1]
    print("Citizenid column collation fetched successfully: " .. row.collation)
  else
    print("Failed to fetch citizenid column collation or table does not exist.")
  end

  local success, result = pcall(mysqlReady.query.await, mysqlReady, [[
        SELECT COLUMN_NAME, COLLATION_NAME FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = "player_vehicles" AND column_name = "plate"
    ]])
  if success and result[1] then
    local row = result[1]
    print("Plate column collation fetched successfully: " .. row.collation)
  else
    print("Failed to fetch plate column collation or table does not exist.")
  end

  if not core then
    core = detectCore("es_extended")
    if core then
      local success, result = pcall(mysqlReady.query.await, mysqlReady, [[
            ALTER TABLE `users` 
            ADD COLUMN `photo` longtext DEFAULT NULL
        ]])
      if not success then
        print("Failed to add photo column to users table: " .. result)
      end

      local success, result = pcall(mysqlReady.query.await, mysqlReady, [[
            SELECT COLUMN_NAME, COLLATION_NAME FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = "users" AND column_name = "identifier"
        ]])
      if success and result[1] then
        local row = result[1]
        print("Citizenid column collation fetched successfully: " .. row.collation)
      else
        print("Failed to fetch citizenid column collation or table does not exist.")
      end

      local success, result = pcall(mysqlReady.query.await, mysqlReady, [[
            SELECT COLUMN_NAME, COLLATION_NAME FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = "owned_vehicles" AND column_name = "plate"
        ]])
      if success and result[1] then
        local row = result[1]
        print("Plate column collation fetched successfully: " .. row.collation)
      else
        print("Failed to fetch plate column collation or table does not exist.")
      end
    end
  end
end

createTables()

else
    print("Failed to fetch plate column collation or table does not exist.")
end
else
    local detectCoreResult = detectCore("ox_core")
    if detectCoreResult then
        local query = MySQL.query.await
        local result, err = pcall(query, [[
            ALTER TABLE `characters` 
            ADD COLUMN `photo` longtext DEFAULT NULL
        ]])
        if not result then
        end
    end
end

::label::
local query = MySQL.query.await
local result, err = pcall(query, [[
    ALTER TABLE mdt_weapons CHANGE citizenid citizenId VARCHAR(50);
]])
if not result then
end
result, err = pcall(query, [[
    ALTER TABLE `mdt_police_reports` 
    ADD COLUMN `evidence_locker` longtext DEFAULT NULL
]])
if not result then
end
result, err = pcall(query, [[
    ALTER TABLE `mdt_police_reports` 
    ADD COLUMN `members` LONGTEXT DEFAULT NULL,
    ADD COLUMN `lock_reason` LONGTEXT DEFAULT NULL,
    ADD COLUMN `isLocked` TINYINT(1) DEFAULT 0
]])
if not result then
end
result, err = pcall(query, [[
    ALTER TABLE `mdt_police_incidents` 
    ADD COLUMN `evidence_locker` longtext DEFAULT NULL
]])
if not result then
end
result, err = pcall(query, [[
    ALTER TABLE `mdt_police_incidents` 
    ADD COLUMN `officerId` longtext DEFAULT NULL
]])
if not result then
end
result, err = pcall(query, [[
    ALTER TABLE `mdt_police_incidents` 
    ADD COLUMN `members` LONGTEXT DEFAULT NULL,
    ADD COLUMN `lock_reason` LONGTEXT DEFAULT NULL,
    ADD COLUMN `isLocked` TINYINT(1) DEFAULT 0
]])
if not result then
end
result, err = pcall(query, [[
    ALTER TABLE `mdt_ems_incidents` 
    ADD COLUMN `medicId` longtext DEFAULT NULL
]])
if not result then
end
result, err = pcall(query, [[
    ALTER TABLE `mdt_ems_incidents` 
    ADD COLUMN `bodyData` longtext DEFAULT NULL
]])
if not result then
end
result, err = pcall(query, [[
    ALTER TABLE `mdt_ems_incidents` 
    ADD COLUMN `members` LONGTEXT DEFAULT NULL,
    ADD COLUMN `lock_reason` LONGTEXT DEFAULT NULL,
    ADD COLUMN `isLocked` TINYINT(1) DEFAULT 0
]])
if not result then
end
result, err = pcall(query, [[
    ALTER TABLE `mdt_ems_reports` 
    ADD COLUMN `bodyData` longtext DEFAULT NULL
]])
if not result then
end
result, err = pcall(query, [[
    ALTER TABLE `mdt_ems_reports` 
    ADD COLUMN `members` LONGTEXT DEFAULT NULL,
    ADD COLUMN `lock_reason` LONGTEXT DEFAULT NULL,
    ADD COLUMN `isLocked` TINYINT(1) DEFAULT 0
]])
if not result then
end
result, err = pcall(query, [[
    ALTER TABLE `mdt_units`
    ADD COLUMN `bodycam` ENUM('off', 'on') NOT NULL DEFAULT 'off',
    ADD COLUMN `tags` LONGTEXT DEFAULT NULL;
]])
if not result then
end
result, err = pcall(query, [[
    ALTER TABLE `mdt_units`
    ADD COLUMN `dutyStatus` ENUM('clr','avl','enr','busy') NOT NULL DEFAULT 'avl';
]])
if not result then
end
result, err = pcall(query, [[
    ALTER TABLE `mdt_units` DROP INDEX `callsign`;
]])
if not result then
end
result, err = pcall(query, [[
    CREATE TABLE IF NOT EXISTS `mdt_court_cases` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `title` varchar(255) NOT NULL,
        `date` varchar(50) NOT NULL,
        `status` varchar(50) NOT NULL,
        `defendant` varchar(255) NOT NULL,
        `judge` varchar(255) DEFAULT NULL,
        `defense` varchar(255) DEFAULT NULL,
        `prosecution` varchar(255) DEFAULT NULL,
        `courtroom` varchar(50) DEFAULT NULL,
        `relatedReports` longtext DEFAULT NULL,
        `verdict` longtext DEFAULT NULL,
        `sentence` longtext DEFAULT NULL,
        `postponedReason` longtext DEFAULT NULL,
        `newDate` varchar(50) DEFAULT NULL,
        PRIMARY KEY (`id`)
    )  ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
]])
if not result then
    print("Failed to create `mdt_court_cases`:", err)
end
result, err = pcall(query, [[
    CREATE TABLE IF NOT EXISTS `mdt_court_case_notes` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `caseId` int(11) NOT NULL,
        `timestamp` varchar(50) NOT NULL,
        `author` varchar(255) NOT NULL,
        `content` longtext NOT NULL,
        PRIMARY KEY (`id`),
        KEY `caseId` (`caseId`)
    )  ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
]])
if not result then
    print("Failed to create `mdt_court_case_notes`:", err)
end
if true then
    local tables = {
        "mdt_criminal_codes",
        "mdt_ems_bulletin",
        "mdt_ems_reports",
        "mdt_ems_incidents",
        "mdt_police_bulletin",
        "mdt_police_reports",
        "mdt_police_incidents",
        "mdt_profiles",
        "mdt_units",
        "mdt_ems_fto_reports",
        "mdt_police_fto_reports",
        "mdt_bodycams",
        "mdt_cameras",
        "mdt_warrants",
        "mdt_weapons",
        "mdt_licenses",
        "mdt_court_cases",
        "mdt_court_case_notes",
        "mdt_fake_profiles"
    }
    for _, table_name in ipairs(tables) do
        local query_str = string.format("ALTER TABLE %s CONVERT TO CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;", table_name)
        result, err = pcall(query, query_str)
        if not result then
            print(string.format("Failed to convert character set and collation for table '%s':", table_name), err)
        end
    end
end
if true then
    local vehicle_tables = {
        "mdt_vehicles",
        "mdt_vehicles_strikes"
    }
    for _, table_name in ipairs(vehicle_tables) do
        local query_str = string.format("ALTER TABLE %s CONVERT TO CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;", table_name)
        result, err = pcall(query, query_str)
        if not result then
            print(string.format("Failed to convert character set and collation for table '%s':", table_name), err)
        end
    end
end
print("All tables have been created or checked successfully.")
print("[WARRANTS] Checking for expired warrants on script start...")
updateWarrantStatus()
result, err = pcall(query, [[
    UPDATE `mdt_units` SET `status` = 'off-duty'
]])
if not result then
    print("Failed to reset unit statuses to 'off-duty':", err)
end
result, err = pcall(query, [[
    UPDATE `mdt_units` SET `bodycam` = 'off'
]])
if not result then
    print("Failed to reset bodycam statuses to 'off':", err)
end
result, err = pcall(query, [[
    CREATE TABLE IF NOT EXISTS `mdt_channels` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `owner` varchar(100) NOT NULL,
        `name` varchar(255) DEFAULT NULL,
        `type` enum('dm','group') NOT NULL DEFAULT 'group',
        `members` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
        `createdAt` bigint(20) DEFAULT NULL,
        PRIMARY KEY (`id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
]])
if not result then
    print("Failed to create `mdt_channels`:", err)
end
result, err = pcall(query, [[
    CREATE TABLE IF NOT EXISTS `mdt_messages` (
        `id` INT(11) NOT NULL AUTO_INCREMENT,
        `channelId` INT(11) NOT NULL,
        `authorId` VARCHAR(100) NOT NULL,
        `authorName` VARCHAR(255) NOT NULL,
        `content` LONGTEXT NOT NULL,
        `edited` TINYINT(1) NOT NULL DEFAULT 0,
        `timestamp` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        KEY `channelId` (`channelId`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
]])
if not result then
    print("Failed to create `mdt_messages`:", err)
end