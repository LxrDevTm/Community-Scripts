lib.addCommand('911', {
    help = 'Send a message to 911',
    params = {{
        name = 'message',
        type = 'string',
        help = '911 Message'
    }}
}, function(source, args, raw)
    local message = raw:sub(5)
    local emergencyServices = {
        police = true
    }
    TriggerClientEvent('kartik-mdt:client:sendCall', source, message, false, emergencyServices, "911")
end)

lib.addCommand('911a', {
    help = 'Send an anonymous message to 911',
    params = {{
        name = 'message',
        type = 'string',
        help = '911 Message'
    }}
}, function(source, args, raw)
    local message = raw:sub(5)
    local emergencyServices = {
        police = true
    }
    TriggerClientEvent('kartik-mdt:client:sendCall', source, message, true, emergencyServices, "911")
end)

lib.addCommand('311', {
    help = 'Send a message to 311',
    params = {{
        name = 'message',
        type = 'string',
        help = '311 Message'
    }}
}, function(source, args, raw)
    local message = raw:sub(5)
    local emergencyServices = {
        ems = true
    }
    TriggerClientEvent('kartik-mdt:client:sendCall', source, message, false, emergencyServices, "311")
end)

lib.addCommand('311a', {
    help = 'Send an anonymous message to 311',
    params = {{
        name = 'message',
        type = 'string',
        help = '311 Message'
    }}
}, function(source, args, raw)
    local message = raw:sub(5)
    local emergencyServices = {
        ems = true
    }
    TriggerClientEvent('kartik-mdt:client:sendCall', source, message, true, emergencyServices, "311")
end)

lib.addCommand('311r', {
    help = 'Send a reply message to 311',
    params = {
        {
            name = 'id',
            type = 'number',
            help = 'Incident Id',
        },
        {
            name = 'message',
            type = 'string',
            help = '311 Message'
        },
    }
}, function(source, args, raw)
    local trimmedRaw = raw:sub(#'311r' + 2)
    local spacePos = trimmedRaw:find(' ')
    local replyMessage = trimmedRaw:sub(spacePos + 1)
    ReplyToIncident(source, args.id, replyMessage)
end)

lib.addCommand('911r', {
    help = 'Send a reply message to 911',
    params = {
        {
            name = 'id',
            type = 'number',
            help = 'Incident Id',
        },
        {
            name = 'message',
            type = 'string',
            help = '911 Message'
        },
    }
}, function(source, args, raw)
    local trimmedRaw = raw:sub(#'911r' + 2)
    local spacePos = trimmedRaw:find(' ')
    local replyMessage = trimmedRaw:sub(spacePos + 1)
    ReplyToIncident(source, args.id, replyMessage)
end)