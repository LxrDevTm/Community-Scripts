local hasPermission, deepCopy, getSanitizedPermissions

function hasPermission(userPermissions, requiredPermissions)
  local permissionType = type(requiredPermissions)
  if permissionType ~= "table" then
    return false
  end
  local rank = requiredPermissions.rank
  local tags = requiredPermissions.tags
  local requireType = requiredPermissions.require or "any"
  local hasRequiredRank = rank and rank ~= false and userPermissions >= rank
  local hasRequiredTag = hasPermission(userPermissions, tags)
  if requireType == "all" then
    return hasRequiredRank or hasRequiredTag
  else
    return hasRequiredRank and hasRequiredTag
  end
end

function deepCopy(object)
  local copiedObject = {}
  for key, value in pairs(object) do
    local valueType = type(value)
    if valueType == "table" then
      copiedObject[key] = deepCopy(value)
    else
      copiedObject[key] = value
    end
  end
  return copiedObject
end

function getSanitizedPermissions(permissionName, userRank, permissions)
  local config = Config.Permissions[permissionName]
  if not config then
    return {}
  end
  local pages = config.Pages
  if not pages then
    return {}
  end
  if not permissions then
    permissions = {}
  end
  local sanitizedPages = deepCopy(pages)
  for pageName, page in pairs(pages) do
    local viewPermission = page.view
    local editPermission = page.edit
    local hasViewPermission = false
    local hasEditPermission = false
    if viewPermission then
      hasViewPermission = hasPermission(viewPermission, userRank, permissions)
    end
    if editPermission then
      hasEditPermission = hasPermission(editPermission, userRank, permissions)
    end
    sanitizedPages[pageName] = { view = hasViewPermission, edit = hasEditPermission }
  end
  return { Pages = sanitizedPages }
end

GetSanitizedPermissions = getSanitizedPermissions