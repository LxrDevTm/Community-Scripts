local registerCallback, fetchRealCitizens, fetchLicenses, fetchCitizenVehiclesFromTable, fetchCitizenProperties, fetchHealthInsurance, fetchHomeInsurance, fetchVehicleInsurance, fetchVehicleRegistration, fetchCitizenCitations

local lib = lib
local callback = lib.callback
local register = callback.register
local fetchCitizensEvent = "kartik-mdt:server:fetchCitizens"

local function fetchCitizens(query, page)
    if not query then
        return
    end
    local queryLower = query.query:lower()
    if queryLower then
        goto skipQueryCheck
    end
    queryLower = ""
    ::skipQueryCheck::
    local maxPage = math.max(1, page and page or 1)
    local offset = (maxPage - 1) * 10
    local limit = 10
    local citizens = {}
    local totalCount = 0
    local result, count = fetchRealCitizens(queryLower, offset, limit)
    totalCount = count
    citizens = result or citizens
    if not result then
        citizens = {}
    end
    if limit > count then
        local diff = limit - count
        local whereClause = ""
        local params = {}
        if queryLower ~= "" then
            whereClause = [[
                WHERE 
                    LOWER(firstname) LIKE ? OR
                    LOWER(lastname) LIKE ? OR
                    LOWER(citizenid) LIKE ?
            ]]
            for i = 1, 3 do
                table.insert(params, "%" .. queryLower .. "%")
            end
        end
        local querySql = "SELECT COUNT(citizenid) as count FROM mdt_fake_profiles " .. whereClause
        local countResult = MySQL.query.await(querySql, params)
        if countResult and countResult[1] then
            totalCount = totalCount + countResult[1].count
        else
            totalCount = totalCount + 0
        end
        local fakeProfilesSql = "SELECT * FROM mdt_fake_profiles " .. whereClause .. " LIMIT ? OFFSET ?"
        local fakeProfilesParams = params
        table.insert(fakeProfilesParams, limit)
        table.insert(fakeProfilesParams, offset)
        local fakeProfilesResult = MySQL.query.await(fakeProfilesSql, fakeProfilesParams)
        for _, profile in ipairs(fakeProfilesResult or {}) do
            local profileData = {}
            profileData.citizenid = profile.citizenid
            profileData.firstname = profile.firstname
            profileData.surname = profile.lastname
            profileData.gender = profile.gender
            profileData.nationality = profile.nationality
            profileData.birthdate = profile.birthdate
            profileData.photo = profile.photo
            profileData.bankAccount = profile.bankAccount
            profileData.phoneNumber = profile.phoneNumber
            profileData.job = profile.job
            local warrantData = MySQL.query.await("SELECT warrant, fingerprint, dna, isDangerous FROM mdt_profiles WHERE citizenid = ?", {profile.citizenid})
            if warrantData and warrantData[1] then
                profileData.warrant = warrantData[1].warrant or 0
                profileData.isDangerous = warrantData[1].isDangerous or 0
            else
                profileData.warrant = 0
                profileData.isDangerous = 0
            end
            profileData.licenses = fetchLicenses(profile.citizenid) or {}
            profileData.fingerprint = warrantData and warrantData[1] and warrantData[1].fingerprint or "Not Registered"
            profileData.dna = warrantData and warrantData[1] and warrantData[1].dna or "Not Registered"
            table.insert(citizens, profileData)
        end
    end
    local response = {}
    response.citizens = citizens
    response.totalCount = totalCount
    return response
end
register(fetchCitizensEvent, fetchCitizens)

local fetchCitizenDataEvent = "kartik-mdt:server:fetchCitizenDataByCitizenId"
local function fetchCitizenData(citizenId)
    if citizenId then
        local query = "SELECT * FROM mdt_profiles WHERE citizenid = ?"
        local params = {citizenId}
        local result = MySQL.query.await(query, params)
        if result and result[1] then
            local data = {}
            data.success = true
            data.notes = result[1].notes or ""
            return data
        else
            local query = "INSERT INTO mdt_profiles SET citizenid = ?"
            local params = {citizenId}
            MySQL.query.await(query, params)
            local data = {}
            data.success = true
            return data
        end
    else
        return {}
    end
end
register(fetchCitizenDataEvent, fetchCitizenData)

local fetchCitizenReportsEvent = "kartik-mdt:server:fetchCitizenReports"
local function fetchCitizenReports(citizenId)
    if citizenId then
        local query = [[
            SELECT * FROM mdt_police_reports 
            WHERE JSON_CONTAINS(peopleInvolved, '{"citizenId": "]] .. citizenId .. [[
"}', '$')
        ]]
        local result = MySQL.query.await(query)
        if result and #result > 0 then
            local reports = {}
            for _, report in ipairs(result) do
                local reportData = {}
                reportData.reportId = report.reportId
                reportData.reportName = report.name or "Unknown"
                reportData.location = report.location
                reportData.citizenId = report.citizenid or citizenId
                reportData.dateTime = report.dateTime
                reportData.peopleInvolved = report.peopleInvolved
                table.insert(reports, reportData)
            end
            return reports
        end
    end
    return {}
end
register(fetchCitizenReportsEvent, fetchCitizenReports)

local fetchCitizenIncidentReportsEvent = "kartik-mdt:server:fetchCitizenIncidentReports"
local function fetchCitizenIncidentReports(citizenId)
    if citizenId then
        local query = [[
            SELECT * FROM mdt_police_incidents 
            WHERE JSON_CONTAINS(peopleInvolved, '{"citizenId": "]] .. citizenId .. [[
"}', '$')
        ]]
        local result = MySQL.query.await(query)
        if result and #result > 0 then
            local reports = {}
            for _, report in ipairs(result) do
                local reportData = {}
                reportData.incidentId = report.incidentId
                reportData.incidentName = report.title or "Unknown"
                reportData.location = report.location
                reportData.citizenId = report.citizenid or citizenId
                reportData.dateTime = report.dateTime
                reportData.peopleInvolved = report.peopleInvolved
                table.insert(reports, reportData)
            end
            return reports
        end
    end
    return {}
end
register(fetchCitizenIncidentReportsEvent, fetchCitizenIncidentReports)

local function fetchCitizenVehicles(citizenId)
    return fetchCitizenVehiclesFromTable(citizenId)
end

local function fetchCitizenWeapons(citizenId)
    local query = [[
        SELECT 
            serialNumber,
            weaponName,
            registrationDate
        FROM 
            mdt_weapons
        WHERE
            citizenId = @citizenId
    ]]
    local result = MySQL.query.await(query, {citizenId = citizenId})
    local weapons = {}
    for _, weapon in ipairs(result) do
        local weaponData = {}
        weaponData.serialNumber = weapon.serialNumber
        weaponData.weaponName = weapon.weaponName
        weaponData.registrationDate = weapon.registrationDate
        table.insert(weapons, weaponData)
    end
    return weapons
end

local fetchCitizenAssetsEvent = "kartik-mdt:server:fetchCitizenAssets"
local function fetchCitizenAssets(citizenId)
    if citizenId then
        local vehicles = fetchCitizenVehicles(citizenId)
        local weapons = fetchCitizenWeapons(citizenId)
        local properties = pcall(fetchCitizenProperties, citizenId) or {}
        local response = {}
        response.success = true
        response.vehicles = vehicles or {}
        response.weapons = weapons or {}
        response.properties = properties or {}
        return response
    end
end
register(fetchCitizenAssetsEvent, fetchCitizenAssets)

local fetchCitizenInsurancesEvent = "kartik-mdt:server:fetchCitizenInsurances"
local function fetchCitizenInsurances(citizenId)
    if citizenId then
        local healthInsurance = fetchHealthInsurance and fetchHealthInsurance(citizenId) or {}
        local homeInsurance = fetchHomeInsurance and fetchHomeInsurance(citizenId) or {}
        local vehicleInsurance = fetchVehicleInsurance and fetchVehicleInsurance(citizenId) or {}
        local vehicleRegistration = fetchVehicleRegistration and fetchVehicleRegistration(citizenId) or {}
        local insurances = {}
        for _, insurance in ipairs(healthInsurance) do
            table.insert(insurances, insurance)
        end
        for _, insurance in ipairs(homeInsurance) do
            table.insert(insurances, insurance)
        end
        for _, insurance in ipairs(vehicleInsurance) do
            table.insert(insurances, insurance)
        end
        for _, insurance in ipairs(vehicleRegistration) do
            table.insert(insurances, insurance)
        end
        local response = {}
        response.success = true
        response.insurances = insurances
        return response
    end
end
register(fetchCitizenInsurancesEvent, fetchCitizenInsurances)

local fetchCitizenCitationsEvent = "kartik-mdt:server:fetchCitizenCitations"
local function fetchCitizenCitations(citizenId)
    if citizenId then
        local citations = pcall(fetchCitizenCitations, citizenId) or {}
        return citations
    end
end
register(fetchCitizenCitationsEvent, fetchCitizenCitations)

lib.callback.register("kartik-mdt:server:fetchCitizenWarrants", function(source, data)
  local citizenId = data.citizenId
  local query = "SELECT * FROM mdt_warrants WHERE suspectId = ?"
  local params = {citizenId}
  local result = MySQL.query.await(query, params)
  if result then
    local warrants = {}
    for _, row in ipairs(result) do
      local warrant = {
        id = row.id,
        suspectId = row.suspectId,
        status = row.status,
        issueDate = row.issueDate or "Unknown",
        expiryDate = row.expiryDate or "Unknown",
        charges = row.charges or "[]",
        issuingAuthority = row.issuingAuthority or ""
      }
      table.insert(warrants, warrant)
    end
    return warrants
  else
    return {}
  end
end)

lib.callback.register("kartik-mdt:server:addCitizenNote", function(source, data)
  if data then
    local citizenId = data.citizenid
    local notesData = data.notesData
    local query = "UPDATE mdt_profiles SET notes = ? WHERE citizenid = ?"
    local params = {notesData, citizenId}
    MySQL.query.await(query, params)
    return true
  else
    return false
  end
end)

lib.callback.register("kartik-mdt:server:deleteNote", function(source, data)
  if data then
    local citizenId = data.citizenId
    local updatedNotes = data.updatedNotes
    local notesJson = json.encode(updatedNotes)
    local query = "UPDATE mdt_profiles SET notes = ? WHERE citizenid = ?"
    local params = {notesJson, citizenId}
    MySQL.query.await(query, params)
    return {success = true}
  else
    return {success = false}
  end
end)

lib.callback.register("kartik-mdt:server:updateCitizenPhoto", function(source, data)
  if data and data.citizenId and data.photo then
    if updateCitizenPhoto then
      updateCitizenPhoto(data.citizenId, data.photo)
    end
    local query = "UPDATE mdt_fake_profiles SET photo = ? WHERE citizenid = ?"
    local params = {data.photo, data.citizenId}
    local result = MySQL.query.await(query, params)
    if result and result.affectedRows > 0 then
      return {success = true, message = "Photo changed successfully."}
    else
      return {success = false, message = "Citizen ID not found"}
    end
  else
    return {success = false, message = "Invalid or missing data."}
  end
end)

lib.callback.register("kartik-mdt:server:updateCitizenDangerStatus", function(source, data)
  if data then
    local citizenId = data.citizenId
    local isDangerous = data.isDangerous
    local query = "UPDATE mdt_profiles SET isDangerous = ? WHERE citizenid = ?"
    local params = {isDangerous, citizenId}
    MySQL.query.await(query, params)
    return {success = true}
  else
    return {success = false}
  end
end)

lib.callback.register("kartik-mdt:server:updateCitizenBiometric", function(source, data)
  if data then
    local citizenId = data.citizenId
    local type = data.type
    local value = data.value
    local query = "UPDATE mdt_profiles SET " .. type .. " = ? WHERE citizenid = ?"
    local params = {value, citizenId}
    MySQL.query.await(query, params)
    return {success = true}
  else
    return {success = false}
  end
end)

function AddFakeProfile(data)
  if data.citizenid and data.firstname and data.lastname then
    if checkCitizenIdInPlayers then
      if checkCitizenIdInPlayers(data.citizenid) then
        return false, "Citizen ID already exists in players table"
      end
    end
    local query = [[
      INSERT INTO mdt_fake_profiles 
      (citizenid, firstname, lastname, gender, nationality, birthdate, photo, bankAccount, phoneNumber, job)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      ON DUPLICATE KEY UPDATE
      firstname = VALUES(firstname),
      lastname = VALUES(lastname),
      gender = VALUES(gender),
      nationality = VALUES(nationality),
      birthdate = VALUES(birthdate),
      photo = VALUES(photo),
      bankAccount = VALUES(bankAccount),
      phoneNumber = VALUES(phoneNumber),
      job = VALUES(job)
    ]]
    local params = {
      data.citizenid,
      data.firstname,
      data.lastname,
      data.gender or "Unknown",
      data.nationality or "Unknown",
      data.birthdate or "Unknown",
      data.photo or nil,
      data.bankAccount or nil,
      data.phoneNumber or nil,
      data.job or "Unknown"
    }
    MySQL.query.await(query, params)
    return true, "Profile added successfully"
  else
    return false, "Missing required fields"
  end
end
exports("AddFakeProfile", AddFakeProfile)

function RemoveFakeProfile(citizenid)
  if citizenid then
    local query = "DELETE FROM mdt_fake_profiles WHERE citizenid = ?"
    MySQL.query.await(query, {citizenid})
    return true, "Profile removed successfully"
  else
    return false, "Missing citizenid"
  end
end
exports("RemoveFakeProfile", RemoveFakeProfile)

lib.callback.register("kartik-mdt:server:updateCitizenName", function(source, data)
  local result = {success = false}
  if data then
    local citizenId = data.citizenId
    local firstname = data.firstname
    local surname = data.surname
    if SetPlayerName then
      SetPlayerName(citizenId, firstname, surname)
      result.success = true
    end
    return result
  else
    return result
  end
end)