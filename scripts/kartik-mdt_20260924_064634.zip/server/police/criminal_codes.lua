local callback, eventName, fetchCriminalCodes
callback = lib.callback
callback = callback.register
eventName = "kartik-mdt:server:fetchCriminalCodes"
function fetchCriminalCodes(source, data)
  if data then
    local query = data.query
    if not query then
      query = ""
    end
    local page = data.page
    local offset = (page - 1) * 10
    local whereClause = ""
    local params = {}
    if query ~= "" then
      whereClause = "WHERE LOWER(id) LIKE LOWER(?) OR LOWER(title) LIKE LOWER(?) OR LOWER(description) LIKE LOWER(?) "
      local likePattern = "%" .. query .. "%"
      params = {likePattern, likePattern, likePattern}
    end
    local sql = "SELECT * FROM mdt_criminal_codes " .. whereClause .. " LIMIT 10 OFFSET ?"
    table.insert(params, offset)
    local results = MySQL.query.await(sql, params)
    local criminalCodes = {}
    for _, row in ipairs(results) do
      local code = {
        id = row.id,
        title = row.title,
        description = row.description,
        fine = row.fine,
        category = row.category,
        additonalPenalties = row.additonalPenalties,
        sentence = row.sentence
      }
      table.insert(criminalCodes, code)
    end
    if query ~= "" then
      params[3] = nil
    end
    local countSql = "SELECT COUNT(*) as count FROM mdt_criminal_codes " .. whereClause
    local countResults = MySQL.query.await(countSql, params)
    local totalCount = countResults[1].count
    return {
      criminalCodesData = criminalCodes,
      totalCount = totalCount
    }
  end
end
callback(eventName, fetchCriminalCodes)

callback = lib.callback
callback = callback.register
eventName = "kartik-mdt:server:fetchAllCriminalCodes"
function fetchAllCriminalCodes(source, data)
  if data then
    local sql = "SELECT * FROM mdt_criminal_codes "
    local results = MySQL.query.await(sql, {})
    local criminalCodes = {}
    for _, row in ipairs(results) do
      local code = {
        id = row.id,
        title = row.title,
        description = row.description,
        fine = row.fine,
        category = row.category,
        additonalPenalties = row.additonalPenalties,
        sentence = row.sentence
      }
      table.insert(criminalCodes, code)
    end
    return {
      success = true,
      criminalCodesData = criminalCodes
    }
  end
end
callback(eventName, fetchAllCriminalCodes)

callback = lib.callback
callback = callback.register
eventName = "kartik-mdt:server:fetchCriminalCodeById"
function fetchCriminalCodeById(source, data)
  if data then
    local id = data.id
    local sql = "SELECT * FROM mdt_criminal_codes WHERE id = ?"
    local params = {id}
    local results = MySQL.query.await(sql, params)
    if results[1] then
      local code = results[1]
      local changeHistory = code.changeHistory
      if not changeHistory then
        changeHistory = ""
      end
      local additonalPenalties = code.additonalPenalties
      if not additonalPenalties then
        additonalPenalties = ""
      end
      return {
        changeHistory = changeHistory,
        additonalPenalties = additonalPenalties
      }
    end
  end
  return nil
end
callback(eventName, fetchCriminalCodeById)

callback = lib.callback
callback = callback.register
eventName = "kartik-mdt:server:addCriminalCode"
function addCriminalCode(source, data)
  if data then
    local code = data.codeToAdd
    if code then
      local id = code.id
      local title = code.title
      local description = code.description
      local fine = code.fine
      local category = code.category
      local sentence = code.sentence
      local changeHistory = json.encode(code.changeHistory)
      local additonalPenalties = json.encode(code.additonalPenalties)
      local sql = "INSERT INTO mdt_criminal_codes (id, title, description, category, fine, sentence, changeHistory, additonalPenalties) VALUES (?, ?, ?, ?, ?, ?, ?, ?)"
      local params = {id, title, description, category, fine, sentence, changeHistory, additonalPenalties}
      local results = MySQL.query.await(sql, params)
      if results.affectedRows > 0 then
        SendDiscordLog("criminal_code", "\240\159\147\156 Criminal Code Added", nil, 5763719, {
          {name = "Code ID", value = tostring(id), inline = true},
          {name = "Title", value = title or "N/A", inline = true},
          {name = "Fine", value = "$" .. tostring(fine or 0), inline = true},
          {name = "Sentence", value = tostring(sentence or 0) .. " months", inline = true},
          {name = "Category", value = category or "N/A", inline = true},
          {name = "Added By", value = GetPlayerName(source) or ("Source: " .. tostring(source)), inline = false}
        })
        return {
          success = true,
          message = "Inserted successfully."
        }
      else
        return {
          success = false,
          message = "Failed to insert the code."
        }
      end
    end
  end
  return {
    success = false,
    message = "No data received."
  }
end
callback(eventName, addCriminalCode)

callback = lib.callback
callback = callback.register
eventName = "kartik-mdt:server:updateCriminalCode"
function updateCriminalCode(source, data)
  if data then
    local code = data.code
    if code then
      local id = code.id
      local title = code.title
      local description = code.description
      local fine = code.fine
      local category = code.category
      local sentence = code.sentence
      local additonalPenalties = json.encode(code.additonalPenalties)
      local changeHistory = json.encode(code.changeHistory)
      local sql = "UPDATE mdt_criminal_codes SET title = ?, description = ?, fine = ?, sentence = ?, additonalPenalties = ?, changeHistory = ?, category = ? WHERE id = ?"
      local params = {title, description, fine, sentence, additonalPenalties, changeHistory, category, id}
      local results = MySQL.query.await(sql, params)
      if results.affectedRows > 0 then
        SendDiscordLog("criminal_code", "\226\156\143\239\184\143 Criminal Code Updated", nil, 3447003, {
          {name = "Code ID", value = tostring(id), inline = true},
          {name = "Title", value = title or "N/A", inline = true},
          {name = "category", value = category or "N/A", inline = true},
          {name = "Fine", value = "$" .. tostring(fine or 0), inline = true},
          {name = "Sentence", value = tostring(sentence or 0) .. " months", inline = true},
          {name = "Updated By", value = GetPlayerName(source) or ("Source: " .. tostring(source)), inline = false}
        })
        return {
          success = true,
          message = "Report saved successfully."
        }
      else
        return {
          success = false,
          message = "Failed to update the report."
        }
      end
    end
  end
  return {
    success = false,
    message = "No data received."
  }
end
callback(eventName, updateCriminalCode)

callback = lib.callback
callback = callback.register
eventName = "kartik-mdt:server:deleteCriminalCode"
function deleteCriminalCode(source, data)
  if data then
    local id = data.id
    if id then
      local sql = "DELETE FROM mdt_criminal_codes WHERE id = ?"
      local params = {id}
      local results = MySQL.query.await(sql, params)
      if results.affectedRows > 0 then
        SendDiscordLog("criminal_code", "\240\159\151\145\239\184\143 Criminal Code Deleted", nil, 15158332, {
          {name = "Code ID", value = tostring(id), inline = true},
          {name = "Deleted By", value = GetPlayerName(source) or ("Source: " .. tostring(source)), inline = false}
        })
        return {
          success = true,
          message = "Code deleted successfully."
        }
      else
        return {
          success = false,
          message = "Failed to delete the Code."
        }
      end
    end
  end
  return {
    success = false,
    message = "No data received."
  }
end
callback(eventName, deleteCriminalCode)