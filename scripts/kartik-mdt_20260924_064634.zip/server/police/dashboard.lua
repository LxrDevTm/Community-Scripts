local fetchAnnouncements, lib, MySQL, SendDiscordLog, GetPlayerName, fetchWarrants, fetchRecentReports, fetchWantedVehicles

function fetchAnnouncements(data)
  local query = "SELECT COUNT(*) as total FROM mdt_police_bulletin"
  local result = MySQL.query.await(query, {})
  local total = result[1].total or 0
  local hasMore = false
  if data then
    local page = data.page
    local limit = data.limit
    if page and limit then
      local offset = (page - 1) * limit
      query = "SELECT * FROM mdt_police_bulletin ORDER BY dateTime DESC LIMIT ? OFFSET ?"
      local params = {limit, offset}
      result = MySQL.query.await(query, params)
      hasMore = total > page * limit
      return {success = true, announcements = result, message = "", hasMore = hasMore}
    end
  end
  return {success = false, message = "No announcements found."}
end

lib.callback.register("kartik-mdt:server:fetchAnnouncements", function(data)
  return fetchAnnouncements(data)
end)

function initPoliceDashboard(data)
  local announcements = fetchAnnouncements(data)
  local warrantsData = fetchWarrants(data)
  local reports = fetchRecentReports(data)
  local vehiclesData = fetchWantedVehicles(data)
  return {announcements = announcements.announcements, warrantsData = warrantsData, reports = reports, vehiclesData = vehiclesData}
end

lib.callback.register("kartik-mdt:server:initPoliceDashboard", function(data)
  return initPoliceDashboard(data)
end)

function addAnnouncement(player, data)
  if data and data.announcementToAdd then
    local announcementId = data.announcementToAdd.announcementId
    local title = data.announcementToAdd.title
    local description = data.announcementToAdd.description
    local dateTime = data.announcementToAdd.dateTime
    local query = "INSERT INTO mdt_police_bulletin (announcementId, title, description, dateTime) VALUES (?, ?, ?, ?)"
    local params = {announcementId, title, description, dateTime}
    local result = MySQL.query.await(query, params)
    if result.affectedRows > 0 then
      SendDiscordLog("pd_announcement", "\240\159\147\162 New Announcement Added", nil, 8311585, {
        {name = "Title", value = title or "N/A", inline = true},
        {name = "Posted At", value = dateTime or os.date("%Y-%m-%d %H:%M:%S"), inline = true},
        {name = "Player", value = string.format("%s (source: %d)", GetPlayerName(player) or "Unknown", player), inline = false}
      })
      return {success = true, message = "Announcement added successfully."}
    else
      return {success = false, message = "Failed to add announcement."}
    end
  else
    return {success = false, message = "No data received."}
  end
end

lib.callback.register("kartik-mdt:server:addAnnouncement", function(player, data)
  return addAnnouncement(player, data)
end)

function deleteAnnouncement(player, data)
  if data and data.announcementId then
    local announcementId = data.announcementId
    local query = "DELETE FROM mdt_police_bulletin WHERE announcementId = ?"
    local params = {announcementId}
    local result = MySQL.query.await(query, params)
    if result.affectedRows > 0 then
      SendDiscordLog("pd_announcement", "\240\159\151\145\239\184\143 Announcement Deleted", nil, 15158332, {
        {name = "Announcement ID", value = tostring(announcementId), inline = true},
        {name = "Player", value = string.format("%s (source: %d)", GetPlayerName(player) or "Unknown", player), inline = false}
      })
      return {success = true, message = "Announcement deleted successfully."}
    else
      return {success = false, message = "Failed to delete the announcement."}
    end
  else
    return {success = false, message = "No data received."}
  end
end

lib.callback.register("kartik-mdt:server:deleteAnnouncement", function(player, data)
  return deleteAnnouncement(player, data)
end)

function editAnnouncement(player, data)
  if data and data.edited then
    local announcementId = data.edited.announcementId
    local title = data.edited.title
    local description = data.edited.description
    local dateTime = data.edited.dateTime
    local query = "SELECT * FROM mdt_police_bulletin WHERE announcementId = ?"
    local params = {announcementId}
    local result = MySQL.query.await(query, params)
    if #result > 0 then
      query = "UPDATE mdt_police_bulletin SET title = ?, description = ?, dateTime = ? WHERE announcementId = ?"
      params = {title, description, dateTime, announcementId}
      result = MySQL.query.await(query, params)
      if result.affectedRows > 0 then
        SendDiscordLog("pd_announcement", "\226\156\143\239\184\143 Announcement Edited", nil, 3447003, {
          {name = "Announcement ID", value = tostring(announcementId), inline = true},
          {name = "New Title", value = title or "N/A", inline = true},
          {name = "New Date", value = dateTime or os.date("%Y-%m-%d %H:%M:%S"), inline = true},
          {name = "Player", value = string.format("%s (source: %d)", GetPlayerName(player) or "Unknown", player), inline = false}
        })
        return {success = true, message = "Announcement Changed Successfully"}
      else
        return {success = false, message = "Failed to change."}
      end
    else
      return {success = false, message = "Failed to change the announcement."}
    end
  else
    return nil
  end
end

lib.callback.register("kartik-mdt:server:editAnnouncement", function(player, data)
  return editAnnouncement(player, data)
end)

function fetchWarrants(data)
  if data then
    local page = data.page
    local limit = data.limit
    if page and limit then
      local offset = (page - 1) * limit
      local result = fetchWarrantsWithPlayers(limit, offset)
      return {warrantsData = result, success = true}
    end
  end
end

lib.callback.register("kartik-mdt:server:fetchActiveWarrants", function(data)
  return fetchWarrants(data)
end)

function fetchWantedVehicles(data)
  if data then
    local page = data.page
    local limit = data.limit
    if page and limit then
      local offset = (page - 1) * limit
      local result = fetchWantedVehiclesWithPlayers(limit, offset)
      return {vehiclesData = result, success = true}
    end
  end
end

lib.callback.register("kartik-mdt:server:fetchWantedVehicles", function(data)
  return fetchWantedVehicles(data)
end)