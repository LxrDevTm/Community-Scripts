local radioChannels = {}
local incidentNumber = 0

function fetchActiveUnitsHere(data)
    local pcall = pcall
    local function innerFetchActiveUnitsHere()
        local query = "SELECT COUNT(*) as total FROM mdt_units WHERE status = ? AND isFired = 0"
        local result = MySQL.query.await(query, {"on-duty"})
        local hasMore = false
        if result[1] and result[1].total then
            hasMore = result[1].total > (data.page or 1) * (data.limit or 5)
        else
            hasMore = false
        end
        local offset = (data.page or 1) - 1
        offset = offset * (data.limit or 5)
        local query = "SELECT * FROM mdt_units WHERE status = ? AND isFired = 0 LIMIT ? OFFSET ?"
        local params = {"on-duty", data.limit or 5, offset}
        table.insert(params, "on-duty")
        table.insert(params, data.limit or 5)
        table.insert(params, offset)
        local result = MySQL.query.await(query, params)
        if type(result) == "table" then
            local units = {}
            for _, v in ipairs(result) do
                local player = GetPlayerByCitizenId(v.citizenid)
                if player then
                    local unitData = {
                        source = player.source,
                        officerId = v.id,
                        department = player.jobData.label or "Unknown",
                        job = player.jobData.name or "Unknown",
                        depName = player.jobData.name or "Unknown",
                        dutyStatus = v.dutyStatus or "avl",
                        rank = player.jobData.grade and player.jobData.grade.name or "Unknown",
                        callsign = v.callsign,
                        citizenId = v.citizenid,
                        status = v.status,
                        name = player.name or "Unknown"
                    }
                    table.insert(units, unitData)
                end
            end
            return {units = units, success = true, hasMore = hasMore}
        else
            error("MySQL query failed or returned invalid result.")
        end
    end
    local success, result = pcall(innerFetchActiveUnitsHere)
    if success then
        return result
    else
        return {units = {}, success = false, error = result}
    end
end

function sendDispatchNotificationBack(data, message)
    if data then
        local citizenid = data.citizenid
        if citizenid then
            local player = GetPlayerByCitizenId(citizenid)
            if player then
                local ped = GetPlayerPed(player.source)
                local coords = GetEntityCoords(ped)
                local notificationData = {
                    id = tostring(os.time()),
                    time = os.date("%Y-%m-%d %H:%M:%S"),
                    title = "Reply to call",
                    code = "Reply",
                    x = coords.x,
                    y = coords.y,
                    z = coords.z,
                    description = message or "Unit are on its way",
                    type = "Call"
                }
                TriggerClientEvent("kartik-mdt:client:sendReplyDispatchNotification", player.source, notificationData)
            end
        end
    end
end

local lib = lib
lib.callback.register("kartik-mdt:server:fetchActiveUnitsHere", function(data, cb)
    if data then
        return fetchActiveUnitsHere(data)
    else
        return nil
    end
end)

lib.callback.register("kartik-mdt:server:getRadioChannels", function(data, cb)
    if data then
        return {radioChannels = radioChannels, success = true}
    else
        return nil
    end
end)

lib.callback.register("kartik-mdt:server:createRadioChannels", function(data, cb)
    if data then
        table.insert(radioChannels, data.newChannel)
        CreateThread(function()
            syncDataBetweenUnits("setRadioChannels", radioChannels)
        end)
        return {radioChannels = radioChannels, success = true}
    else
        return nil
    end
end)

function LeaveRadio(citizenid)
    local found = false
    if radioChannels then
        for _, channel in pairs(radioChannels) do
            for i, unit in ipairs(channel.units) do
                if unit.citizenid == citizenid then
                    table.remove(channel.units, i)
                    found = true
                    break
                end
            end
        end
    end
    if found then
        CreateThread(function()
            syncDataBetweenUnits("setRadioChannels", radioChannels)
        end)
    end
end

function JoinLeaveRadio(data)
    local channelId = data.channelId
    local unitId = data.unitId
    local isJoining = data.isJoining
    local citizenid = data.citizenid
    local player = GetPlayerByCitizenId(citizenid)
    if player then
        local playerName = player.name
        local playerSource = player.source
        local found = false
        for _, channel in ipairs(radioChannels) do
            if channel.id == channelId then
                if isJoining then
                    local existingUnit = false
                    for _, unit in ipairs(channel.units) do
                        if unit.citizenid == citizenid then
                            existingUnit = true
                            break
                        end
                    end
                    if not existingUnit then
                        table.insert(channel.units, {callsign = unitId, citizenid = citizenid, name = playerName})
                    end
                else
                    for i, unit in ipairs(channel.units) do
                        if unit.citizenid == citizenid then
                            table.remove(channel.units, i)
                            break
                        end
                    end
                end
                found = true
                local radioNumber = channel.radioNumber
                TriggerClientEvent("kartik-mdt:client:updateRadioChannel", playerSource, radioNumber, isJoining)
                if player.jobData then
                    local defaultRadios = Config.DefaultRadios
                    if defaultRadios and defaultRadios[player.jobData.name] then
                        radioNumber = defaultRadios[player.jobData.name]
                        isJoining = true
                    end
                end
                local playerList = radioChannels[channelId].units
                for _, unit in ipairs(playerList) do
                    local unitPlayer = GetPlayerByCitizenId(unit.citizenid)
                    if unitPlayer then
                        local unitSource = unitPlayer.source
                        TriggerClientEvent("kartik-mdt:client:updateRadioChannel", unitSource, radioNumber, isJoining)
                    end
                end
                CreateThread(function()
                    syncDataBetweenUnits("setRadioChannels", radioChannels)
                end)
                break
            end
        end
        return {radioChannels = radioChannels, success = true}
    end
end

lib.callback.register("kartik-mdt:server:joinLeaveRadio", function(data, cb)
    if data then
        return JoinLeaveRadio(data)
    else
        return {success = false}
    end
end)

lib.callback.register("kartik-mdt:server:assignRadioNumber", function(data, cb)
    if data then
        local channelId = data.channelId
        local radioNumber = data.radioNumber
        for _, channel in ipairs(radioChannels) do
            if channel.id == channelId then
                channel.radioNumber = radioNumber
                for _, unit in pairs(channel.units) do
                    local player = GetPlayerByCitizenId(unit.citizenid)
                    if player then
                        local playerSource = player.source
                        TriggerClientEvent("kartik-mdt:client:updateRadioChannel", playerSource, radioNumber, true)
                        local playerList = radioChannels[channelId].units
                        for _, unit in ipairs(playerList) do
                            local unitPlayer = GetPlayerByCitizenId(unit.citizenid)
                            if unitPlayer then
                                local unitSource = unitPlayer.source
                                TriggerClientEvent("kartik-mdt:client:updateRadioChannel", unitSource, radioNumber, true)
                            end
                        end
                    end
                end
                CreateThread(function()
                    syncDataBetweenUnits("setRadioChannels", radioChannels)
                end)
                return {radioChannels = radioChannels, success = true}
            end
        end
    end
end)

local renameChannelResult = {}
renameChannelResult.success = false
return renameChannelResult
end
end
lib.callback.register("kartik-mdt:server:renameChannelName", function(channelData)
  local channelId = channelData.channelId
  local renameChannelName = channelData.renameChannelName
  for index, channel in ipairs(radioChannels) do
    if channel.id == channelId then
      channel.name = renameChannelName
      break
    end
  end
  CreateThread(function()
    syncDataBetweenUnits("setRadioChannels", radioChannels)
  end)
  local result = {}
  result.radioChannels = radioChannels
  result.success = true
  return result
end)
lib.callback.register("kartik-mdt:server:deleteRadioChannel", function(channelData)
  local channelId = channelData.channelId
  if channelId then
    for index, channel in ipairs(radioChannels) do
      if channel.id == channelId then
        local incidentId = channel.incidentId
        if incidentId then
          for _, incident in pairs(incidents) do
            if incident.id == incidentId then
              incident.units = nil
              break
            end
          end
        end
        for _, unit in pairs(channel.units) do
          local player = GetPlayerByCitizenId(unit.citizenid)
          if player then
            TriggerClientEvent("kartik-mdt:client:updateRadioChannel", player.source, radioNumber, false)
          end
        end
        table.remove(radioChannels, index)
        CreateThread(function()
          syncDataBetweenUnits("setRadioChannels", radioChannels)
        end)
        local result = {}
        result.radioChannels = radioChannels
        result.recentIncidents = incidents
        result.success = true
        return result
      end
    end
  end
  local result = {}
  result.success = false
  return result
end)
lib.callback.register("kartik-mdt:server:getActiveIncidents", function(playerSource)
  if not playerSource then
    return nil
  end
  local playerData = GetPlayerData(playerSource)
  if not playerData then
    error("Player data not found for source: " .. tostring(playerSource))
  end
  local departmentName = playerData.jobData.name
  if not departmentName then
    error("Department name missing for player source: " .. tostring(playerSource))
  end
  local departmentCategory = getDepartmentCategory(departmentName)
  if not departmentCategory then
    error("Job category not found for department: " .. tostring(departmentName))
  end
  local activeIncidents = {}
  for _, incident in pairs(incidents) do
    if incident.jobs and incident.jobs[departmentCategory] then
      table.insert(activeIncidents, incident)
    end
  end
  local result = {}
  result.incidents = activeIncidents
  result.success = true
  return result
end)
lib.callback.register("kartik-mdt:server:attachUnitToIncident", function(playerSource, incidentData)
  if incidentData then
    local incidentId = incidentData.incident
    if incidentId then
      local incident = nil
      for _, i in ipairs(incidents) do
        if i.id == incidentId then
          incident = i
          break
        end
      end
      if not incident then
        local result = {}
        result.success = false
        result.message = "Incident not found"
        return result
      end
      local channelId = incident.units
      local channelLocation = incident.location
      if not channelLocation then
        channelLocation = "Unknown Location"
      end
      local channelIncidentId = incident.id
      local channelTitle = incident.title
      if not channelTitle then
        channelTitle = "Unknown Call"
      end
      if Config.AutoCallCreation or incidentData.type ~= "car" then
        local channelName = string.format("%s - %s", channelTitle, channelLocation)
        if not channelId then
          local channelTime = os.time()
          local channelId = "CH" .. tostring(channelTime)
          local channel = {}
          channel.id = channelId
          channel.name = channelName
          channel.incidentId = channelIncidentId
          channel.status = "In-situation"
          channel.units = {}
          table.insert(radioChannels, channel)
          for _, unit in pairs(incident.units) do
            local player = GetPlayerByCitizenId(unit.citizenid)
            if player then
              TriggerClientEvent("kartik-mdt:client:updateRadioChannel", player.source, radioNumber, false)
            end
          end
          CreateThread(function()
            syncDataBetweenUnits("setIncidentsAndRadio", { radioChannels = radioChannels, incidents = incidents })
          end)
          local result = {}
          result.success = true
          result.radioChannels = radioChannels
          result.incidents = incidents
          return result
        end
        else
          local channel = {}
          channel.channelId = channelId
          channel.unitId = incidentData.unitData.callsign
          channel.isJoining = true
          channel.citizenid = incidentData.unitData.citizenid
          JoinLeaveRadio(channel)
        end
        for _, channel in ipairs(radioChannels) do
          if channel.id == channelId then
            if channel.incidentId == incidentId then
              channel.status = "In-situation"
              break
            end
          end
        end
        for _, incident in ipairs(incidents) do
          if incident.id == incidentId then
            incident.units = channelId
            incident.location = channelLocation
            break
          end
        end
      end
      if incident.person then
        sendDispatchNotificationBack(incident.person)
      end
      local playerData = GetPlayerData(playerSource)
      if not playerData then
        local result = {}
        result.success = false
        result.message = "Player data not found"
        return result
      end
      local departmentName = playerData.jobData.name
      if not departmentName then
        local result = {}
        result.success = false
        result.message = "Department name missing"
        return result
      end
      local departmentCategory = getDepartmentCategory(departmentName)
      if not departmentCategory then
        local result = {}
        result.success = false
        result.message = "Job category not found"
        return result
      end
      local activeIncidents = {}
      for _, incident in ipairs(incidents) do
        if incident.jobs and incident.jobs[departmentCategory] then
          table.insert(activeIncidents, incident)
        end
      end
      CreateThread(function()
        syncDataBetweenUnits("setIncidentsAndRadio", { radioChannels = radioChannels, incidents = activeIncidents })
      end)
      local result = {}
      result.success = true
      result.radioChannels = radioChannels
      result.incidents = activeIncidents
      return result
    end
    else
      local result = {}
      result.success = false
      result.message = "No incident data received."
      return result
    end
end)
lib.callback.register("kartik-mdt:server:detachUnit", function(playerSource, channelData)
  if channelData then
    local channelId = channelData.channelId
    if channelId then
      local incidentId = channelData.incidentId
      for _, channel in pairs(radioChannels) do
        if channel.id == channelId then
          channel.incidentId = nil
          channel.status = "active"
          break
        end
      end
      for _, incident in ipairs(incidents) do
        if incident.id == incidentId then
          incident.units = nil
          break
        end
      end
      local playerData = GetPlayerData(playerSource)
      if not playerData then
        local result = {}
        result.success = false
        result.error = "Player data not found"
        return result
      end
      local departmentName = playerData.jobData.name
      if not departmentName then
        local result = {}
        result.success = false
        result.error = "Department name missing"
        return result
      end
      local departmentCategory = getDepartmentCategory(departmentName)
      if not departmentCategory then
        local result = {}
        result.success = false
        result.error = "Job category not found"
        return result
      end
      local activeIncidents = {}
      for _, incident in ipairs(incidents) do
        if incident.jobs and incident.jobs[departmentCategory] then
          table.insert(activeIncidents, incident)
        end
      end
      CreateThread(function()
        syncDataBetweenUnits("setIncidentsAndRadio", { radioChannels = radioChannels, incidents = activeIncidents })
      end)
      local result = {}
      result.success = true
      result.radioChannels = radioChannels
      result.incidents = activeIncidents
      return result
    end
    else
      local result = {}
      result.success = false
      return result
    end
end)
lib.callback.register("kartik-mdt:server:deleteDispatchIncident", function(playerSource, incidentData)

local incidentId, incidentData, unitId, radioChannelId, radioChannels, incidents, jobData, departmentCategory, playerData

if incidentId then
    if incidentId ~= "" then
        goto label10
    end
end

incidentData = {}
incidentData.success = false
return incidentData

::label10::
incidentId = incidentId
unitId = nil
radioChannelId = nil
local ipairsFunc = ipairs
local incidentsTable = incidents
local iterator, incident, key, value = ipairsFunc(incidentsTable)
for i, incident in iterator, incidentsTable, key, value do
    local incidentIdCheck = incident.id
    if incidentIdCheck == incidentId then
        unitId = i
        radioChannelId = incident.units
        break
    end
end
if not unitId then
    local result = {}
    result.success = false
    return result
end
local tableFunc = table
local removeFunc = tableFunc.remove
local incidentsTable = incidents
local unitIdToRemove = unitId
removeFunc(incidentsTable, unitIdToRemove)
if radioChannelId then
    local ipairsFunc = ipairs
    local radioChannelsTable = radioChannels
    local iterator, radioChannel, key, value = ipairsFunc(radioChannelsTable)
    for i, radioChannel in iterator, radioChannelsTable, key, value do
        local radioChannelIdCheck = radioChannel.id
        if radioChannelIdCheck == radioChannelId then
            radioChannel.incidentId = nil
            radioChannel.status = "active"
            break
        end
    end
end
local getPlayerDataFunc = GetPlayerData
local playerId = playerId
local playerData = getPlayerDataFunc(playerId)
if not playerData then
    local result = {}
    result.success = false
    result.error = "Player data not found"
    return result
end
local jobData = playerData.jobData
if jobData then
    jobData = playerData.jobData
    jobData = jobData.name
end
if not jobData then
    local result = {}
    result.success = false
    result.error = "Department name missing"
    return result
end
local getDepartmentCategoryFunc = getDepartmentCategory
local departmentCategory = getDepartmentCategoryFunc(jobData)
if not departmentCategory then
    local result = {}
    result.success = false
    result.error = "Job category not found"
    return result
end
local result = {}
local ipairsFunc = ipairs
local incidentsTable = incidents
local iterator, incident, key, value = ipairsFunc(incidentsTable)
for i, incident in iterator, incidentsTable, key, value do
    local jobs = incident.jobs
    if jobs then
        jobs = incident.jobs
        jobs = jobs[departmentCategory]
        if jobs then
            local tableFunc = table
            local insertFunc = tableFunc.insert
            local resultTable = result
            local incidentToInsert = incident
            insertFunc(resultTable, incidentToInsert)
        end
    end
end
local createThreadFunc = CreateThread
local function threadFunc()
    local syncDataBetweenUnitsFunc = syncDataBetweenUnits
    local data = "setIncidentsAndRadio"
    local dataToSync = {}
    dataToSync.radioChannels = radioChannels
    dataToSync.incidents = result
    syncDataBetweenUnitsFunc(data, dataToSync)
end
createThreadFunc(threadFunc)
result.incidents = result
result.radioChannels = radioChannels
result.success = true
return result

local lib = lib
local callback = lib.callback
local registerFunc = callback.register
local eventName = "kartik-mdt:server:setlastwaypoint"
local function eventHandler(playerId)
    local getPlayerDataFunc = GetPlayerData
    local playerData = getPlayerDataFunc(playerId)
    local jobData = playerData.jobData
    local departmentCategory = jobData.name
    local getSanitizedPermissionsFunc = GetSanitizedPermissions
    local permissions = getSanitizedPermissionsFunc(departmentCategory, jobData.grade.level)
    if permissions then
        local nextFunc = next
        local permissionsTable = permissions
        local firstKey = nextFunc(permissionsTable)
        if firstKey then
            local pages = permissions.Pages
            local dispatchView = pages.dispatch.view
            if dispatchView then
                goto label30
            end
        end
    end
    local result = {}
    result.success = false
    result.message = "Permission denied."
    return result
    ::label30::
    local nextFunc = next
    local incidentsTable = incidents
    local firstKey = nextFunc(incidentsTable)
    if firstKey then
        local result = {}
        local getDepartmentCategoryFunc = getDepartmentCategory
        local departmentCategory = getDepartmentCategoryFunc(departmentCategory)
        local pairsFunc = pairs
        local incidentsTable = incidents
        local iterator, incident, key, value = pairsFunc(incidentsTable)
        for i, incident in iterator, incidentsTable, key, value do
            local jobs = incident.jobs
            if jobs then
                jobs = incident.jobs
                jobs = jobs[departmentCategory]
                if jobs then
                    local tableFunc = table
                    local insertFunc = tableFunc.insert
                    local resultTable = result
                    local incidentToInsert = incident
                    insertFunc(resultTable, incidentToInsert)
                end
            end
        end
        local length = #result
        if length == 0 then
            local result = {}
            result.success = false
            result.message = "No matching incidents for your department."
            return result
        end
        local lastIncident = result[length]
        local coords = {}
        coords.x = lastIncident.x
        coords.y = lastIncident.y
        local result = {}
        result.coords = coords
        result.success = true
        return result
    else
        local result = {}
        result.success = false
        result.message = "No incidents found."
        return result
    end
end
registerFunc(eventName, eventHandler)

local function sendDispatchNotification(data)
    if not data then
        return
    end
    local pcallFunc = pcall
    local function innerFunc()
        local fetchActiveUnitsHereFunc = fetchActiveUnitsHere
        local activeUnits = fetchActiveUnitsHereFunc()
        local incidentId = data.id
        if not incidentId then
            local incidentNumber = incidentNumber
            incidentNumber = incidentNumber + 1
            data.id = incidentNumber
            incidentId = data.id
            incidentNumber = incidentId
        end
        local osDateFunc = os.date
        local dateFormat = "%Y-%m-%d %H:%M:%S"
        local osTimeFunc = os.time
        local time = osTimeFunc()
        local date = osDateFunc(dateFormat, time)
        data.time = date
        local jobs = data.jobs
        if not jobs then
            jobs = {}
            data.jobs = jobs
        end
        jobs = {}
        local pairsFunc = pairs
        local jobsTable = data.jobs
        local iterator, job, key, value = pairsFunc(jobsTable)
        for i, job in iterator, jobsTable, key, value do
            local config = Config
            local jobsConfig = config.Jobs
            local jobConfig = jobsConfig[i]
            if jobConfig then
                jobs[i] = job
            else
                local getDepartmentCategoryFunc = getDepartmentCategory
                local departmentCategory = getDepartmentCategoryFunc(i)
                if departmentCategory then
                    jobs[departmentCategory] = true
                end
            end
        end
        data.jobs = jobs
        local tableFunc = table
        local insertFunc = tableFunc.insert
        local incidentsTable = incidents
        local incidentToInsert = data
        insertFunc(incidentsTable, incidentToInsert)
        if activeUnits.success then
            local pairsFunc = pairs
            local unitsTable = activeUnits.units
            local iterator, unit, key, value = pairsFunc(unitsTable)
            for i, unit in iterator, unitsTable, key, value do
                local depName = unit.depName
                if not depName then
                else
                    local getDepartmentCategoryFunc = getDepartmentCategory
                    local departmentCategory = getDepartmentCategoryFunc(depName)
                    if not departmentCategory then
                    else
                        local jobs = data.jobs
                        local departmentCategoryCheck = jobs[departmentCategory]
                        if not departmentCategoryCheck then
                        else
                            local source = unit.source
                            if source then
                                local triggerClientEventFunc = TriggerClientEvent
                                local eventName = "kartik-mdt:client:sendDispatchNotification"
                                local sourceToTrigger = source
                                local dataToTrigger = data
                                triggerClientEventFunc(eventName, sourceToTrigger, dataToTrigger)
                            end
                        end
                    end
                end
            end
        end
    end
    local success, error = pcallFunc(innerFunc)
    if not success then
        local printFunc = print
        local errorMessage = "^1[sendDispatchNotification] Error: ^0"
        local errorToString = tostring
        local errorString = errorToString(error)
        errorMessage = errorMessage .. errorString
        printFunc(errorMessage)
    end
end
exports("sendDispatchNotification", sendDispatchNotification)

local registerNetEventFunc = RegisterNetEvent
local eventName = "kartik-mdt:server:sendDispatchNotification"
local function eventHandler(data)
    local config = Config
    local disableNetEvent = config.DisableNetEvent
    if disableNetEvent then
        return
    end
    local sendDispatchNotificationFunc = sendDispatchNotification
    sendDispatchNotificationFunc(data)
end
registerNetEventFunc(eventName, eventHandler)

local function getUnitAttachments()
    local unitAttachments = unitAttachments
    if not unitAttachments then
        unitAttachments = {}
    end
    local result = {}
    result.success = true
    result.attachments = unitAttachments
    return result
end
local lib = lib
local callback = lib.callback
local registerFunc = callback.register
local eventName = "kartik-mdt:server:GetUnitAttachments"
registerFunc(eventName, getUnitAttachments)

local function attachUnitToUnit(unitId, parentUnitId, attachedUnitsToMove)
    if not unitId or not parentUnitId then
        local result = {}
        result.success = false
        result.message = "Missing unit IDs"
        return result
    end
    local unitAttachments = unitAttachments
    local parentUnit = unitAttachments[parentUnitId]
    if not parentUnit then
        parentUnit = {}
        unitAttachments[parentUnitId] = parentUnit
    end
    local parentUnitAttachments = unitAttachments[parentUnitId]
    local existingUnit = parentUnitAttachments[unitId]
    if existingUnit then
        local result = {}
        result.success = true
        result.message = "Unit is already attached to the call."
        return result
    end
    local tableFunc = table
    local insertFunc = tableFunc.insert
    local parentUnitAttachmentsTable = parentUnitAttachments
    local unitIdToInsert = unitId
    insertFunc(parentUnitAttachmentsTable, unitIdToInsert)
    if attachedUnitsToMove then
        local length = #attachedUnitsToMove
        if length > 0 then
            local ipairsFunc = ipairs
            local attachedUnitsToMoveTable = attachedUnitsToMove
            local iterator, unit, key, value = ipairsFunc(attachedUnitsToMoveTable)
            for i, unit in iterator, attachedUnitsToMoveTable, key, value do
                local tableFunc = table
                local insertFunc = tableFunc.insert
                local parentUnitAttachmentsTable = parentUnitAttachments
                local unitToInsert = unit
                insertFunc(parentUnitAttachmentsTable, unitToInsert)
            end
            unitAttachments[unitId] = nil
        end
    end
    if attachedUnitsToMove then
        local length = #attachedUnitsToMove
        if length > 0 then
        end
    end
    local createThreadFunc = CreateThread
    local function threadFunc()
        local syncDataBetweenUnitsFunc = syncDataBetweenUnits
        local data = "setUnitAttachments"
        local dataToSync = unitAttachments
        syncDataBetweenUnitsFunc(data, dataToSync)
    end
    createThreadFunc(threadFunc)
    local result = {}
    result.success = true
    result.attachments = unitAttachments
    return result
end
local lib = lib
local callback = lib.callback
local registerFunc = callback.register
local eventName = "kartik-mdt:server:attachUnitToUnit"
local function eventHandler(data)
    local unitId = data.unitId
    local parentUnitId = data.targetUnitId
    local attachedUnitsToMove = data.attachedUnitsToMove
    return attachUnitToUnit(unitId, parentUnitId, attachedUnitsToMove)
end
registerFunc(eventName, eventHandler)

local function detachUnitFromUnit(unitId, parentUnitId, attachedUnits)
    if not unitId or not parentUnitId then
        local result = {}
        result.success = false
        result.message = "Missing unit IDs"
        return result
    end
    local unitAttachments = unitAttachments
    local parentUnit = unitAttachments[parentUnitId]
    if not parentUnit then
        local result = {}
        result.success = false
        result.message = "Parent unit not found"
        return result
    end
    local found = false
    local ipairsFunc = ipairs
    local parentUnitAttachmentsTable = parentUnit
    local iterator, unit, key, value = ipairsFunc(parentUnitAttachmentsTable)
    for i, unit in iterator, parentUnitAttachmentsTable, key, value do
        if unit == unitId then
            local tableFunc = table
            local removeFunc = tableFunc.remove
            local parentUnitAttachmentsTable = parentUnit
            local indexToRemove = i
            removeFunc(parentUnitAttachmentsTable, indexToRemove)
            found = true
            break
        end
    end
    if not found then
        local result = {}
        result.success = false
        result.message = "Unit not found in parent's attachments"
        return result
    end
    if attachedUnits then
        local length = #attachedUnits
        if length > 0 then
            unitAttachments[unitId] = attachedUnits
        end
    end
    local parentUnitAttachments = unitAttachments[parentUnitId]
    local length = #parentUnitAttachments
    if length == 0 then
        unitAttachments[parentUnitId] = nil
    end
    local createThreadFunc = CreateThread
    local function threadFunc()
        local syncDataBetweenUnitsFunc = syncDataBetweenUnits
        local data = "setUnitAttachments"
        local dataToSync = unitAttachments
        syncDataBetweenUnitsFunc(data, dataToSync)
    end
    createThreadFunc(threadFunc)
    local result = {}
    result.success = true
    result.attachments = unitAttachments
    return result
end
local lib = lib
local callback = lib.callback
local registerFunc = callback.register
local eventName = "kartik-mdt:server:detachUnitFromUnit"
local function eventHandler(data)
    local unitId = data.unitId
    local parentUnitId = data.parentUnitId
    local attachedUnits = data.attachedUnits
    return detachUnitFromUnit(unitId, parentUnitId, attachedUnits)
end
registerFunc(eventName, eventHandler)

local createThreadFunc = CreateThread
local function threadFunc()
    while true do
        local waitFunc = Wait
        local timeToWait = 600000
        waitFunc(timeToWait)
        local osTimeFunc = os.time
        local time = osTimeFunc()
        local i = 1
        while true do
            local incidentsTable = incidents
            local length = #incidentsTable
            if not (i <= length) then
                break
            end
            local osTimeFunc = os.time
            local time = osTimeFunc()
            local date = {}
            local year = tonumber(incidentsTable[i].time:sub(1, 4))
            date.year = year
            local month = tonumber(incidentsTable[i].time:sub(6, 7))
            date.month = month
            local day = tonumber(incidentsTable[i].time:sub(9, 10))
            date.day = day
            local hour = tonumber(incidentsTable[i].time:sub(12, 13))
            date.hour = hour
            local min = tonumber(incidentsTable[i].time:sub(15, 16))
            date.min = min
            i = i + 1
        end
    end
end
createThreadFunc(threadFunc)

local isActionAllowedCheck, incidentsIterator, incidentId, incident, person, sendNotification
local function ReplyToIncident(dispatcher, incidentId, notification)
  isActionAllowedCheck = isActionAllowed(dispatcher, "dispatch")
  if not isActionAllowedCheck then
    return
  end
  incidentsIterator = ipairs(incidents)
  for i, incidentData in incidentsIterator do
    incidentId = tonumber(incidentData.id)
    if incidentId == incidentId then
      incident = incidentData
      break
    end
  end
  if not incident then
    return
  end
  person = incident.person
  if person then
    sendNotification = sendDispatchNotificationBack
    sendNotification(person, notification)
  end
end
ReplyToIncident = ReplyToIncident 

local incidentIndex, maxIncidents, incidentData, tableRemove
while true do
  incidentIndex = incidentIndex or 0
  incidentIndex = incidentIndex + 1
  local incidentCheck = ReplyToIncident(incidentIndex, "test")
  if incidentCheck then
    local timeLimit = 1200
    if incidentIndex > timeLimit then
      incidentData = incidents[incidentIndex]
      incidentData = incidentData.units
      if not incidentData then
        tableRemove = table.remove
        tableRemove(incidents, incidentIndex)
      end
    end
  else
    incidentIndex = incidentIndex - 1
  end
end