local registerCallback, fetchFTOReportsCallback, fetchFTOReportDataByReportIdCallback, createFTOReportCallback, saveFTOReportCallback, approveFTOReportCallback, rejectFTOReportCallback

registerCallback = lib.callback.register
fetchFTOReportsCallback = function(source, data)
    if data then
        local reports = {}
        local query = data.query
        if not query then
            query = ""
        end
        local page = data.page
        local offset = (page - 1) * 10
        local whereClause = ""
        local params = {}
        if query ~= "" then
            whereClause = "WHERE LOWER(trainee_name) LIKE LOWER(?) OR LOWER(id) LIKE LOWER(?) OR LOWER(fto_name) LIKE LOWER(?) "
            local likeQuery = "%" .. query .. "%"
            params = {likeQuery, likeQuery, likeQuery}
        end
        local querySql = "SELECT * FROM mdt_police_fto_reports " .. whereClause .. " ORDER BY id DESC LIMIT 10 OFFSET ?"
        table.insert(params, offset)
        local results = MySQL.query.await(querySql, params)
        for _, result in ipairs(results) do
            local report = {
                id = result.id,
                traineeName = result.trainee_name,
                ftoName = result.fto_name,
                status = result.status,
                date = result.date,
                shift = result.shift,
                phase = result.phase,
                overallPerformance = result.overall_performance
            }
            table.insert(reports, report)
        end
        if query ~= "" then
            params[3] = nil
        end
        local countQuerySql = "SELECT COUNT(*) as count FROM mdt_police_fto_reports " .. whereClause
        local countResults = MySQL.query.await(countQuerySql, params)
        local totalCount = countResults[1].count
        return {ftoreports = reports, totalCount = totalCount}
    end
end
registerCallback("kartik-mdt:server:fetchFTOReports", fetchFTOReportsCallback)

fetchFTOReportDataByReportIdCallback = function(source, data)
    if data and data.ReportId then
        local reportId = data.ReportId
        local querySql = "SELECT * FROM mdt_police_fto_reports WHERE id = ?"
        local params = {reportId}
        local results = MySQL.query.await(querySql, params)
        if results[1] then
            local report = {
                id = results[1].id,
                categories = results[1].categories,
                strengths = results[1].strengths,
                areasForImprovement = results[1].areas_for_improvement,
                additionalComments = results[1].additional_comments or "",
                rejectionReason = results[1].rejection_reason or ""
            }
            return report
        else
            return nil
        end
    end
end
registerCallback("kartik-mdt:server:fetchFTOReportDataByReportId", fetchFTOReportDataByReportIdCallback)

createFTOReportCallback = function(source, data)
    if data and data.report then
        local report = data.report
        local traineeName = report.traineeName
        local ftoName = report.ftoName
        local date = report.date
        local shift = report.shift
        local phase = report.phase
        local categories = json.encode(report.categories)
        local overallPerformance = report.overallPerformance
        local strengths = report.strengths
        local areasForImprovement = report.areasForImprovement
        local additionalComments = report.additionalComments or ""
        local querySql = "INSERT INTO mdt_police_fto_reports (trainee_name, fto_name, date, shift, phase, categories, overall_performance, strengths, areas_for_improvement, additional_comments, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
        local params = {traineeName, ftoName, date, shift, phase, categories, overallPerformance, strengths, areasForImprovement, additionalComments, "pending"}
        local results = MySQL.query.await(querySql, params)
        local reportId = results.insertId
        SendDiscordLog("pd_fto", "\240\159\147\157 FTO Report Created", nil, 5763719, {
            {name = "Trainee", value = traineeName or "N/A", inline = true},
            {name = "FTO", value = ftoName or "N/A", inline = true},
            {name = "Date", value = date or os.date(), inline = true},
            {name = "Shift", value = shift or "N/A", inline = true},
            {name = "Phase", value = phase or "N/A", inline = true},
            {name = "Player", value = FormatPlayer(source), inline = false}
        })
        return {success = true, message = "Report added successfully.", reportId = reportId}
    else
        return {success = false, message = "No data received."}
    end
end
registerCallback("kartik-mdt:server:createFTOReport", createFTOReportCallback)

saveFTOReportCallback = function(source, data)
    if data and data.reportId and data.report then
        local reportId = data.reportId
        local report = data.report
        local traineeName = report.traineeName
        local ftoName = report.ftoName
        local date = report.date
        local shift = report.shift
        local phase = report.phase
        local categories = json.encode(report.categories)
        local overallPerformance = report.overallPerformance
        local strengths = report.strengths
        local areasForImprovement = report.areasForImprovement
        local additionalComments = report.additionalComments or ""
        local querySql = "UPDATE mdt_police_fto_reports SET trainee_name = ?, fto_name = ?, date = ?, shift = ?, phase = ?, categories = ?, overall_performance = ?, strengths = ?, areas_for_improvement = ?, additional_comments = ? WHERE id = ?"
        local params = {traineeName, ftoName, date, shift, phase, categories, overallPerformance, strengths, areasForImprovement, additionalComments, reportId}
        local results = MySQL.query.await(querySql, params)
        if results.affectedRows > 0 then
            SendDiscordLog("pd_fto", "\226\156\143\239\184\143 FTO Report Updated", nil, 3447003, {
                {name = "Trainee", value = traineeName or "N/A", inline = true},
                {name = "FTO", value = ftoName or "N/A", inline = true},
                {name = "Date", value = date or os.date(), inline = true},
                {name = "Phase", value = phase or "N/A", inline = true},
                {name = "Report ID", value = tostring(reportId), inline = true},
                {name = "Player", value = FormatPlayer(source), inline = false}
            })
            return {success = true, message = "Report saved successfully."}
        else
            return {success = false, message = "Failed to update the report."}
        end
    else
        return {success = false, message = "No data received."}
    end
end
registerCallback("kartik-mdt:server:saveFTOReport", saveFTOReportCallback)

approveFTOReportCallback = function(source, data)
    if data and data.reportId then
        local reportId = data.reportId
        local querySql = "UPDATE mdt_police_fto_reports SET status = 'approved' WHERE id = ?"
        local params = {reportId}
        local results = MySQL.query.await(querySql, params)
        if results.affectedRows > 0 then
            SendDiscordLog("pd_fto", "\226\156\133 FTO Report Approved", nil, 5763719, {
                {name = "Report ID", value = tostring(reportId), inline = true},
                {name = "Player", value = FormatPlayer(source), inline = false}
            })
            return {success = true, message = "Report approved successfully."}
        else
            return {success = false, message = "Failed to approve the report."}
        end
    else
        return {success = false, message = "No data received."}
    end
end
registerCallback("kartik-mdt:server:approveFTOReport", approveFTOReportCallback)

rejectFTOReportCallback = function(source, data)
    if data and data.reportId and data.rejectionReason then
        local reportId = data.reportId
        local rejectionReason = data.rejectionReason
        local querySql = "UPDATE mdt_police_fto_reports SET status = 'rejected', rejection_reason = ? WHERE id = ?"
        local params = {rejectionReason, reportId}
        local results = MySQL.query.await(querySql, params)
        if results.affectedRows > 0 then
            SendDiscordLog("pd_fto", "\226\157\140 FTO Report Rejected", nil, 15158332, {
                {name = "Report ID", value = tostring(reportId), inline = true},
                {name = "Reason", value = rejectionReason or "No reason provided", inline = false},
                {name = "Player", value = FormatPlayer(source), inline = false}
            })
            return {success = true, message = "Report rejected successfully."}
        else
            return {success = false, message = "Failed to reject the report."}
        end
    else
        return {success = false, message = "No data received."}
    end
end
registerCallback("kartik-mdt:server:rejectFTOReport", rejectFTOReportCallback)

FormatPlayer = function(source)
    local playerName = GetPlayerName(source)
    if not playerName then
        playerName = "Unknown"
    end
    return string.format("[%s] %s ", source, playerName)
end