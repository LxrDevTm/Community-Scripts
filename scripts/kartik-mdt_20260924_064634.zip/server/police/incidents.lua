local registerCallback, fetchIncidentsCallback, fetchIncidentDataByIncidentIdCallback, addNewIncidentCallback, saveIncidentCallback, deleteIncidentCallback

registerCallback = lib.callback.register
fetchIncidentsCallback = function(source, data)
    if data then
        local playerData = GetPlayerData(source)
        if not playerData then
            local result = {}
            result.incidents = {}
            result.totalCount = 0
            return result
        end
        local page = data.page
        local query = data.query
        if not query then
            query = ""
        end
        local offset = (page - 1) * 10
        local whereClause = ""
        local params = {}
        if query ~= "" then
            whereClause = "WHERE LOWER(title) LIKE LOWER(?) OR LOWER(incidentId) LIKE LOWER(?) "
            local param1 = "%" .. query .. "%"
            local param2 = "%" .. query .. "%"
            table.insert(params, param1)
            table.insert(params, param2)
        end
        local querySql = "SELECT * FROM mdt_police_incidents " .. whereClause .. " ORDER BY incidentId DESC"
        table.insert(params, offset)
        querySql = querySql .. " LIMIT 10 OFFSET ?"
        local results = MySQL.query.await(querySql, params)
        local incidents = {}
        for _, result in ipairs(results) do
            local incident = {}
            incident.incidentId = result.incidentId
            incident.title = result.title
            local officerName = "Unknown"
            if result.officerId then
                local citizenId = getCitizenIdFromUnitId(result.officerId)
                if citizenId then
                    local offlinePlayer = GetOfflinePlayerByCitizenId(citizenId)
                    if offlinePlayer then
                        officerName = offlinePlayer.name
                    end
                else
                    officerName = result.officerId
                end
            end
            incident.officerName = officerName
            incident.isLocked = result.isLocked
            if result.isLocked then
                local hasPermission = checkReportPermission(playerData.citizenId, result.incidentId, "incident", "police")
                incident.canAccessReport = not hasPermission
            end
            incident.lockReason = result.lock_reason or "No reason specified"
            incident.dateTime = result.dateTime
            incident.priority = result.priority
            incident.status = result.status
            incident.peopleInvolved = result.peopleInvolved
            incident.location = result.location
            table.insert(incidents, incident)
        end
        if query ~= "" then
            params[3] = nil
        end
        local countQuery = "SELECT COUNT(*) as count FROM mdt_police_incidents " .. whereClause
        local countResults = MySQL.query.await(countQuery, params)
        local totalCount = countResults[1].count
        local result = {}
        result.incidents = incidents
        result.totalCount = totalCount
        return result
    end
end
registerCallback("kartik-mdt:server:fetchIncidents", fetchIncidentsCallback)

fetchIncidentDataByIncidentIdCallback = function(source, data)
    if data then
        local incidentId = data.incidentId
        local query = "SELECT * FROM mdt_police_incidents WHERE incidentId = ?"
        local params = { incidentId }
        local results = MySQL.query.await(query, params)
        if #results == 0 then
            local result = {}
            result.success = false
            result.message = "No data found."
            return result
        end
        local result = results[1]
        if result.isLocked then
            local playerData = GetPlayerData(source)
            if not playerData then
                local result = {}
                result.success = false
                result.message = "No player data found."
                return result
            end
            local citizenId = playerData.citizenId
            local jobName = playerData.jobData.name
            local jobGrade = playerData.jobData.grade.level
            local hasPermission = checkReportPermission(citizenId, incidentId, "incident", "police", jobName, jobGrade)
            if not hasPermission then
                local result = {}
                result.success = false
                result.message = "No permission."
                return result
            end
        end
        local reportAccess = {}
        local members = result.members
        if members then
            local decodedMembers = json.decode(members)
            if type(decodedMembers) == "table" then
                for _, member in ipairs(decodedMembers) do
                    local offlinePlayer = GetOfflinePlayerByCitizenId(member)
                    if offlinePlayer then
                        local memberData = {}
                        memberData.id = member
                        memberData.name = offlinePlayer.name
                        table.insert(reportAccess, memberData)
                    end
                end
            end
        end
        local incidentData = {}
        incidentData.incidentId = incidentId
        incidentData.title = result.title or ""
        incidentData.priority = result.priority or ""
        incidentData.evidenceLockerNumber = result.evidence_locker
        incidentData.status = result.status or ""
        incidentData.dateTime = result.dateTime
        incidentData.description = result.description or ""
        incidentData.evidences = result.evidences or ""
        incidentData.peopleInvolved = result.peopleInvolved or ""
        incidentData.vehiclesInvolved = result.vehiclesInvolved or ""
        incidentData.timeline = result.timeline or ""
        incidentData.reportAccess = reportAccess or {}
        local result = {}
        result.success = true
        result.data = incidentData
        return result
    else
        local result = {}
        result.success = false
        result.message = "No data found."
        return result
    end
end
registerCallback("kartik-mdt:server:fetchIncidentDataByIncidentId", fetchIncidentDataByIncidentIdCallback)

addNewIncidentCallback = function(source, data)
    if data then
        local incidentToAdd = data.incidentToAdd
        if incidentToAdd then
            local title = incidentToAdd.title
            local location = incidentToAdd.location
            local priority = incidentToAdd.priority
            local description = incidentToAdd.description
            local dateTime = incidentToAdd.dateTime
            local officerId = incidentToAdd.officerId
            local evidences = json.encode(incidentToAdd.evidences)
            local peopleInvolved = json.encode(incidentToAdd.peopleInvolved)
            local vehiclesInvolved = json.encode(incidentToAdd.vehiclesInvolved)
            local status = incidentToAdd.status
            local timeline = json.encode(incidentToAdd.timeline)
            local query = "INSERT INTO mdt_police_incidents (title, officerId, location, priority, description, dateTime, evidences, peopleInvolved, vehiclesInvolved, status, timeline) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
            local params = { title, officerId, location, priority, description, dateTime, evidences, peopleInvolved, vehiclesInvolved, status, timeline }
            local results = MySQL.query.await(query, params)
            local incidentId = results.insertId
            SendDiscordLog("pd_incident", "\240\159\147\132 Incident Created", nil, 8311585, {
                { name = "Incident ID", value = tostring(incidentId), inline = true },
                { name = "Title", value = title or "N/A", inline = true },
                { name = "Priority", value = priority or "N/A", inline = true },
                { name = "Status", value = status or "N/A", inline = true },
                { name = "Location", value = location or "N/A", inline = true },
                { name = "Player", value = FormatPlayer(source), inline = false }
            })
            local result = {}
            result.success = true
            result.message = "Incident added successfully."
            result.incidentId = incidentId
            return result
        end
    end
    local result = {}
    result.success = false
    result.message = "No data received."
    return result
end
registerCallback("kartik-mdt:server:addNewIncident", addNewIncidentCallback)

saveIncidentCallback = function(source, data)
    if data then
        local incidentId = data.incidentId
        if incidentId then
            local title = data.title
            local location = data.location
            local description = data.description
            local evidences = json.encode(data.evidences)
            local peopleInvolved = json.encode(data.peopleInvolved)
            local vehiclesInvolved = json.encode(data.vehiclesInvolved)
            local status = data.status
            local priority = data.priority
            local evidenceLockerNumber = data.evidenceLockerNumber
            local timeline = json.encode(data.timeline)
            local query = "UPDATE mdt_police_incidents SET title = ?, location = ?, evidence_locker = ?, description = ?, evidences = ?, peopleInvolved = ?, vehiclesInvolved = ?, status = ?, priority = ?, timeline = ? WHERE incidentId = ?"
            local params = { title, location, evidenceLockerNumber, description, evidences, peopleInvolved, vehiclesInvolved, status, priority, timeline, incidentId }
            local results = MySQL.query.await(query, params)
            if results.affectedRows > 0 then
                SendDiscordLog("pd_incident", "\226\156\143\239\184\143 Incident Updated", nil, 3447003, {
                    { name = "Incident ID", value = tostring(incidentId), inline = true },
                    { name = "Title", value = title or "N/A", inline = true },
                    { name = "Priority", value = priority or "N/A", inline = true },
                    { name = "Status", value = status or "N/A", inline = true },
                    { name = "Location", value = location or "N/A", inline = true },
                    { name = "Player", value = FormatPlayer(source), inline = false }
                })
                local result = {}
                result.success = true
                result.message = "Incident saved successfully."
                return result
            else
                local result = {}
                result.success = false
                result.message = "Failed to update the incident."
                return result
            end
        end
    end
    local result = {}
    result.success = false
    result.message = "No data received."
    return result
end
registerCallback("kartik-mdt:server:saveIncident", saveIncidentCallback)

deleteIncidentCallback = function(source, data)
    if data then
        local incidentId = data.incidentId
        if incidentId then
            local query = "DELETE FROM mdt_police_incidents WHERE incidentId = ?"
            local params = { incidentId }
            local results = MySQL.query.await(query, params)
            if results.affectedRows > 0 then
                SendDiscordLog("pd_incident", "\240\159\151\145\239\184\143 Incident Deleted", nil, 15158332, {
                    { name = "Incident ID", value = tostring(incidentId), inline = true },
                    { name = "Player", value = FormatPlayer(source), inline = false }
                })
                local result = {}
                result.success = true
                result.message = "Incident deleted successfully."
                return result
            end
        end
    end
    local result = {}
    result.success = false
    result.message = "Failed to delete the incident."
    return result
end
registerCallback("kartik-mdt:server:deleteIncident", deleteIncidentCallback)

local deleteIncidentResponse = {}
if data then
  if deleteIncident then
    deleteIncidentResponse.success = true
    deleteIncidentResponse.message = "Incident deleted successfully."
    return deleteIncidentResponse
  else
    deleteIncidentResponse.success = false
    deleteIncidentResponse.message = "Failed to delete the incident."
    return deleteIncidentResponse
  end
else
  local noDataResponse = {}
  noDataResponse.success = false
  noDataResponse.message = "No data received."
  return noDataResponse
end
ESCROWSHX0_1(ESCROWSHX1_1, ESCROWSHX2_1)