local registerCallback, fetchUnitData, setJob, SendDiscordLog, FormatPlayer
registerCallback = lib.callback.register
fetchUnitData = lib.callback.register("kartik-mdt:server:fetchOfficers", function(source, data)
  if not data then
    return
  end
  local page = data.page or 1
  local query = data.query or ""
  local offset = (page - 1) * 10
  local unitData, totalCount = fetchUnitData(query, offset, "police")
  local result = {}
  result.officers = unitData
  result.totalCount = totalCount
  return result
end)

registerCallback = lib.callback.register
registerCallback("kartik-mdt:server:addNewOfficers", function(source, data)
  if data then
    local officer = data.officer
    if officer then
      local id = officer.id or ""
      local citizenId = officer.citizenId or ""
      local department = officer.department or "police"
      local rank = officer.rank or ""
      local status = officer.status or ""
      local dutyRecords = officer.dutyRecords or {}
      local serviceHistory = officer.serviceHistory or {}
      local currentAssignments = officer.currentAssignments or {}
      if type(serviceHistory) == "string" then
        serviceHistory = json.decode(serviceHistory) or serviceHistory
        if not serviceHistory then
          serviceHistory = {}
        end
      end
      local query = "SELECT * FROM mdt_units WHERE citizenid = ?"
      local params = {citizenId}
      local result = MySQL.query.await(query, params)
      if result and #result > 0 then
        local isFired = result[1].isFired
        if isFired == 0 then
          return {success = false, message = "Failed to hire the officer: Officer is already active."}
        else
          local date = os.date("%Y-%m-%d")
          local event = "Rehired to department: " .. department
          table.insert(serviceHistory, {date = date, event = event})
          serviceHistory = json.encode(serviceHistory)
          query = [[
            UPDATE mdt_units
            SET id = ?, citizenid = ?, department = ?, currentAssignments = ?, 
                dutyRecords = ?, serviceHistory = ?, status = ?, isFired = 0
            WHERE citizenid = ?
          ]]
          params = {id, citizenId, department, json.encode(currentAssignments), json.encode(dutyRecords), serviceHistory, status, citizenId}
          result = MySQL.query.await(query, params)
          if result and result.affectedRows > 0 then
            setJob(citizenId, department, rank)
            SendDiscordLog("pd_officer", "\240\159\145\174 Officer Rehired", nil, 3447003, {
              {name = "Citizen ID", value = citizenId, inline = true},
              {name = "Department", value = department, inline = true},
              {name = "Rank", value = rank or "N/A", inline = true},
              {name = "Player", value = FormatPlayer(source), inline = false}
            })
            return {success = true, message = "Rehired successfully."}
          end
        end
      else
        query = "INSERT INTO mdt_units (id, citizenid, department, currentAssignments, dutyRecords, serviceHistory, status) VALUES (?, ?, ?, ?, ?, ?, ?)"
        params = {id, citizenId, department, json.encode(currentAssignments), json.encode(dutyRecords), json.encode(serviceHistory), status}
        result = MySQL.query.await(query, params)
        if result and result.affectedRows > 0 then
          setJob(citizenId, department, rank)
          SendDiscordLog("pd_officer", "\226\156\133 Officer Hired", nil, 5763719, {
            {name = "Citizen ID", value = citizenId, inline = true},
            {name = "Department", value = department, inline = true},
            {name = "Rank", value = rank or "N/A", inline = true},
            {name = "Player", value = FormatPlayer(source), inline = false}
          })
          return {success = true, message = "Officer hired successfully."}
        end
      end
    end
  else
    return {success = false, message = "No data received."}
  end
end)

registerCallback = lib.callback.register
registerCallback("kartik-mdt:server:fetchOfficerDataByOfficerId", function(source, data)
  if data then
    local officerId = data.OfficerId
    local query = "SELECT * FROM mdt_units WHERE id = ?"
    local params = {officerId}
    local result = MySQL.query.await(query, params)
    if result and #result > 0 then
      local dutyRecords = json.decode(result[1].dutyRecords) or {}
      if #dutyRecords > 10 then
        dutyRecords = table.unpack(dutyRecords, #dutyRecords - 9, #dutyRecords)
      end
      local currentAssignments = result[1].currentAssignments or ""
      local serviceHistory = result[1].serviceHistory or ""
      local totalHours = result[1].totalHours or 0.0
      return {
        currentAssignments = currentAssignments,
        serviceHistory = serviceHistory,
        dutyRecords = dutyRecords,
        totalHours = totalHours
      }
    end
  end
end)

registerCallback = lib.callback.register
registerCallback("kartik-mdt:server:updateOfficerRank", function(source, data)
  if data then
    local officerId = data.officerId
    local citizenId = data.citizenId
    local rank = data.rank
    local department = data.department
    local serviceHistory = data.serviceHistory
    serviceHistory = json.encode(serviceHistory)
    local query = "UPDATE mdt_units SET serviceHistory = ?, department = ?, callsign = NULL WHERE id = ?"
    local params = {serviceHistory, department, officerId}
    local result = MySQL.query.await(query, params)
    if result then
      setJob(citizenId, department, rank)
      SendDiscordLog("pd_officer", "\240\159\147\138 Officer Rank Updated", nil, 3447003, {
        {name = "Citizen ID", value = citizenId or "N/A", inline = true},
        {name = "New Rank", value = rank or "N/A", inline = true},
        {name = "Department", value = department or "police", inline = true},
        {name = "Player", value = FormatPlayer(source), inline = false}
      })
      return {success = true, message = "Updated"}
    end
  end
end)

registerCallback = lib.callback.register
registerCallback("kartik-mdt:server:addOfficerAssignment", function(source, data)
  if data then
    local officerId = data.officerId
    local currentAssignments = json.encode(data.currentAssignments)
    local query = "UPDATE mdt_units SET currentAssignments = ? WHERE id = ?"
    local params = {currentAssignments, officerId}
    local result = MySQL.query.await(query, params)
    if result then
      SendDiscordLog("pd_officer", "\240\159\151\130\239\184\143 Officer Assignments Updated", nil, 3447003, {
        {name = "Officer ID", value = tostring(officerId), inline = true},
        {name = "Player", value = FormatPlayer(source), inline = false}
      })
      return {success = true, message = "Updated"}
    end
  end
end)

registerCallback = lib.callback.register
registerCallback("kartik-mdt:server:fireOfficer", function(source, data)
  if data then
    local citizenId = data.citizenId
    local serviceHistory = json.encode(data.serviceHistory)
    local query = "UPDATE mdt_units SET isFired = ?, status = ?, serviceHistory = ?, callsign = NULL WHERE citizenid = ?"
    local params = {1, "off-duty", serviceHistory, citizenId}
    local result = MySQL.query.await(query, params)
    if result then
      setJob(citizenId, "unemployed", 0)
      SendDiscordLog("pd_officer", "\240\159\148\165 Officer Fired", nil, 15158332, {
        {name = "Citizen ID", value = citizenId or "N/A", inline = true},
        {name = "New Job", value = "unemployed", inline = true},
        {name = "Player", value = FormatPlayer(source), inline = false}
      })
      return {success = true, message = "Updated"}
    end
  end
end)

registerCallback = lib.callback.register
registerCallback("kartik-mdt:server:updateOfficertags", function(source, data)
  if data then
    local tags = data.tags
    if tags then
      local citizenId = data.citizenId
      local tags = json.encode(tags)
      local query = "UPDATE mdt_units SET tags = ? WHERE citizenid = ?"
      local params = {tags, citizenId}
      local result = MySQL.query.await(query, params)
      if result then
        SendDiscordLog("pd_officer", "\240\159\148\165 Officer Tags Updated", nil, 15158332, {
          {name = "Citizen ID", value = citizenId or "N/A", inline = true},
          {name = "New Tags", value = tags, inline = true},
          {name = "Player", value = FormatPlayer(source), inline = false}
        })
      end
    end
  end
end)

local officerType = "pd_officer"
local notificationMessage = "\240\159\143\183\239\184\143 Officer Tags Updated"
local data = {}
local citizenIdField = {}
citizenIdField.name = "Citizen ID"
citizenIdField.value = ESCROWSHX2_2 or "N/A"
citizenIdField.inline = true
local tagsField = {}
tagsField.name = "Tags"
local tags = ESCROWSHX1_2.tags or {}
tagsField.value = table.concat(tags, ", ")
tagsField.inline = false
local playerField = {}
playerField.name = "Player"
playerField.value = FormatPlayer(ESCROWSHX0_2)
playerField.inline = false
data[1] = citizenIdField
data[2] = tagsField
data[3] = playerField
ESCROWSHX7_2(officerType, notificationMessage, nil, 8311585, data)
local result = {}
result.success = true
result.message = "Updated Tags"
return result