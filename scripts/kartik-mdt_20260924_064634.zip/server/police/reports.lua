local callback, eventName, fetchReports
callback = lib.callback
callback = callback.register
eventName = "kartik-mdt:server:fetchReports"
function fetchReports(player, data)
    if data then
        local page = data.page
        local query = data.query
        if not query then
            query = ""
        end
        local offset = (page - 1) * 10
        local whereClause = ""
        local params = {}
        if query ~= "" then
            whereClause = "WHERE LOWER(name) LIKE LOWER(?) OR LOWER(reportId) LIKE LOWER(?) "
            params = {"%" .. query .. "%", "%" .. query .. "%"}
        end
        local querySql = "SELECT * FROM mdt_police_reports " .. whereClause .. " ORDER BY reportId DESC LIMIT 10 OFFSET ?"
        table.insert(params, offset)
        local results = MySQL.query.await(querySql, params)
        local reports = {}
        for _, row in ipairs(results) do
            local report = {}
            report.reportId = row.reportId
            report.reportName = row.name
            report.dateTime = row.dateTime
            report.officerName = "unknown"
            if row.officerId then
                local citizenId = getCitizenIdFromUnitId(row.officerId)
                if citizenId then
                    local officerName = pcall(GetOfflinePlayerByCitizenId, citizenId)
                    if officerName then
                        report.officerName = officerName.name or report.officerName
                    end
                else
                    report.officerName = row.officerId
                end
            end
            report.isLocked = row.isLocked
            if report.isLocked then
                local playerData = GetPlayerData(player)
                if playerData then
                    local hasPermission = checkReportPermission(playerData.citizenId, row.reportId, "report", "police")
                    report.canAccessReport = not hasPermission
                end
            end
            report.lockReason = row.lock_reason or "No reason specified"
            report.category = row.category
            report.peopleInvolved = row.peopleInvolved
            report.location = row.location
            table.insert(reports, report)
        end
        if query ~= "" then
            params[3] = nil
        end
        local countSql = "SELECT COUNT(*) as count FROM mdt_police_reports " .. whereClause
        local countResults = MySQL.query.await(countSql, params)
        local totalCount = countResults[1].count
        return { reports = reports, totalCount = totalCount }
    end
end
callback(eventName, fetchReports)
callback = lib.callback
callback = callback.register
eventName = "kartik-mdt:server:fetchReportDataByReportId"
function fetchReportDataByReportId(player, data)
    if data then
        local reportId = data.reportId
        local querySql = "SELECT * FROM mdt_police_reports WHERE reportId = ?"
        local params = { reportId }
        local results = MySQL.query.await(querySql, params)
        if #results > 0 then
            local report = results[1]
            if report.isLocked then
                local playerData = GetPlayerData(player)
                if playerData then
                    local hasPermission = checkReportPermission(playerData.citizenId, reportId, "report", "police", playerData.jobData.name, playerData.jobData.grade.level)
                    if not hasPermission then
                        return { success = false, message = "No permission." }
                    end
                end
            end
            local reportAccess = {}
            local members = report.members
            if members then
                members = json.decode(members)
                if type(members) == "table" then
                    for _, member in ipairs(members) do
                        local memberData = GetOfflinePlayerByCitizenId(member)
                        if memberData then
                            table.insert(reportAccess, { id = member, name = memberData.name })
                        end
                    end
                end
            end
            return {
                success = true,
                data = {
                    reportId = reportId,
                    reportName = report.name,
                    officerId = report.officerId,
                    evidenceLockerNumber = report.evidence_locker,
                    dateTime = report.dateTime,
                    location = report.location or "",
                    description = report.description or "",
                    evidences = report.evidences or "",
                    peopleInvolved = report.peopleInvolved or "",
                    vehiclesInvolved = report.vehiclesInvolved or "",
                    reportAccess = reportAccess or {}
                }
            }
        else
            return { success = false, message = "No data found." }
        end
    end
end
callback(eventName, fetchReportDataByReportId)
callback = lib.callback
callback = callback.register
eventName = "kartik-mdt:server:fetchLockerItems"
function fetchLockerItems(player, data)
    if data then
        local lockerNumber = data.lockerNumber
        local stashId = GetEvidenceStashId(lockerNumber)
        if stashId then
            local items = getStashItems("evidence_" .. lockerNumber)
            local lockerItems = {}
            for item, itemData in pairs(items) do
                local metadata = {}
                if formatMetadata then
                    metadata = formatMetadata(itemData.metadata)
                end
                table.insert(lockerItems, {
                    name = itemData.name,
                    label = itemData.label,
                    amount = itemData.count or itemData.amount,
                    description = itemData.label,
                    metadata = metadata
                })
            end
            return { lockerItems = lockerItems }
        end
    end
end
callback(eventName, fetchLockerItems)
callback = lib.callback
callback = callback.register
eventName = "kartik-mdt:server:addNewReport"
function addNewReport(player, data)
    if data then
        local reportToAdd = data.reportToAdd
        if reportToAdd then
            local reportName = reportToAdd.reportName
            local officerId = reportToAdd.officerId
            local location = reportToAdd.location
            local category = reportToAdd.category
            local description = reportToAdd.description
            local dateTime = reportToAdd.dateTime
            local evidences = json.encode(reportToAdd.evidences)
            local peopleInvolved = json.encode(reportToAdd.peopleInvolved)
            local vehiclesInvolved = json.encode(reportToAdd.vehiclesInvolved)
            local querySql = "INSERT INTO mdt_police_reports (name, officerId, location, category, description, dateTime, evidences, peopleInvolved, vehiclesInvolved) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)"
            local params = { reportName, officerId, location, category, description, dateTime, evidences, peopleInvolved, vehiclesInvolved }
            local results = MySQL.query.await(querySql, params)
            local reportId = results.insertId
            SendDiscordLog("pd_report", "\240\159\147\139 New Report Created", nil, 3066993, {
                { name = "\240\159\145\174 Officer ID", value = tostring(officerId), inline = true },
                { name = "\240\159\147\132 Report Name", value = reportName or "Unknown", inline = true },
                { name = "\240\159\147\141 Location", value = location or "N/A", inline = true },
                { name = "\240\159\143\183\239\184\143 Category", value = category or "N/A", inline = true },
                { name = "\240\159\149\146 Date/Time", value = os.date("%Y-%m-%d %H:%M:%S"), inline = false }
            })
            return { success = true, message = "Report added successfully.", reportId = reportId }
        end
    end
    return { success = false, message = "No data received." }
end
callback(eventName, addNewReport)
callback = lib.callback
callback = callback.register
eventName = "kartik-mdt:server:saveCurrentReport"
function saveCurrentReport(player, data)
    if data then
        local reportId = data.reportId
        if reportId then
            local reportName = data.reportName
            local location = data.location
            local description = data.description
            local evidences = json.encode(data.evidences)
            local peopleInvolved = json.encode(data.peopleInvolved)
            local vehiclesInvolved = json.encode(data.vehiclesInvolved)
            local evidenceLockerNumber = data.evidenceLockerNumber
            local querySql = "UPDATE mdt_police_reports SET name = ?, location = ?, evidence_locker = ?, description = ?, evidences = ?, peopleInvolved = ?, vehiclesInvolved = ? WHERE reportId = ?"
            local params = { reportName, location, evidenceLockerNumber, description, evidences, peopleInvolved, vehiclesInvolved, reportId }
            local results = MySQL.query.await(querySql, params)
            if results.affectedRows > 0 then
                SendDiscordLog("pd_report", "\226\156\143\239\184\143 Report Updated", nil, 3447003, {
                    { name = "Report ID", value = tostring(reportId), inline = true },
                    { name = "Name", value = reportName or "N/A", inline = true },
                    { name = "Location", value = location or "N/A", inline = true },
                    { name = "Officer", value = GetPlayerName(player) or "Source: " .. tostring(player), inline = true },
                    { name = "Source", value = tostring(player), inline = true }
                })
                return { success = true, message = "Report saved successfully." }
            else
                return { success = false, message = "Failed to update the report." }
            end
        end
    end
    return { success = false, message = "No data received." }
end
callback(eventName, saveCurrentReport)
callback = lib.callback
callback = callback.register
eventName = "kartik-mdt:server:deleteReport"
function deleteReport(player, data)
    -- TO DO: implement delete report functionality
end
callback(eventName, deleteReport)

local lib = lib
local callback = lib.callback
local register = callback.register

local function deleteReport(player, data)
    if data then
        local reportId = data.reportId
        if reportId then
            local query = "DELETE FROM mdt_police_reports WHERE reportId = ?"
            local params = {reportId}
            local result = MySQL.query.await(query, params)
            if result.affectedRows > 0 then
                local logData = {
                    "pd_report",
                    "\240\159\151\145\239\184\143 Report Deleted",
                    nil,
                    15158332,
                    {
                        {name = "Report ID", value = tostring(reportId), inline = true},
                        {name = "Officer", value = GetPlayerName(player) or "Source: " .. tostring(player), inline = true}
                    }
                }
                SendDiscordLog(unpack(logData))
                return {success = true, message = "Report deleted successfully."}
            else
                return {success = false, message = "Failed to delete the report."}
            end
        end
    end
    return {success = false, message = "No data received."}
end

register("kartik-mdt:server:deleteReport", deleteReport)

local function jailPerson(player, data)
    if data then
        local citizenId = data.citizenId
        if citizenId then
            local jailSentence = data.jailSentence
            if jailSentence then
                local success, result = pcall(JailPerson, player, citizenId, jailSentence)
                if success then
                    local logData = {
                        "jail",
                        "\240\159\154\147 Jail Sentence Applied",
                        15105570,
                        {
                            {name = "Citizen ID", value = citizenId, inline = true},
                            {name = "Sentence (months)", value = tostring(jailSentence), inline = true},
                            {name = "Officer", value = GetPlayerName(player) or "Source: " .. tostring(player), inline = true}
                        }
                    }
                    SendDiscordLog(unpack(logData))
                    return result
                else
                    return DefaultJailPerson(player, citizenId, jailSentence)
                end
            end
        end
    end
    return {success = false, message = "No data received."}
end

register("kartik-mdt:server:jailPerson", jailPerson)

local function finePerson(player, data)
    if data then
        local citizenId = data.citizenId
        if citizenId then
            local fineAmount = data.fineAmount
            if fineAmount then
                local success, result = pcall(FinePerson, player, citizenId, fineAmount)
                if success then
                    local logData = {
                        "fine",
                        "\240\159\146\176 Fine Issued",
                        15844367,
                        {
                            {name = "Citizen ID", value = citizenId, inline = true},
                            {name = "Fine Amount", value = "$" .. tostring(fineAmount), inline = true},
                            {name = "Officer", value = GetPlayerName(player) or "Source: " .. tostring(player), inline = true}
                        }
                    }
                    SendDiscordLog(unpack(logData))
                    return result
                else
                    return DefaultFinePerson(player, citizenId, fineAmount)
                end
            end
        end
    end
    return {success = false, message = "No data received."}
end

register("kartik-mdt:server:finePerson", finePerson)

local function fetchEvidenceCases(player, data)
    if data then
        local cases = fetchEvidenceLockers(data)
        return {success = true, cases = cases.cases, totalCount = cases.totalCount}
    end
    return {success = false, message = "No data received."}
end

register("kartik-mdt:server:fetchEvidenceCases", fetchEvidenceCases)