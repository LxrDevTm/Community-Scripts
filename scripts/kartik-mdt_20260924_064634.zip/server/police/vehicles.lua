local trimString, addBolo, clearBolo
function trimString(input)
  local input = input
  local pattern = "^%s*(.-)%s*$"
  return input:match(pattern)
end

function addBolo(plate)
  if plate then
    local query = "SELECT * FROM mdt_vehicles WHERE plate = ?"
    local MySQL = MySQL.query.await
    local result = MySQL(query, {plate})
    local vehicle = next(result)
    if vehicle then
      local status = vehicle.status
      if status == "bolo" then
        return {success = false, message = "Vehicle is already marked as BOLO."}
      end
      query = "UPDATE mdt_vehicles SET status = 'bolo' WHERE plate = ?"
      local result = MySQL(query, {plate})
      if result.affectedRows > 0 then
        return {success = true, message = "Bolo added successfully"}
      else
        return {success = false, message = "Failed to add bolo."}
      end
    else
      local owner = GetVehicleOwner(plate)
      if owner then
        query = "INSERT INTO mdt_vehicles (plate, status) VALUES (?, 'bolo')"
        MySQL(query, {plate})
        return {success = true, message = "Bolo added successfully"}
      else
        return {success = false, message = "Owner not found in database."}
      end
    end
  else
    return {success = false, message = "No data received."}
  end
end

function clearBolo(plate)
  if plate then
    local query = "SELECT * FROM mdt_vehicles WHERE plate = ?"
    local MySQL = MySQL.query.await
    local result = MySQL(query, {plate})
    local vehicle = next(result)
    if vehicle then
      local status = vehicle.status
      if status ~= "bolo" then
        return {success = false, message = "Vehicle is not marked as BOLO."}
      end
      query = "UPDATE mdt_vehicles SET status = 'clear' WHERE plate = ?"
      local result = MySQL(query, {plate})
      if result.affectedRows > 0 then
        return {success = true, message = "Bolo removed successfully"}
      else
        return {success = false, message = "Failed to remove bolo."}
      end
    else
      local owner = GetVehicleOwner(plate)
      if owner then
        query = "INSERT INTO mdt_vehicles (plate, status) VALUES (?, 'clear')"
        MySQL(query, {plate})
        return {success = true, message = "Bolo removed successfully"}
      else
        return {success = false, message = "Owner not found in database."}
      end
    end
  else
    return {success = false, message = "No data received."}
  end
end

exports("addBolo", addBolo)
exports("clearBolo", clearBolo)

RegisterNetEvent("kartik-mdt:server:addBolo", function(plate)
  local trimmedPlate = trimString(plate)
  addBolo(trimmedPlate)
end)

RegisterNetEvent("kartik-mdt:server:clearBolo", function(plate)
  local trimmedPlate = trimString(plate)
  clearBolo(trimmedPlate)
end)

lib.callback.register("kartik-mdt:server:fetchVehicles", function(data, cb)
  if data then
    local page = data.page or 1
    local query = data.query or ""
    local offset = (page - 1) * 10
    local limit = 10
    local vehicles = fetchVehiclesFromPlayerTable(query, offset, limit)
    local count = countVehiclesFromPlayerTable(query)
    return {vehiclesData = vehicles, totalCount = count}
  end
end)

lib.callback.register("kartik-mdt:server:getVehicleDataByPlate", function(data, cb)
  if data then
    local plate = data.id
    local vehicle = fetchVehicleByPlate(plate)
    return {data = vehicle, success = true}
  end
end)

lib.callback.register("kartik-mdt:server:fetchVehicleDataByPlate", function(data, cb)
  if data then
    local plate = data.plate
    local query = "SELECT * FROM mdt_vehicles WHERE plate = ?"
    local params = {plate}
    local MySQL = MySQL.query.await
    local result = MySQL(query, params)
    local vehicle = next(result)
    if not vehicle then
      query = "INSERT INTO mdt_vehicles (plate, status) VALUES (?, 'clear')"
      MySQL(query, params)
      vehicle = {plate = plate, status = "clear"}
    end
    vehicle.plate = vehicle.plate or plate
    vehicle.status = vehicle.status or "clear"
    vehicle.sightings = vehicle.sightings or ""
    vehicle.photo = vehicle.photo
    return vehicle
  else
    return nil
  end
end)

lib.callback.register("kartik-mdt:server:fetchVehiclesStrikes", function(data, cb)
  if data then
    local plate = data.plate
    local query = "SELECT * FROM mdt_vehicles_strikes WHERE plate = ?"
    local params = {plate}
    local MySQL = MySQL.query.await
    local result = MySQL(query, params)
    local strikes = next(result)
    if not strikes then
      return {}
    end
    return result
  else
    return {}
  end
end)

lib.callback.register("kartik-mdt:server:fetchVehiclesReports", function(data, cb)
  if data then
    local plate = data.plate
    local query = [[
      SELECT * FROM mdt_police_reports 
      WHERE JSON_CONTAINS(vehiclesInvolved, '{"plate": "]] .. plate .. [["
    '}$')
    ]]
    local MySQL = MySQL.query.await
    local result = MySQL(query)
    if result then
      local reports = {}
      for _, report in ipairs(result) do
        local reportData = {
          reportId = report.reportId,
          reportName = report.name or "Unknown",
          dateTime = report.dateTime,
          peopleInvolved = report.peopleInvolved
        }
        table.insert(reports, reportData)
      end
      return reports
    end
  end
end)

lib.callback.register("kartik-mdt:server:updateVehicleStatus", function(data, cb)
  if data then
    local plate = data.plate
    if plate then
      local status = data.status
      local query = "UPDATE mdt_vehicles SET status = ? WHERE plate = ?"
      local params = {status, plate}
      local MySQL = MySQL.query.await
      local result = MySQL(query, params)
      if result.affectedRows > 0 then
        if status == "bolo" then
          GlobalState.wanted_vehicles[plate] = true
        else
          GlobalState.wanted_vehicles[plate] = nil
        end
        SendDiscordLog("vehicle", "\240\159\154\152 Vehicle Status Updated", nil, 3447003, {
          {name = "Plate", value = plate, inline = true},
          {name = "New Status", value = status, inline = true},
          {name = "Player", value = FormatPlayer(data.player), inline = false}
        })
        return {success = true, message = "Vehicle status updated successfully."}
      else
        return {success = false, message = "Failed to update the vehicle status."}
      end
    end
  else
    return {success = false, message = "No data received."}
  end
end)

lib.callback.register("kartik-mdt:server:addVehicleReportSightings", function(data, cb)
  if data then
    local plate = data.plate
    if plate then
      local sightings = data.sightings
      local query = "UPDATE mdt_vehicles SET sightings = ? WHERE plate = ?"
      local params = {json.encode(sightings), plate}
      local MySQL = MySQL.query.await
      local result = MySQL(query, params)
      if result.affectedRows > 0 then
        SendDiscordLog("vehicle", "\240\159\145\129\239\184\143 Vehicle Sightings Added", nil, 10181046, {
          {name = "Plate", value = plate, inline = true},
          {name = "Sightings Count", value = tostring(#sightings), inline = true},
          {name = "Player", value = FormatPlayer(data.player), inline = false}
        })
        return {success = true, message = "sightings inserted successfully."}
      else
        return {success = false, message = "Failed to insert the sightings."}
      end
    end
  else
    return {success = false, message = "No data received."}
  end
end)

lib.callback.register("kartik-mdt:server:updateVehiclePhoto", function(data, cb)
  if data then
    local plate = data.plate
    local photo = data.photo
    local query = "UPDATE mdt_vehicles SET photo = ? WHERE plate = ?"
    local params = {photo, plate}
    local MySQL = MySQL.query.await
    local result = MySQL(query, params)
    if result.affectedRows > 0 then
      SendDiscordLog("vehicle", "\240\159\147\183 Vehicle Photo Updated", nil, 10181046, {
        {name = "Plate", value = plate, inline = true},
        {name = "Photo", value = photo, inline = true},
        {name = "Player", value = FormatPlayer(data.player), inline = false}
      })
      return {success = true, message = "Vehicle photo updated successfully."}
    else
      return {success = false, message = "Failed to update the vehicle photo."}
    end
  end
end)

local vehicleStrikeResult = nil
local vehicleStrikePoints = 16763904
local vehicleStrikeData = {}
local vehicleStrikePlateData = {}
vehicleStrikePlateData.name = "Plate"
vehicleStrikePlateData.value = vehicleStrikeResult
vehicleStrikePlateData.inline = true
local vehicleStrikePlayerData = {}
vehicleStrikePlayerData.name = "Player"
local formattedPlayer = FormatPlayer
local player = vehicleStrikeResult
formattedPlayer = formattedPlayer(player)
vehicleStrikePlayerData.value = formattedPlayer
vehicleStrikePlayerData.inline = false
vehicleStrikeData[1] = vehicleStrikePlateData
vehicleStrikeData[2] = vehicleStrikePlayerData
AddVehicleStrike(vehicleStrikeResult, vehicleStrikePoints, vehicleStrikeData)
local result = {}
result.success = true
result.message = "Photo Changed Successfully"
return result
function GetBoloStatus(plate)
  local mysql = MySQL.query.await
  local query = "SELECT plate, status FROM mdt_vehicles WHERE plate = @plate"
  local params = {["@plate"] = plate}
  local result = mysql(query, params)
  if result and result[1] then
    local status = result[1].status
    if status == "bolo" then
      return true
    end
  end
  return false
end
function GetWarrantStatus(citizenId)
  local mysql = MySQL.query.await
  local query = "SELECT warrant FROM mdt_profiles WHERE citizenid = @citizenId"
  local params = {["@citizenId"] = citizenId}
  local result = mysql(query, params)
  if result and result[1] then
    local warrant = result[1].warrant
    if warrant == 1 then
      return true
    end
  end
  return false
end
function GetWantedVehicles()
  local mysql = MySQL.query.await
  local query = "SELECT plate FROM mdt_vehicles WHERE status = ?"
  local params = {"bolo"}
  local result = mysql(query, params)
  if result then
    local wantedVehicles = {}
    for _, vehicle in ipairs(result) do
      wantedVehicles[vehicle.plate] = true
    end
    return wantedVehicles
  end
  return {}
end
CreateThread(function()
  Wait(10000)
  local wantedVehicles = GetWantedVehicles()
  GlobalState.wanted_vehicles = wantedVehicles
end)
lib.callback.register("kartik-mdt:server:addVehicleStrike", function(player, data)
  if data and data.plate and data.strike then
    local plate = data.plate
    local strike = data.strike
    local points = strike.points
    if not points then
      strike.points = 1
    end
    local pointsType = type(strike.points)
    if pointsType ~= "number" then
      strike.points = tonumber(strike.points)
    end
    strike.points = math.floor(strike.points)
    local config = Config.VehicleStrikePoints
    if not config then
      config = 10
    end
    if strike.points < 1 then
      strike.points = 1
    end
    if config < strike.points then
      strike.points = config
    end
    if not strike.expiryDate then
      strike.expiryDate = os.date("%Y-%m-%dT%H:%M:%S.000Z", os.time() + 2592000)
    end
    if strike.reason and strike.location and strike.status then
      local query = "INSERT INTO mdt_vehicles_strikes (plate, points, reason, issuingOfficer, location, status, expiryDate) VALUES (?, ?, ?, ?, ?, ?, ?)"
      local params = {plate, strike.points, strike.reason, player, strike.location, strike.status, strike.expiryDate}
      MySQL.query.await(query, params)
      SendDiscordLog("vehicle", "\240\159\154\168 Vehicle Strike Issued", nil, 16733525, {
        {name = "Plate", value = plate, inline = true},
        {name = "Reason", value = strike.reason or "N/A", inline = true},
        {name = "Points", value = tostring(strike.points), inline = true},
        {name = "Location", value = strike.location or "Unknown", inline = true},
        {name = "Status", value = strike.status or "pending", inline = true},
        {name = "Expires", value = strike.expiryDate or "N/A", inline = true},
        {name = "Player", value = FormatPlayer(player), inline = false},
      })
      return true
    end
  end
  return false
end)
lib.callback.register("kartik-mdt:server:updateVehicleStrike", function(player, data)
  if data and data.plate and data.strikeId and data.updatedStrike then
    local plate = data.plate
    local strikeId = data.strikeId
    local updatedStrike = data.updatedStrike
    local status = updatedStrike.status
    local dismissalReason = updatedStrike.dismissalReason
    local dismissalDate = updatedStrike.dismissalDate
    local dismissedBy = updatedStrike.dismissedBy
    local query = "UPDATE mdt_vehicles_strikes SET status = ?, dismissalReason = ?, dismissalDate = ?, dismissedBy = ? WHERE id = ?"
    local params = {status, dismissalReason, dismissalDate, dismissedBy, strikeId}
    local result = MySQL.query.await(query, params)
    if result.affectedRows > 0 then
      SendDiscordLog("vehicle", "\226\156\133 Vehicle Strike Updated", nil, 8311585, {
        {name = "Strike ID", value = tostring(strikeId), inline = true},
        {name = "New Status", value = status or "N/A", inline = true},
        {name = "Dismissed By", value = dismissedBy or "N/A", inline = true},
        {name = "Dismissal Reason", value = dismissalReason or "None", inline = false},
        {name = "Player", value = FormatPlayer(player), inline = false},
      })
      return true
    end
  end
  return false
end)