local isDangerous, fetchWarrants, fetchWarrantDataByWarrantId, updateWarrant, addNewWarrant, addReportSightings, updateCaseNotes, deleteWarrant

function isDangerous(citizenId)
    local query = "SELECT * FROM mdt_profiles WHERE citizenid = ?"
    local params = {citizenId}
    local result = MySQL.query.await(query, params)
    if result then
        if #result > 0 then
            local profile = result[1]
            local isDangerous = profile.isDangerous
            if isDangerous == 1 then
                return true
            end
        end
    end
    return false
end

function fetchWarrants(player, data)
    if data then
        local page = data.page or 1
        local query = data.query or ""
        local status = data.status or false
        local offset = (page - 1) * 10
        local limit = 10
        local warrants = fetchWarrantsFromPlayers(query, offset, limit, status)
        local count = countWarrantsFromPlayers(query, status)
        return {warrantsData = warrants, totalCount = count}
    end
end

function fetchWarrantDataByWarrantId(player, data)
    if data then
        local warrantId = data.warrantId
        local query = "SELECT * FROM mdt_warrants WHERE id = ?"
        local params = {warrantId}
        local result = MySQL.query.await(query, params)
        if result then
            if #result > 0 then
                local warrant = result[1]
                local suspectId = warrant.suspectId or ""
                local expiryDate = warrant.expiryDate or ""
                local status = warrant.status
                local caseNotes = json.decode(warrant.caseNotes or "[]")
                local sightings = json.decode(warrant.sightings or "[]")
                return {
                    suspectId = suspectId,
                    expiryDate = expiryDate,
                    status = status,
                    caseNotes = caseNotes,
                    sightings = sightings
                }
            end
        end
    end
end

function updateWarrant(player, data)
    if data then
        local warrant = data.warrant
        if warrant then
            local id = warrant.id
            local expiryDate = warrant.expiryDate
            local charges = json.encode(warrant.charges)
            local issuingAuthority = warrant.issuingAuthority
            local status = warrant.status or "active"
            local query = "UPDATE mdt_warrants SET expiryDate = ?, charges = ?, issuingAuthority = ?, status = ? WHERE id = ?"
            local params = {expiryDate, charges, issuingAuthority, status, id}
            local result = MySQL.query.await(query, params)
            if result.affectedRows > 0 then
                local warrantStatus = status == "active" and 1 or 0
                local query = "UPDATE mdt_profiles SET warrant = ? WHERE citizenid = ?"
                local params = {warrantStatus, warrant.suspectId}
                MySQL.query.await(query, params)
                SendDiscordLog("warrant", "\240\159\147\132 Warrant Updated", nil, 3447003, {
                    {name = "Warrant ID", value = tostring(id), inline = true},
                    {name = "Status", value = status or "unknown", inline = true},
                    {name = "Expiry Date", value = expiryDate or "N/A", inline = true},
                    {name = "Player", value = FormatPlayer(player), inline = false}
                })
                return {success = true, message = "Warrant saved successfully."}
            else
                return {success = false, message = "Failed to update the Warrant."}
            end
        end
    end
    return {success = false, message = "No data received."}
end

function addNewWarrant(player, data)
    if data then
        local warrant = data.warrant
        if warrant then
            local id = warrant.id
            local suspectId = warrant.suspectId
            local issueDate = warrant.issueDate
            local expiryDate = warrant.expiryDate
            local charges = json.encode(warrant.charges)
            local issuingAuthority = warrant.issuingAuthority
            local status = warrant.status or "active"
            local caseNotes = json.encode(warrant.caseNotes)
            local query = "INSERT INTO mdt_warrants (id, suspectId, issueDate, expiryDate, charges, issuingAuthority, status, caseNotes) VALUES (?, ?, ?, ?, ?, ?, ?, ?)"
            local params = {id, suspectId, issueDate, expiryDate, charges, issuingAuthority, status, caseNotes}
            local result = MySQL.query.await(query, params)
            if result.affectedRows > 0 then
                local warrantStatus = status == "active" and 1 or 0
                local query = "UPDATE mdt_profiles SET warrant = ? WHERE citizenid = ?"
                local params = {warrantStatus, suspectId}
                MySQL.query.await(query, params)
                SendDiscordLog("warrant", "\240\159\147\140 New Warrant Issued", nil, 15844367, {
                    {name = "Warrant ID", value = tostring(id), inline = true},
                    {name = "Suspect ID", value = suspectId or "N/A", inline = true},
                    {name = "Issued", value = issueDate or "N/A", inline = true},
                    {name = "Expires", value = expiryDate or "N/A", inline = true},
                    {name = "Player", value = FormatPlayer(player), inline = false}
                })
                return {success = true, message = "Warrant inserted successfully."}
            else
                return {success = false, message = "Failed to insert the Warrant."}
            end
        end
    end
    return {success = false, message = "No data received."}
end

function addReportSightings(player, data)
    if data then
        local warrantId = data.warrantId
        if warrantId then
            local sightingsData = data.sightingsData
            local sightings = json.encode(sightingsData)
            local query = "UPDATE mdt_warrants SET sightings = ? WHERE id = ?"
            local params = {sightings, warrantId}
            local result = MySQL.query.await(query, params)
            if result.affectedRows > 0 then
                SendDiscordLog("warrant", "\240\159\145\129\239\184\143 Warrant Sightings Added", nil, 10181046, {
                    {name = "Warrant ID", value = tostring(warrantId), inline = true},
                    {name = "Sightings Count", value = tostring(#sightingsData), inline = true},
                    {name = "Player", value = FormatPlayer(player), inline = false}
                })
                return {success = true, message = "sightings inserted successfully."}
            else
                return {success = false, message = "Failed to insert the sightings."}
            end
        end
    end
    return {success = false, message = "No data received."}
end

function updateCaseNotes(player, data)
    if data then
        local warrantId = data.warrantId
        if warrantId then
            local caseNoteData = data.caseNoteData
            local caseNotes = json.encode(caseNoteData)
            local query = "UPDATE mdt_warrants SET caseNotes = ? WHERE id = ?"
            local params = {caseNotes, warrantId}
            local result = MySQL.query.await(query, params)
            if result.affectedRows > 0 then
                SendDiscordLog("warrant", "\240\159\147\157 Warrant Case Notes Updated", nil, 8359053, {
                    {name = "Warrant ID", value = tostring(warrantId), inline = true},
                    {name = "Notes Count", value = tostring(#caseNoteData), inline = true},
                    {name = "Player", value = FormatPlayer(player), inline = false}
                })
                return {success = true, message = "Case Notes inserted successfully."}
            else
                return {success = false, message = "Failed to insert the Case Notes."}
            end
        end
    end
    return {success = false, message = "No data received."}
end

function deleteWarrant(player, data)
    if data then
        local warrantId = data.warrantId
        if warrantId then
            local query = "DELETE FROM mdt_warrants WHERE id = ?"
            local params = {warrantId}
            local result = MySQL.query.await(query, params)
            if result.affectedRows > 0 then
                SendDiscordLog("warrant", "\240\159\151\145\239\184\143 Warrant Deleted", nil, 8359053, {
                    {name = "Warrant ID", value = tostring(warrantId), inline = true},
                    {name = "Deleted By", value = FormatPlayer(player), inline = false}
                })
                return {success = true, message = "Warrant deleted successfully."}
            else
                return {success = false, message = "Failed to delete the warrant or it does not exist."}
            end
        end
    end
    return {success = false, message = "No warrant ID received."}
end

lib.callback.register("kartik-mdt:server:fetchWarrants", fetchWarrants)
lib.callback.register("kartik-mdt:server:fetchWarrantDataByWarrantId", fetchWarrantDataByWarrantId)
lib.callback.register("kartik-mdt:server:updateWarrant", updateWarrant)
lib.callback.register("kartik-mdt:server:addNewWarrant", addNewWarrant)
lib.callback.register("kartik-mdt:server:addReportSightings", addReportSightings)
lib.callback.register("kartik-mdt:server:updateCaseNotes", updateCaseNotes)
lib.callback.register("kartik-mdt:server:deleteWarrant", deleteWarrant)

function checkExpiredWarrants()
    local query = [[
        SELECT suspectId 
        FROM mdt_warrants
        WHERE status != 'expired' AND expiryDate < NOW()
    ]]
    local result = MySQL.Async.fetchAll(query)
    for _, warrant in pairs(result) do
        local suspectId = warrant.suspectId
        local query = "UPDATE mdt_warrants SET status = 'expired' WHERE suspectId = ?"
        local params = {suspectId}
        MySQL.query.await(query, params)
        local query = "UPDATE mdt_profiles SET warrant = 0 WHERE citizenid = ?"
        local params = {suspectId}
        MySQL.query.await(query, params)
    end
end

warrantUpdateData = {}
function updateWarrantStatus(warrants)
    local warrantCount = #warrants
    if warrantCount > 0 then
        local suspectIds = {}
        for _, warrant in ipairs(warrants) do
            table.insert(suspectIds, warrant.suspectId)
        end
        local query = [[
            UPDATE mdt_warrants
            SET status = 'expired'
            WHERE status != 'expired' AND expiryDate < NOW()
        ]]
        MySQL.Async.execute(query, {}, function(rowsChanged)
            if rowsChanged > 0 then
                print("[WARRANTS] Updated %d expired warrants.", rowsChanged)
                updateProfiles(suspectIds)
            else
                print("[WARRANTS] No expired warrants found.")
            end
        end)
    else
        print("[WARRANTS] No expired warrants found.")
    end
end

function updateProfiles(profiles)
    local profileCount = #profiles
    if profileCount == 0 then
        print("[PROFILES] No profiles to update.")
        return
    end
    local citizenIds = {}
    for _, profile in ipairs(profiles) do
        table.insert(citizenIds, string.format("'%s'", profile))
    end
    local idsString = table.concat(citizenIds, ", ")
    local query = string.format([[
        UPDATE mdt_profiles p
        SET p.warrant = (
            SELECT CASE
                WHEN COUNT(w.id) > 0 THEN 1  -- Set warrant to 1 if any active warrants are found
                ELSE 0
            END
            FROM mdt_warrants w
            WHERE w.suspectId = p.citizenid AND w.status != 'expired'
        )
        WHERE p.citizenid IN (%s)
    ]], idsString)
    MySQL.Async.execute(query, {}, function(rowsChanged)
        print("[PROFILES] Updated `warrant` status for %d profiles.", rowsChanged)
    end)
end