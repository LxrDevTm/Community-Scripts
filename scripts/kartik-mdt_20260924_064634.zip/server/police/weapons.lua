local registerCallback, fetchWeaponsCallback, fetchWeaponDataBySerialNumberCallback, updateWeaponCallback, deleteWeaponCallback, addWeaponCallback, updateWeaponImageCallback

registerCallback = lib.callback.register
fetchWeaponsCallback = function(source, data)
    local mysql = MySQL.query.await
    local query = data.query or ""
    local page = data.page or 1
    local offset = (page - 1) * 10
    local totalCountQuery = [[
        SELECT COUNT(*) as total FROM mdt_weapons
        WHERE (citizenId LIKE ? OR serialNumber LIKE ?)
    ]]
    local totalCountParams = {"%" .. query .. "%", "%" .. query .. "%"}
    local totalCountResult = mysql(totalCountQuery, totalCountParams)
    local totalCount = totalCountResult[1].total or 0

    local weaponsQuery = [[
        SELECT * FROM mdt_weapons
        WHERE (citizenId LIKE ? OR serialNumber LIKE ?)
        LIMIT 10 OFFSET ?
    ]]
    local weaponsParams = {"%" .. query .. "%", "%" .. query .. "%", offset}
    local weaponsResult = mysql(weaponsQuery, weaponsParams)

    for i, weapon in ipairs(weaponsResult) do
        local citizenId = weapon.citizenId
        local player = GetOfflinePlayerByCitizenId(citizenId)
        if player then
            weapon.ownerName = player.name
        else
            weapon.ownerName = "Unknown"
        end
    end

    return {
        totalCount = totalCount,
        weapons = weaponsResult
    }
end

fetchWeaponDataBySerialNumberCallback = function(source, data)
    local mysql = MySQL.query.await
    local serialNumber = data.serialNumber
    local query = "SELECT * FROM mdt_weapons WHERE serialNumber = ?"
    local params = {serialNumber}
    local result = mysql(query, params)
    return {
        success = true,
        message = "Weapon fetched successfully.",
        weaponData = result
    }
end

updateWeaponCallback = function(source, data)
    local mysql = MySQL.query.await
    local serialNumber = data.weapon.serialNumber
    local image = data.weapon.image
    local query = "UPDATE mdt_weapons SET image = ? WHERE serialNumber = ?"
    local params = {image, serialNumber}
    mysql(query, params)
    SendDiscordLog("weapon", "\240\159\155\160\239\184\143 Weapon Image Updated", nil, 15844367, {
        {name = "Serial Number", value = serialNumber or "N/A", inline = true},
        {name = "Player", value = FormatPlayer(source), inline = false}
    })
    return {
        success = true,
        message = "Weapon updated successfully.",
        weaponData = mysql(query, params)
    }
end

deleteWeaponCallback = function(source, data)
    local mysql = MySQL.query.await
    local serialNumber = data.id
    local query = "DELETE FROM mdt_weapons WHERE serialNumber = ?"
    local params = {serialNumber}
    mysql(query, params)
    SendDiscordLog("weapon", "\240\159\151\145\239\184\143 Weapon Deleted", nil, 15158332, {
        {name = "Serial Number", value = serialNumber or "N/A", inline = true},
        {name = "Player", value = FormatPlayer(source), inline = false}
    })
    return {
        success = true,
        message = "Weapon deleted successfully.",
        weaponData = mysql(query, params)
    }
end

addWeaponCallback = function(source, data)
    local mysql = MySQL.query.await
    local serialNumber = data.weapon.serialNumber
    local query = "SELECT * FROM mdt_weapons WHERE serialNumber = ?"
    local params = {serialNumber}
    local result = mysql(query, params)
    if #result > 0 then
        return {
            success = false,
            message = "Weapon already exists."
        }
    else
        local image = data.weapon.image
        local weaponName = data.weapon.weaponName
        local citizenId = data.weapon.citizenId
        query = "INSERT INTO mdt_weapons (serialNumber, image, weaponName, citizenId) VALUES (?, ?, ?, ?)"
        params = {serialNumber, image, weaponName, citizenId}
        mysql(query, params)
        SendDiscordLog("weapon", "\240\159\148\171 Weapon Added", nil, 5763719, {
            {name = "Serial Number", value = serialNumber or "N/A", inline = true},
            {name = "Weapon Name", value = weaponName or "N/A", inline = true},
            {name = "Citizen ID", value = citizenId or "N/A", inline = true},
            {name = "Player", value = FormatPlayer(source), inline = false}
        })
        return {
            success = true,
            message = "Weapon added successfully.",
            weaponData = mysql(query, params)
        }
    end
end

updateWeaponImageCallback = function(source, data)
    local mysql = MySQL.query.await
    local serialNumber = data.serialNumber
    local photo = data.photo
    local query = "UPDATE mdt_weapons SET image = ? WHERE serialNumber = ?"
    local params = {photo, serialNumber}
    mysql(query, params)
    SendDiscordLog("weapon", "\240\159\155\160\239\184\143 Weapon Image Updated", nil, 15844367, {
        {name = "Serial Number", value = serialNumber or "N/A", inline = true},
        {name = "Player", value = FormatPlayer(source), inline = false}
    })
    return {
        success = true,
        message = "Weapon updated successfully.",
        weaponData = mysql(query, params)
    }
end

registerCallback("kartik-mdt:server:fetchWeapons", fetchWeaponsCallback)
registerCallback("kartik-mdt:server:fetchWeaponDataBySerialNumber", fetchWeaponDataBySerialNumberCallback)
registerCallback("kartik-mdt:server:updateWeapon", updateWeaponCallback)
registerCallback("kartik-mdt:server:deleteWeapon", deleteWeaponCallback)
registerCallback("kartik-mdt:server:addWeapon", addWeaponCallback)
registerCallback("kartik-mdt:server:updateWeaponImage", updateWeaponImageCallback)