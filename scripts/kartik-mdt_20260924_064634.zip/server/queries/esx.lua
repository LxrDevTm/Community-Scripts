local resourceName, esExtended
resourceName = GetCurrentResourceName
resourceName = resourceName()
if "kartik-mdt" ~= resourceName then
  return
end
esExtended = detectCore
esExtended = esExtended("es_extended")
if not esExtended then
  return
end
local Jobs = {}
function fetchRealCitizens(search, limit, offset)
  local query, params, results
  params = {}
  if search ~= "" then
    query = [[
            WHERE 
                LOWER(users.firstname) LIKE ? OR
                LOWER(users.lastname) LIKE ? OR
                LOWER(users.identifier) LIKE ? 
        ]]
    for i = 1, 3 do
      table.insert(params, "%" .. search .. "%")
    end
  end
  query = "SELECT COUNT(users.identifier) as count FROM users " .. (query or "")
  results = MySQL.query.await(query, params)
  if results and results[1] and results[1].count then
    query = "SELECT * FROM users " .. (query or "") .. " LIMIT ? OFFSET ?"
    table.insert(params, limit)
    table.insert(params, offset)
    results = MySQL.query.await(query, params)
    local citizens = {}
    for _, result in ipairs(results or {}) do
      local job = Jobs[result.job]
      if not job then
        job = {}
      end
      local mdtProfile = MySQL.query.await("SELECT warrant, fingerprint, dna, isDangerous FROM mdt_profiles WHERE citizenid = ?", {result.identifier})
      if mdtProfile and mdtProfile[1] then
        mdtProfile = mdtProfile[1]
      else
        mdtProfile = {}
      end
      local licenses = fetchLicenses(result.identifier)
      if not licenses then
        licenses = {}
      end
      local phoneNumber = "Unknown"
      if GetPhoneNumber then
        local success, phoneNumber = pcall(GetPhoneNumber, result.identifier)
        if success then
          phoneNumber = phoneNumber
        end
      end
      local citizen = {
        id = result.id,
        citizenid = result.identifier,
        firstname = result.firstname,
        surname = result.lastname,
        gender = result.sex == "f" and "Female" or "Male",
        nationality = result.nationality or "Unknown",
        birthdate = result.dateofbirth or "Unknown",
        photo = result.photo,
        bankAccount = result.account or "Unknown",
        phoneNumber = phoneNumber,
        job = job.label,
        warrant = mdtProfile.warrant or 0,
        isDangerous = mdtProfile.isDangerous or 0,
        licenses = licenses,
        fingerprint = mdtProfile.fingerprint or "Not Registered",
        dna = mdtProfile.dna or "Not Registered"
      }
      table.insert(citizens, citizen)
    end
    return citizens, results and results[1] and results[1].count or 0
  end
  return {}, 0
end

function updateCitizenPhoto(photo, citizenId)
  local query = "UPDATE users SET photo = ? WHERE identifier = ?"
  local params = {photo, citizenId}
  local result = MySQL.query.await(query, params)
  return result and result.affectedRows > 0
end

function checkCitizenIdInPlayers(citizenId)
  local query = "SELECT COUNT(*) as count FROM users WHERE identifier = ?"
  local params = {citizenId}
  local result = MySQL.query.await(query, params)
  return result and result[1] and result[1].count > 0
end

function fetchBodycamPlayerCount(where, params)
  local query = [[
        SELECT COUNT(*) as count
        FROM mdt_units
        JOIN users ON mdt_units.citizenid = users.identifier
    ]] .. where
  local result = MySQL.query.await(query, params)
  return result and result[1] and result[1].count or 0
end

function fetchBodycamPlayersWithPagination(search, offset)
  local where = "WHERE mdt_units.citizenid = users.identifier"
  local params = {}
  if search ~= "" then
    where = where .. " AND (LOWER(users.firstname) LIKE LOWER(?) OR LOWER(users.lastname) LIKE LOWER(?) OR LOWER(users.identifier) LIKE LOWER(?))"
    table.insert(params, "%" .. search .. "%")
    table.insert(params, "%" .. search .. "%")
    table.insert(params, "%" .. search .. "%")
  end
  local query = [[
        SELECT 
            mdt_units.citizenid, 
            mdt_units.bodycam AS status,
            users.firstname, 
            users.lastname, 
            users.job
        FROM mdt_units
        JOIN users ON mdt_units.citizenid = users.identifier
    ]] .. where .. [[
        ORDER BY 
            CASE mdt_units.bodycam
                WHEN 'on' THEN 0
                WHEN 'off' THEN 1
                ELSE 2
            END,
            users.firstname ASC
        LIMIT 10 OFFSET ?
    ]]
  table.insert(params, offset)
  local results = MySQL.query.await(query, params)
  local players = {}
  for _, result in ipairs(results or {}) do
    local job = Jobs[result.job]
    if not job then
      job = {}
    end
    local player = {
      citizenId = result.citizenid,
      name = (result.firstname or "Unknown") .. " " .. (result.lastname or ""),
      department = job.label or "Unknown",
      rank = job.grade_name or "Unknown",
      status = result.status
    }
    table.insert(players, player)
  end
  return players, fetchBodycamPlayerCount(where, params)
end

function fetchUnitCount(where, params)
  local query = [[
        SELECT COUNT(*) as count
        FROM mdt_units
        JOIN users ON mdt_units.citizenid = users.identifier
    ]] .. where
  local result = MySQL.query.await(query, params)
  return result and result[1] and result[1].count or 0
end

function fetchUnitsWithPagination(search, department, offset)
  local where = "WHERE mdt_units.department = '" .. department .. "' AND mdt_units.citizenid = users.identifier"
  local params = {}
  if search ~= "" then
    where = where .. " AND (LOWER(users.firstname) LIKE LOWER(?) OR LOWER(users.lastname) LIKE LOWER(?) OR LOWER(users.identifier) LIKE LOWER(?))"
    table.insert(params, "%" .. search .. "%")
    table.insert(params, "%" .. search .. "%")
    table.insert(params, "%" .. search .. "%")
  end
  local query = [[
        SELECT mdt_units.id, mdt_units.dutyRecords, mdt_units.tags, mdt_units.isFired,
               mdt_units.totalHours, mdt_units.status, users.identifier AS citizenid, users.photo,
               users.firstname, users.lastname, users.job, mdt_units.callsign
        FROM mdt_units
        JOIN users ON mdt_units.citizenid = users.identifier
    ]] .. where .. [[
        LIMIT 10 OFFSET ?
    ]]
  table.insert(params, offset)
  local results = MySQL.query.await(query, params)
  local units = {}
  for _, result in ipairs(results or {}) do
    local job = Jobs[result.job]
    if not job then
      job = {}
    end
    local dutyRecords = json.decode(result.dutyRecords or "[]")
    if #dutyRecords > 10 then
      dutyRecords = {}
      for i = #dutyRecords - 9, #dutyRecords do
        table.insert(dutyRecords, dutyRecords[i])
      end
    end
    local unit = {
      id = result.id,
      citizenId = result.citizenid,
      name = (result.firstname or "Unknown") .. " " .. (result.lastname or ""),
      rank = job.grade_name or "Unknown",
      department = job.label or "Unknown",
      tags = result.tags,
      status = result.status,
      isFired = result.isFired or 0,
      photo = result.photo,
      totalDutyHours = result.totalHours,
      callsign = result.callsign,
      dutyRecords = dutyRecords
    }
    table.insert(units, unit)
  end
  return units
end

fetchUnitCount = fetchUnitCount
unitCount, warrantCount = fetchUnitCount(unitCount, warrantCount)
unitCount = warrantCount
warrantCount = fetchUnitCount
return unitCount, warrantCount
end

fetchUnitData = function(limit, offset)
    local query = [[
        SELECT 
            warrants.id AS warrant_id,
            warrants.expiryDate AS expiryDate,
            warrants.issueDate AS issueDate,
            warrants.status AS status,
            users.firstname AS player_firstname,
            users.lastname AS player_lastname
        FROM 
            mdt_warrants AS warrants
        JOIN 
            users AS users 
        ON 
            warrants.suspectId = users.identifier
        WHERE 
            warrants.status = 'active'
        LIMIT ? OFFSET ?;
    ]]
    local params = {limit, offset}
    local results = MySQL.query.await(query, params)
    if not results then
        results = {}
    end
    local warrants = {}
    for _, result in ipairs(results) do
        local warrant = {}
        warrant.id = result.warrant_id
        warrant.expiryDate = result.expiryDate
        warrant.issueDate = result.issueDate
        local playerName = result.player_firstname
        if not playerName then
            playerName = "Unknown"
        end
        local playerLastName = result.player_lastname
        if not playerLastName then
            playerLastName = ""
        end
        warrant.name = playerName .. " " .. playerLastName
        warrant.status = result.status
        table.insert(warrants, warrant)
    end
    return warrants
end

fetchWarrantsWithPlayers = function(limit, offset)
    local query = [[
        SELECT 
            owned_vehicles.plate AS plate,
            owned_vehicles.vehicle AS vehicle,
            COALESCE(mdt_vehicles.status, 'Unknown') AS status,
            owned_vehicles.owner AS citizenid
        FROM 
            owned_vehicles
        LEFT JOIN 
            mdt_vehicles 
        ON 
            mdt_vehicles.plate = owned_vehicles.plate
        WHERE
            mdt_vehicles.status = 'bolo'
        LIMIT ? OFFSET ?;
    ]]
    local params = {limit, offset}
    local results = MySQL.query.await(query, params)
    if not results then
        results = {}
    end
    local vehicles = {}
    for _, result in ipairs(results) do
        local vehicle = {}
        vehicle.plate = result.plate
        vehicle.status = result.status
        local vehicleModel = json.decode(result.vehicle)
        vehicle.model = vehicleModel.model
        local ownerName = GetOfflinePlayerByCitizenId(result.citizenid)
        if ownerName then
            vehicle.owner = ownerName.name
        else
            vehicle.owner = "Unknown"
        end
        vehicle.citizenid = result.citizenid
        table.insert(vehicles, vehicle)
    end
    return vehicles
end

GetVehicleOwner = function(plate)
    local query = "SELECT plate, owner AS citizenid, id FROM owned_vehicles WHERE plate = @plate"
    local params = {@plate = plate}
    local result = MySQL.query.await(query, params)
    if result and result[1] then
        local citizenId = result[1].citizenid
        local ownerName = GetOfflinePlayerByCitizenId(citizenId)
        if ownerName then
            return ownerName.name
        end
    end
    return false
end

fetchVehicleByPlate = function(plate)
    local query = [[
        SELECT 
            owned_vehicles.plate AS plate,
            owned_vehicles.vehicle AS vehicle,
            COALESCE(mdt_vehicles.status, 'Unknown') AS status,
            owned_vehicles.owner AS citizenid,
            mdt_vehicles.sightings AS sightings,
            mdt_vehicles.photo AS photo
        FROM 
            owned_vehicles
        LEFT JOIN 
            mdt_vehicles 
        ON 
            mdt_vehicles.plate = owned_vehicles.plate
        WHERE 
            owned_vehicles.plate = ?
    ]]
    local params = {plate}
    local result = MySQL.query.await(query, params)
    if result and result[1] then
        local vehicle = {}
        vehicle.plate = result[1].plate
        vehicle.status = result[1].status
        local vehicleModel = json.decode(result[1].vehicle)
        vehicle.model = vehicleModel.model
        vehicle.sightings = result[1].sightings
        vehicle.photo = result[1].photo
        local ownerName = GetOfflinePlayerByCitizenId(result[1].citizenid)
        if ownerName then
            vehicle.owner = ownerName.name
        else
            vehicle.owner = "Unknown"
        end
        vehicle.citizenid = result[1].citizenid
        return vehicle
    end
    return nil
end

fetchVehiclesFromPlayerTable = function(search, limit, offset)
    local query = [[
        SELECT 
            owned_vehicles.plate AS plate,
            owned_vehicles.vehicle AS vehicle,
            COALESCE(mdt_vehicles.status, 'Unknown') AS status,
            owned_vehicles.owner AS citizenid
        FROM 
            owned_vehicles
        LEFT JOIN 
            mdt_vehicles 
        ON 
            mdt_vehicles.plate = owned_vehicles.plate
    ]]
    local params = {}
    if search and search ~= "" then
        query = query .. " WHERE LOWER(owned_vehicles.plate) LIKE LOWER(?) OR LOWER(owned_vehicles.owner) LIKE LOWER(?)"
        table.insert(params, "%" .. search .. "%")
        table.insert(params, "%" .. search .. "%")
    end
    query = query .. " LIMIT ? OFFSET ?"
    table.insert(params, limit)
    table.insert(params, offset)
    local results = MySQL.query.await(query, params)
    local vehicles = {}
    for _, result in ipairs(results) do
        local vehicle = {}
        vehicle.plate = result.plate
        vehicle.status = result.status
        local vehicleModel = json.decode(result.vehicle)
        vehicle.model = vehicleModel.model
        local ownerName = GetOfflinePlayerByCitizenId(result.citizenid)
        if ownerName then
            vehicle.owner = ownerName.name
        else
            vehicle.owner = "Unknown"
        end
        vehicle.citizenid = result.citizenid
        table.insert(vehicles, vehicle)
    end
    return vehicles
end

countVehiclesFromPlayerTable = function(search)
    local query = "SELECT COUNT(*) AS count FROM owned_vehicles"
    local params = {}
    if search and search ~= "" then
        query = query .. " WHERE LOWER(owned_vehicles.plate) LIKE LOWER(?) OR LOWER(owned_vehicles.owner) LIKE LOWER(?)"
        table.insert(params, "%" .. search .. "%")
        table.insert(params, "%" .. search .. "%")
    end
    local result = MySQL.query.await(query, params)
    if result and result[1] then
        return result[1].count
    end
    return 0
end

fetchWarrantsFromPlayers = function(search, limit, offset, status)
    local query = [[
        SELECT 
            warrants.id AS report_id,
            warrants.suspectId AS report_suspectId,
            warrants.charges AS report_charges,
            warrants.issueDate AS issueDate,
            warrants.issuingAuthority AS issuingAuthority,
            warrants.status AS status,
            users.photo AS photo,
            users.firstname AS player_firstname,
            users.lastname AS player_lastname,
            users.dateofbirth AS player_birthdate
        FROM 
            mdt_warrants AS warrants
        JOIN 
            users AS users 
        ON 
            warrants.suspectId = users.identifier
    ]]
    local params = {}
    local conditions = {}
    if search and search ~= "" then
        table.insert(conditions, "(LOWER(users.firstname) LIKE LOWER(?) OR LOWER(users.lastname) LIKE LOWER(?) OR LOWER(users.identifier) LIKE LOWER(?) OR warrants.id = ?)")
        table.insert(params, "%" .. search .. "%")
        table.insert(params, "%" .. search .. "%")
        table.insert(params, "%" .. search .. "%")
        table.insert(params, search)
    end
    if status and status ~= "" then
        table.insert(conditions, "warrants.status = ?")
        table.insert(params, status)
    end
    if #conditions > 0 then
        query = query .. " WHERE " .. table.concat(conditions, " AND ")
    end
    query = query .. " LIMIT ? OFFSET ?"
    table.insert(params, limit)
    table.insert(params, offset)
    local results = MySQL.query.await(query, params)
    local warrants = {}
    for _, result in ipairs(results) do
        local warrant = {}
        warrant.id = result.report_id
        warrant.charges = result.report_charges
        warrant.issueDate = result.issueDate
        warrant.issuingAuthority = result.issuingAuthority
        if not warrant.issuingAuthority then
            warrant.issuingAuthority = ""
        end
        warrant.status = result.status
        warrant.photo = result.photo
        local playerName = result.player_firstname .. " " .. result.player_lastname
        warrant.name = playerName
        warrant.birthdate = result.player_birthdate
        warrant.nationality = "Unknown"
        warrant.isDangerous = isDangerous(result.report_suspectId)
        table.insert(warrants, warrant)
    end
    return warrants
end

countWarrantsFromPlayers = function(citizenId)
  local queryConditions = {}
  queryConditions.citizenid = citizenId
  local query = [[
        SELECT 
            warrants.suspectId AS citizenid
        FROM 
            mdt_warrants AS warrants
        WHERE
            warrants.suspectId = @citizenid
    ]]
  local results = MySQL.query.await(query, queryConditions)
  local conditions = {}
  for _, result in ipairs(results) do
    table.insert(conditions, "warrants.suspectId = '" .. result.citizenid .. "'")
  end
  if #conditions > 0 then
    local whereClause = "WHERE " .. table.concat(conditions, " OR ")
    query = [[
        SELECT COUNT(*) AS count
        FROM mdt_warrants AS warrants
        JOIN users AS users
        ON warrants.suspectId = users.identifier
    ]] .. " " .. whereClause
    results = MySQL.query.await(query, {})
    if results[1] and results[1].count then
      return results[1].count
    end
  end
  return 0
end

fetchCitizenVehiclesFromTable = function(citizenId)
  local queryConditions = {}
  queryConditions.citizenid = citizenId
  local query = [[
        SELECT 
            owned_vehicles.plate AS plate,
            owned_vehicles.vehicle AS vehicle,
            COALESCE(mdt_vehicles.status, 'Unknown') AS status,
            owned_vehicles.owner AS citizenid
        FROM 
            owned_vehicles
        LEFT JOIN 
            mdt_vehicles 
        ON 
            mdt_vehicles.plate = owned_vehicles.plate
        WHERE
            owned_vehicles.owner = @citizenid
    ]]
  local results = MySQL.query.await(query, queryConditions)
  local vehicles = {}
  for _, result in ipairs(results) do
    local playerName = GetOfflinePlayerByCitizenId(result.citizenid)
    if playerName then
      playerName = playerName.name
    else
      playerName = "Unknown"
    end
    local vehicleModel = json.decode(result.vehicle)
    if vehicleModel then
      vehicleModel = vehicleModel.model
    else
      vehicleModel = "Unknown"
    end
    local lastSeen = "Unknown"
    if result.sightings and #result.sightings > 0 then
      lastSeen = result.sightings[#result.sightings].timestamp
    end
    local vehicleInfo = {
      plate = result.plate,
      status = result.status,
      model = vehicleModel,
      owner = playerName,
      citizenid = result.citizenid,
      lastseen = lastSeen
    }
    table.insert(vehicles, vehicleInfo)
  end
  return vehicles
end