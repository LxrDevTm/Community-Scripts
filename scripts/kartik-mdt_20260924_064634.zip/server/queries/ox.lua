local resourceName, coreName
resourceName = GetCurrentResourceName
resourceName = resourceName()
if "kartik-mdt" ~= resourceName then
  return
end
resourceName = detectCore
coreName = "ox_core"
resourceName = resourceName(coreName)
if not resourceName then
  return
end

function fetchRealCitizens(query, limit, offset)
  local results, count, whereClause, params, sql
  results = {}
  count = 0
  whereClause = ""
  params = {}
  if query ~= "" then
    whereClause = [[
      (
          LOWER(characters.firstName) LIKE ? AND
          LOWER(characters.lastName) LIKE ?
      )
    ]]
    params = {
      "%" .. query:lower() .. "%",
      "%" .. query:lower() .. "%"
    }
  else
    whereClause = [[
      (
          LOWER(characters.firstName) LIKE ? OR
          LOWER(characters.lastName) LIKE ? OR
          LOWER(characters.stateId) LIKE ?
      )
    ]]
    for i = 1, 3 do
      table.insert(params, "%")
    end
  end
  sql = "SELECT COUNT(*) FROM characters WHERE " .. whereClause
  count = MySQL.scalar.await(sql, params)
  if query ~= "" then
    whereClause = [[
      (
          LOWER(mdt_profiles.notes) LIKE ? OR
          LOWER(mdt_profiles.fingerprint) LIKE ? OR
          LOWER(mdt_profiles.dna) LIKE ?
      )
    ]]
    params = {
      "%" .. query:lower() .. "%",
      "%" .. query:lower() .. "%",
      "%" .. query:lower() .. "%"
    }
    sql = [[
      SELECT COUNT(DISTINCT characters.stateId)
      FROM mdt_profiles
      JOIN characters ON characters.stateId = mdt_profiles.citizenid
      WHERE
    ]] .. whereClause
    local mdtCount = MySQL.scalar.await(sql, params)
    count = count + mdtCount
  end
  if query ~= "" then
    whereClause = [[
      (
          LOWER(characters.firstName) LIKE ? AND
          LOWER(characters.lastName) LIKE ?
      )
    ]]
    params = {
      "%" .. query:lower() .. "%",
      "%" .. query:lower() .. "%"
    }
    sql = [[
      SELECT charId as id, stateId, charinfo, photo, job FROM (
          SELECT characters.charId, characters.stateId, JSON_OBJECT('firstName', characters.firstName, 'lastName', characters.lastName, 'phoneNumber', characters.phoneNumber, 'dateOfBirth', characters.dateOfBirth) as charinfo, characters.photo, character_groups.name as job
          FROM characters
          LEFT JOIN character_groups ON characters.charId = character_groups.charId AND character_groups.isActive = 1
          WHERE
    ]] .. whereClause .. [[
      )
      UNION
      SELECT characters.charId, characters.stateId, JSON_OBJECT('firstName', characters.firstName, 'lastName', characters.lastName, 'phoneNumber', characters.phoneNumber, 'dateOfBirth', characters.dateOfBirth) as charinfo, characters.photo, character_groups.name as job
      FROM mdt_profiles
      JOIN characters ON characters.stateId = mdt_profiles.citizenid
      JOIN character_groups ON characters.charId = character_groups.charId AND character_groups.isActive = 1
      WHERE
    ]] .. whereClause .. [[
    ) AS combined_results
    LIMIT ? OFFSET ?
  ]]
    params = {
      "%" .. query:lower() .. "%",
      "%" .. query:lower() .. "%",
      limit,
      offset
    }
  else
    sql = [[
      SELECT
          characters.charId,
          characters.stateId,
          JSON_OBJECT('firstName', characters.firstName, 'lastName', characters.lastName, 'phoneNumber', characters.phoneNumber, 'dateOfBirth', characters.dateOfBirth) as charinfo,
          characters.photo,
          character_groups.name as job
      FROM characters
      LEFT JOIN character_groups ON characters.charId = character_groups.charId AND character_groups.isActive = 1
      LIMIT ? OFFSET ?
    ]]
    params = {
      limit,
      offset
    }
  end
  results = MySQL.query.await(sql, params)
  for _, result in ipairs(results) do
    local charInfo = json.decode(result.charinfo)
    local group = GlobalState["group." .. result.job]
    local mdtProfile = MySQL.query.await("SELECT warrant, fingerprint, dna, isDangerous FROM mdt_profiles WHERE citizenid = ?", {result.stateId})
    if mdtProfile and mdtProfile[1] then
      mdtProfile = mdtProfile[1]
    else
      mdtProfile = {}
    end
    local licenses = fetchLicenses(result.stateId)
    if not licenses then
      licenses = {}
    end
    local phoneNumber = charInfo.phoneNumber
    if not phoneNumber then
      phoneNumber = "Unknown"
    end
    if GetPhoneNumber then
      local success, phoneNumberResult = pcall(GetPhoneNumber, result.stateId)
      if success then
        phoneNumber = phoneNumberResult
      end
    end
    table.insert(results, {
      citizenid = result.stateId,
      firstname = charInfo.firstName,
      surname = charInfo.lastName,
      gender = charInfo.gender == 1 and "Female" or "Male",
      nationality = type(charInfo.nationality) == "table" and charInfo.nationality.name or charInfo.nationality,
      birthdate = charInfo.dateOfBirth,
      photo = result.photo,
      bankAccount = charInfo.account,
      phoneNumber = phoneNumber,
      job = group and group.label or "Unknown",
      warrant = mdtProfile.warrant or 0,
      isDangerous = mdtProfile.isDangerous or 0,
      licenses = licenses,
      fingerprint = mdtProfile.fingerprint or "Not Registered",
      dna = mdtProfile.dna or "Not Registered"
    })
  end
  return results, count
end

function updateCitizenPhoto(photo, citizenId)
  local sql = "UPDATE characters SET photo = ? WHERE stateId = ?"
  local params = {photo, citizenId}
  local result = MySQL.query.await(sql, params)
  return result and result.affectedRows > 0
end

function checkCitizenIdInPlayers(citizenId)
  local sql = "SELECT COUNT(*) as count FROM characters WHERE stateId = ?"
  local params = {citizenId}
  local result = MySQL.query.await(sql, params)
  return result and result[1] and result[1].count > 0
end

function fetchBodycamPlayerCount(whereClause, params)
  local sql = "SELECT COUNT(*) as count FROM mdt_units JOIN characters ON mdt_units.citizenid = characters.stateId " .. whereClause
  local result = MySQL.query.await(sql, params)
  return result and result[1] and result[1].count or 0
end

function fetchBodycamPlayersWithPagination(query, offset)
  local whereClause = "WHERE mdt_units.citizenid = characters.stateId"
  local params = {}
  if query ~= "" then
    whereClause = whereClause .. [[
      AND (
          LOWER(characters.firstName) LIKE LOWER(?) OR
          LOWER(characters.lastName) LIKE LOWER(?) OR
          LOWER(characters.stateId) LIKE ?
      )
    ]]
    params = {
      "%" .. query .. "%",
      "%" .. query .. "%",
      "%" .. query .. "%",
      offset
    }
  else
    params = {offset}
  end
  local sql = [[
    SELECT
        mdt_units.citizenid,
        mdt_units.bodycam AS status,
        JSON_OBJECT(
            'firstName', characters.firstName,
            'lastName', characters.lastName,
            'phoneNumber', characters.phoneNumber,
            'dateOfBirth', characters.dateOfBirth
        ) AS charinfo,
        JSON_OBJECT(
            'name', character_groups.name,
            'grade', character_groups.grade
        ) AS job
    FROM mdt_units
    JOIN characters ON mdt_units.citizenid = characters.stateId
    LEFT JOIN character_groups ON characters.charId = character_groups.charId AND character_groups.isActive = 1
  ]] .. whereClause .. [[
    ORDER BY 
        CASE mdt_units.bodycam 
            WHEN 'on' THEN 0 
            WHEN 'off' THEN 1 
            ELSE 2 
        END,
        characters.firstName ASC
    LIMIT 10 OFFSET ?
  ]]
  local results = MySQL.query.await(sql, params)
  local players = {}
  for _, result in ipairs(results) do
    local charInfo = json.decode(result.charinfo)
    local job = json.decode(result.job)
    local group = GlobalState["group." .. job.name]
    table.insert(players, {
      citizenId = result.citizenid,
      name = (charInfo.firstName or "Unknown") .. " " .. (charInfo.lastName or ""),
      department = group and group.label or "Unknown",
      rank = group and group.grades and group.grades[job.grade] and group.grades[job.grade].label or "Unknown",
      status = result.status
    })
  end
  local playerCount = fetchBodycamPlayerCount(whereClause, params)
  return players, playerCount
end

local query, params
query = [[
    SELECT COUNT(*) as count
    FROM mdt_units
    JOIN characters ON mdt_units.citizenid = characters.stateId
]]
local mysql = MySQL.query.await
local result = mysql(query, {})
if result and result[1] then
    local count = result[1].count
    if count then
        return count
    end
end
return 0

function fetchUnitData(department, offset, search)
    local whereClause, params
    whereClause = "WHERE mdt_units.department = '"
    whereClause = whereClause .. department .. "' AND mdt_units.citizenid = characters.stateId"
    if search ~= "" then
        whereClause = whereClause .. [[
            AND (
                LOWER(characters.firstName) LIKE LOWER(?) OR
                LOWER(characters.lastName) LIKE LOWER(?) OR
                LOWER(characters.stateId) LIKE ?
            )]]
        params = {}
        local wildcard = "%"
        local searchValue = search
        local param1 = wildcard .. searchValue .. wildcard
        local param2 = wildcard .. searchValue .. wildcard
        local param3 = wildcard .. searchValue .. wildcard
        params[1] = param1
        params[2] = param2
        params[3] = param3
    end
    params = params or {}
    table.insert(params, offset)
    local query = [[
        SELECT
            mdt_units.id,
            mdt_units.dutyRecords,
            mdt_units.tags,
            mdt_units.isFired,
            mdt_units.totalHours,
            mdt_units.status,
            characters.stateId,
            characters.photo,
            JSON_OBJECT('firstName', characters.firstName, 'lastName', characters.lastName, 'phoneNumber', characters.phoneNumber, 'dateOfBirth', characters.dateOfBirth) as charinfo,
            JSON_OBJECT('name', character_groups.name, 'grade', character_groups.grade) as job,
            mdt_units.callsign
        FROM mdt_units
        JOIN characters ON mdt_units.citizenid = characters.stateId
        LEFT JOIN character_groups ON characters.charId = character_groups.charId AND character_groups.isActive = 1
    ]] .. whereClause .. [[
        LIMIT 10 OFFSET ?
    ]]
    local mysql = MySQL.query.await
    local result = mysql(query, params)
    if not result then
        result = {}
    end
    local units = {}
    for _, row in ipairs(result) do
        local charInfo = json.decode(row.charinfo or "{}")
        local jobInfo = json.decode(row.job or "{}")
        local dutyRecords = json.decode(row.dutyRecords or "[]")
        if #dutyRecords > 10 then
            dutyRecords = {}
            for i = #dutyRecords - 9, #dutyRecords do
                table.insert(dutyRecords, dutyRecords[i])
            end
        end
        local unit = {
            id = row.id,
            citizenId = row.stateId,
            name = (charInfo.firstName or "Unknown") .. " " .. (charInfo.lastName or ""),
            rank = jobInfo.grade and jobInfo.grade.name or "Unknown",
            department = jobInfo.label or "Unknown",
            tags = row.tags,
            status = row.status,
            isFired = row.isFired or 0,
            photo = row.photo,
            totalDutyHours = row.totalHours,
            callsign = row.callsign,
            dutyRecords = dutyRecords,
        }
        table.insert(units, unit)
    end
    local count = fetchUnitCount(department, search)
    return units, count
end

function fetchWarrantsWithPlayers(limit, offset)
    local query = [[
        SELECT 
            warrants.id AS warrant_id,
            warrants.expiryDate AS expiryDate,
            warrants.issueDate AS issueDate,
            warrants.status AS status,
            characters.firstName,
            characters.lastName
        FROM 
            mdt_warrants AS warrants
        JOIN 
            characters
        ON 
            warrants.suspectId = characters.stateId
        WHERE 
            warrants.status = 'active'
        LIMIT ? OFFSET ?;
    ]]
    local params = {limit, offset}
    local mysql = MySQL.query.await
    local result = mysql(query, params)
    if not result then
        result = {}
    end
    local warrants = {}
    for _, row in ipairs(result) do
        local warrant = {
            id = row.warrant_id,
            expiryDate = row.expiryDate,
            issueDate = row.issueDate,
            status = row.status,
            name = (row.firstName or "Unknown") .. " " .. (row.lastName or ""),
        }
        table.insert(warrants, warrant)
    end
    return warrants
end

function fetchWantedVehiclesWithPlayers(limit, offset)
    local query = [[
        SELECT 
            vehicles.plate AS plate,
            vehicles.model AS vehicle,
            COALESCE(mdt_vehicles.status, 'Unknown') AS status,
            characters.stateId AS stateId
        FROM vehicles
        LEFT JOIN mdt_vehicles ON mdt_vehicles.plate = vehicles.plate
        LEFT JOIN characters ON vehicles.owner = characters.charId
        WHERE
            mdt_vehicles.status = 'bolo'
        LIMIT ? OFFSET ?;
    ]]
    local params = {limit, offset}
    local mysql = MySQL.query.await
    local result = mysql(query, params)
    if not result then
        result = {}
    end
    local vehicles = {}
    for _, row in ipairs(result) do
        local ownerName
        local player = GetOfflinePlayerByCitizenId(row.stateId)
        if player then
            ownerName = player.name
        else
            ownerName = "Unknown"
        end
        local vehicle = {
            plate = row.plate,
            status = row.status,
            model = GetHashKey(row.vehicle),
            owner = ownerName,
            citizenid = row.stateId,
        }
        table.insert(vehicles, vehicle)
    end
    return vehicles
end

function GetVehicleOwner(plate)
    local query = [[
        SELECT
            vehicles.plate as plate,
            characters.stateId as stateId,
            vehicles.id as id
        FROM vehicles
        LEFT JOIN characters ON vehicles.owner = characters.charId
        WHERE vehicles.plate = ?
    ]]
    local params = {plate}
    local mysql = MySQL.query.await
    local result = mysql(query, params)
    if result and result[1] then
        local row = result[1]
        local player = GetOfflinePlayerByCitizenId(row.stateId)
        if player then
            return player.name
        else
            return "Unknown"
        end
    else
        return false
    end
end

function fetchVehicleByPlate(plate)
    local query = [[
        SELECT 
            vehicles.plate AS plate,
            vehicles.model AS vehicle,
            COALESCE(mdt_vehicles.status, 'Unknown') AS status,
            characters.stateId AS stateId,
            mdt_vehicles.sightings AS sightings,
            mdt_vehicles.photo AS photo
        FROM vehicles
        LEFT JOIN mdt_vehicles ON mdt_vehicles.plate = vehicles.plate
        LEFT JOIN characters ON vehicles.owner = characters.charId
        WHERE vehicles.plate = ?
    ]]
    local params = {plate}
    local mysql = MySQL.query.await
    local result = mysql(query, params)
    if result and result[1] then
        local row = result[1]
        local player = GetOfflinePlayerByCitizenId(row.stateId)
        if player then
            local ownerName = player.name
        else
            local ownerName = "Unknown"
        end
        local vehicle = {
            plate = row.plate,
            status = row.status,
            model = GetHashKey(row.vehicle),
            owner = ownerName,
            sightings = row.sightings,
            photo = row.photo,
            citizenid = row.stateId,
        }
        return vehicle
    else
        return nil
    end
end

function fetchVehiclesFromPlayerTable(search, limit, offset)
    local whereClause, params
    whereClause = ""
    params = {}
    if search ~= "" then
        whereClause = " WHERE LOWER(vehicles.plate) LIKE LOWER(?) OR LOWER(characters.stateId) LIKE LOWER(?) "
        local wildcard = "%"
        local searchValue = search
        local param1 = wildcard .. searchValue .. wildcard
        local param2 = wildcard .. searchValue .. wildcard
        params = {param1, param2}
    end
    table.insert(params, limit)
    table.insert(params, offset)
    local query = [[
        SELECT 
            vehicles.plate AS plate,
            vehicles.model AS vehicle,
            COALESCE(mdt_vehicles.status, 'Unknown') AS status,
            characters.stateId AS stateId
        FROM vehicles
        LEFT JOIN mdt_vehicles ON mdt_vehicles.plate = vehicles.plate
        LEFT JOIN characters ON vehicles.owner = characters.charId
    ]] .. whereClause .. [[
        LIMIT ? OFFSET ?
    ]]
    local mysql = MySQL.query.await
    local result = mysql(query, params)
    if not result then
        result = {}
    end
    local vehicles = {}
    for _, row in ipairs(result) do
        local player = GetOfflinePlayerByCitizenId(row.stateId)
        if player then
            local ownerName = player.name
        else
            local ownerName = "Unknown"
        end
        local vehicle = {
            plate = row.plate,
            status = row.status,
            model = GetHashKey(row.vehicle),
            owner = ownerName,
            citizenid = row.stateId,
        }
        table.insert(vehicles, vehicle)
    end
    return vehicles
end

local query = "SELECT COUNT(*) AS count FROM vehicles LEFT JOIN characters ON vehicles.owner = characters.charId "
local mysqlQuery = MySQL.query.await
local result = mysqlQuery(query, {})
local count = 0
if result and result[1] then
    count = result[1].count
end
return count

function fetchWarrantsFromPlayers(search, limit, offset)
    local conditions = {}
    local params = {}
    if search and search ~= "" then
        table.insert(conditions, "(LOWER(characters.firstName) LIKE LOWER(?) OR LOWER(characters.lastName) LIKE LOWER(?) OR LOWER(characters.stateId) LIKE LOWER(?) OR warrants.id = ?)")
        table.insert(params, "%" .. search .. "%")
        table.insert(params, "%" .. search .. "%")
        table.insert(params, "%" .. search .. "%")
        table.insert(params, search)
    end
    if limit and limit ~= "" then
        table.insert(conditions, "warrants.status = ?")
        table.insert(params, limit)
    end
    local where = ""
    if #conditions > 0 then
        where = "WHERE " .. table.concat(conditions, " AND ")
    end
    local query = [[
        SELECT 
            warrants.id AS report_id,
            warrants.suspectId AS report_suspectId,
            warrants.charges AS report_charges,
            warrants.issueDate AS issueDate,
            warrants.issuingAuthority AS issuingAuthority,
            warrants.status AS status,
            characters.photo AS photo,
            characters.firstName AS player_firstname,
            characters.lastName AS player_lastname,
            characters.dateOfBirth AS player_birthdate,
            '' AS player_nationality
        FROM 
            mdt_warrants AS warrants
        JOIN 
            characters 
        ON 
            warrants.suspectId = characters.stateId
    ]] .. " " .. where .. " LIMIT ? OFFSET ?"
    table.insert(params, offset)
    table.insert(params, limit)
    local result = mysqlQuery(query, params)
    local warrants = {}
    for _, row in ipairs(result) do
        local warrant = {
            id = row.report_id,
            charges = row.report_charges,
            issueDate = row.issueDate,
            issuingAuthority = row.issuingAuthority or "",
            status = row.status,
            photo = row.photo,
            name = row.player_firstname .. " " .. row.player_lastname,
            birthdate = row.player_birthdate,
            nationality = row.player_nationality,
            isDangerous = isDangerous(row.report_suspectId)
        }
        table.insert(warrants, warrant)
    end
    return warrants
end

function countWarrantsFromPlayers(search, status)
    local conditions = {}
    local params = {}
    if search and search ~= "" then
        table.insert(conditions, "(LOWER(characters.firstName) LIKE LOWER(?) OR LOWER(characters.lastName) LIKE LOWER(?) OR LOWER(characters.stateId) LIKE LOWER(?) OR warrants.id = ?)")
        table.insert(params, "%" .. search .. "%")
        table.insert(params, "%" .. search .. "%")
        table.insert(params, "%" .. search .. "%")
        table.insert(params, search)
    end
    if status and status ~= "" then
        table.insert(conditions, "warrants.status = ?")
        table.insert(params, status)
    end
    local where = ""
    if #conditions > 0 then
        where = "WHERE " .. table.concat(conditions, " AND ")
    end
    local query = [[
        SELECT COUNT(*) AS count
        FROM mdt_warrants AS warrants
        JOIN characters
        ON warrants.suspectId = characters.stateId
    ]] .. " " .. where
    local result = mysqlQuery(query, params)
    local count = 0
    if result and result[1] then
        count = result[1].count
    end
    return count
end

function fetchCitizenVehiclesFromTable(citizenid)
    local query = [[
        SELECT 
            vehicles.plate AS plate,
            vehicles.model AS vehicle,
            COALESCE(mdt_vehicles.status, 'Unknown') AS status,
            characters.stateId AS citizenid
        FROM vehicles
        LEFT JOIN mdt_vehicles ON mdt_vehicles.plate = vehicles.plate
        LEFT JOIN characters ON vehicles.owner = characters.charId
        WHERE characters.stateId = @citizenid
    ]]
    local params = { citizenid = citizenid }
    local result = mysqlQuery(query, params)
    local vehicles = {}
    for _, row in ipairs(result) do
        local owner = GetOfflinePlayerByCitizenId(row.citizenid)
        if owner and owner.name then
            owner = owner.name
        else
            owner = "Unknown"
        end
        local vehicle = {
            plate = row.plate,
            status = row.status,
            model = GetHashKey(row.vehicle),
            owner = owner,
            citizenid = row.citizenid,
            lastseen = "Unknown"
        }
        table.insert(vehicles, vehicle)
    end
    return vehicles
end