local resourceName, coreName
resourceName = GetCurrentResourceName
resourceName = resourceName()
if "kartik-mdt" ~= resourceName then
  return
end
resourceName = detectCore
coreName = "qbx-core"
resourceName = resourceName(coreName)
if not resourceName then
  return
end

function fetchRealCitizens(searchQuery, limit, offset)
  local results, totalCount, whereClause, params, query
  results = {}
  totalCount = 0
  whereClause = ""
  params = {}
  if searchQuery ~= "" then
    local firstname, lastname
    firstname = searchQuery:match("^(%S+)%s+(.+)$")
    lastname = searchQuery:match("^(%S+)%s+(.+)$")
    if firstname and lastname then
      firstname = firstname:lower()
      lastname = lastname:lower()
      whereClause = [[
        (
          LOWER(JSON_UNQUOTE(JSON_EXTRACT(players.charinfo, "$.firstname"))) LIKE ? AND
          LOWER(JSON_UNQUOTE(JSON_EXTRACT(players.charinfo, "$.lastname"))) LIKE ?
        )
      ]]
      params = {
        "%" .. firstname .. "%",
        "%" .. lastname .. "%"
      }
    else
      whereClause = [[
        (
          LOWER(JSON_UNQUOTE(JSON_EXTRACT(players.charinfo, "$.firstname"))) LIKE ? OR
          LOWER(JSON_UNQUOTE(JSON_EXTRACT(players.charinfo, "$.lastname"))) LIKE ? OR
          LOWER(players.citizenid) LIKE ?
        )
      ]]
      params = {
        "%" .. searchQuery .. "%",
        "%" .. searchQuery .. "%",
        "%" .. searchQuery .. "%"
      }
    end
  end
  query = "SELECT COUNT(*) FROM players WHERE " .. whereClause
  local count = MySQL.scalar.await(query, params)
  totalCount = count or 0
  if searchQuery ~= "" then
    query = [[
      SELECT COUNT(DISTINCT players.citizenid)
      FROM mdt_profiles
      JOIN players ON players.citizenid = mdt_profiles.citizenid
      WHERE
    ]] .. whereClause
    local count = MySQL.scalar.await(query, params)
    totalCount = totalCount + (count or 0)
  end
  if searchQuery == "" then
    query = "SELECT id, citizenid, charinfo, photo, job FROM players LIMIT ? OFFSET ?"
    params = {limit, offset}
  else
    query = [[
      SELECT id, citizenid, charinfo, photo, job
      FROM (
        SELECT players.id, players.citizenid, players.charinfo, players.photo, players.job
        FROM players
        WHERE
    ]] .. whereClause .. [[
      )
      UNION
      SELECT players.id, players.citizenid, players.charinfo, players.photo, players.job
      FROM mdt_profiles
      JOIN players ON players.citizenid = mdt_profiles.citizenid
      WHERE
    ]] .. whereClause .. [[
    ) AS combined_results
    LIMIT ? OFFSET ?
    ]]
    params = {}
    for i = 1, #params do
      table.insert(params, "%" .. searchQuery .. "%")
    end
    table.insert(params, limit)
    table.insert(params, offset)
  end
  results = MySQL.query.await(query, params)
  for _, result in ipairs(results) do
    local charInfo, jobInfo, licenses, phoneNumber
    charInfo = json.decode(result.charinfo)
    jobInfo = json.decode(result.job)
    licenses = fetchLicenses(result.citizenid)
    phoneNumber = charInfo.phone or "Unknown"
    if GetPhoneNumber then
      local success, phoneNumberResult = pcall(GetPhoneNumber, result.citizenid)
      if success then
        phoneNumber = phoneNumberResult
      end
    end
    table.insert(results, {
      citizenid = result.citizenid,
      firstname = charInfo.firstname,
      surname = charInfo.lastname,
      gender = charInfo.gender == 1 and "Female" or "Male",
      nationality = type(charInfo.nationality) == "table" and charInfo.nationality.name or charInfo.nationality,
      photo = result.photo,
      bankAccount = charInfo.account,
      phoneNumber = phoneNumber,
      job = jobInfo.label,
      warrant = 0,
      isDangerous = 0,
      licenses = licenses or {},
      fingerprint = "Not Registered",
      dna = "Not Registered"
    })
    local mdtProfile = MySQL.query.await("SELECT warrant, fingerprint, dna, isDangerous FROM mdt_profiles WHERE citizenid = ?", {result.citizenid})
    if mdtProfile and mdtProfile[1] then
      results.warrant = mdtProfile[1].warrant or 0
      results.isDangerous = mdtProfile[1].isDangerous or 0
      results.fingerprint = mdtProfile[1].fingerprint or "Not Registered"
      results.dna = mdtProfile[1].dna or "Not Registered"
    end
  end
  return results, totalCount
end

function updateCitizenPhoto(photo, citizenId)
  local query = "UPDATE players SET photo = ? WHERE citizenid = ?"
  local params = {photo, citizenId}
  local result = MySQL.query.await(query, params)
  return result.affectedRows > 0
end

function checkCitizenIdInPlayers(citizenId)
  local query = "SELECT COUNT(*) as count FROM players WHERE citizenid = ?"
  local params = {citizenId}
  local result = MySQL.query.await(query, params)
  return result and result[1] and result[1].count > 0
end

function fetchBodycamPlayerCount(whereClause, params)
  local query = "SELECT COUNT(*) as count FROM mdt_units JOIN players ON mdt_units.citizenid = players.citizenid " .. whereClause
  local result = MySQL.query.await(query, params)
  return result and result[1] and result[1].count or 0
end

function fetchBodycamPlayersWithPagination(searchQuery, limit, offset)
  local whereClause, params
  whereClause = "WHERE mdt_units.citizenid = players.citizenid"
  params = {}
  if searchQuery ~= "" then
    whereClause = whereClause .. " AND (LOWER(JSON_UNQUOTE(JSON_EXTRACT(players.charinfo, \"$.firstname\"))) LIKE LOWER(?) OR LOWER(JSON_UNQUOTE(JSON_EXTRACT(players.charinfo, \"$.lastname\"))) LIKE LOWER(?) OR LOWER(players.citizenid) LIKE LOWER(?))"
    params = {
      "%" .. searchQuery .. "%",
      "%" .. searchQuery .. "%",
      "%" .. searchQuery .. "%"
    }
  end
  params = {table.unpack(params)}
  table.insert(params, limit)
  local query = [[
    SELECT
      mdt_units.citizenid,
      mdt_units.bodycam AS status,
      players.charinfo,
      players.job
    FROM mdt_units
    JOIN players ON mdt_units.citizenid = players.citizenid
  ]] .. whereClause .. [[
    ORDER BY
      CASE mdt_units.bodycam
        WHEN 'on' THEN 0
        WHEN 'off' THEN 1
        ELSE 2
      END,
      JSON_UNQUOTE(JSON_EXTRACT(players.charinfo, "$.firstname")) ASC
    LIMIT 10 OFFSET ?
  ]]
  local results = MySQL.query.await(query, params)
  local totalCount = fetchBodycamPlayerCount(whereClause, params)
  local formattedResults = {}
  for _, result in ipairs(results) do
    local charInfo, jobInfo
    charInfo = json.decode(result.charinfo)
    jobInfo = json.decode(result.job)
    table.insert(formattedResults, {
      citizenId = result.citizenid,
      name = (charInfo.firstname or "Unknown") .. " " .. (charInfo.lastname or ""),
      department = jobInfo.label or "Unknown",
      rank = jobInfo.grade and jobInfo.grade.name or "Unknown",
      status = result.status
    })
  end
  return formattedResults, totalCount
end

function fetchUnitCount(whereClause, params)
  local query = "SELECT COUNT(*) as count FROM mdt_units JOIN players ON mdt_units.citizenid = players.citizenid " .. whereClause
  local result = MySQL.query.await(query, params)
  return result and result[1] and result[1].count or 0
end

function fetchUnitData(searchTerm, offset)
    local query = "SELECT mdt_units.id, mdt_units.dutyRecords, mdt_units.tags, mdt_units.isFired, mdt_units.totalHours, mdt_units.status, players.citizenid, players.photo, players.charinfo, players.job, mdt_units.callsign FROM mdt_units JOIN players ON mdt_units.citizenid = players.citizenid "
    local params = {}
    if searchTerm ~= "" then
        query = query .. "WHERE (LOWER(JSON_UNQUOTE(JSON_EXTRACT(players.charinfo, \"$.firstname\"))) LIKE LOWER(?) OR LOWER(JSON_UNQUOTE(JSON_EXTRACT(players.charinfo, \"$.lastname\"))) LIKE LOWER(?) OR LOWER(players.citizenid) LIKE LOWER(?)) "
        table.insert(params, "%" .. searchTerm .. "%")
        table.insert(params, "%" .. searchTerm .. "%")
        table.insert(params, "%" .. searchTerm .. "%")
    end
    query = query .. "LIMIT 10 OFFSET ?"
    table.insert(params, offset)
    local results = MySQL.query.await(query, params)
    if not results then
        results = {}
    end
    local units = {}
    for _, row in ipairs(results) do
        local charInfo = json.decode(row.charinfo or "{}")
        local jobInfo = json.decode(row.job or "{}")
        local dutyRecords = json.decode(row.dutyRecords or "[]")
        if #dutyRecords > 10 then
            dutyRecords = {}
            for i = #dutyRecords - 9, #dutyRecords do
                table.insert(dutyRecords, dutyRecords[i])
            end
        end
        local unit = {
            id = row.id,
            citizenId = row.citizenid,
            name = (charInfo.firstname or "Unknown") .. " " .. (charInfo.lastname or ""),
            rank = jobInfo.grade and jobInfo.grade.name or "Unknown",
            department = jobInfo.label or "Unknown",
            tags = row.tags,
            status = row.status,
            isFired = row.isFired or 0,
            photo = row.photo,
            totalDutyHours = row.totalHours,
            callsign = row.callsign,
            dutyRecords = dutyRecords
        }
        table.insert(units, unit)
    end
    local count = fetchUnitCount(query, params)
    return units, count
end

function fetchWarrantsWithPlayers(limit, offset)
    local query = [[
        SELECT 
            warrants.id AS warrant_id,
            warrants.expiryDate AS expiryDate,
            warrants.issueDate AS issueDate,
            warrants.status AS status,
            JSON_UNQUOTE(JSON_EXTRACT(players.charinfo, "$.firstname")) AS player_firstname,
            JSON_UNQUOTE(JSON_EXTRACT(players.charinfo, "$.lastname")) AS player_lastname
        FROM 
            mdt_warrants AS warrants
        JOIN 
            players AS players 
        ON 
            warrants.suspectId = players.citizenid
        WHERE 
            warrants.status = 'active'
        LIMIT ? OFFSET ?;
    ]]
    local params = {limit, offset}
    local results = MySQL.query.await(query, params)
    if not results then
        results = {}
    end
    local warrants = {}
    for _, row in ipairs(results) do
        local warrant = {
            id = row.warrant_id,
            expiryDate = row.expiryDate,
            issueDate = row.issueDate,
            status = row.status,
            name = (row.player_firstname or "Unknown") .. " " .. (row.player_lastname or "")
        }
        table.insert(warrants, warrant)
    end
    return warrants
end

function fetchWantedVehiclesWithPlayers(searchTerm, limit, offset)
    local query = [[
        SELECT 
            player_vehicles.plate AS plate,
            player_vehicles.vehicle AS vehicle,
            COALESCE(mdt_vehicles.status, 'Unknown') AS status,
            player_vehicles.citizenid AS citizenid
        FROM 
            player_vehicles
        LEFT JOIN 
            mdt_vehicles 
        ON 
            mdt_vehicles.plate = player_vehicles.plate
        WHERE
            mdt_vehicles.status = 'bolo'
    ]]
    local params = {}
    if searchTerm ~= "" then
        query = query .. " AND (LOWER(player_vehicles.plate) LIKE LOWER(?) OR LOWER(player_vehicles.citizenid) LIKE LOWER(?)) "
        table.insert(params, "%" .. searchTerm .. "%")
        table.insert(params, "%" .. searchTerm .. "%")
    end
    query = query .. "LIMIT ? OFFSET ?"
    table.insert(params, limit)
    table.insert(params, offset)
    local results = MySQL.query.await(query, params)
    if not results then
        results = {}
    end
    local vehicles = {}
    for _, row in ipairs(results) do
        local owner = GetOfflinePlayerByCitizenId(row.citizenid)
        if owner then
            owner = owner.name
        else
            owner = "Unknown"
        end
        local vehicle = {
            plate = row.plate,
            status = row.status,
            model = GetHashKey(row.vehicle),
            owner = owner,
            citizenid = row.citizenid
        }
        table.insert(vehicles, vehicle)
    end
    return vehicles
end

function GetVehicleOwner(plate)
    local query = "SELECT plate, citizenid, id FROM player_vehicles WHERE plate = @plate"
    local params = {["@plate"] = plate}
    local results = MySQL.query.await(query, params)
    if results and results[1] then
        local owner = GetOfflinePlayerByCitizenId(results[1].citizenid)
        if owner then
            return owner.name
        end
    end
    return false
end

function fetchVehicleByPlate(plate)
    local query = [[
        SELECT 
            player_vehicles.plate AS plate,
            player_vehicles.vehicle AS vehicle,
            COALESCE(mdt_vehicles.status, 'Unknown') AS status,
            player_vehicles.citizenid AS citizenid,
            mdt_vehicles.sightings AS sightings,
            mdt_vehicles.photo AS photo
        FROM player_vehicles
        LEFT JOIN mdt_vehicles 
            ON mdt_vehicles.plate = player_vehicles.plate
        WHERE player_vehicles.plate = ?
    ]]
    local params = {plate}
    local results = MySQL.query.await(query, params)
    if results and results[1] then
        local owner = GetOfflinePlayerByCitizenId(results[1].citizenid)
        if owner then
            owner = owner.name
        else
            owner = "Unknown"
        end
        local vehicle = {
            plate = results[1].plate,
            status = results[1].status,
            model = GetHashKey(results[1].vehicle),
            owner = owner,
            citizenid = results[1].citizenid,
            sightings = results[1].sightings,
            photo = results[1].photo
        }
        return vehicle
    end
    return nil
end

function fetchVehiclesFromPlayerTable(searchTerm, limit, offset)
    local query = [[
        SELECT 
            player_vehicles.plate AS plate,
            player_vehicles.vehicle AS vehicle,
            COALESCE(mdt_vehicles.status, 'Unknown') AS status,
            player_vehicles.citizenid AS citizenid
        FROM 
            player_vehicles
        LEFT JOIN 
            mdt_vehicles 
        ON 
            mdt_vehicles.plate = player_vehicles.plate
    ]]
    local params = {}
    if searchTerm ~= "" then
        query = query .. " WHERE (LOWER(player_vehicles.plate) LIKE LOWER(?) OR LOWER(player_vehicles.citizenid) LIKE LOWER(?)) "
        table.insert(params, "%" .. searchTerm .. "%")
        table.insert(params, "%" .. searchTerm .. "%")
    end
    query = query .. "LIMIT ? OFFSET ?"
    table.insert(params, limit)
    table.insert(params, offset)
    local results = MySQL.query.await(query, params)
    if not results then
        results = {}
    end
    local vehicles = {}
    for _, row in ipairs(results) do
        local owner = GetOfflinePlayerByCitizenId(row.citizenid)
        if owner then
            owner = owner.name
        else
            owner = "Unknown"
        end
        local vehicle = {
            plate = row.plate,
            status = row.status,
            model = GetHashKey(row.vehicle),
            owner = owner,
            citizenid = row.citizenid
        }
        table.insert(vehicles, vehicle)
    end
    return vehicles
end

function countVehiclesFromPlayerTable(searchTerm)
    local query = "SELECT COUNT(*) AS count FROM player_vehicles "
    local params = {}
    if searchTerm ~= "" then
        query = query .. "WHERE (LOWER(player_vehicles.plate) LIKE LOWER(?) OR LOWER(player_vehicles.citizenid) LIKE LOWER(?)) "
        table.insert(params, "%" .. searchTerm .. "%")
        table.insert(params, "%" .. searchTerm .. "%")
    end
    local results = MySQL.query.await(query, params)
    if results and results[1] then
        return results[1].count or 0
    end
    return 0
end

function fetchUnitCount(query, params)
    local countQuery = "SELECT COUNT(*) AS count FROM (" .. query .. ") AS subquery"
    local countParams = params
    local results = MySQL.query.await(countQuery, countParams)
    if results and results[1] then
        return results[1].count or 0
    end
    return 0
end

function fetchWarrantsFromPlayers(searchTerm, status, limit, offset)
    local conditions = {}
    local params = {}
    if searchTerm and searchTerm ~= "" then
        table.insert(conditions, "(LOWER(JSON_UNQUOTE(JSON_EXTRACT(players.charinfo, '$.firstname'))) LIKE LOWER(?) OR LOWER(JSON_UNQUOTE(JSON_EXTRACT(players.charinfo, '$.lastname'))) LIKE LOWER(?) OR LOWER(players.citizenid) LIKE LOWER(?) OR warrants.id = ?")
        table.insert(params, "%" .. searchTerm .. "%")
        table.insert(params, "%" .. searchTerm .. "%")
        table.insert(params, "%" .. searchTerm .. "%")
        table.insert(params, searchTerm)
    end
    if status and status ~= "" then
        table.insert(conditions, "warrants.status = ?")
        table.insert(params, status)
    end
    local whereClause = ""
    if #conditions > 0 then
        whereClause = "WHERE " .. table.concat(conditions, " AND ")
    end
    local query = [[
        SELECT 
            warrants.id AS report_id,
            warrants.suspectId AS report_suspectId,
            warrants.charges AS report_charges,
            warrants.issueDate AS issueDate,
            warrants.issuingAuthority AS issuingAuthority,
            warrants.status AS status,
            players.photo AS photo,
            JSON_UNQUOTE(JSON_EXTRACT(players.charinfo, '$.firstname')) AS player_firstname,
            JSON_UNQUOTE(JSON_EXTRACT(players.charinfo, '$.lastname')) AS player_lastname,
            JSON_UNQUOTE(JSON_EXTRACT(players.charinfo, '$.birthdate')) AS player_birthdate,
            JSON_UNQUOTE(JSON_EXTRACT(players.charinfo, '$.nationality')) AS player_nationality
        FROM 
            mdt_warrants AS warrants
        JOIN 
            players AS players 
        ON 
            warrants.suspectId = players.citizenid
    ]] .. " " .. whereClause .. " LIMIT ? OFFSET ?"
    table.insert(params, limit)
    table.insert(params, offset)
    local results = MySQL.query.await(query, params)
    local warrants = {}
    for _, result in ipairs(results) do
        local warrant = {}
        warrant.id = result.report_id
        warrant.charges = result.report_charges
        warrant.issueDate = result.issueDate
        warrant.issuingAuthority = result.issuingAuthority or ""
        warrant.status = result.status
        warrant.photo = result.photo
        warrant.name = result.player_firstname .. " " .. result.player_lastname
        warrant.birthdate = result.player_birthdate
        warrant.nationality = result.player_nationality
        warrant.isDangerous = isDangerous(result.report_suspectId)
        table.insert(warrants, warrant)
    end
    return warrants
end

function countWarrantsFromPlayers(searchTerm, status)
    local conditions = {}
    local params = {}
    if searchTerm and searchTerm ~= "" then
        table.insert(conditions, "(LOWER(JSON_UNQUOTE(JSON_EXTRACT(players.charinfo, '$.firstname'))) LIKE LOWER(?) OR LOWER(JSON_UNQUOTE(JSON_EXTRACT(players.charinfo, '$.lastname'))) LIKE LOWER(?) OR LOWER(players.citizenid) LIKE LOWER(?) OR warrants.id = ?")
        table.insert(params, "%" .. searchTerm .. "%")
        table.insert(params, "%" .. searchTerm .. "%")
        table.insert(params, "%" .. searchTerm .. "%")
        table.insert(params, searchTerm)
    end
    if status and status ~= "" then
        table.insert(conditions, "warrants.status = ?")
        table.insert(params, status)
    end
    local whereClause = ""
    if #conditions > 0 then
        whereClause = "WHERE " .. table.concat(conditions, " AND ")
    end
    local query = [[
        SELECT COUNT(*) AS count
        FROM mdt_warrants AS warrants
        JOIN players AS players
        ON warrants.suspectId = players.citizenid
    ]] .. " " .. whereClause
    local results = MySQL.query.await(query, params)
    return results[1] and results[1].count or 0
end

function fetchCitizenVehiclesFromTable(citizenId)
    local query = [[
        SELECT 
            player_vehicles.plate AS plate,
            player_vehicles.vehicle AS vehicle,
            COALESCE(mdt_vehicles.status, 'Unknown') AS status,
            player_vehicles.citizenid AS citizenid
        FROM 
            player_vehicles
        LEFT JOIN 
            mdt_vehicles 
        ON 
            mdt_vehicles.plate = player_vehicles.plate
        WHERE
            player_vehicles.citizenid = @citizenid
    ]]
    local params = { citizenid = citizenId }
    local results = MySQL.query.await(query, params)
    local vehicles = {}
    for _, result in ipairs(results) do
        local vehicle = {}
        vehicle.plate = result.plate
        vehicle.status = result.status
        vehicle.model = GetHashKey(result.vehicle)
        local player = GetOfflinePlayerByCitizenId(result.citizenid)
        vehicle.owner = player and player.name or "Unknown"
        vehicle.citizenid = result.citizenid
        vehicle.lastseen = "Unknown"
        if result.sightings and #result.sightings > 0 then
            vehicle.lastseen = result.sightings[#result.sightings].timestamp
        end
        table.insert(vehicles, vehicle)
    end
    return vehicles
end