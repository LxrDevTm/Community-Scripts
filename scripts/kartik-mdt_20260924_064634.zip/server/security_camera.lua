local registerCallback, saveVideoUrl, getPaginatedSecurityCameraVideos
registerCallback = lib.callback.register
saveVideoUrl = "kartik-mdt:server:saveVideoUrl"
function saveVideo(data)
  if data then
    local id = data.id
    local url = data.url
    local type = data.type
    if "bodycam" == type then
      local query = "INSERT INTO mdt_bodycams (citizenid, videoURL) VALUES (?, ?)"
      local params = {id, url}
      MySQL.query.await(query, params)
    else
      local camera = Config.Cameras[id]
      if camera then
        local query = "INSERT INTO mdt_cameras (cameraId, videoURL) VALUES (?, ?)"
        local params = {id, url}
        MySQL.query.await(query, params)
      end
    end
  else
    return nil
  end
end
registerCallback(saveVideoUrl, saveVideo)

registerCallback = lib.callback.register
getPaginatedSecurityCameraVideos = "kartik-mdt:server:getPaginatedSecurityCameraVideos"
function getPaginatedSecurityCameraVideos(data)
  if data then
    local id = data.id
    local page = data.page
    local perPage = data.perPage
    local offset = (page - 1) * perPage
    local query = "SELECT * FROM mdt_cameras WHERE cameraId = ? LIMIT ? OFFSET ?"
    local params = {id, perPage, offset}
    local videos = MySQL.query.await(query, params)
    local countQuery = "SELECT COUNT(*) AS count FROM mdt_cameras WHERE cameraId = ?"
    local countParams = {id}
    local count = MySQL.query.await(countQuery, countParams)[1].count
    if videos then
      local result = {}
      result.success = true
      result.videos = videos
      result.totalCount = count
      return result
    else
      local result = {}
      result.success = false
      result.totalCount = count
      return result
    end
  else
    return nil
  end
end
registerCallback(getPaginatedSecurityCameraVideos, getPaginatedSecurityCameraVideos)