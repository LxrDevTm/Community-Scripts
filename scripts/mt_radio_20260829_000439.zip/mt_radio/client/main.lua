-- Looking for more free scripts? Check out our community : https://lxrdev.com/Community/free-scripts

local config = Config and Config.Client or {}
local sharedConfig = Config and Config.Shared or {}

local radioMenu = false
local isPowered = false
local isConnected = false
local isTransmitting = false
local radioChannel = 0
local radioVolume = config.defaultVolume or 50
local radioProps = {}
local micClicks = config.defaultMicClicks or true
local activeRadioSlot
local activeRadioMetadata = {}

local function getPlayerData()
    return exports['mt_core']:GetPlayerData() or {}
end

local function isPoliceRadioJob(pData)
    pData = pData or getPlayerData()
    if not pData or not pData.job then return false end

    local jobName = (pData.job.name or ""):lower()
    local jobType = (pData.job.type or ""):lower()
    local jobGrade = (pData.job.grade and (pData.job.grade.level or pData.job.grade)) or 0
    local policeJobs = Config and Config.PoliceRadioJobs or {}
    local minGrade = policeJobs[jobName]

    if jobType == "leo" or jobName == "police" or jobName == "sheriff" or jobName == "military" or jobName == "army" or jobName == "state" or jobName == "bcso" or jobName == "sast" or jobName == "doc" then
        if pData.job.onduty == false then
            return false
        end
        return true
    end

    if minGrade ~= nil and (tonumber(jobGrade) or 0) >= minGrade then
        if pData.job.onduty == false then
            return false
        end
        return true
    end

    return false
end

local function radioMemory()
    return {
        favorites = type(activeRadioMetadata.radioFavorites) == 'table' and activeRadioMetadata.radioFavorites or {},
        recent = type(activeRadioMetadata.radioRecent) == 'table' and activeRadioMetadata.radioRecent or {}
    }
end

local function formattedChannel(channel)
    return string.format('%.' .. (config.decimalPlaces or 2) .. 'f', channel or 0)
end

local function uiState()
    local memory = radioMemory()
    return {
        type = 'state',
        powered = isPowered,
        connected = isConnected,
        transmitting = isTransmitting,
        channel = formattedChannel(radioChannel),
        volume = radioVolume,
        micClicks = micClicks,
        minFrequency = config.minFrequency or 1,
        maxFrequency = config.maxFrequency or 999.99,
        decimalPlaces = config.decimalPlaces or 2,
        favorites = memory.favorites,
        recent = memory.recent
    }
end

local function pushUiState()
    SendNUIMessage(uiState())
end

local function notify(message, kind)
    exports.mt_core:Notify(message, kind)
end

local function hasRestrictedAccess(channel)
    if not sharedConfig or not sharedConfig.restrictedChannels then return true end
    local frequency = sharedConfig.whitelistSubChannels and channel or math.floor(channel)
    local jobs = sharedConfig.restrictedChannels[frequency]
    if not jobs then return true end

    local pData = getPlayerData()
    local job = pData and pData.job
    return job and jobs[job.name] == true and (job.onduty == true or job.onduty == nil)
end

local function validateChannel(value)
    local channel = tonumber(value)
    if not channel or channel ~= channel then
        return nil, 'invalid'
    end

    local dec = config.decimalPlaces or 2
    local mult = 10 ^ dec
    channel = math.floor(channel * mult + 0.5) / mult

    if channel < (config.minFrequency or 1) or channel > (config.maxFrequency or 999.99) then
        return nil, 'invalid'
    end

    if not hasRestrictedAccess(channel) then
        return nil, 'restricted'
    end

    return channel
end

local function leaveChannel(silent)
    if isConnected and not silent then
        notify('Left radio channel', 'error')
    end

    radioChannel = 0
    isConnected = false
    isTransmitting = false
    exports['pma-voice']:setRadioChannel(0)
    exports['pma-voice']:setVoiceProperty('radioEnabled', false)
    pushUiState()
end

local function connectToRadio(channel, method)
    radioChannel = channel
    isConnected = true
    exports['pma-voice']:setRadioChannel(channel)
    exports['pma-voice']:setVoiceProperty('radioEnabled', true)
    notify('Joined radio channel: ' .. formattedChannel(channel) .. ' MHz', 'success')
    pushUiState()
    return {
        ok = true,
        action = method or 'dial',
        state = uiState()
    }
end

local function setRadioOpen(open)
    if open and isPoliceRadioJob() then
        TriggerEvent("projectpx35_toggleradio")
        return
    end

    radioMenu = open
    SetNuiFocus(open, open)
    TriggerServerEvent('mt_radio:server:setHoldingRadio', open)
    pcall(function()
        if GetResourceState('mt_interface') == 'started' then
            exports.mt_interface:pushHud(open, false)
        end
    end)

    if open then
        pcall(function()
            RequestAnimDict('cellphone@')
            TaskPlayAnim(PlayerPedId(), 'cellphone@', 'cellphone_text_read_base', 2.0, 2.0, -1, 51, 0.0, false, false, false)
        end)
        SendNUIMessage({ type = 'open', state = uiState() })
    else
        ClearPedTasks(PlayerPedId())
        SendNUIMessage({ type = 'close' })
    end
end

local function setPower(powered)
    isPowered = powered
    if not isPowered then
        leaveChannel(true)
    else
        exports['pma-voice']:setVoiceProperty('radioEnabled', true)
        exports['pma-voice']:setRadioVolume(radioVolume)
    end
    pushUiState()
end

local function cleanupRadioProp(serverId)
    if not radioProps[serverId] then return end
    SetEntityAsMissionEntity(radioProps[serverId], true, true)
    DeleteEntity(radioProps[serverId])
    radioProps[serverId] = nil
end

AddStateBagChangeHandler('isHoldingRadio', '', function(bagName, _, value, _, replicated)
    if replicated then return end

    local player = GetPlayerFromStateBagName(bagName)
    if not player then return end

    local serverId = GetPlayerServerId(player)
    if not value then
        cleanupRadioProp(serverId)
        return
    end

    local model = GetHashKey('prop_cs_hand_radio')
    if not IsModelInCdimage(model) then return end
    RequestModel(model)

    local ped = GetPlayerPed(player)
    if not ped or ped <= 0 then return end

    local coords = GetEntityCoords(ped)
    radioProps[serverId] = CreateObject(model, coords.x, coords.y, coords.z, false, false, false)
    AttachEntityToEntity(radioProps[serverId], ped, GetPedBoneIndex(ped, 28422), -0.01, 0.0, 0.0, 0.0, 0.0, 0.0, true, true, false, true, 1, true)
    SetModelAsNoLongerNeeded(model)
end)

AddEventHandler('pma-voice:radioActive', function(active)
    isTransmitting = active == true
    if radioMenu then pushUiState() end
end)

RegisterNetEvent('pma-voice:radioChangeRejected', function()
    radioChannel = 0
    isConnected = false
    isTransmitting = false
    notify('Restricted channel', 'error')
    pushUiState()
end)

RegisterNetEvent('onPlayerDropped', function(serverId)
    cleanupRadioProp(serverId)
end)

AddEventHandler('onResourceStop', function(resource)
    if resource ~= GetCurrentResourceName() then return end
    SetNuiFocus(false, false)
    pcall(function()
        if GetResourceState('mt_interface') == 'started' then
            exports.mt_interface:pushHud(false, false)
        end
    end)
    for serverId in pairs(radioProps) do
        cleanupRadioProp(serverId)
    end
end)

exports('IsRadioOn', function()
    return isPowered
end)

exports('toggleRadio', function()
    setRadioOpen(not radioMenu)
end)

exports('openRadio', function()
    setRadioOpen(true)
end)

exports('closeRadio', function()
    setRadioOpen(false)
end)

RegisterCommand('radio', function()
    setRadioOpen(not radioMenu)
end, false)

RegisterNetEvent('QBCore:Client:OnPlayerLoaded', function()
    exports['pma-voice']:setVoiceProperty('micClicks', config.defaultMicClicks or true)
end)

RegisterNetEvent('QBCore:Client:OnPlayerUnload', function()
    if isConnected then leaveChannel(true) end
    isPowered = false
    if radioMenu then setRadioOpen(false) end
end)

AddEventHandler('mt_inventory:itemCount', function(itemName, totalCount)
    if (itemName ~= 'civilian_radio' and itemName ~= 'radio') or totalCount > 0 then return end
    if isConnected then leaveChannel(true) end
    isPowered = false
    if radioMenu then setRadioOpen(false) end
end)

local function onUseRadio(data, item)
    if isPoliceRadioJob() then
        TriggerEvent("projectpx35_toggleradio")
        return
    end

    item = item or data
    if type(item) == 'table' and item.slot then
        activeRadioSlot = tonumber(item.slot)
        activeRadioMetadata = type(item.metadata) == 'table' and item.metadata or {}
    else
        activeRadioSlot = nil
        activeRadioMetadata = {}
    end

    CreateThread(function()
        Wait(100)
        setRadioOpen(true)
    end)
end

RegisterNetEvent('mt_radio:client:use', onUseRadio)
RegisterNetEvent('mt_radio:useRadio', onUseRadio)
RegisterNetEvent('radio:toggle', onUseRadio)
RegisterNetEvent('qb-radio:use', onUseRadio)

RegisterNetEvent('mt_radio:client:onRadioDrop', function()
    if isConnected then leaveChannel(true) end
    isPowered = false
    if radioMenu then setRadioOpen(false) end
end)

RegisterNUICallback('joinRadio', function(data, cb)
    if not isPowered then
        cb({ ok = false, reason = 'power' })
        return
    end

    local channel, reason = validateChannel(data.channel)
    if not channel then
        notify(reason == 'restricted' and 'Restricted channel' or 'Invalid channel', 'error')
        cb({ ok = false, reason = reason })
        return
    end

    if isConnected and channel == radioChannel then
        notify('Already on this channel', 'error')
        cb({ ok = false, reason = 'same' })
        return
    end

    cb(connectToRadio(channel, data.method))
end)

RegisterNUICallback('leaveChannel', function(_, cb)
    if not isPowered or not isConnected then
        notify('Not on a channel', 'error')
        cb({ ok = false, reason = 'disconnected' })
        return
    end

    leaveChannel()
    cb({ ok = true, state = uiState() })
end)

RegisterNUICallback('setVolume', function(data, cb)
    if not isPowered then
        cb({ ok = false, reason = 'power' })
        return
    end

    radioVolume = math.min(100, math.max(5, tonumber(data.volume) or radioVolume))
    radioVolume = math.floor(radioVolume / 5 + 0.5) * 5
    exports['pma-voice']:setRadioVolume(radioVolume)
    pushUiState()
    cb({ ok = true, state = uiState() })
end)

RegisterNUICallback('updateMemory', function(data, cb)
    cb({ ok = true, memory = { favorites = {}, recent = {} } })
end)

RegisterNUICallback('stepChannel', function(data, cb)
    if not isPowered then
        cb({ ok = false, reason = 'power' })
        return
    end

    local direction = tonumber(data.direction) or 0
    local inputChannel = tonumber(data.channel)
    local startChannel = isConnected and radioChannel or inputChannel or (config.minFrequency or 1)
    local step = config.channelStep or 1
    local maxFreq = config.maxFrequency or 999.99
    local minFreq = config.minFrequency or 1

    local candidate = startChannel + (direction > 0 and step or -step)
    candidate = math.min(maxFreq, math.max(minFreq, candidate))
    local channel, reason = validateChannel(candidate)

    while not channel and reason == 'restricted' do
        candidate = candidate + (direction > 0 and step or -step)
        if candidate < minFreq or candidate > maxFreq then break end
        channel, reason = validateChannel(candidate)
    end

    if not channel or channel == radioChannel then
        cb({ ok = false, reason = reason or 'edge' })
        return
    end

    cb(connectToRadio(channel, 'scan'))
end)

RegisterNUICallback('toggleClicks', function(_, cb)
    if not isPowered then
        cb({ ok = false, reason = 'power' })
        return
    end

    micClicks = not micClicks
    exports['pma-voice']:setVoiceProperty('micClicks', micClicks)
    pushUiState()
    cb({ ok = true, state = uiState() })
end)

RegisterNUICallback('power', function(_, cb)
    setPower(not isPowered)
    cb({ ok = true, state = uiState() })
end)

RegisterNUICallback('escape', function(_, cb)
    setRadioOpen(false)
    cb({ ok = true })
end)

if config.leaveOnDeath then
    AddStateBagChangeHandler('isDead', ('player:%s'):format(GetPlayerServerId(PlayerId())), function(_, _, value)
        if value and isConnected then leaveChannel(true) end
    end)
end
