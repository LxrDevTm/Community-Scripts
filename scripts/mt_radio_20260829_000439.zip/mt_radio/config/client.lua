-- Looking for more free scripts? Check out our community : https://lxrdev.com/Community/free-scripts

Config = Config or {}

Config.Client = {
    maxFrequency = 999.99,
    minFrequency = 1,
    leaveOnDeath = true,
    decimalPlaces = 2,
    defaultMicClicks = true,
    defaultVolume = 50,
    channelStep = 1
}
