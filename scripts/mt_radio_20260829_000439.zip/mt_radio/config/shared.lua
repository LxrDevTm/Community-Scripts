-- Looking for more free scripts? Check out our community : https://lxrdev.com/Community/free-scripts

Config = Config or {}

-- Configured jobs and minimum grades allowed to use Police Radio (projectpx35_radio)
-- Format: ['job_name'] = min_grade (0 means all ranks/grades)
Config.PoliceRadioJobs = {
    ['police'] = 0,
    ['ambulance'] = 0,
    ['sheriff'] = 0,
    ['bcso'] = 0,
    ['sast'] = 0,
    ['military'] = 0,
    ['army'] = 0,
    ['state'] = 0,
    ['doc'] = 0,
}

Config.Shared = {
    whitelistSubChannels = false,
    restrictedChannels = {
        [1] = { police = true, ambulance = true, sheriff = true },
        [2] = { police = true, ambulance = true, sheriff = true },
        [3] = { police = true, ambulance = true, sheriff = true },
        [4] = { police = true, ambulance = true, sheriff = true },
        [5] = { police = true, ambulance = true, sheriff = true },
        [6] = { police = true, ambulance = true, sheriff = true },
        [7] = { police = true, ambulance = true, sheriff = true },
        [8] = { police = true, ambulance = true, sheriff = true },
        [9] = { police = true, ambulance = true, sheriff = true },
        [10] = { police = true, ambulance = true, sheriff = true }
    }
}
