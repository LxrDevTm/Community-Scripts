
fx_version 'cerulean'
game 'gta5'

name 'mt_radio'
author 'Shared By LxrDev'
description 'Shared By LxrDev'
version '2.0.0'

ox_lib 'locale'

shared_scripts {
    '@ox_lib/init.lua',
    '@mt_core/modules/lib.lua',
    'config/shared.lua'
}

client_scripts {
    'config/client.lua',
    '@mt_core/modules/playerdata.lua',
    'client/main.lua',
}

server_scripts {
    'server/main.lua'
}

ui_page 'html/index.html'

files {
    'html/index.html',
    'html/js/script.js',
    'html/css/style.css',
    'html/img/mt-wave-radio.png',
    'html/fonts/Nunito.ttf',
    'locales/*.json'
}

dependency 'pma-voice'

lua54 'yes'
use_experimental_fxv2_oal 'yes'
