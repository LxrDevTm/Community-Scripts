const stage = document.getElementById('radio-stage');
const radio = document.querySelector('.radio-wrap');
const channelInput = document.getElementById('channel-input');
const statusLabel = document.getElementById('status-label');
const channelLabel = document.getElementById('channel-label');
const connectButton = document.getElementById('connect-button');
const connectLabel = connectButton.querySelector('span');
const volumeValue = document.getElementById('volume-value');
const volumeFill = document.getElementById('volume-fill');
const clicksToggle = document.getElementById('clicks-toggle');
const recentList = document.getElementById('recent-list');
const favoritesList = document.getElementById('favorites-list');
const favoritesEmpty = document.getElementById('favorites-empty');
const favoriteCount = document.getElementById('favorite-count');
const favoriteLabel = document.getElementById('favorite-label');
const favoriteCurrent = document.getElementById('favorite-current');
const clockElement = document.getElementById('clock');
const resourceName = typeof GetParentResourceName === 'function' ? GetParentResourceName() : 'mt_radio';
const isPreview = typeof GetParentResourceName !== 'function';

let activePage = 'main';
let state = {
    powered: false,
    connected: false,
    transmitting: false,
    channel: '100.00',
    volume: 50,
    micClicks: true,
    minFrequency: 1,
    maxFrequency: 999.99,
    decimalPlaces: 2,
    recent: [],
    favorites: []
};

function pressFeedback() {
    radio.classList.add('button-press');
    window.setTimeout(() => radio.classList.remove('button-press'), 90);
}

async function post(endpoint, payload = {}) {
    if (isPreview) return previewResponse(endpoint, payload);
    const response = await fetch(`https://${resourceName}/${endpoint}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json; charset=UTF-8' },
        body: JSON.stringify(payload)
    });
    return response.json();
}

function previewResponse(endpoint, payload) {
    if (endpoint === 'power') {
        state.powered = !state.powered;
        if (!state.powered) {
            state.connected = false;
            state.transmitting = false;
        }
    } else if (endpoint === 'joinRadio') {
        state.powered = true;
        state.connected = true;
        state.channel = Number(payload.channel || 100).toFixed(state.decimalPlaces);
    } else if (endpoint === 'leaveChannel') {
        state.connected = false;
    } else if (endpoint === 'toggleClicks') {
        state.micClicks = !state.micClicks;
    } else if (endpoint === 'setVolume') {
        state.volume = payload.volume;
    } else if (endpoint === 'stepChannel') {
        state.connected = true;
        state.channel = (Number(state.channel) + payload.direction).toFixed(state.decimalPlaces);
    } else if (endpoint === 'updateMemory') {
        const frequency = Number(payload.frequency).toFixed(state.decimalPlaces);
        if (payload.action === 'remember') {
            state.recent = [{ frequency: Number(frequency) }, ...state.recent.filter((entry) => Number(entry.frequency) !== Number(frequency))].slice(0, 3);
        } else if (payload.action === 'favorite') {
            const entry = { label: payload.label || `RADIO ${state.favorites.length + 1}`, frequency: Number(frequency) };
            state.favorites = [entry, ...state.favorites.filter((saved) => Number(saved.frequency) !== Number(frequency))].slice(0, 6);
        } else if (payload.action === 'remove') {
            state.favorites = state.favorites.filter((entry) => Number(entry.frequency) !== Number(frequency));
        }
        render(state);
        return Promise.resolve({ ok: true, memory: { recent: state.recent, favorites: state.favorites } });
    }

    render(state);
    return Promise.resolve({ ok: true, state });
}

function applyState(nextState) {
    if (!nextState) return;
    state = { ...state, ...nextState };
    state.recent = Array.isArray(state.recent) ? state.recent : [];
    state.favorites = Array.isArray(state.favorites) ? state.favorites : [];
    render(state);
}

function showPage(page) {
    activePage = page;
    document.getElementById('main-page').classList.toggle('active', page === 'main');
    document.getElementById('favorites-page').classList.toggle('active', page === 'favorites');
}

function createTuneButton(entry, favorite = false) {
    const frequency = Number(entry.frequency).toFixed(state.decimalPlaces);
    const row = document.createElement('div');
    row.className = 'memory-row';
    if (state.connected && Number(state.channel) === Number(entry.frequency)) row.classList.add('active');

    const tuneButton = document.createElement('button');
    tuneButton.type = 'button';
    tuneButton.className = 'memory-tune';
    tuneButton.disabled = !state.powered;

    const label = document.createElement('strong');
    label.textContent = favorite ? entry.label : `${frequency} MHz`;
    const detail = document.createElement('small');
    detail.textContent = favorite ? `${frequency} MHz` : 'TAP TO REJOIN';
    tuneButton.append(label, detail);
    tuneButton.addEventListener('click', () => tune(frequency, favorite ? 'favorite' : 'recent'));
    row.appendChild(tuneButton);

    if (favorite) {
        const removeButton = document.createElement('button');
        removeButton.type = 'button';
        removeButton.className = 'memory-remove';
        removeButton.setAttribute('aria-label', `Remove ${entry.label}`);
        removeButton.innerHTML = '<svg viewBox="0 0 24 24"><path d="M6 6l12 12M18 6 6 18"/></svg>';
        removeButton.addEventListener('click', () => updateMemory('remove', { frequency: entry.frequency }));
        row.appendChild(removeButton);
    }

    return row;
}

function renderMemory() {
    recentList.replaceChildren();
    state.recent.slice(0, 3).forEach((entry) => recentList.appendChild(createTuneButton(entry)));
    if (!state.recent.length) {
        const empty = document.createElement('span');
        empty.className = 'memory-empty';
        empty.textContent = 'NO RECENT CHANNELS';
        recentList.appendChild(empty);
    }

    favoritesList.replaceChildren();
    state.favorites.slice(0, 6).forEach((entry) => favoritesList.appendChild(createTuneButton(entry, true)));
    favoritesEmpty.hidden = state.favorites.length > 0;
    favoriteCount.textContent = `${state.favorites.length}/6`;
}

function render(nextState) {
    radio.classList.toggle('powered', nextState.powered);
    radio.classList.toggle('connected', nextState.connected);
    radio.classList.toggle('transmitting', nextState.transmitting);
    clicksToggle.classList.toggle('enabled', nextState.micClicks);
    channelInput.disabled = !nextState.powered;

    document.querySelectorAll('.device button').forEach((button) => {
        const alwaysAvailable = button.id === 'power-button' || button.id === 'close-hotspot' || button.id === 'favorites-back';
        button.disabled = !alwaysAvailable && !nextState.powered;
    });

    if (document.activeElement !== channelInput) {
        channelInput.value = nextState.connected ? nextState.channel : channelInput.value || '100.00';
    }

    const memoryFrequency = Number(channelInput.value) || Number(nextState.channel) || nextState.minFrequency;
    favoriteCurrent.textContent = `SAVE ${memoryFrequency.toFixed(nextState.decimalPlaces)} MHz`;
    volumeValue.textContent = `${nextState.volume}%`;
    volumeFill.style.width = `${nextState.volume}%`;

    if (nextState.transmitting) {
        statusLabel.lastChild.textContent = ' TRANSMITTING';
        channelLabel.textContent = 'VOICE LINK ACTIVE';
    } else if (nextState.connected) {
        statusLabel.lastChild.textContent = ' CONNECTED';
        channelLabel.textContent = 'CHANNEL LOCKED';
    } else if (nextState.powered) {
        statusLabel.lastChild.textContent = ' STANDBY';
        channelLabel.textContent = 'READY TO TUNE';
    } else {
        statusLabel.lastChild.textContent = ' OFFLINE';
        channelLabel.textContent = 'RADIO OFF';
    }

    connectLabel.textContent = nextState.connected ? 'LEAVE' : 'CONNECT';
    renderMemory();
}

function deny() {
    radio.classList.remove('shake');
    void radio.offsetWidth;
    radio.classList.add('shake');
}

async function updateMemory(action, payload) {
    const response = await post('updateMemory', { action, ...payload });
    if (!response.ok || !response.memory) {
        deny();
        return false;
    }

    applyState({
        recent: response.memory.recent,
        favorites: response.memory.favorites
    });
    return true;
}

async function tune(value, method = 'dial') {
    if (!state.powered) {
        deny();
        return;
    }

    const numeric = Number(String(value).replace(',', '.'));
    if (!Number.isFinite(numeric) || numeric < state.minFrequency || numeric > state.maxFrequency) {
        deny();
        channelInput.select();
        return;
    }

    const response = await post('joinRadio', { channel: numeric, method });
    if (!response.ok) {
        deny();
        return;
    }

    applyState(response.state);
    await updateMemory('remember', { frequency: numeric });
}

async function toggleConnection() {
    if (state.connected) {
        const response = await post('leaveChannel');
        if (response.ok) applyState(response.state);
        else deny();
        return;
    }
    tune(channelInput.value);
}

async function changeVolume(delta) {
    const target = Math.min(100, Math.max(5, state.volume + delta));
    if (target === state.volume) {
        deny();
        return;
    }
    const response = await post('setVolume', { volume: target });
    if (response.ok) {
        applyState(response.state);
        pressFeedback();
    } else {
        deny();
    }
}

async function stepChannel(direction) {
    const response = await post('stepChannel', { direction, channel: channelInput.value });
    if (response.ok) {
        applyState(response.state);
        await updateMemory('remember', { frequency: response.state.channel });
    } else {
        deny();
    }
}

async function toggleClicks() {
    const response = await post('toggleClicks');
    if (response.ok) applyState(response.state);
    else deny();
}

document.getElementById('power-button').addEventListener('click', async () => {
    const response = await post('power');
    applyState(response.state);
    pressFeedback();
});
connectButton.addEventListener('click', toggleConnection);
document.getElementById('join-hotspot').addEventListener('click', toggleConnection);
document.getElementById('volume-up').addEventListener('click', () => changeVolume(5));
document.getElementById('volume-down').addEventListener('click', () => changeVolume(-5));
document.getElementById('channel-up').addEventListener('click', () => stepChannel(1));
document.getElementById('channel-down').addEventListener('click', () => stepChannel(-1));
document.getElementById('clicks-button').addEventListener('click', toggleClicks);
document.getElementById('mute-hotspot').addEventListener('click', toggleClicks);
document.getElementById('open-favorites').addEventListener('click', () => showPage('favorites'));
document.getElementById('favorites-back').addEventListener('click', () => showPage('main'));
document.getElementById('save-favorite').addEventListener('click', async () => {
    const frequency = Number(channelInput.value) || Number(state.channel);
    const label = favoriteLabel.value.trim();
    if (!label || !Number.isFinite(frequency)) {
        deny();
        favoriteLabel.focus();
        return;
    }
    if (await updateMemory('favorite', { frequency, label })) favoriteLabel.value = '';
});
document.getElementById('close-hotspot').addEventListener('click', () => {
    post('escape');
    closeRadio();
});

channelInput.addEventListener('input', () => {
    channelInput.value = channelInput.value.replace(/[^0-9.,]/g, '').replace(',', '.');
    const frequency = Number(channelInput.value);
    if (Number.isFinite(frequency)) favoriteCurrent.textContent = `SAVE ${frequency.toFixed(state.decimalPlaces)} MHz`;
});
channelInput.addEventListener('focus', () => channelInput.select());

document.addEventListener('keyup', (event) => {
    if (event.key === 'Escape') {
        if (activePage === 'favorites') showPage('main');
        else {
            post('escape');
            closeRadio();
        }
    }
    if (event.key === 'Enter' && document.activeElement !== favoriteLabel) toggleConnection();
    if (event.key === 'ArrowUp' && document.activeElement !== favoriteLabel) stepChannel(1);
    if (event.key === 'ArrowDown' && document.activeElement !== favoriteLabel) stepChannel(-1);
});

function openRadio(nextState) {
    if (nextState) applyState(nextState);
    showPage('main');
    stage.classList.add('visible');
    stage.setAttribute('aria-hidden', 'false');
    requestAnimationFrame(() => stage.classList.add('open'));
}

function closeRadio() {
    stage.classList.remove('open');
    stage.setAttribute('aria-hidden', 'true');
    window.setTimeout(() => stage.classList.remove('visible'), 280);
}

window.addEventListener('message', (event) => {
    if (event.data.type === 'open') openRadio(event.data.state);
    if (event.data.type === 'close') closeRadio();
    if (event.data.type === 'state') applyState(event.data);
});

function updateClock() {
    const now = new Date();
    clockElement.textContent = now.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' });
}

updateClock();
window.setInterval(updateClock, 15000);
render(state);
if (isPreview) {
    openRadio({
        ...state,
        powered: true,
        connected: true,
        channel: '200.00',
        recent: [{ frequency: 200 }, { frequency: 146.5 }, { frequency: 88.75 }],
        favorites: [{ label: 'CREW', frequency: 200 }, { label: 'GARAGE', frequency: 146.5 }]
    });
}
