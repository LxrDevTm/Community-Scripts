-- Looking for more free scripts? Check out our community : https://lxrdev.com/Community/free-scripts

local MTCore = nil
pcall(function() MTCore = exports['qb-core']:GetCoreObject() end)
if not MTCore then pcall(function() MTCore = exports['mt_core']:GetCoreObject() end) end

local function useRadio(source, item)
    TriggerClientEvent('mt_radio:client:use', source, item or {}, item or {})
end

MTCore.Functions.CreateUseableItem('radio', function(source, item)
    useRadio(source, item)
end)

MTCore.Functions.CreateUseableItem('civilian_radio', function(source, item)
    useRadio(source, item)
end)

pcall(function()
    if exports['mt_inventory'] and exports['mt_inventory'].RegisterUsableItem then
        exports['mt_inventory']:RegisterUsableItem('radio', useRadio)
        exports['mt_inventory']:RegisterUsableItem('civilian_radio', useRadio)
    end
end)

RegisterNetEvent('mt_radio:server:setRadioChannel', function(channel)
    local src = source
    Player(src).state:set('radioChannel', channel, true)
end)

RegisterNetEvent('mt_radio:server:setHoldingRadio', function(holding)
    local src = source
    Player(src).state:set('isHoldingRadio', holding, true)
end)
