-- alpr.lua

local alprOpen        = false   -- whether ALPR UI is visible
local speedLockThresh = 80      -- speed lock threshold
local alprActive      = false   -- whether the ALPR scanning loop is running
local boloList        = {}      -- synced BOLO plates from server
local lastScannedPlate = nil    -- plate currently in the ALPR camera
local lockedPlate      = "UNKNOWN"
local lockedAt         = 0      -- GetGameTimer() when lock was acquired
local isScanning       = false  -- true while waiting for bolo check result
local scanStartTime    = 0      -- GetGameTimer() when scan began
local nextAlertAllowed = 0      -- cooldown: earliest timer value for next alert sound

-- Valid ALPR sizes, cycled with the size command
local alprSizes    = { "normal", "small", "large" }
local alprSizeIdx  = 1

-- ─── Speed unit helpers ───────────────────────────────────────────────────────

function GetSpeedUnitLabel()
    local unit = tostring(Config.SpeedUnit or "kmh"):lower()
    return (unit == "mph") and "MPH" or "KM/H"
end

function GetSpeedMultiplier()
    local unit = tostring(Config.SpeedUnit or "kmh"):lower()
    return (unit == "mph") and 2.236936 or 3.6
end

function GetVehicleSpeedConverted(vehicle)
    return math.floor(GetEntitySpeed(vehicle) * GetSpeedMultiplier())
end

-- ─── BOLO sync ───────────────────────────────────────────────────────────────

RegisterNetEvent("plt_departments:client:SyncBolos", function(bolos)
    boloList = bolos
end)

-- ─── Authorized vehicle check ────────────────────────────────────────────────
-- Returns true when the local player is on-duty in an authorized dept AND
-- is sitting in a vehicle that is listed in DepartmentData for their dept.

function IsInAuthorizedALPRVehicle()
    local playerData = Framework.GetPlayerData()
    if not playerData then return false end

    if not (LocalPlayerJob and LocalPlayerJob.onDuty) then return false end

    local playerDept = (LocalPlayerJob and LocalPlayerJob.dept) or "none"
    local playerJob  = (playerData.job and playerData.job.name) or "none"

    local ped     = PlayerPedId()
    local vehicle = GetVehiclePedIsIn(ped, false)
    if not vehicle or vehicle == 0 then return false end

    local vehicleModel = GetEntityModel(vehicle)

    if not (DepartmentData and DepartmentData.nodes) then return false end

    for _, node in ipairs(DepartmentData.nodes) do
        if node.type == "vehicle" or node.type == "helipad" then
            local deptId = GetDepartmentForNode(node.id, DepartmentData)
            if deptId then
                local frameworkJob = GetFrameworkJobFromNodeId(deptId)

                -- Check: framework job match OR dept number match
                local jobMatch  = tostring(deptId) == tostring(playerDept)
                if not jobMatch and LocalPlayerJob.dept ~= "none" then
                    jobMatch = tostring(LocalPlayerJob.dept) == tostring(deptId)
                end

                if jobMatch and node.vehicles then
                    for _, entry in ipairs(node.vehicles) do
                        if entry.model and entry.model ~= "" then
                            local hash = (type(entry.model) == "string")
                                and GetHashKey(entry.model)
                                or entry.model
                            if hash == vehicleModel then
                                return true
                            end
                        end
                    end
                end
            end
        end
    end

    return false
end

-- ─── Raycast: vehicle ahead ───────────────────────────────────────────────────
-- Fires a 50 m forward ray from the player vehicle; returns hit vehicle or nil.

function GetVehicleInFront(vehicle)
    local origin  = GetEntityCoords(vehicle)
    local forward = GetOffsetFromEntityInWorldCoords(vehicle, 0.0, 50.0, 0.0)

    local ray = StartShapeTestRay(
        origin.x, origin.y, origin.z,
        forward.x, forward.y, forward.z,
        10, vehicle, 0
    )

    local _, hit, _, _, hitEntity = GetShapeTestResult(ray)

    if hit == 1 and IsEntityAVehicle(hitEntity) then
        return hitEntity
    end
    return nil
end

-- ─── Toggle / configure ALPR command ─────────────────────────────────────────

function ToggleALPR(arg)
    -- Validate dept
    if not (LocalPlayerJob and LocalPlayerJob.dept and LocalPlayerJob.dept ~= "none") then
        return
    end

    local ped     = PlayerPedId()
    local vehicle = GetVehiclePedIsIn(ped, false)

    if not vehicle or vehicle == 0 then
        Framework.Notify(T("alpr_vehicle_required"), "error")
        return
    end

    -- Validate authorized vehicle
    if not IsInAuthorizedALPRVehicle() then
        local msg
        if not (LocalPlayerJob and LocalPlayerJob.onDuty) then
            msg = "You must be ON DUTY to use ALPR systems!"
        elseif GetVehiclePedIsIn(PlayerPedId(), false) == 0 then
            msg = T("alpr_vehicle_required")
        else
            msg = "This vehicle is not equipped with ALPR systems!"
        end
        Framework.Notify(msg, "error")
        return
    end

    -- Numeric arg → set speed lock
    if arg then
        local numericArg = tonumber(arg)
        if numericArg then
            speedLockThresh = numericArg
            if not alprActive then
                alprActive = true
                alprOpen   = true
            end
            SendNUIMessage({
                action    = "openALPR",
                speedLock = speedLockThresh,
                speedUnit = GetSpeedUnitLabel(),
            })
            Framework.Notify(T("alpr_speed_set", { speed = numericArg, unit = GetSpeedUnitLabel() }), "success")
            return
        end

        -- Size arg → set display size
        local sizeArg = arg:lower()
        if sizeArg == "small" or sizeArg == "normal" or sizeArg == "large" then
            if not alprActive then
                alprActive = true
                alprOpen   = true
            end
            SendNUIMessage({ action = "setAlprSize", size = sizeArg })
            Framework.Notify(T("alpr_size_set", { size = sizeArg:upper() }), "success")
            return
        end
    end

    -- Plain toggle
    alprOpen = not alprOpen
    if alprOpen then
        alprActive = true
        SendNUIMessage({
            action    = "openALPR",
            speedLock = speedLockThresh,
            speedUnit = GetSpeedUnitLabel(),
        })
    else
        alprActive = false
        SetNuiFocus(false, false)
        SendNUIMessage({ action = "closeALPR" })
    end
end

-- ─── Chat suggestion ──────────────────────────────────────────────────────────

CreateThread(function()
    Wait(1000)
    local cmd = Config.OfficerCommands.alpr or "alpr"
    TriggerEvent("chat:addSuggestion", "/" .. cmd, "Toggle ALPR or Configure (Optional: [speed/size])", {
        { name = "parameter", help = "Speed (e.g. 80) or Size (small/normal/large)" },
    })
end)

-- ─── Commands ────────────────────────────────────────────────────────────────

RegisterCommand(Config.OfficerCommands.alprsize or "alprsize", function()
    if not alprActive then
        Framework.Notify(T("alpr_must_be_active"), "error")
        return
    end
    alprSizeIdx = alprSizeIdx + 1
    if alprSizeIdx > #alprSizes then alprSizeIdx = 1 end

    local size = alprSizes[alprSizeIdx]
    SendNUIMessage({ action = "setAlprSize", size = size })
    Framework.Notify(T("alpr_size_msg", { size = size:upper() }), "primary")
end, false)

RegisterCommand(Config.OfficerCommands.alpr or "alpr", function(source, args)
    ToggleALPR(args[1])
end, false)

RegisterCommand("!alpr_toggle", function()
    ToggleALPR()
end, false)

RegisterKeyMapping("!alpr_toggle", "Toggle ALPR System", "keyboard", "F11")

-- ─── NUI callbacks ───────────────────────────────────────────────────────────

RegisterNUICallback("setSpeedLock", function(data, cb)
    speedLockThresh = tonumber(data.speed)
    cb("ok")
end)

RegisterNUICallback("closeALPR", function(data, cb)
    alprOpen   = false
    alprActive = false
    SetNuiFocus(false, false)
    cb("ok")
end)

RegisterNUICallback("closeAlprMove", function(data, cb)
    SetNuiFocus(false, false)
    cb("ok")
end)

-- ─── Main ALPR scanning loop ──────────────────────────────────────────────────

CreateThread(function()
    while true do
        local tickInterval = 1000

        if alprActive then
            tickInterval = 200

            if IsInAuthorizedALPRVehicle() then
                local ped         = PlayerPedId()
                local myVehicle   = GetVehiclePedIsIn(ped, false)
                local mySpeed     = GetVehicleSpeedConverted(myVehicle)
                local targetVeh   = GetVehicleInFront(myVehicle)
                local targetSpeed = 0

                -- Lock logic: vehicle ahead → record plate + time
                if targetVeh then
                    targetSpeed = GetVehicleSpeedConverted(targetVeh)
                    local plate = GetVehicleNumberPlateText(targetVeh)
                    lockedPlate = plate

                    if targetSpeed > speedLockThresh then
                        lastScannedPlate = plate  -- ⚠️ overloaded: also used as locked plate for speed alert
                        lockedAt         = GetGameTimer()
                    end
                end

                -- Determine display plate and lock state
                local displayPlate  = lockedPlate
                local displayLocked = false
                if lastScannedPlate then
                    local elapsed = GetGameTimer() - lockedAt
                    if elapsed < 300000 then   -- lock persists 5 min
                        displayPlate  = lastScannedPlate
                        displayLocked = true
                    end
                end

                SendNUIMessage({
                    action      = "updateALPR",
                    mySpeed     = mySpeed,
                    targetSpeed = targetSpeed,
                    speedUnit   = GetSpeedUnitLabel(),
                    targetPlate = displayPlate,
                    isLocked    = displayLocked,
                })

                -- Bolo scanner: watch for new vehicles entering frame
                if targetVeh then
                    local rawPlate    = GetVehicleNumberPlateText(targetVeh)
                    local cleanPlate  = rawPlate:gsub("%s+", "")

                    if lastScannedPlate ~= cleanPlate then
                        -- New vehicle: reset and begin scan timer
                        lastScannedPlate = cleanPlate
                        scanStartTime    = GetGameTimer()
                        isScanning       = true
                        SendNUIMessage({ action = "updateBoloScanner", plate = rawPlate, status = "SCANNING" })
                    elseif isScanning then
                        local scanElapsed = GetGameTimer() - scanStartTime
                        if scanElapsed >= 5000 then
                            isScanning = false
                            if Framework and Framework.TriggerCallback then
                                Framework.TriggerCallback("plt_departments:server:checkBolo", function(isBolo)
                                    -- Play alert sound on hit, with 10-second cooldown
                                    if isBolo then
                                        local now = GetGameTimer()
                                        if now > nextAlertAllowed then
                                            PlaySoundFrontend(-1, "BASE_JUMP_PASSED", "HUD_AWARDS", 1)
                                            nextAlertAllowed = now + 10000
                                        end
                                    end

                                    SendNUIMessage({
                                        action = "updateBoloScanner",
                                        plate  = rawPlate,
                                        isBolo = isBolo,
                                        status = isBolo and "WANTED" or "CLEAR",
                                    })
                                end, rawPlate)
                            end
                        end
                    end
                else
                    -- No vehicle in frame: reset scanner
                    if lastScannedPlate ~= nil then
                        lastScannedPlate = nil
                        isScanning       = false
                        SendNUIMessage({ action = "updateBoloScanner", plate = nil, isBolo = false, status = "READY" })
                    end
                end
            else
                -- No longer in an authorized vehicle: force-close ALPR
                alprActive = false
                alprOpen   = false
                SetNuiFocus(false, false)
                SendNUIMessage({ action = "closeALPR" })
            end
        end

        Wait(tickInterval)
    end
end)
