-- ============================================================
--  plt_departments  |  client/breathalyzer.lua  (refactored)
-- ============================================================

local FINGER_ANIM_DICT = "mp_player_int_upperfinger"
local FINGER_ANIM_CLIP = "mp_player_int_upperfinger"

local DRINK_ANIM_DICT  = "amb@world_human_drinking@coffee@male@base"
local DRINK_ANIM_CLIP  = "base"

-- Load an animation dictionary, waiting until it is ready
local function LoadAnimDict(dict)
    RequestAnimDict(dict)
    while not HasAnimDictLoaded(dict) do
        Wait(0)
    end
end

-- Stop the finger-raise animation on the local ped
local function StopFingerAnim()
    StopAnimTask(PlayerPedId(), FINGER_ANIM_DICT, FINGER_ANIM_CLIP, 1.0)
end


-- ============================================================
--  Net events
-- ============================================================

-- Officer uses breathalyzer: find nearest player and request a breath test
RegisterNetEvent("plt_departments:client:useBreathalyzer")
AddEventHandler("plt_departments:client:useBreathalyzer", function()
    local playerId, distance = Framework.GetClosestPlayer()

    if playerId ~= -1 and distance < 2.0 then
        local serverId = GetPlayerServerId(playerId)
        TriggerServerEvent("plt_departments:server:requestBreathTest", serverId)
        Framework.Notify("Requesting breath test from nearest person...", "primary")
    else
        Framework.Notify("No one nearby!", "error")
    end
end)

-- Open the breathalyzer UI; play blow animation if this client is the subject
RegisterNetEvent("plt_departments:client:startBreathTest")
AddEventHandler("plt_departments:client:startBreathTest", function(officerId, isSubject)
    SetNuiFocus(isSubject, isSubject)
    SendNUIMessage({ action = "openBreathalyzer", officerId = officerId, isPlayer = isSubject })

    if isSubject then
        local ped = PlayerPedId()
        LoadAnimDict(FINGER_ANIM_DICT)
        TaskPlayAnim(ped, FINGER_ANIM_DICT, FINGER_ANIM_CLIP,
            8.0, -8.0, -1, 49, 0, false, false, false)
    end
end)

-- Sync breath-test progress bar to the officer's UI
RegisterNetEvent("plt_departments:client:updateBreathProgress")
AddEventHandler("plt_departments:client:updateBreathProgress", function(progress, indicatorPos)
    SendNUIMessage({ action = "syncBreathProgress", progress = progress, indicatorPos = indicatorPos })
end)

-- Show the final breath-test result in the officer's UI
RegisterNetEvent("plt_departments:client:breathTestResult")
AddEventHandler("plt_departments:client:breathTestResult", function(result, targetName)
    SendNUIMessage({ action = "showBreathResult", result = result, targetName = targetName })
end)

-- Play drinking animation and drunk-cam shake on the subject
RegisterNetEvent("plt_departments:client:consumeAlcohol")
AddEventHandler("plt_departments:client:consumeAlcohol", function()
    local ped = PlayerPedId()

    LoadAnimDict(DRINK_ANIM_DICT)
    TaskPlayAnim(ped, DRINK_ANIM_DICT, DRINK_ANIM_CLIP,
        8.0, 8.0, 5000, 49, 0, false, false, false)

    Wait(5000)
    StopAnimTask(ped, DRINK_ANIM_DICT, DRINK_ANIM_CLIP, 1.0)

    ShakeGameplayCam("DRUNK_SHAKE", 1.0)
    SetTimeout(30000, function()
        StopGameplayCamShaking(true)
    end)
end)


-- ============================================================
--  NUI callbacks
-- ============================================================

-- Subject blowing into the breathalyzer: forward progress to server
RegisterNUICallback("syncBreathProgress", function(data, cb)
    TriggerServerEvent("plt_departments:server:syncBreathProgress",
        data.officerId, data.progress, data.indicatorPos)
    cb("ok")
end)

-- Breathalyzer minigame complete: send result to server, stop animation
RegisterNUICallback("breathalyzerComplete", function(data, cb)
    SetNuiFocus(false, false)

    local officerId = data.officerId
    local bac = 0.0
    if data.success then
        bac = math.random(0, 25) / 100
    end

    TriggerServerEvent("plt_departments:server:sendBreathResult", officerId, bac)
    StopFingerAnim()
    cb("ok")
end)

-- Close the breathalyzer UI without a result
RegisterNUICallback("closeBreathalyzer", function(data, cb)
    SetNuiFocus(false, false)
    StopFingerAnim()
    cb("ok")
end)