-- cameras.lua (refactored)
-- Handles surveillance camera viewing: scripted cam creation, pan/tilt/zoom, and teardown.

local isCameraActive = false
local scriptCam      = nil
local activeCamData  = nil  -- the camera node data currently being viewed

-- ─── Camera Teardown ─────────────────────────────────────────────────────────

function ExitSurveillanceFeed()
    if not isCameraActive then return end
    isCameraActive = false

    RenderScriptCams(false, false, 0, true, true)

    if scriptCam then
        DestroyCam(scriptCam, false)
        scriptCam = nil
    end

    ClearFocus()
    SetFocusEntity(PlayerPedId())
    DisplayHud(true)
    DisplayRadar(true)
    SendNUIMessage({ action = "hideCameraOverlay" })

    -- ⚠️ Clears inventory stash — tightly coupled to qb-inventory.
    TriggerEvent("qb-inventory:client:SetCurrentStash", nil)

    Framework.Notify("Exited surveillance feed.", "primary")
end

-- ─── Camera Activation ───────────────────────────────────────────────────────

RegisterNetEvent("plt_departments:client:ViewCamera")
AddEventHandler("plt_departments:client:ViewCamera", function(camData)
    if isCameraActive then ExitSurveillanceFeed() end

    activeCamData  = camData
    isCameraActive = true

    local coords  = camData.coords
    local heading = camData.heading or 0.0
    local label   = camData.label   or "Unknown Camera"

    DisplayHud(false)
    DisplayRadar(false)
    SendNUIMessage({ action = "showCameraOverlay", label = label })

    SetFocusPosAndVel(coords.x, coords.y, coords.z, 0.0, 0.0, 0.0)

    scriptCam = CreateCam("DEFAULT_SCRIPTED_CAMERA", true)
    SetCamCoord(scriptCam, coords.x, coords.y, coords.z + 1.5)
    SetCamRot(scriptCam, -20.0, 0.0, heading, 2)
    SetCamFov(scriptCam, 60.0)
    RenderScriptCams(true, false, 0, true, true)

    -- Input / pan-tilt-zoom loop
    CreateThread(function()
        while isCameraActive do
            DisableAllControlActions(0)
            EnableControlAction(0, 1,   true)   -- look left/right
            EnableControlAction(0, 2,   true)   -- look up/down
            EnableControlAction(0, 15,  true)   -- scroll wheel up (zoom in)
            EnableControlAction(0, 16,  true)   -- scroll wheel down (zoom out)
            EnableControlAction(0, 177, true)   -- back/cancel
            EnableControlAction(0, 202, true)   -- escape

            -- Pan / tilt
            local rot   = GetCamRot(scriptCam, 2)
            local yawDelta   = GetDisabledControlNormal(0, 1) * -5.0
            local pitchDelta = GetDisabledControlNormal(0, 2) * -5.0

            if yawDelta ~= 0.0 or pitchDelta ~= 0.0 then
                local newPitch = math.max(-70.0, math.min(20.0, rot.x + pitchDelta))
                local newYaw   = rot.z + yawDelta
                SetCamRot(scriptCam, newPitch, 0.0, newYaw, 2)
            end

            -- Zoom
            local fov = GetCamFov(scriptCam)
            if IsControlPressed(0, 15) or IsDisabledControlPressed(0, 15) then
                SetCamFov(scriptCam, math.max(10.0, fov - 1.0))
            elseif IsControlPressed(0, 16) or IsDisabledControlPressed(0, 16) then
                SetCamFov(scriptCam, math.min(100.0, fov + 1.0))
            end

            -- Exit on back / escape
            if IsControlJustPressed(0, 177) or IsControlJustPressed(0, 202) then
                ExitSurveillanceFeed()
            end

            Wait(0)
        end
    end)

    -- Scanline / timecycle effect loop
    CreateThread(function()
        while isCameraActive do
            SetTimecycleModifier("scanline_cam_cheap")
            SetTimecycleModifierStrength(1.5)
            SendNUIMessage({ action = "updateCameraTime" })
            Wait(1000)
        end
        ClearTimecycleModifier()
    end)
end)

-- ─── NUI Callback: view a specific camera by node + index ────────────────────

RegisterNUICallback("viewCamera", function(data, cb)
    local nodeId   = data and data.nodeId
    local camIndex = tonumber(data and data.camIndex)

    if not nodeId or camIndex == nil then
        cb("ok")
        return
    end

    -- Resolve the node either via PLTClientNodes helper or by scanning DepartmentData
    local node = nil
    if PLTClientNodes and PLTClientNodes.GetNodeById then
        node = PLTClientNodes.GetNodeById(nodeId, DepartmentData)
    elseif DepartmentData and DepartmentData.nodes then
        for _, n in ipairs(DepartmentData.nodes) do
            if tostring(n.id) == tostring(nodeId) then
                node = n
                break
            end
        end
    end

    local cameraSlot = math.floor(camIndex) + 1   -- NUI sends 0-based index

    -- Validate node type and camera slot existence
    if not node or node.type ~= "camera" or not (node.cameras and node.cameras[cameraSlot]) then
        cb("ok")
        return
    end

    -- Department ownership check
    local nodeDept   = tostring(GetDepartmentForNode(node.id, DepartmentData))
    local playerDept = tostring(LocalPlayerJob and LocalPlayerJob.dept)
    if nodeDept ~= playerDept then
        cb("ok")
        return
    end

    local camEntry = node.cameras[cameraSlot]
    if not camEntry.coords then
        cb("ok")
        return
    end

    -- Build heading: prefer coords.h, fall back to 0.0
    local heading = (camEntry.coords and camEntry.coords.h) or 0.0

    -- Default label
    local label = camEntry.label or ("Camera " .. tostring(cameraSlot))

    TriggerEvent("plt_departments:client:ViewCamera", {
        coords  = camEntry.coords,
        label   = label,
        heading = heading,
    })

    cb("ok")
end)
