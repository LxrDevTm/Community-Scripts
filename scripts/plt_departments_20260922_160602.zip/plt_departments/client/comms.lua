-- ============================================================
--  plt_departments  |  client/comms.lua  (refactored)
-- ============================================================

RegisterNetEvent("plt_departments:client:receiveDeptComms")
AddEventHandler("plt_departments:client:receiveDeptComms", function(messages, dept1, dept2)
    SendNUIMessage({
        action   = "receiveDeptComms",
        messages = messages,
        dept1    = dept1,
        dept2    = dept2,
    })
end)

RegisterNUICallback("sendDeptMessage", function(data, cb)
    TriggerServerEvent("plt_departments:server:sendDeptMessage", data)
    cb("ok")
end)

RegisterNUICallback("getDeptComms", function(data, cb)
    Framework.TriggerCallback("plt_departments:server:getDeptComms", function(result)
        cb(result)
    end, data)
end)

RegisterNUICallback("getAllDepts", function(data, cb)
    Framework.TriggerCallback("plt_departments:server:getAllDepts", function(result)
        cb(result)
    end)
end)