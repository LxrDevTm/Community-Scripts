local activeCalls = {}

-- Export: returns the current active dispatch call list
exports("GetActiveCalls", function()
    return activeCalls
end)

-- Export: add a new dispatch call, broadcast to all clients, cap list at 100
exports("CreateDispatchCall", function(callData)
    if not callData or not callData.code then return end

    -- Generate a unique ID if none provided
    if not callData.id then
        callData.id = tostring(os.time()) .. math.random(100, 999)
    end

    callData.timestamp = os.time()
    callData.time = callData.time or os.date("%H:%M")

    table.insert(activeCalls, callData)

    -- Keep the list from growing unbounded
    if #activeCalls > 100 then
        table.remove(activeCalls, 1)
    end

    TriggerClientEvent("plt_departments:client:addDispatchCall", -1, callData)
    TriggerEvent("plt_departments:server:OnDispatchCall", callData)
end)

-- Net event: a client requests a new dispatch call be created
-- ⚠️ PLTServerNodes and MemberData are external globals — BuildDispatchCallForSource may enrich the callData with location/unit info
RegisterNetEvent("plt_departments:server:createDispatchCall")
AddEventHandler("plt_departments:server:createDispatchCall", function(callData)
    local playerId = source
    local finalCallData = callData

    if playerId and playerId > 0 then
        if PLTServerNodes and PLTServerNodes.BuildDispatchCallForSource then
            local enriched = PLTServerNodes.BuildDispatchCallForSource(playerId, callData, MemberData)
            if not enriched then return end
            finalCallData = enriched
        end
    end

    exports.plt_departments:CreateDispatchCall(finalCallData)
end)
