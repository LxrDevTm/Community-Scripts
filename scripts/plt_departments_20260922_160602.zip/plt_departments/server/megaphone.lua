-- Register megaphone item — tells the client to toggle megaphone mode
CreateThread(function()
    Wait(1500)
    Framework.RegisterUsableItem("megaphone", function(playerId, itemData)
        local player = Framework.GetPlayer(playerId)
        if not player then return end
        TriggerClientEvent("plt_departments:client:toggleMegaphone", playerId)
    end)
end)
